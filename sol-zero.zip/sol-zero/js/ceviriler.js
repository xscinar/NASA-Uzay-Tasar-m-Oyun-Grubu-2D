/* SOL ZERO · çeviri verisi (en / de / es). Türkçe metin anahtar olarak kullanılır. */
const I18N_DATA = {
  en: {
    Donanım: "Equipment",
    "Roketteki alet sandığından <b>çapayı</b> al": "Take the <b>hoe</b> from the rocket's tool chest",
    "Roketin yanında <b>E</b> ile gir → makine dairesi → <b>ALET SANDIĞI</b> → <b>E</b> → Çapa: <b>Al</b>.":
      "Next to the rocket press <b>E</b> to enter → engine room → <b>TOOL CHEST</b> → <b>E</b> → Hoe: <b>Take</b>.",
    Toplayıcı: "Gatherer",
    "Etrafa saçılmış <b>5 metal numune</b> topla": "Collect <b>5 metal samples</b> scattered around",
    "Haritadaki ◆ işaretlerine yürü, numunenin yanında <b>F</b>'ye bas.":
      "Walk to the ◆ markers on the map and press <b>F</b> next to a sample.",
    Çiftçi: "Farmer",
    "Toprağı kaz ve <b>tohum ek</b>": "Dig the soil and <b>plant a seed</b>",
    "Dışarıda yere <b>sol tıkla</b> (kaz), çukurun yanında <b>F</b> ile ek. Tohum alet sandığında.":
      "Outside, <b>left-click</b> the ground (dig), then plant with <b>F</b> next to the hole. Seeds are in the tool chest.",
    Susuzluk: "Thirst",
    "Bir şişe <b>su iç</b>": "<b>Drink</b> a bottle of water",
    "Su şişesini eline al (alttaki numara tuşu), sonra <b>F</b>'ye bas. Ya da roketteki <b>mutfakta</b> <b>İç</b>.":
      "Hold the water bottle (number key at the bottom), then press <b>F</b>. Or <b>Drink</b> in the rocket's <b>kitchen</b>.",
    "İlk Rapor": "First Report",
    "Dünya'ya <b>ilk raporunu gönder</b>": "<b>Send your first report</b> to Earth",
    "Komuta güvertesi → solda <b>İLETİŞİM</b> masası → <b>E</b> → <b>Rapor hazırla</b> → gözlem seç, not yaz → <b>Dünya'ya gönder</b>.":
      "Command deck → <b>COMMS</b> desk on the left → <b>E</b> → <b>Prepare report</b> → select observations, write a note → <b>Send to Earth</b>.",
    Sığınak: "Safe Harbour",
    "Kum fırtınasını <b>roketin içinde atlat</b>": "<b>Ride out a sandstorm inside the rocket</b>",
    "İlk fırtına <b>2. gün</b> gelir. Turuncu uyarı kartı çıkınca 45 sn içinde rokete gir ve fırtına bitene kadar içeride kal.":
      "The first storm arrives on <b>day 2</b>. When the orange warning card appears, enter the rocket within 45 s and stay inside until the storm ends.",
    Mühendis: "Engineer",
    "Kum fırtınasından sonra <b>ana motoru onar</b>": "<b>Repair the main engine</b> after the sandstorm",
    "2. gün gelen fırtına motoru bozar. Makine dairesi → <b>ANA MOTOR</b> → <b>E</b> → 4 aşamayı tamamla.":
      "The storm on day 2 breaks the engine. Engine room → <b>MAIN ENGINE</b> → <b>E</b> → complete all 4 stages.",
    Kalkan: "Shelter",
    "Radyasyon dalgasını <b>roketin içinde atlat</b>": "<b>Ride out a radiation wave inside the rocket</b>",
    "İlk dalga <b>3. günün</b> başında gelir. Yeşil uyarı kartı çıkınca rokete gir; en kolayı uyku kabininde uyumak.":
      "The first wave arrives at the start of <b>day 3</b>. When the green warning card appears, enter the rocket; the easiest way is to sleep in the sleeping cabin.",
    Hasatçı: "Harvester",
    "Patatesi büyüt ve <b>hasat et</b>": "Grow a potato and <b>harvest it</b>",
    "Parseli <b>F</b> ile sula (hızlandırır). Halka sarı olunca <b>F</b> ile hasat et.":
      "Water the plot with <b>F</b> (speeds it up). When the ring turns yellow, harvest with <b>F</b>.",
    Haberleşme: "Correspondence",
    "Dünya'nın raporuna verdiği <b>resmî yanıtı oku</b>": "<b>Read Earth's official reply</b> to your report",
    "Yanıt raporundan ~½ sol sonra gelir (ACİL: ~¼ sol). İletişim terminali → <b>Gelen kutusu</b> → YANIT etiketli mesajı aç.":
      "The reply arrives ~½ sol after your report (URGENT: ~¼ sol). Communications terminal → <b>Inbox</b> → open the message tagged REPLY.",
    "Çürük Kargo": "Rotten Cargo",
    "Çürük patatesi <b>kargoyla Dünya'ya gönder</b>": "Send the rotten potato <b>to Earth by cargo</b>",
    "Radyasyonu yüksek toprağa ekilen patates çürük çıkar. Çürük patatesi rokete götür → komuta güvertesi → <b>Kargo terminali</b> → <b>Dünya'ya gönder</b>.":
      "Potatoes planted in high-radiation soil come out rotten. Take the rotten potato to the rocket → command deck → <b>Cargo terminal</b> → <b>Send to Earth</b>.",
    "Dünya'nın Cevabı": "Earth's Reply",
    "Dünya'dan gelen <b>analiz mesajını</b> oku": "Read the <b>analysis message</b> from Earth",
    "Kargo ulaşınca Dünya kısa süre içinde cevap yazar. İletişim terminali → <b>Gelen kutusu</b> → ANALİZ etiketli mesaj.":
      "Once the cargo arrives, Earth replies shortly. Comms terminal → <b>Inbox</b> → message tagged ANALYSIS.",
    Ölçüm: "Measurement",
    "Radyasyon ölçerle <b>3 farklı yerde</b> toprağı ölç":
      "Measure the soil in <b>3 different places</b> with the radiation meter",
    "Roketteki <b>alet sandığından</b> radyasyon ölçeri al. Dışarıda eline al (numara tuşu) ve toprağa <b>sol tıkla</b>. Her ölçüm yere renkli bir bayrak diker.":
      "Take the radiation meter from the rocket's <b>tool chest</b>. Outside, hold it (number key) and <b>left-click</b> the soil. Each measurement plants a coloured flag.",
    "Temiz Toprak": "Clean Soil",
    "Güvenli toprağa ek ve <b>sağlıklı hasat</b> al": "Plant in safe soil and get a <b>healthy harvest</b>",
    "<b>1,0 µSv/h</b> altında ölçülen (yeşil bayraklı) yere kaz, tohum ek, sula ve hasat et.":
      "Dig where you measured below <b>1.0 µSv/h</b> (green flag), plant a seed, water it and harvest.",
    "Altın Avcısı": "Gold Hunter",
    "Meteor kraterlerinden <b>3 altın parçası</b> topla":
      "Collect <b>3 gold fragments</b> from meteor craters",
    "Meteor düştükten sonra kraterin çevresinde parlayan sarı parçaları ara, yanında <b>F</b>'ye bas.":
      "After a meteor falls, look for the glittering yellow fragments around the crater and press <b>F</b> next to them.",
    Jeolog: "Geologist",
    "Uzak bölgelerde <b>bilinmeyen bir taş</b> çıkar": "Extract <b>an unknown stone</b> in a remote area",
    "Alet sandığından <b>jeolog kazmasını</b> al. Tarayıcı bip sesi verince haritadaki <b>?</b> işaretine git ve taşı <b>F</b> ile kır.":
      "Take the <b>geologist's pickaxe</b> from the tool chest. When the scanner beeps, go to the <b>?</b> marker on the map and break the stone with <b>F</b>.",
    "Numune Analizi": "Sample Analysis",
    "Bilinmeyen taşı <b>analiz için Dünya'ya gönder</b>":
      "Send the unknown stone <b>to Earth for analysis</b>",
    "Komuta güvertesi → <b>Kargo terminali</b> → ANALİZ İÇİN satırında <b>Analize gönder</b>.":
      "Command deck → <b>Cargo terminal</b> → on the FOR ANALYSIS row, <b>Send for analysis</b>.",
    Terzi: "Tailor",
    "Fabrikasyon atölyesinde <b>yeni bir kıyafet</b> üret":
      "Build <b>a new suit</b> in the Fabrication Workshop",
    "Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b> → Kıyafet setleri → <b>Kaşif Mk-I</b> → Üret ve giy (4 metal).":
      "Living deck → <b>FABRICATION WORKSHOP</b> → <b>E</b> → Suit sets → <b>Explorer Mk-I</b> → Build and wear (4 metal).",
    "Radyasyon Zırhı": "Radiation Armour",
    "Radyasyona dayanıklı <b>Öncü Mk-II</b> kıyafetini üret":
      "Build the radiation-resistant <b>Pioneer Mk-II</b> suit",
    "Fabrikasyon atölyesi → Kıyafet setleri → <b>Öncü Mk-II</b> (radyasyon hasarı %40 azalır).":
      "Fabrication workshop → Suit sets → <b>Pioneer Mk-II</b> (radiation damage −40%).",
    "Zırh Ustası": "Armour Smith",
    "Rokete <b>Titanyum Plakalar</b> zırhını tak": "Fit the <b>Titanium Plates</b> armour to the rocket",
    "Fabrikasyon atölyesi → <b>Roket geliştirme</b> → Titanyum Plakalar (fırtınada arıza olasılığı %60 → %35).":
      "Fabrication workshop → <b>Rocket upgrades</b> → Titanium Plates (storm failure chance 60% → 35%).",
    Kargo: "Cargo",
    "Roketin kargosuna <b>10 numune</b> yükle": "Load <b>10 samples</b> into the rocket's cargo hold",
    "Metal = 1, ⭐ yıldız = 2 numune. Roketin yanında <b>F</b>'ye bas.":
      "Metal = 1, ⭐ star = 2 samples. Press <b>F</b> next to the rocket.",
    "Eve Dönüş": "Homecoming",
    "Roketle <b>Dünya'ya dön</b>": "<b>Return to Earth</b> by rocket",
    "Komuta güvertesi (en üst kat) → <b>NAVİGASYON</b> → <b>E</b> → <b>EVE DÖN</b>.":
      "Command deck (top floor) → <b>NAVIGATION</b> → <b>E</b> → <b>GO HOME</b>.",
    Dünya: "Earth",
    Mars: "Mars",
    "Son kayıt: ": "Last save: ",
    görev: "mission",
    " · Gün ": " · Day ",
    "Kayıtlı görev yok": "No saved missions",
    '<div class="empty-note">Henüz kayıt yok.</div>': '<div class="empty-note">No saves yet.</div>',
    Yükle: "Load",
    Sil: "Delete",
    "Kayıt yüklendi": "Save loaded",
    "Kayıt ": "Save ",
    "💾 Otomatik kaydedildi": "💾 Autosaved",
    "💾 Kaydedildi": "💾 Saved",
    "MAKİNE DAİRESİ": "ENGINE ROOM",
    "YAŞAM GÜVERTESİ": "LIVING DECK",
    "KOMUTA GÜVERTESİ": "COMMAND DECK",
    "Hava kilidi": "Airlock",
    "<b>E</b>: Dışarı çık": "<b>E</b>: Go outside",
    "Alet sandığı": "Tool chest",
    "<b>E</b>: Alet sandığını aç": "<b>E</b>: Open tool chest",
    "O₂ tüpü": "O₂ tank",
    "<b>E</b>: Oksijen doldur": "<b>E</b>: Refill oxygen",
    "Ana motor": "Main engine",
    "<b>E</b>: Ana motoru onar": "<b>E</b>: Repair main engine",
    "Tamir tezgâhı": "Workbench",
    "<b>E</b>: Motor onarımı": "<b>E</b>: Engine repair",
    "Uyku kapsülü": "Sleep pod",
    "<b>E</b>: Yat / uyu (zaman 2×)": "<b>E</b>: Lie down / sleep (time 2×)",
    "Fabrikasyon atölyesi": "Fabrication workshop",
    "<b>E</b>: Atölye · kıyafet & roket geliştirme": "<b>E</b>: Workshop · suit & rocket upgrades",
    Mutfak: "Kitchen",
    "<b>E</b>: Mutfağı aç · <b>F</b>: hızlı ye/iç": "<b>E</b>: Open kitchen · <b>F</b>: quick eat/drink",
    Revir: "Sick bay",
    "<b>E</b>: Revir dolabını aç": "<b>E</b>: Open sick bay cabinet",
    "Yemek kapsülü": "Food capsule",
    "<b>E</b>: Yemek kapsülünü aç": "<b>E</b>: Open food capsule",
    "İletişim terminali": "Communications terminal",
    "<b>E</b>: Dünya iletişim terminali": "<b>E</b>: Earth communications terminal",
    Navigasyon: "Navigation",
    "<b>E</b>: Navigasyon bilgisayarı": "<b>E</b>: Navigation computer",
    "Kargo terminali": "Cargo terminal",
    "<b>E</b>: Kargo terminali": "<b>E</b>: Cargo terminal",
    "🚀 Roketin içindesin — <b>A/D</b> yürü · merdivende <b>W/S</b> · <b>E</b> kullan":
      "🚀 You're inside the rocket — <b>A/D</b> to walk · <b>W/S</b> on ladders · <b>E</b> to use",
    "Hava kilidinden çıktın": "You left through the airlock",
    "Yakında kullanılacak bir istasyon yok": "No station nearby",
    "Numuneleri komuta güvertesindeki <b>stok terminalinden</b> kargoya yükle":
      "Load samples into the cargo hold at the <b>stock terminal</b> on the command deck",
    "Çantanda numune yok — dışarıda metal ve ⭐ topla":
      "No samples in your bag — collect metal and ⭐ outside",
    " numune kargoya yüklendi · kargo ": " samples loaded into cargo · cargo ",
    "🍽️ Yemek kapsülü stoku: 💧": "🍽️ Food capsule stock: 💧",
    "Şu an aç ya da susuz değilsin": "You're not hungry or thirsty right now",
    "Yemek kapsülü boş — patates yetiştir, su geri dönüştürücüyü bekle":
      "Food capsule is empty — grow potatoes and wait for the water recycler",
    "Çapa sırtında — dışarıda yere <b>sol tıkla</b>, toprağı kaz":
      "Hoe on your back — outside, <b>left-click</b> the ground to dig",
    "Çapa alet sandığına bırakıldı": "Hoe put back in the tool chest",
    "Açlık/susuzluktan uyandın — mutfağa git": "You woke up from hunger/thirst — go to the kitchen",
    "🌅 Yeni güne uyandın": "🌅 You woke up to a new day",
    "😴 Uyuyorsun…": "😴 Sleeping…",
    "Gün ": "Day ",
    " · sabaha ": " · until morning ",
    " · zaman 2× hızlı": " · time 2× faster",
    "E: uyan": "E: wake up",
    CAN: "HEALTH",
    TOKLUK: "FOOD",
    SU: "WATER",
    "Uyuyorsun; oyun zamanı 2× hızlanıyor. Roket gövdesi radyasyonu keser.":
      "You're asleep; game time runs 2× faster. The rocket hull blocks radiation.",
    "☢️ Dışarıda radyasyon var. Roket içindeyken güvendesin.":
      "☢️ There is radiation outside. You're safe inside the rocket.",
    "Uyumak zamanı 2× hızlandırır: mahsul daha çabuk büyür, can hızla yenilenir. Sabah olunca kendiliğinden uyanırsın.":
      "Sleeping makes time pass 2× faster: crops grow quicker and health regenerates fast. You wake up automatically in the morning.",
    "☀️ Uyan": "☀️ Wake up",
    "🛌 Uyu": "🛌 Sleep",
    Uyandın: "You woke up",
    "Uyku başladı — zaman 2× hızlanıyor": "Sleep started — time runs 2× faster",
    "<b>E</b>: Oksijen doldur · giysi %": "<b>E</b>: Refill oxygen · suit %",
    " · tüp %": " · tank %",
    " öğe": " items",
    "<b>E</b>: İletişim terminali": "<b>E</b>: Communications terminal",
    " yeni mesaj": " new messages",
    " gözlem": " observations",
    " · <b>F</b>: numuneleri yükle": " · <b>F</b>: load samples",
    " — motor çalışıyor ✔": " — engine running ✔",
    "<b>E</b>: Ana motoru onar · aşama ": "<b>E</b>: Repair main engine · stage ",
    " · medikit ": " · medkits ",
    " · çanta ": " · bag ",
    " · <b>G</b>: hızlı kullan": " · <b>G</b>: quick use",
    " · metal ": " · metal ",
    " · altın ": " · gold ",
    "<b>W</b>/<b>S</b>: Merdivenle ": "<b>W</b>/<b>S</b>: Use ladder to ",
    "yukarı çık": "go up",
    "aşağı in": "go down",
    "PARAŞÜT / YÜK BÖLMESİ": "PARACHUTE / PAYLOAD BAY",
    "HAVA KİLİDİ": "AIRLOCK",
    "ANA MOTOR": "MAIN ENGINE",
    "MOTOR: ÇALIŞIYOR": "ENGINE: RUNNING",
    "ONARIM ": "REPAIR ",
    "MOTOR: ONARIM": "ENGINE: REPAIR",
    MUTFAK: "KITCHEN",
    "MEDİKİT ×": "MEDKIT ×",
    REVİR: "SICK BAY",
    "UPLINK ": "UPLINK ",
    " YENİ MESAJ": " NEW MESSAGES",
    "AĞ · AKTİF": "NETWORK · ACTIVE",
    İLETİŞİM: "COMMS",
    MARS: "MARS",
    DÜNYA: "EARTH",
    "NAV v2.1 · SOL ": "NAV v2.1 · SOL ",
    " · KARGO ": " · CARGO ",
    "SİSTEM: HAZIR": "SYSTEM: READY",
    "KALKIŞ KİLİTLİ": "LAUNCH LOCKED",
    NAVİGASYON: "NAVIGATION",
    "KARGO ": "CARGO ",
    STOK: "STOCK",
    Kablolar: "Cables",
    Sigortalar: "Fuses",
    Basınç: "Pressure",
    Ateşleme: "Ignition",
    "✅ Ana motor çalışıyor — onarım gerekmiyor": "✅ Main engine is running — no repair needed",
    "AŞAMA ": "STAGE ",
    "İLERLEME ": "PROGRESS ",
    TAMAMLANDI: "COMPLETED",
    "İLERLEME 100%": "PROGRESS 100%",
    "Tüm sistemler <b>çevrimiçi</b>. Roket kalkışa hazır.":
      "All systems <b>online</b>. The rocket is ready for launch.",
    "MOTOR ÇEVRİMİÇİ": "ENGINE ONLINE",
    "İTKİ ÇEKİRDEĞİ STABİL · KALKIŞ KİLİDİ AÇIK": "THRUST CORE STABLE · LAUNCH LOCK RELEASED",
    "Harika — kapat": "Great — close",
    "🔧 Ana motor onarıldı — roket kalkışa hazır!":
      "🔧 Main engine repaired — the rocket is ready for launch!",
    "Kopan <b>güç kablolarını</b> aynı renkteki motor soketlerine sürükle (ya da önce kabloya, sonra sokete tıkla).":
      "Drag the broken <b>power cables</b> to the engine sockets of the same color (or click a cable, then a socket).",
    "GÜÇ ÜNİTESİ": "POWER UNIT",
    "⚠ DEVRE AÇIK": "⚠ CIRCUIT OPEN",
    "✔ DEVRE KAPALI": "✔ CIRCUIT CLOSED",
    "Kablolar bağlandı": "Cables connected",
    "Kısa devre <b>sigortaları yaktı</b>. Kararmış olanlara tıklayıp değiştir, sonra <b>ana şalteri</b> kaldır. Sağlamlara dokunma!":
      "The short circuit <b>blew the fuses</b>. Click the blackened ones to replace them, then raise the <b>main switch</b>. Don't touch the good ones!",
    "SİGORTA PANOSU · 40A": "FUSE PANEL · 40A",
    "YANIK: ": "BLOWN: ",
    "ŞALTERİ KALDIR": "RAISE THE SWITCH",
    "ANA ŞALTER": "MAIN SWITCH",
    "YANIK: 4": "BLOWN: 4",
    "GÜÇ VAR": "POWER ON",
    "Sigortalar değiştirildi": "Fuses replaced",
    "İbre <b>yeşil bölgedeyken</b> KİLİTLE'ye bas (ya da <b>Space</b>). 3 başarılı kilit gerekli; her kilitte bölge daralır.":
      "Press LOCK while the needle is <b>in the green zone</b> (or <b>Space</b>). 3 successful locks are needed; the zone narrows each time.",
    "YAKIT HATTI BASINCI · kPa": "FUEL LINE PRESSURE · kPa",
    "KİLİT 0/3": "LOCK 0/3",
    KİLİTLE: "LOCK",
    "KİLİT ": "LOCK ",
    "Basınç kalibre edildi": "Pressure calibrated",
    "Ateşleme dizisini <b>izle</b>, sonra düğmelere <b>aynı sırayla</b> bas.":
      "<b>Watch</b> the ignition sequence, then press the buttons <b>in the same order</b>.",
    "↻ TEKRAR İZLE": "↻ WATCH AGAIN",
    İZLE: "WATCH",
    "Dizi oynatılıyor…": "Playing sequence…",
    "SIRA SENDE": "YOUR TURN",
    HATA: "ERROR",
    "Dizi yeniden oynatılıyor": "Replaying sequence",
    ATEŞLEME: "IGNITION",
    "İtki çekirdeği aktif": "Thrust core active",
    "Ateşleme dizisi doğru": "Ignition sequence correct",
    "🛡️ Fırtına kalkanı roketi korudu — motor sağlam":
      "🛡️ The storm shield protected the rocket — engine intact",
    "💥 Şiddetli bir esinti roketi savurdu — motordan duman yükseliyor!":
      "💥 A violent gust shook the rocket — smoke is rising from the engine!",
    "Kum fırtınası yaklaşıyor": "Sandstorm approaching",
    "Roketin içindesin — güvendesin": "You're inside the rocket — you're safe",
    "Rüzgâr hızlanıyor · görüş azalacak": "Wind picking up · visibility will drop",
    "Roket içi güvenli": "Safe inside the rocket",
    "Dışarıda kum fırtınası · rüzgâr ": "Sandstorm outside · wind ",
    "Kum fırtınası": "Sandstorm",
    "Rüzgâr ": "Wind ",
    " km/s · görüş çok düşük": " km/h · visibility very low",
    "Jeolog kazması": "Geologist's pickaxe",
    "Çürük patates": "Rotten potato",
    "DZ-7 radyasyon ölçer": "DZ-7 radiation meter",
    "Su şişesi": "Water bottle",
    Patates: "Potato",
    "Patates tohumu": "Potato seed",
    Medikit: "Medkit",
    Çapa: "Hoe",
    "Metal numune": "Metal sample",
    "Yıldız kristali": "Star crystal",
    "🫁 Oksijen %30 — rokete dönüp tüpten doldur":
      "🫁 Oxygen at 30% — return to the rocket and refill from the tank",
    "⚠️ Oksijen kritik! Hemen rokete dön": "⚠️ Oxygen critical! Return to the rocket now",
    "🫁 Giysi oksijeni zaten dolu": "🫁 Suit oxygen is already full",
    "O₂ tüpü boş — jeneratör dolduruyor, biraz bekle":
      "O₂ tank empty — the generator is refilling it, wait a moment",
    "🫁 Oksijen dolu · tüp %": "🫁 Oxygen full · tank %",
    "O₂ tüpü boşaldı — jeneratör dolduruyor": "O₂ tank empty — the generator is refilling it",
    OKSİJEN: "OXYGEN",
    "Alet Sandığı": "Tool Chest",
    "Toprağı kazar ve parsel açar": "Digs the soil and opens plots",
    "Yalnızca bilinmeyen (?) taşları kırar": "Only breaks unknown (?) stones",
    "Toprağın radyasyonunu ölçer · ekimden önce kullan": "Measures soil radiation · use before planting",
    "Dışarıdaki parsele ekilir": "Planted in the plot outside",
    "Yaşam güvertesi · tıbbi dolap ve sedye": "Living deck · medical cabinet and stretcher",
    "Canı +": "Restores health +",
    " yeniler · yanında taşıyıp G ile kullan": " · carry it and use with G",
    "Yaşam güvertesi · dolaplar, su sebili ve buzdolabı":
      "Living deck · cupboards, water dispenser and fridge",
    "Şişe su · su sebilinden geri dönüştürülür": "Bottled water · recycled by the water dispenser",
    "Haşlanmış patates · açlığı giderir": "Boiled potato · relieves hunger",
    "Yemek Kapsülü": "Food Capsule",
    "Yaşam güvertesi · soğuk saklama + su geri dönüştürücü": "Living deck · cold storage + water recycler",
    "Susuzluğu giderir · geri dönüştürülür": "Relieves thirst · recycled",
    "Açlığı giderir · tarladan yetişir": "Relieves hunger · grown in the field",
    sandığa: "chest",
    kapsüle: "capsule",
    SANDIK: "CHEST",
    KAPSÜL: "CAPSULE",
    '<div class="cap-art"><img src="{0}" alt=""><span class="cap-n">×{1}</span></div>\n      <div class="cap-nm">{2}</div><div class="cap-ds">{3}</div>\n      <div class="cap-bar"><i style="width:{4}%"></i></div>\n      <div class="cap-meta"><span>{5} {6}/{7}</span><span>ÇANTA {8}</span></div>':
      '<div class="cap-art"><img src="{0}" alt=""><span class="cap-n">×{1}</span></div>\n      <div class="cap-nm">{2}</div><div class="cap-ds">{3}</div>\n      <div class="cap-bar"><i style="width:{4}%"></i></div>\n      <div class="cap-meta"><span>{5} {6}/{7}</span><span>BAG {8}</span></div>',
    Al: "Take",
    Koy: "Store",
    Kullan: "Use",
    "❤️ Revirde tedavi oldun · +": "❤️ You were treated in the sick bay · +",
    " can": " health",
    İç: "Drink",
    Ye: "Eat",
    "CAN %": "HEALTH %",
    "💧 +1 su / ": "💧 +1 water / ",
    " dk": " min",
    "KİLİT: AÇIK": "LOCK: OPEN",
    " ÖĞE": " ITEMS",
    "YEMEK KAPSÜLÜ": "FOOD CAPSULE",
    "KİT KAPSÜLÜ": "KIT CAPSULE",
    "ALET SANDIĞI": "TOOL CHEST",
    '<span class="ev rd">☢ Radyasyon · 00:00–01:30</span>':
      '<span class="ev rd">☢ Radiation · 00:00–01:30</span>',
    '<span class="ev st">🌪 Kum fırtınası · 01:30–04:00</span>':
      '<span class="ev st">🌪 Sandstorm · 01:30–04:00</span>',
    "<span class='ev ok'>Sakin</span>": "<span class='ev ok'>Calm</span>",
    '<tr class="{0}"><td>Gün {1}{2}</td><td>{3}</td></tr>':
      '<tr class="{0}"><td>Day {1}{2}</td><td>{3}</td></tr>',
    '<div class="pg-cover"><div class="emb"><span>ARES-1</span><i></i></div>\n    <h1>SAHA REHBERİ</h1><div class="sub">Mars Yüzey Operasyonları El Kitabı</div>\n    <p class="c">Bu kitap çantanda hep durur. <kbd>R</kbd> ile aç / kapat.</p>\n    <p class="c sm">Sayfa çevirmek için ◀ ▶ düğmeleri ya da klavyede <kbd>←</kbd> <kbd>→</kbd>.</p>\n    <p class="c sm">Kitap açıkken oyun zamanı durur.</p>\n    <div class="sig">— ARES-1 Görev Kontrol</div></div>':
      '<div class="pg-cover"><div class="emb"><span>ARES-1</span><i></i></div>\n    <h1>FIELD GUIDE</h1><div class="sub">Mars Surface Operations Handbook</div>\n    <p class="c">This book always stays in your bag. Open / close it with <kbd>R</kbd>.</p>\n    <p class="c sm">Turn pages with the ◀ ▶ buttons or the <kbd>←</kbd> <kbd>→</kbd> keys.</p>\n    <p class="c sm">Game time is paused while the book is open.</p>\n    <div class="sig">— ARES-1 Mission Control</div></div>',
    "İlk adımlar ve kontroller": "First steps and controls",
    Oksijen: "Oxygen",
    "Yemek ve su": "Food and water",
    "Roketin içi": "Inside the rocket",
    Tarım: "Farming",
    "Numuneler ve kargo": "Samples and cargo",
    "⚠ Kum fırtınası": "⚠ Sandstorm",
    "⚠ Radyasyon dalgası": "⚠ Radiation wave",
    "⚠ Meteor yağmuru": "⚠ Meteor shower",
    "Motor onarımı": "Engine repair",
    "Uyku ve zaman": "Sleep and time",
    "Felaket takvimi": "Disaster calendar",
    "Dünya ile iletişim": "Communicating with Earth",
    "Kıyafet & roket geliştirme": "Suit & rocket upgrades",
    "Acil durum listesi": "Emergency checklist",
    "Görev mimarisi": "Mission architecture",
    '<h2>İçindekiler</h2><ol class="toc">{0}</ol>\n    <div class="note">İpucu: bir başlığa tıklarsan o sayfaya gidersin.</div>':
      '<h2>Contents</h2><ol class="toc">{0}</ol>\n    <div class="note">Tip: click a heading to jump to that page.</div>',
    '<h2><small>Bölüm 1</small>İlk adımlar</h2>\n    <table class="keys"><tr><td><kbd>W A S D</kbd></td><td>Yürü · <kbd>Shift</kbd> koş</td></tr>\n    <tr><td><kbd>1</kbd>…<kbd>7</kbd></td><td>Eşyayı eline al · aynı tuşa tekrar bas = kullan</td></tr>\n    <tr><td><kbd>F</kbd></td><td>Topla · elindekiyle ek, sula, iç, ye</td></tr>\n    <tr><td><kbd>E</kbd></td><td>Rokete gir · istasyonu kullan</td></tr>\n    <tr><td><kbd>G</kbd></td><td>Medikit kullan</td></tr>\n    <tr><td>Sol tık</td><td>Çapa elindeyken yeri kaz</td></tr>\n    <tr><td><kbd>R</kbd></td><td>Bu rehberi aç</td></tr></table>\n    <div class="tip"><b>Altın kural:</b> sadece <u>elindeki</u> eşyayı kullanırsın. Çapa elindeyken su içemezsin; önce suyu eline al.</div>\n    <p>Sol üstte <b>gün ve saat</b>, altında <b>görev kartı</b> var. Görev kartındaki 💡 satırı ne yapacağını adım adım söyler.</p>':
      '<h2><small>Chapter 1</small>First steps</h2>\n    <table class="keys"><tr><td><kbd>W A S D</kbd></td><td>Walk · <kbd>Shift</kbd> run</td></tr>\n    <tr><td><kbd>1</kbd>…<kbd>7</kbd></td><td>Hold an item · press the same key again = use</td></tr>\n    <tr><td><kbd>F</kbd></td><td>Collect · plant, water, drink, eat with what you hold</td></tr>\n    <tr><td><kbd>E</kbd></td><td>Enter the rocket · use a station</td></tr>\n    <tr><td><kbd>G</kbd></td><td>Use a medkit</td></tr>\n    <tr><td>Left click</td><td>Dig the ground while holding the hoe</td></tr>\n    <tr><td><kbd>R</kbd></td><td>Open this guide</td></tr></table>\n    <div class="tip"><b>Golden rule:</b> you can only use the item <u>in your hand</u>. You can\'t drink water while holding the hoe; take the water first.</div>\n    <p>Top left shows the <b>day and time</b>, with the <b>mission card</b> below it. The 💡 line on the mission card tells you what to do, step by step.</p>',
    "<h2><small>Bölüm 2</small>Oksijen {0}</h2>\n    <p>Mars'ın havası solunamaz. Giysindeki oksijen dışarıda yaklaşık <b>3,5 dakikada</b> biter. Koşarken %35, fırtınada %25 daha hızlı azalır.</p>\n    <ul><li><b>%30</b>'da uyarı alırsın, <b>%10</b>'da alarm çalar.</li>\n    <li><b>%0</b>'da her saniye ~5 can kaybedersin, ekran kararır.</li>\n    <li>Roketin içinde oksijen azalmaz.</li></ul>\n    <div class=\"tip\"><b>Doldurma:</b> rokete gir → makine dairesi → <b>O₂ tüpleri</b> → <kbd>E</kbd>. Hortum sırt çantana bağlanır ve giysi dolar.</div>\n    <p>Tüplerin de bir kapasitesi var. Boşalırsa oksijen jeneratörü onları yavaşça yeniden doldurur; tüp göstergesini takip et.</p>":
      '<h2><small>Chapter 2</small>Oxygen {0}</h2>\n    <p>The Martian air is not breathable. Your suit\'s oxygen runs out in about <b>3.5 minutes</b> outside. It drains 35% faster while running and 25% faster in a storm.</p>\n    <ul><li>You get a warning at <b>30%</b> and an alarm at <b>10%</b>.</li>\n    <li>At <b>0%</b> you lose ~5 health per second and the screen darkens.</li>\n    <li>Oxygen does not drain inside the rocket.</li></ul>\n    <div class="tip"><b>Refilling:</b> enter the rocket → engine room → <b>O₂ tanks</b> → <kbd>E</kbd>. The hose connects to your backpack and fills your suit.</div>\n    <p>The tanks have a limited capacity too. When empty, the oxygen generator slowly refills them; keep an eye on the tank gauge.</p>',
    "<h2><small>Bölüm 3</small>Yemek ve su {0}</h2>\n    <p><b>Su</b> yaklaşık 4, <b>tokluk</b> yaklaşık 5,5 dakikada biter. Biri sıfırlanırsa saniyede 4 can gider.</p>\n    <ul><li>{1} <b>Su şişesi:</b> +35 su. Eline al ve <kbd>F</kbd>'ye bas.</li>\n    <li>{2} <b>Patates:</b> +35 tokluk. Eline al ve <kbd>F</kbd>'ye bas.</li></ul>\n    <div class=\"tip\"><b>Mutfak:</b> yaşam güvertesindeki mutfakta <kbd>E</kbd> → envanteri açılır. Oradan çantana alabilir ya da hemen içip yiyebilirsin.</div>\n    <p>Su stoku sınırlıdır ama <b>su geri dönüştürücü</b> her 2,5 dakikada 1 şişe üretir. Patatesi ise tarlada sen yetiştirirsin.</p>":
      '<h2><small>Chapter 3</small>Food and water {0}</h2>\n    <p><b>Water</b> runs out in about 4 minutes, <b>food</b> in about 5.5 minutes. If either reaches zero you lose 4 health per second.</p>\n    <ul><li>{1} <b>Water bottle:</b> +35 water. Hold it and press <kbd>F</kbd>.</li>\n    <li>{2} <b>Potato:</b> +35 food. Hold it and press <kbd>F</kbd>.</li></ul>\n    <div class="tip"><b>Kitchen:</b> press <kbd>E</kbd> at the kitchen on the living deck → its inventory opens. You can take items into your bag or eat and drink right away.</div>\n    <p>Water stock is limited, but the <b>water recycler</b> produces 1 bottle every 2.5 minutes. Potatoes you grow yourself in the field.</p>',
    '<h2><small>Bölüm 4</small>Roketin içi</h2>\n    <p>Roket 3 katlıdır. Merdivenin yanında <kbd>W</kbd>/<kbd>S</kbd> ile kat değiştirirsin.</p>\n    <div class="deck"><b>3 · Komuta güvertesi</b><span>Navigasyon (kalkış) · Kargo terminali</span></div>\n    <div class="deck"><b>2 · Yaşam güvertesi</b><span>Uyku kabini · Mutfak · Revir · Yemek kapsülü</span></div>\n    <div class="deck"><b>1 · Makine dairesi</b><span>Hava kilidi (çıkış) · Alet sandığı · O₂ tüpleri · Ana motor · Tamir tezgâhı</span></div>\n    <div class="tip">Roketin gövdesi seni <b>radyasyondan, fırtınadan ve meteorlardan</b> korur. Bir felaket yaklaşırken en güvenli yer burasıdır.</div>':
      '<h2><small>Chapter 4</small>Inside the rocket</h2>\n    <p>The rocket has 3 decks. Next to a ladder, change decks with <kbd>W</kbd>/<kbd>S</kbd>.</p>\n    <div class="deck"><b>3 · Command deck</b><span>Navigation (launch) · Cargo terminal</span></div>\n    <div class="deck"><b>2 · Living deck</b><span>Sleeping cabin · Kitchen · Sick bay · Food capsule</span></div>\n    <div class="deck"><b>1 · Engine room</b><span>Airlock (exit) · Tool chest · O₂ tanks · Main engine · Workbench</span></div>\n    <div class="tip">The rocket\'s hull protects you from <b>radiation, storms and meteors</b>. When a disaster approaches, this is the safest place.</div>',
    '<h2><small>Bölüm 5</small>Tarım {0}</h2>\n    <ol><li>Alet sandığından {1} <b>çapayı</b> al. Çapayı eline al ve yere <b>sol tıkla</b>.</li>\n    <li>{2} <b>Tohumu</b> eline al, çukurun yanında <kbd>F</kbd>.</li>\n    <li>{3} <b>Suyu</b> eline al, <kbd>F</kbd> ile sula. Islak toprak bitkiyi 2,4 kat hızlı büyütür.</li>\n    <li>Halka <b>sarı</b> olunca <kbd>F</kbd> ile hasat et: 1–2 patates + 1 tohum.</li></ol>\n    <p>Büyümesi sulamadan yaklaşık 75 saniye sürer. Bitki aşamaları: filiz → fide → çiçekli bitki → hasat.</p>\n    <div class="warn">Kum fırtınasında bitkiler sallanır ama zarar görmez. Parselleri roketin yakınına aç ki fırtınada kaybolmayasın.</div>':
      '<h2><small>Chapter 5</small>Farming {0}</h2>\n    <ol><li>Take the {1} <b>hoe</b> from the tool chest. Hold the hoe and <b>left-click</b> the ground.</li>\n    <li>Hold a {2} <b>seed</b> and press <kbd>F</kbd> next to the hole.</li>\n    <li>Hold {3} <b>water</b> and water it with <kbd>F</kbd>. Wet soil makes the plant grow 2.4 times faster.</li>\n    <li>When the ring turns <b>yellow</b>, harvest with <kbd>F</kbd>: 1–2 potatoes + 1 seed.</li></ol>\n    <p>Without watering it takes about 75 seconds to grow. Plant stages: sprout → seedling → flowering plant → harvest.</p>\n    <div class="warn">During a sandstorm plants sway but are not damaged. Dig your plots close to the rocket so you don\'t get lost in a storm.</div>',
    '<h2><small>Bölüm 6</small>Numuneler ve kargo {0}</h2>\n    <p>Görevin bilimsel amacı Mars numunelerini Dünya\'ya götürmek.</p>\n    <ul><li>{1} <b>Metal numune</b> = 1 puan. Haritada ◆ olarak görünür.</li>\n    <li>{2} <b>Yıldız kristali</b> = 2 puan. Meteor çarpınca kraterde kalabilir.</li></ul>\n    <div class="tip">Roketin yanında <kbd>F</kbd> ya da komuta güvertesindeki <b>kargo terminali</b> ile kargoya yükle. Hedef: <b>10 numune</b>.</div>\n    <p>Çantana en fazla {3} metal numune sığar. Dolunca rokete dönüp boşalt.</p>':
      '<h2><small>Chapter 6</small>Samples and cargo {0}</h2>\n    <p>The scientific goal of the mission is to bring Martian samples to Earth.</p>\n    <ul><li>{1} <b>Metal sample</b> = 1 point. Shown as ◆ on the map.</li>\n    <li>{2} <b>Star crystal</b> = 2 points. Can be left in a crater after a meteor impact.</li></ul>\n    <div class="tip">Load them into cargo with <kbd>F</kbd> next to the rocket or at the <b>cargo terminal</b> on the command deck. Goal: <b>10 samples</b>.</div>\n    <p>Your bag holds at most {3} metal samples. When it\'s full, return to the rocket and unload.</p>',
    '<h2 class="danger"><small>Bölüm 7 · Felaket</small>🌪 Kum fırtınası (1/2)</h2>\n    <p><b>Ne zaman?</b> İlki <b>2. gün</b> gelir, sonra <b>her 5 günde bir</b> tekrarlar (7, 12, 17…). Günün 01:30\'unda başlar, <b>2,5 dakika</b> sürer.</p>\n    <p><b>Uyarı:</b> başlamadan <b>45 saniye</b> önce turuncu bir kart çıkar ve geri sayar.</p>\n    <p><b>Neler olur?</b></p>\n    <ul><li>Görüş birkaç metreye düşer, gökyüzü kararır.</li>\n    <li>Rüzgâr (130 km/s\'ye kadar) seni savurur, rüzgâra karşı yürümek zorlaşır.</li>\n    <li>Harita sinyali kaybolur: "SİNYAL ZAYIF".</li>\n    <li>Oksijen %25 daha hızlı tükenir.</li>\n    <li>Ani esintiler ekranı sarsar.</li></ul>':
      '<h2 class="danger"><small>Chapter 7 · Disaster</small>🌪 Sandstorm (1/2)</h2>\n    <p><b>When?</b> The first one arrives on <b>day 2</b>, then repeats <b>every 5 days</b> (7, 12, 17…). It starts at 01:30 and lasts <b>2.5 minutes</b>.</p>\n    <p><b>Warning:</b> an orange card appears <b>45 seconds</b> before it starts and counts down.</p>\n    <p><b>What happens?</b></p>\n    <ul><li>Visibility drops to a few metres and the sky darkens.</li>\n    <li>Wind (up to 130 km/h) pushes you around; walking against it is hard.</li>\n    <li>The map signal is lost: "WEAK SIGNAL".</li>\n    <li>Oxygen drains 25% faster.</li>\n    <li>Sudden gusts shake the screen.</li></ul>',
    '<h2 class="danger"><small>Bölüm 7 · Felaket</small>🌪 Kum fırtınası (2/2)</h2>\n    <div class="warn"><b>İLK FIRTINA ROKETİ VURUR!</b> 2. gündeki fırtına zirvedeyken sert bir esinti roketi savurur ve <b>ana motor bozulur</b>. Motordan duman yükselir, kalkış kilitlenir.</div>\n    <p><b>Ne yapmalı?</b></p>\n    <ol><li>Uyarı kartını görünce işini bırak, <b>rokete dön</b>.</li>\n    <li>Fırtına bitene kadar içeride kal. Bu arada ye, iç, oksijen doldur.</li>\n    <li>Dışarıda yakalanırsan haritadaki roket okunu takip et.</li>\n    <li>Fırtına bitince motoru onar (Bölüm 10).</li></ol>\n    <p class="sm">Sonraki fırtınalarda motor <b>%60</b> olasılıkla yeniden bozulabilir; fırtına kalkanı bu riski azaltır (Bölüm 14).</p>':
      '<h2 class="danger"><small>Chapter 7 · Disaster</small>🌪 Sandstorm (2/2)</h2>\n    <div class="warn"><b>THE FIRST STORM HITS THE ROCKET!</b> At the peak of the day-2 storm, a violent gust shakes the rocket and <b>the main engine breaks down</b>. Smoke rises from the engine and launch is locked.</div>\n    <p><b>What to do?</b></p>\n    <ol><li>When you see the warning card, drop what you\'re doing and <b>return to the rocket</b>.</li>\n    <li>Stay inside until the storm ends. Meanwhile eat, drink and refill oxygen.</li>\n    <li>If you\'re caught outside, follow the rocket arrow on the map.</li>\n    <li>When the storm is over, repair the engine (Chapter 10).</li></ol>\n    <p class="sm">In later storms the engine can break down again with a <b>60%</b> chance; the storm shield reduces this risk (Chapter 14).</p>',
    '<h2 class="danger"><small>Bölüm 8 · Felaket</small>☢ Radyasyon dalgası</h2>\n    <p><b>Ne zaman?</b> Güneş patlaması <b>3. günden itibaren her 3 günde bir</b> (3, 6, 9…), günün en başında (00:00) gelir ve <b>1,5 dakika</b> sürer.</p>\n    <p><b>Uyarı:</b> önceki günün bitmesine <b>40 saniye</b> kala yeşil kart çıkar.</p>\n    <ul><li>Dışarıdaysan ekran <b>yeşile</b> döner ve saniyede ~3 can kaybedersin — standart giysiyle 30 saniyede ölürsün! Kalkan Mk-III ve ARES Elite setleri hasarı büyük ölçüde azaltır.</li>\n    <li>Başının üstünde "☢" hasar yazıları belirir.</li>\n    <li>Dalganın tamamını dışarıda geçirmek kesin ölümdür!</li></ul>\n    <div class="tip"><b>Korunma:</b> rokete gir. Gövde zırhı radyasyonu tamamen keser, içeride can kaybetmezsin. En iyi taktik: dalga gecesinde roketin <b>uyku kabininde</b> uyumak.</div>':
      '<h2 class="danger"><small>Chapter 8 · Disaster</small>☢ Radiation wave</h2>\n    <p><b>When?</b> A solar flare arrives <b>every 3 days from day 3 on</b> (3, 6, 9…) at the very start of the day (00:00) and lasts <b>1.5 minutes</b>.</p>\n    <p><b>Warning:</b> a green card appears <b>40 seconds</b> before the previous day ends.</p>\n    <ul><li>If you\'re outside, the screen turns <b>green</b> and you lose ~3 health per second — in the standard suit you die within 30 seconds! The Shield Mk-III and ARES Elite sets greatly reduce the damage.</li>\n    <li>"☢" damage numbers appear above your head.</li>\n    <li>Spending the whole wave outside means certain death!</li></ul>\n    <div class="tip"><b>Protection:</b> enter the rocket. The hull armour blocks radiation completely; you lose no health inside. Best tactic: sleep in the rocket\'s <b>sleeping cabin</b> on the night of the wave.</div>',
    '<h2 class="danger"><small>Bölüm 9 · Felaket</small>☄ Meteor yağmuru</h2>\n    <p>Meteorlar <b>uyarı vermeden</b>, rastgele zamanlarda 1–3 tane düşer. Kum fırtınası sırasında düşmez.</p>\n    <p><b>Belirtiler:</b> önce yükselen bir uğultu duyulur. Gökyüzünde iz bırakan bir ateş topu belirir ve yerde <b>büyüyen bir gölge</b> oluşur. Gölge çarpma noktasıdır!</p>\n    <ul><li>Çarpma yarıçapı ~9 m, hasar <b>26 can</b>.</li>\n    <li>Çarpma kalıcı bir krater bırakır. Krater bir süre sıcak kalır ve tüter.</li></ul>\n    <div class="tip"><b>Fırsat:</b> kraterlerde sık sık {0} <b>yıldız kristali</b> ya da metal numune kalır. Gölgeden uzaklaş, çarpmadan sonra topla.</div>':
      '<h2 class="danger"><small>Chapter 9 · Disaster</small>☄ Meteor shower</h2>\n    <p>Meteors fall <b>without warning</b>, 1–3 at a time, at random moments. They don\'t fall during a sandstorm.</p>\n    <p><b>Signs:</b> first you hear a rising rumble. A fireball with a trail appears in the sky and a <b>growing shadow</b> forms on the ground. The shadow is the impact point!</p>\n    <ul><li>Impact radius ~9 m, damage <b>26 health</b>.</li>\n    <li>The impact leaves a permanent crater. The crater stays hot and smokes for a while.</li></ul>\n    <div class="tip"><b>Opportunity:</b> craters often contain a {0} <b>star crystal</b> or a metal sample. Move away from the shadow and collect after the impact.</div>',
    '<h2><small>Bölüm 10</small>Motor onarımı 🔧</h2>\n    <p>Makine dairesinde <b>ANA MOTOR</b> → <kbd>E</kbd>. Onarım 4 aşamadır; tamamladığın aşamalar kaydedilir.</p>\n    <ol><li><b>Kablolar:</b> renkli kabloları aynı renkteki sokete sürükle.</li>\n    <li><b>Sigortalar:</b> kararmış sigortalara tıkla, sonra ana şalteri kaldır. Sağlamlara dokunma!</li>\n    <li><b>Basınç:</b> ibre yeşil bölgedeyken KİLİTLE ya da <kbd>Space</kbd>. 3 kez başarman gerekir.</li>\n    <li><b>Ateşleme:</b> ışık dizisini izle, aynı sırayla bas.</li></ol>\n    <div class="tip">Onarım bitince kalkış kilidi açılır ve görevler seni Dünya\'ya yönlendirir.</div>':
      '<h2><small>Chapter 10</small>Engine repair 🔧</h2>\n    <p>In the engine room: <b>MAIN ENGINE</b> → <kbd>E</kbd>. The repair has 4 stages; completed stages are saved.</p>\n    <ol><li><b>Cables:</b> drag the coloured cables to the socket of the same colour.</li>\n    <li><b>Fuses:</b> click the blackened fuses, then raise the main switch. Don\'t touch the good ones!</li>\n    <li><b>Pressure:</b> press LOCK or <kbd>Space</kbd> while the needle is in the green zone. You need to succeed 3 times.</li>\n    <li><b>Ignition:</b> watch the light sequence and press in the same order.</li></ol>\n    <div class="tip">Once the repair is done, the launch lock is released and the missions guide you back to Earth.</div>',
    '<h2><small>Bölüm 11</small>Uyku ve zaman</h2>\n    <p>Mars\'ta <b>1 gün = 6 dakika</b>. Sol üstteki çubuk günün ilerleyişini, turuncu çizgiler olayları gösterir.</p>\n    <ul><li>Uyku kabininde uyursan <b>zaman 2 kat hızlanır</b>, can hızla yenilenir.</li>\n    <li>Sabah olunca kendiliğinden uyanırsın. Aç ya da susuz kalırsan erken uyanırsın.</li>\n    <li>Uyurken mahsul de 2 kat hızlı büyür.</li></ul>\n    <div class="tip">Radyasyon gecesinde ya da uzun bir fırtınada uyumak, tehlikeyi güvenle atlatmanın en kolay yolu.</div>':
      '<h2><small>Chapter 11</small>Sleep and time</h2>\n    <p>On Mars <b>1 day = 6 minutes</b>. The bar at the top left shows the day\'s progress; orange marks show events.</p>\n    <ul><li>If you sleep in the sleeping cabin, <b>time runs 2× faster</b> and health regenerates quickly.</li>\n    <li>You wake up automatically in the morning. If you get hungry or thirsty, you wake up early.</li>\n    <li>Crops also grow 2× faster while you sleep.</li></ul>\n    <div class="tip">Sleeping through a radiation night or a long storm is the easiest way to get through the danger safely.</div>',
    '<h2><small>Bölüm 12</small>Felaket takvimi</h2>\n    <p class="sm">Bugün: <b>Gün {0}</b> · gün bitimine <b>{1}</b> · sonraki fırtına <b>Gün {2}</b></p>\n    <table class="cal">{3}</table>\n    <p class="sm">Meteorlar takvime girmez: her an düşebilir.</p>':
      '<h2><small>Chapter 12</small>Disaster calendar</h2>\n    <p class="sm">Today: <b>Day {0}</b> · until day\'s end <b>{1}</b> · next storm <b>Day {2}</b></p>\n    <table class="cal">{3}</table>\n    <p class="sm">Meteors are not on the calendar: they can fall at any time.</p>',
    "<h2><small>Bölüm 13</small>Dünya ile iletişim 📡</h2>\n    <p>Görevin asıl amacı: Mars'ta yaşadıklarını ve topladığın bilgileri <b>Dünya'ya aktarmak</b>. Komuta güvertesinin solundaki <b>İLETİŞİM</b> masasına <kbd>E</kbd>.</p>\n    <ul><li><b>Saha günlüğü</b> fırtına, radyasyon, meteor, arıza, numune, tarım ve kritik değerleri <b>otomatik</b> kaydeder.</li>\n    <li>Kayıtları seç, kendi notunu yaz (sorunlarını, sorularını), öncelik belirle ve gönder.</li>\n    <li>Görev Kontrol <b>~½ sol</b> sonra (ACİL: ~¼ sol) resmî bir yanıt yollar: analiz, talimatlar ve 5 sollük tahmin.</li>\n    <li>Kum fırtınası sırasında anten tozla kapanır, <b>gönderim yapılamaz</b>.</li>\n    <li><b>🛰️ Yer Birimi</b> sekmesi, raporlarını alan yer istasyonlarını ve görev kontrol merkezlerini gösterir.</li></ul>\n    <div class=\"tip\">Görev Kontrol bazen kendiliğinden yazar: hava bültenleri, telemetri uyarıları, rapor talepleri. Sağ üstteki rozet yeni mesajı gösterir.</div>":
      '<h2><small>Chapter 13</small>Communicating with Earth 📡</h2>\n    <p>The real goal of the mission: <b>transmitting to Earth</b> what you experience on Mars and the data you collect. Press <kbd>E</kbd> at the <b>COMMS</b> desk on the left of the command deck.</p>\n    <ul><li>The <b>field log</b> <b>automatically</b> records storms, radiation, meteors, breakdowns, samples, farming and critical values.</li>\n    <li>Select entries, write your own note (your problems, your questions), set a priority and send.</li>\n    <li>Mission Control sends an official reply after <b>~½ sol</b> (URGENT: ~¼ sol): analysis, instructions and a 5-sol forecast.</li>\n    <li>During a sandstorm the antenna is clogged with dust and <b>nothing can be sent</b>.</li>\n    <li>The <b>🛰️ Ground Segment</b> tab shows the ground stations and mission control centers that receive your reports.</li></ul>\n    <div class="tip">Mission Control sometimes writes on its own: weather bulletins, telemetry alerts, report requests. The badge at the top right shows new messages.</div>',
    '<h2><small>Bölüm 14</small>Kıyafet & roket geliştirme 🧬</h2>\n    <p>Yaşam güvertesindeki <b>Fabrikasyon Atölyesi</b> <kbd>E</kbd> ile açılır.</p>\n    <ul><li><b>Kıyafet setleri</b> (Kaşif → Öncü → Kalkan → ARES Elite) metal numune, yıldız kristali ve nadir taşlarla sırayla üretilir. Her set oksijen tüketimini, yürüme hızını, radyasyon ve fırtına korumasını artırır.</li>\n    <li><b>Roket geliştirme</b> meteor kraterlerinin çevresine saçılan <b>altın parçaları</b> ve titanyum cevheriyle yapılır. Fırtına kalkanı 3 seviyedir; son seviyede fırtına motoru bozamaz.</li>\n    <li>İlk fırtınadan sonraki her fırtınada motor <b>%60</b> olasılıkla bozulur — kalkan bunu azaltır.</li>\n    <li>Altınla rokete yeni boyalar da alabilirsin.</li></ul>\n    <div class="tip">Meteor düştükten sonra krater çevresini tara: parıldayan sarı parçalar altındır. Uzak bölgelerde tarayıcının bip sesini takip et: <b>bilinmeyen taşlar</b> (titanyum, olivin, Ares taşı) üst seviye geliştirmeler için şart — çıkarmak için saha kiti gerekir.</div>':
      '<h2><small>Chapter 14</small>Suit & rocket upgrades 🧬</h2>\n    <p>The <b>Fabrication Workshop</b> on the living deck opens with <kbd>E</kbd>.</p>\n    <ul><li><b>Suit sets</b> (Explorer → Pioneer → Shield → ARES Elite) are built in order from metal samples, star crystals and rare stones. Each set improves oxygen use, walking speed, and radiation and storm protection.</li>\n    <li><b>Rocket upgrades</b> are made with the <b>gold fragments</b> scattered around meteor craters and with titanium ore. The storm shield has 3 levels; at the last level storms can no longer break the engine.</li>\n    <li>In every storm after the first one, the engine breaks down with a <b>60%</b> chance — the shield reduces this.</li>\n    <li>With gold you can also buy new paint jobs for the rocket.</li></ul>\n    <div class="tip">After a meteor falls, search around the crater: the glittering yellow fragments are gold. In remote areas follow the scanner\'s beep: <b>unknown stones</b> (titanium, olivine, Ares stone) are required for top-tier upgrades — you need the field kit to extract them.</div>',
    '<h2><small>Bölüm 15</small>Acil durum listesi</h2>\n    <table class="emg"><tr><td>🫁 Oksijen &lt; %30</td><td>Rokete dön → O₂ tüpleri</td></tr>\n    <tr><td>❤ Can düşük</td><td>Medikit (<kbd>G</kbd>), revir ya da uyku</td></tr>\n    <tr><td>💧 / 🍽 bitti</td><td>Mutfak ya da yemek kapsülü</td></tr>\n    <tr><td>🌪 Turuncu kart</td><td>45 sn içinde rokete gir</td></tr>\n    <tr><td>☢ Yeşil kart</td><td>Rokete gir, mümkünse uyu</td></tr>\n    <tr><td>☄ Uğultu + gölge</td><td>Gölgeden uzaklaş</td></tr>\n    <tr><td>💨 Motordan duman</td><td>Ana motoru onar</td></tr></table>\n    <h3>Eve dönüş</h3><p>Sol üstteki görev kartını takip et: numune → kit → tarım → ilk rapor → fırtına → motor onarımı → radyasyon → hasat → Dünya\'nın yanıtı → altın → nadir taş → yeni kıyafet → kargo (10). Sonra komuta güvertesinde <b>NAVİGASYON</b> → <b>EVE DÖN</b>.</p>':
      '<h2><small>Chapter 15</small>Emergency checklist</h2>\n    <table class="emg"><tr><td>🫁 Oxygen &lt; 30%</td><td>Back to the rocket → O₂ tanks</td></tr>\n    <tr><td>❤ Low health</td><td>Medkit (<kbd>G</kbd>), sick bay or sleep</td></tr>\n    <tr><td>💧 / 🍽 empty</td><td>Kitchen or food capsule</td></tr>\n    <tr><td>🌪 Orange card</td><td>Enter the rocket within 45 s</td></tr>\n    <tr><td>☢ Green card</td><td>Enter the rocket, sleep if possible</td></tr>\n    <tr><td>☄ Rumble + shadow</td><td>Move away from the shadow</td></tr>\n    <tr><td>💨 Smoke from the engine</td><td>Repair the main engine</td></tr></table>\n    <h3>Going home</h3><p>Follow the mission card at the top left: samples → kit → farming → first report → storm → engine repair → radiation → harvest → Earth\'s reply → gold → rare stone → new suit → cargo (10). Then on the command deck: <b>NAVIGATION</b> → <b>GO HOME</b>.</p>',
    '<h2><small>Bölüm 16</small>Görev mimarisi 📐</h2>\n    <p>ARES-1 bir uzay görevinin tüm parçalarıyla tasarlandı. İletişim terminalindeki <b>📐 Görev Mimarisi</b> sekmesi bunları canlı gösterir.</p>\n    <ul><li><b>Görev segmentleri:</b> fırlatma, uzay, yer ve kullanıcı segmentleri birlikte çalışır.</li>\n    <li><b>Kavram olgunluğu:</b> görev bir fikirle başlar; fizibilite analizi ve ödünleşim çalışmalarından geçerek nokta tasarıma ulaşır.</li>\n    <li><b>Alt sistemler:</b> itki, yaşam desteği, ısıl koruma, yapı ve iletişim ayrı ayrı izlenir.</li></ul>\n    <div class="tip">ARES-1 kurgusal bir görevdir; oyundaki sayılar oyun için basitleştirilmiştir.</div>':
      '<h2><small>Chapter 16</small>Mission architecture 📐</h2>\n    <p>ARES-1 was designed with all the parts of a space mission. The <b>📐 Mission Architecture</b> tab of the communications terminal shows them live.</p>\n    <ul><li><b>Mission segments:</b> the launch, space, ground and user segments work together.</li>\n    <li><b>Concept maturity:</b> a mission starts as an idea and reaches a point design through feasibility analysis and trade studies.</li>\n    <li><b>Subsystems:</b> propulsion, life support, thermal protection, structure and communications are tracked separately.</li></ul>\n    <div class="tip">ARES-1 is a fictional mission; the numbers in the game are simplified for gameplay.</div>',
    "Uçuş Direktörü": "Flight Director",
    "Mürettebat İletişim Sorumlusu": "Crew Communications Officer",
    "İtki Sistemleri Şefi": "Chief of Propulsion Systems",
    "Uzay Hava Durumu Birimi": "Space Weather Unit",
    "Gezegen Bilimi Ekibi Lideri": "Planetary Science Team Lead",
    "Biyorejeneratif Yaşam Destek": "Bioregenerative Life Support",
    "Uçuş Cerrahı": "Flight Surgeon",
    "Davranış Sağlığı Uzmanı": "Behavioral Health Specialist",
    "Lojistik ve Kargo Planlama": "Logistics and Cargo Planning",
    "Görev Destek Yapay Zekâsı": "Mission Support AI",
    "Uzay hava durumu": "Space weather",
    "Ana motor arızası": "Main engine failure",
    "Araç sistemleri": "Vehicle systems",
    "Radyasyon dalgası": "Radiation wave",
    "Meteor düşüşü": "Meteor fall",
    "Gezegen bilimi": "Planetary science",
    "Jeolojik numune": "Geological sample",
    "Tarım deneyi": "Farming experiment",
    "Yaşam bilimi": "Life science",
    "Kargo yüklemesi": "Cargo loading",
    Lojistik: "Logistics",
    "Yaşam destek uyarısı": "Life support alert",
    "Mürettebat sağlığı": "Crew health",
    "Nadir mineral": "Rare mineral",
    "Çürüyen hasat": "Rotten harvest",
    KRİTİK: "CRITICAL",
    ÖNEMLİ: "IMPORTANT",
    OLUMLU: "POSITIVE",
    RUTİN: "ROUTINE",
    Su: "Water",
    Tokluk: "Food",
    Can: "Health",
    Erzak: "Supplies",
    " sa ": " h ",
    "{0}. solda ~{1} süren yerel toz fırtınası. Görüş sıfıra yakın, gövde sarsıntısı yüksek. ":
      "Local dust storm on sol {0} lasting ~{1}. Visibility near zero, heavy shaking of the hull. ",
    "Fırtına sırasında araç dışında {0} geçirildi. ": "{0} spent outside the vehicle during the storm. ",
    "Mürettebat fırtına boyunca araç içinde kaldı. ":
      "The crew stayed inside the vehicle throughout the storm. ",
    "Fırtına ana motoru devre dışı bıraktı.": "The storm disabled the main engine.",
    "Araçta yeni hasar gözlenmedi.": "No new damage observed on the vehicle.",
    "{0}. solda fırtına esnasında itki çekirdeğinde arıza. Makine dairesinde yoğun duman, kalkış kilitli.":
      "Failure in the thrust core during the storm on sol {0}. Heavy smoke in the engine room, launch locked.",
    "Ana motor 4 aşamalı prosedürle onarıldı (kablolar, sigortalar, basınç, ateşleme). Sistem çevrimiçi.":
      "Main engine repaired with the 4-stage procedure (cables, fuses, pressure, ignition). System online.",
    "Güneş kaynaklı parçacık dalgası (~{0}). ": "Solar particle wave (~{0}). ",
    "Dışarıda {0} maruz kalındı, ~{1} can kaybı.": "{0} of exposure outside, ~{1} health lost.",
    "Mürettebat zırhlı gövdede korundu, doz alınmadı.":
      "The crew was protected by the armoured hull; no dose received.",
    "{0} meteor çarpması gözlendi": "{0} meteor impacts observed",
    ", en yakını ~{0} m mesafede.": ", the closest ~{0} m away.",
    " Taze kraterler oluştu.": " Fresh craters formed.",
    " ve {0} yıldız kristali": " and {0} star crystal(s)",
    "{0} metal{1} numunesi toplandı.": "{0} metal samples{1} collected.",
    " parsele tohum ekildi": " plots seeded",
    " hasat alındı": " harvests gathered",
    "Kargo bölmesine {0} birim numune yüklendi (toplam {1}/{2}).":
      "{0} sample units loaded into the cargo bay (total {1}/{2}).",
    " çıkarıldı ve analiz edildi.": " extracted and analysed.",
    "{0} parselden alınan patates yumruları kararmış ve yumuşamış halde çıktı. Yapraklar hasattan önce solmuştu. Nedeni bilinmiyor.":
      "The potato tubers from {0} plot(s) came out blackened and soft. The leaves had wilted before harvest. The cause is unknown.",
    "Kritik değerler: ": "Critical values: ",
    "erzak tükendi": "supplies exhausted",
    "📝 Saha günlüğüne eklendi: <b>": "📝 Added to the field log: <b>",
    "</b> — komuta güvertesindeki <b>iletişim terminalinden</b> Dünya'ya raporla":
      "</b> — report it to Earth from the <b>communications terminal</b> on the command deck",
    "📨 <b>Dünya'dan resmî mesaj:</b> ": "📨 <b>Official message from Earth:</b> ",
    " — iletişim terminalinden oku": " — read it at the communications terminal",
    "ACİL · ": "URGENT · ",
    '<div class="ltr-cc"><b>Bilgi:</b> {0}</div>': '<div class="ltr-cc"><b>Cc:</b> {0}</div>',
    '<div class="ltr">\n  <div class="ltr-hd"><div class="ltr-seal"><b>ARES</b><span>GK</span></div>\n    <div class="ltr-org"><b>ARES-1 GÖREV KONTROL MERKEZİ</b><span>Yer istasyonu ağı üzerinden</span></div>\n    <div class="ltr-cls {0}">{1}RESMİ<br><small>MÜRETTEBATA ÖZEL</small></div></div>\n  <table class="ltr-meta">\n    <tr><td>Belge No</td><td>{2}</td><td>Tarih</td><td>{3} (Mars yerel)</td></tr>\n    <tr><td>Kime</td><td>ARES-1 Komutanı</td><td>İlgi</td><td>{4}</td></tr>\n    <tr><td>Konu</td><td colspan="3"><b>{5}</b></td></tr></table>\n  <div class="ltr-body">{6}</div>\n  {7}\n  <div class="ltr-sign">{8}</div>\n  {9}\n  <div class="ltr-ft">Bu ileti {10} dk ışık gecikmesiyle iletilmiştir · Şifreli kanal AES-256 · {11}</div>\n</div>':
      '<div class="ltr">\n  <div class="ltr-hd"><div class="ltr-seal"><b>ARES</b><span>MC</span></div>\n    <div class="ltr-org"><b>ARES-1 MISSION CONTROL CENTER</b><span>Via the ground station network</span></div>\n    <div class="ltr-cls {0}">{1}OFFICIAL<br><small>CREW ONLY</small></div></div>\n  <table class="ltr-meta">\n    <tr><td>Document No</td><td>{2}</td><td>Date</td><td>{3} (Mars local)</td></tr>\n    <tr><td>To</td><td>ARES-1 Commander</td><td>Ref.</td><td>{4}</td></tr>\n    <tr><td>Subject</td><td colspan="3"><b>{5}</b></td></tr></table>\n  <div class="ltr-body">{6}</div>\n  {7}\n  <div class="ltr-sign">{8}</div>\n  {9}\n  <div class="ltr-ft">This message was transmitted with a {10} min light delay · Encrypted channel AES-256 · {11}</div>\n</div>',
    '<span class="fx rd">☢ Radyasyon · {0}–{1}</span>': '<span class="fx rd">☢ Radiation · {0}–{1}</span>',
    '<span class="fx st">🌪 Kum fırtınası · {0}–{1}</span>':
      '<span class="fx st">🌪 Sandstorm · {0}–{1}</span>',
    '<span class="fx ok">Açık · dış görev uygun</span>':
      '<span class="fx ok">Clear · suitable for EVA</span>',
    "EK-A · Uzay hava durumu tahmini": "ANNEX A · Space weather forecast",
    '<div class="ltr-annex"><div class="ah">{0}</div><table>{1}</table><div class="an">Meteor düşüşleri öngörülemez; tahmine dahil değildir.</div></div>':
      '<div class="ltr-annex"><div class="ah">{0}</div><table>{1}</table><div class="an">Meteor falls cannot be predicted and are not included in the forecast.</div></div>',
    "<p>Sayın Komutan,</p>\n  <p>ARES-1 aracının Mars yüzeyine başarılı inişini tebrik ederiz. Tüm Görev Kontrol ekibi şu an sizi izliyor ve iniş telemetrisini eksiksiz aldık.</p>\n  <p>Görevinizin temel amacı, yüzeyde <b>bilimsel veri toplamak</b> ve yaşadığınız her olayı — özellikle tehlikeli olanları — Dünya'ya <b>raporlamaktır</b>. Burada hiçbir insanın daha önce yaşamadığı koşulları yaşayacaksınız; gözlemleriniz gelecekteki mürettebatların hayatını kurtaracak.</p>\n  <ol><li>Fırtına, radyasyon, meteor, arıza, numune ve tarım olayları aracın <b>saha günlüğüne</b> otomatik kaydedilir.</li>\n  <li>Komuta güvertesindeki <b>İletişim Terminali</b>nden bu kayıtları seçip kendi notunuzu ekleyerek rapor gönderin.</li>\n  <li>Raporlar ekiplerimiz tarafından incelenir; resmî yanıtımız yaklaşık <b>½ sol</b> içinde ulaşır. Hayati durumlarda raporu <b>ACİL</b> işaretleyin; yanıt süresi ~¼ sole iner.</li></ol>\n  <p>Uydu verilerimiz bölgenizde gelişmekte olan bir toz sistemi gösteriyor. Yoğunluğu hakkında henüz kesin bilgimiz yok; lütfen aracın çevresinden çok uzaklaşmayın.</p>\n  <p>Size güveniyoruz. Dünya'dan selamlar.</p>":
      "<p>Dear Commander,</p>\n  <p>Congratulations on the successful landing of ARES-1 on the surface of Mars. The entire Mission Control team is watching you right now, and we have received the landing telemetry in full.</p>\n  <p>The main goal of your mission is to <b>collect scientific data</b> on the surface and to <b>report</b> every event you experience — especially the dangerous ones — to Earth. You will face conditions no human has ever experienced; your observations will save the lives of future crews.</p>\n  <ol><li>Storms, radiation, meteors, breakdowns, samples and farming events are automatically recorded in the vehicle's <b>field log</b>.</li>\n  <li>Send reports from the <b>Communications Terminal</b> on the command deck by selecting these entries and adding your own note.</li>\n  <li>Reports are reviewed by our teams; our official reply arrives within about <b>½ sol</b>. In critical situations mark the report <b>URGENT</b>; the reply time drops to ~¼ sol.</li></ol>\n  <p>Our satellite data shows a dust system developing in your area. We don't yet know its intensity; please don't stray far from the vehicle.</p>\n  <p>We trust you. Greetings from Earth.</p>",
    "Görev başlangıç brifingi": "Mission start briefing",
    "Yörünge görüntüleri bölgenize doğru ilerleyen bir toz cephesi gösteriyor.":
      "Orbital images show a dust front moving toward your area.",
    "Basınç modellerimiz yerel bir toz fırtınasının oluşacağını öngörüyor.":
      "Our pressure models predict that a local dust storm will form.",
    "Hellas havzasından yükselen bir toz sistemi konumunuza yaklaşıyor.":
      "A dust system rising from the Hellas basin is approaching your position.",
    "<li><b>Sol {0} · Kum fırtınası:</b> {1} Beklenen başlangıç <b>{2}</b>, süre yaklaşık <b>{3}</b>. Rüzgâr hızı {4} km/sa'e ulaşabilir.</li>":
      "<li><b>Sol {0} · Sandstorm:</b> {1} Expected onset <b>{2}</b>, duration about <b>{3}</b>. Wind speed may reach {4} km/h.</li>",
    "Güneş yüzeyinde X sınıfı bir patlama kaydedildi.": "An X-class flare was recorded on the Sun's surface.",
    "SOHO gözlemleri yüksek enerjili bir koronal kütle atımı gösteriyor.":
      "SOHO observations show a high-energy coronal mass ejection.",
    "Güneş rüzgârı parçacık akısında ani artış bekleniyor.":
      "A sudden increase in solar wind particle flux is expected.",
    "<li><b>Sol {0} · Radyasyon dalgası:</b> {1} Parçacık akısı <b>{2}–{3}</b> arasında zirve yapacak. Bu sürede <b>araç dışına çıkmayın</b>.</li>":
      "<li><b>Sol {0} · Radiation wave:</b> {1} The particle flux will peak between <b>{2}–{3}</b>. <b>Do not leave the vehicle</b> during this time.</li>",
    "Uzay hava durumu biriminin günlük değerlendirmesi aşağıdadır.":
      "Below is the space weather unit's daily assessment.",
    "Önümüzdeki iki sol için risk değerlendirmemiz ekte sunulmuştur.":
      "Our risk assessment for the next two sols is attached.",
    "Rutin uzay hava durumu bülteni bilgilerinize sunulur.":
      "The routine space weather bulletin is provided for your information.",
    "Dış görevlerinizi bu pencerelerin dışına planlamanızı öneriyoruz.":
      "We recommend scheduling your EVAs outside these windows.",
    "Numunelerinizi olay öncesinde kargoya yüklemenizi öneriyoruz.":
      "We recommend loading your samples into cargo before the event.",
    "Olay sırasındaki gözlemlerinizi raporlamanız modellerimizi iyileştirecektir.":
      "Reporting your observations during the event will improve our models.",
    '<p>ARES-1 mürettebatına,</p><p>{0}</p>\n  <ul class="ltr-ul">{1}</ul>\n  <p>{2}</p>':
      '<p>To the ARES-1 crew,</p><p>{0}</p>\n  <ul class="ltr-ul">{1}</ul>\n  <p>{2}</p>',
    "Uzay hava durumu bülteni · Sol ": "Space weather bulletin · Sol ",
    "Uzay hava durumu bülteni": "Space weather bulletin",
    '<p>Sayın Komutan,</p>\n  <p>Araç telemetrisinde <b>itki sisteminde anomali</b> tespit ettik: ana motor kontrol kartından veri alınamıyor, yakıt hattında basınç dalgalanması görülüyor. Bu tablo, son fırtınada ciddi bir hasar oluştuğuna işaret ediyor.</p>\n  <p>Henüz sizden bu konuda bir rapor almadık. Lütfen <b>en kısa sürede durum raporu gönderin</b> ve makine dairesindeki tamir tezgâhından onarım prosedürünü başlatın.</p>\n  <div class="ltr-dir"><b>TALİMATLAR</b><ol><li>Makine dairesine inin, ana motora <kbd>E</kbd> ile erişin.</li><li>Prosedürü sırayla uygulayın: kablolar → sigortalar → basınç → ateşleme.</li><li>Duman yoğunsa oksijen seviyenizi kontrol edin.</li></ol></div>':
      '<p>Dear Commander,</p>\n  <p>We have detected an <b>anomaly in the propulsion system</b> in the vehicle telemetry: no data is coming from the main engine control board, and there are pressure fluctuations in the fuel line. This picture points to serious damage during the last storm.</p>\n  <p>We have not yet received a report from you on this. Please <b>send a status report as soon as possible</b> and start the repair procedure from the workbench in the engine room.</p>\n  <div class="ltr-dir"><b>INSTRUCTIONS</b><ol><li>Go down to the engine room and access the main engine with <kbd>E</kbd>.</li><li>Follow the procedure in order: cables → fuses → pressure → ignition.</li><li>If the smoke is heavy, check your oxygen level.</li></ol></div>',
    "Telemetri anomalisi · itki sistemi": "Telemetry anomaly · propulsion system",
    "<p>Komutan,</p><p>Son <b>{0} soldur</b> sizden rapor alamadık. Telemetri aracın çalıştığını gösteriyor, ancak saha günlüğünüzde <b>{1} gönderilmemiş kayıt</b> birikmiş durumda.</p>\n  <p>Bilim ekibimiz ve mürettebat sağlığı birimimiz verilerinizi bekliyor. Kısa da olsa bir durum raporu göndermenizi rica ederiz. Nasıl hissettiğinizi bir iki cümleyle yazmanız da bizim için değerlidir.</p>":
      "<p>Commander,</p><p>We have not received a report from you for the last <b>{0} sols</b>. Telemetry shows the vehicle is operating, but <b>{1} unsent entries</b> have piled up in your field log.</p>\n  <p>Our science team and crew health unit are waiting for your data. We'd ask you to send a status report, however brief. A sentence or two about how you are feeling is also valuable to us.</p>",
    "Rapor talebi": "Report request",
    "<p>Sayın Komutan,</p><p>Telemetri ana motorun çevrimiçi olduğunu ve kargo bölmesinin <b>{0}/{1}</b> dolduğunu doğruluyor. <b>Dünya'ya dönüş penceresi açılmıştır.</b></p>\n  <p>Komuta güvertesindeki navigasyon bilgisayarından dönüş rotasını onaylayabilirsiniz. Kalkıştan önce yaşadıklarınızı içeren son bir rapor göndermeniz, görev arşivi için çok değerli olacaktır.</p><p>Eve hoş geleceksiniz.</p>":
      "<p>Dear Commander,</p><p>Telemetry confirms that the main engine is online and the cargo bay is <b>{0}/{1}</b> full. <b>The return window to Earth is now open.</b></p>\n  <p>You can confirm the return course from the navigation computer on the command deck. Sending one last report about your experiences before launch would be very valuable for the mission archive.</p><p>Welcome home in advance.</p>",
    "Dönüş penceresi açıldı": "Return window open",
    "Çürüyen patatesleri biyoloji ekibi inceleyecek. Çürük patatesi kargo terminalinden bize gönderin.":
      "The biology team will examine the rotten potatoes. Send us a rotten potato from the cargo terminal.",
    "Fırtınalar konusundaki endişenizi anlıyoruz. Fırtınalar her 5 solda bir, sabah saatlerinde başlıyor; uyarı kartı göründüğünde 45 saniyeniz var.":
      "We understand your concern about the storms. They start every 5 sols in the morning hours; when the warning card appears you have 45 seconds.",
    "Toz fırtınası sırasında aracın gövdesi tasarım sınırları içinde kalıyor; içeride güvendesiniz. Sarsıntı normaldir.":
      "During a dust storm the vehicle's hull stays within its design limits; you are safe inside. The shaking is normal.",
    "Motor konusunda yazdıklarınızı itki ekibine ilettik. Duman, kontrol kartındaki yanık sigortalardan ve kopan güç kablolarından kaynaklanıyor; onarım prosedürü bu sırayı izliyor.":
      "We have passed what you wrote about the engine to the propulsion team. The smoke comes from burnt fuses on the control board and severed power cables; the repair procedure follows this order.",
    "İtki ekibi, onarım sırasında aşamaları atlamamanızı rica ediyor: önce kablolar, sonra sigortalar ve ana şalter, ardından basınç kalibrasyonu ve son olarak ateşleme dizisi.":
      "The propulsion team asks you not to skip stages during the repair: first the cables, then the fuses and main switch, then the pressure calibration and finally the ignition sequence.",
    "Oksijen yönetimi hayati önemde: giysi oksijeni %30'un altına indiğinde dış görevi bitirin. Makine dairesindeki O₂ tüpleri kendini yavaşça yeniliyor; tüp seviyesini de takip edin.":
      "Oxygen management is vital: end the EVA when your suit oxygen drops below 30%. The O₂ tanks in the engine room slowly refill themselves; keep an eye on the tank level too.",
    "Su geri dönüştürücü düzenli çalışıyor; stok yavaş da olsa kendiliğinden yenileniyor. Mutfaktan şişe alıp çantanızda taşıyabilirsiniz.":
      "The water recycler is working normally; the stock refills itself, if slowly. You can take bottles from the kitchen and carry them in your bag.",
    "Erzak durumunuzu yakından izliyoruz. Patates yetiştirmek uzun vadeli tek gıda kaynağınız; her hasat ek tohum da veriyor. Mutfak ve yemek kapsülündeki stoku dengeli kullanın.":
      "We are monitoring your food situation closely. Growing potatoes is your only long-term food source; every harvest also yields extra seeds. Use the stock in the kitchen and food capsule sparingly.",
    "Radyasyon dalgaları her 3 solda bir, günün ilk saatlerinde geliyor. Aracın gövde zırhı sizi tamamen koruyor; dalga boyunca içeride kalmanız ya da uyumanız yeterli.":
      "Radiation waves come every 3 sols in the first hours of the day. The vehicle's hull armour protects you completely; staying inside or sleeping through the wave is enough.",
    "Meteorlar öngörülemez, ancak düşmeden önce bir uğultu ve yerde büyüyen bir gölge oluşuyor. Gölgeden uzaklaşın; çarpmadan sonra kraterlerde değerli numuneler bulabilirsiniz.":
      "Meteors are unpredictable, but before they fall there is a rumble and a growing shadow on the ground. Move away from the shadow; after the impact you may find valuable samples in the craters.",
    "Yazdıklarınızı dikkatle okudum. Bu duyguların izole ve yüksek riskli bir ortamda çok doğal olduğunu bilmenizi isterim; zayıflık değil, insan olmanın bir parçası.":
      "I have read what you wrote carefully. I want you to know that these feelings are completely natural in an isolated, high-risk environment; they are not weakness but part of being human.",
    "Günlük bir rutin kurmanızı öneriyorum: düzenli uyku, öğünler ve her sol kısa da olsa bir rapor. Bize yazmak da bir bağ kurmaktır; her mesajınızı okuyoruz. Aileniz iyi ve size selamlarını iletiyorlar.":
      "I suggest building a daily routine: regular sleep, meals and a report every sol, however short. Writing to us is a way of staying connected too; we read every message. Your family is well and sends their regards.",
    "Sağlık durumunuzu kayda aldık. Can değeriniz düştüğünde revirdeki medikitleri kullanın; uyku da iyileşmeyi belirgin şekilde hızlandırıyor.":
      "We have logged your health status. Use the medkits in the sick bay when your health drops; sleep also speeds up recovery noticeably.",
    "Tarım denemeniz biyoloji ekibinin en çok takip ettiği konu. Parsellerinizi sulamayı unutmayın; ıslak toprakta büyüme belirgin şekilde hızlanıyor.":
      "Your farming experiment is the topic the biology team follows most closely. Don't forget to water your plots; growth speeds up noticeably in wet soil.",
    "Dönüş için iki koşul gerekiyor: ana motorun çalışır olması ve kargo bölmesinin {0} birim numuneyle dolması. Bu sağlandığında navigasyon bilgisayarı dönüş rotasını açacak.":
      "Two conditions are needed for the return: a working main engine and a cargo bay filled with {0} sample units. Once these are met, the navigation computer will unlock the return course.",
    "Asıl biz teşekkür ederiz. Kontrol odasında her raporunuz okunurken herkes ekranın başına toplanıyor.":
      "It is we who should thank you. Everyone in the control room gathers around the screen whenever one of your reports is read.",
    "Numune toplama çalışmanız bilim ekibinin önceliği. Yıldız kristalleri metal numunelerin iki katı değerinde; kargoya yüklerken bunu göz önünde bulundurun.":
      "Your sample collection is the science team's priority. Star crystals are worth twice as much as metal samples; keep this in mind when loading the cargo.",
    "Patatesler, ekildikleri toprağın radyasyonu <b>1,0 µSv/h</b> ve üzerindeyse hasatta çürük çıkar. Roketteki <b>alet sandığından</b> radyasyon ölçeri alın ve ekmeden önce toprağı ölçün; ekranda <b>RADYASYON NORMAL</b> görünen yere ekin. Bugüne kadar {0} ölçüm yaptınız, bunların {1} tanesi normal çıktı.":
      "Potatoes come out rotten at harvest if the soil they were planted in reads <b>1.0 µSv/h</b> or more. Take the radiation meter from the rocket's <b>tool chest</b> and measure the soil before planting; plant where the screen shows <b>RADIATION NORMAL</b>. You have taken {0} measurements so far, {1} of them normal.",
    "Giysi oksijeniniz şu anda <b>%{0}</b>, roketteki O₂ tüpü <b>%{1}</b> dolu. Giysi oksijeni %30'un altına düştüğünde rokete dönün ve makine dairesindeki O₂ istasyonundan doldurun. Koşmak tüketimi artırır.":
      "Your suit oxygen is at <b>{0}%</b> and the rocket's O₂ tank is <b>{1}%</b> full. When suit oxygen drops below 30%, return to the rocket and refill at the O₂ station in the engine room. Running increases consumption.",
    "Çantanızda <b>{0}</b>, depoda <b>{1}</b> şişe su var; susuzluk göstergeniz %{2}. Su geri dönüştürücü yaklaşık her {3} dakikada bir şişe üretir. Şişeleri kargo terminalinden ya da mutfaktan alabilirsiniz.":
      "You have <b>{0}</b> bottles of water in your bag and <b>{1}</b> in storage; your thirst gauge is at {2}%. The water recycler produces about one bottle every {3} minutes. You can take bottles from the cargo terminal or the kitchen.",
    "Tokluğunuz %{0}. Çantanızda <b>{1}</b>, depoda <b>{2}</b> patates ve toplam <b>{3}</b> tohum var. Erzak azalıyorsa radyasyonu normal toprağa patates ekin; düzenli sulama büyümeyi hızlandırır.":
      "Your satiety is at {0}%. You have <b>{1}</b> potatoes in your bag, <b>{2}</b> in storage and <b>{3}</b> seeds in total. If supplies run low, plant potatoes in soil with normal radiation; regular watering speeds up growth.",
    "Bir sonraki toz fırtınası <b>Sol {0}</b> için öngörülüyor. Fırtına sırasında anten kapanabilir ve dışarıdaki ana motor arızalanabilir. Uyarı gelince rokete girin ve fırtına geçene kadar dışarı çıkmayın.":
      "The next dust storm is forecast for <b>Sol {0}</b>. During a storm the antenna may be blocked and the main engine outside may fail. When the warning comes, enter the rocket and stay inside until the storm passes.",
    "Bir sonraki güneş kaynaklı radyasyon dalgası <b>Sol {0}</b> için öngörülüyor. Dalga sırasında dışarıda kalmak can kaybettirir; roketin gövdesi koruma sağlar. Şu anki ortam radyasyonu <b>{1} µSv/h</b>.":
      "The next solar radiation wave is forecast for <b>Sol {0}</b>. Staying outside during the wave costs health; the rocket's hull protects you. Current ambient radiation is <b>{1} µSv/h</b>.",
    "Ana motor şu anda <b>çevrimiçi</b>. Fırtınalarda arızalanabileceği için fırtına uyarısında rokete girmeniz yeterlidir.":
      "The main engine is currently <b>online</b>. It can fail in storms, so simply enter the rocket when a storm warning comes.",
    "Ana motor şu anda <b>devre dışı</b>; onarım {0}/4 aşamada. Makine dairesindeki onarım istasyonuna gidip adımları sırasıyla tamamlayın.":
      "The main engine is currently <b>offline</b>; repair is at stage {0}/4. Go to the repair station in the engine room and complete the steps in order.",
    çevrimiçi: "online",
    "devre dışı": "offline",
    "Dünya'ya dönüş için iki koşul gerekiyor: ana motorun çevrimiçi olması (şu an: <b>{0}</b>) ve kargoda en az <b>{1}</b> numune bulunması (şu an: <b>{2}/{3}</b>).":
      "Returning to Earth needs two things: the main engine online (now: <b>{0}</b>) and at least <b>{1}</b> samples in the cargo hold (now: <b>{2}/{3}</b>).",
    "Kargo bölmesinde <b>{0}/{1}</b> numune var. Metal numune 1, yıldız kırıntısı 2 puan sayılır; numuneleri roketin yanında <b>F</b> ile ya da kargo terminalinden yükleyin.":
      "The cargo hold has <b>{0}/{1}</b> samples. A metal sample counts 1 and a star shard 2; load samples next to the rocket with <b>F</b> or from the cargo terminal.",
    "Canınız <b>%{0}</b>. Toplam <b>{1}</b> medikitiniz var; revirden alıp kullanabilirsiniz. Uyumak da canı yavaşça yeniler.":
      "Your health is at <b>{0}%</b>. You have <b>{1}</b> medkits in total; take them from the infirmary. Sleeping also slowly restores health.",
    "Yatakhanedeki ranzada uyuyabilirsiniz. Uyurken zaman hızlanır, can yenilenir; oksijen ve erzak tüketimi devam eder, bu yüzden uyumadan önce stoklarınızı kontrol edin.":
      "You can sleep in the bunk in the crew quarters. Time speeds up and health recovers while you sleep; oxygen and food are still consumed, so check your supplies before sleeping.",
    "Şu an <b>Sol {0}</b>, Mars yerel saati <b>{1}</b>. Bir Mars günü (sol) yaklaşık 24 saat 40 dakika sürer.":
      "It is now <b>Sol {0}</b>, Mars local time <b>{1}</b>. A Mars day (sol) lasts about 24 hours 40 minutes.",
    "Dış sıcaklık şu anda yaklaşık <b>{0} °C</b>. Giysinizin ısıl kontrolü vücut sıcaklığınızı <b>{1} °C</b> civarında tutuyor; gece sıcaklık −75 °C'ye kadar düşebilir.":
      "The outside temperature is about <b>{0} °C</b>. Your suit's thermal control keeps your body temperature around <b>{1} °C</b>; at night it can drop to −75 °C.",
    "Mesajlarınız Mars ile Dünya arasında tek yönde yaklaşık <b>{0} dakikada</b> iletiliyor. Şu an sizi <b>{1}</b> derin uzay anteni izliyor; istasyonlar Dünya döndükçe sırayla devralır.":
      "Your messages take about <b>{0} minutes</b> one way between Mars and Earth. You are currently tracked by the <b>{1}</b> deep space antenna; the stations hand over in turn as Earth rotates.",
    "Meteorlar önceden kesin olarak bilinemez. Düşmeden önce bir uğultu duyulur ve yerde büyüyen bir gölge oluşur; gölgeyi görünce hemen uzaklaşın.":
      "Meteors cannot be predicted precisely. Before impact you hear a rumble and a growing shadow appears on the ground; move away as soon as you see it.",
    "Şu anda <b>{0}</b> altınınız var. Roketteki geliştirme istasyonunda altınla roketinizi ve ekipmanınızı güçlendirebilirsiniz.":
      "You have <b>{0}</b> gold. Use it at the rocket's upgrade station to improve your rocket and equipment.",
    "Tüm görevleri tamamladınız. Dönüş penceresi açıksa rokete binip Dünya'ya dönebilirsiniz.":
      "You have completed all missions. If the return window is open, board the rocket and head back to Earth.",
    "Şu anki göreviniz: <b>{0}</b> — {1}. Önerimiz: {2}":
      "Your current task: <b>{0}</b> — {1}. Our advice: {2}",
    "Duygularınızı paylaştığınız için teşekkür ederiz. Uzun görevlerde bu çok doğal. Davranış sağlığı ekibimiz sizi takip ediyor; düzenli uyku, kısa molalar ve hedeflerinizi küçük adımlara bölmek yardımcı olur. Yalnız değilsiniz, her mesajınız burada okunuyor.":
      "Thank you for sharing how you feel. This is very natural on long missions. Our behavioural health team is with you; regular sleep, short breaks and breaking goals into small steps help. You are not alone; every message you send is read here.",
    "Ben <b>GDY-1</b>, ARES Görev Kontrol Merkezi'nin görev destek yapay zekâsıyım. Raporlarınızdaki soruları canlı görev verileriyle eşleştirip resmî yanıt hazırlıyorum; ayrıntılı değerlendirmeler uzman ekiplerden ayrıca gelir.":
      "I am <b>GDY-1</b>, the mission support AI of ARES Mission Control. I match the questions in your reports with live mission data and prepare official answers; detailed assessments come separately from the expert teams.",
    "Merhaba Komutan. Mesajınız alındı; sinyal kalitesi iyi. Sormak istediğiniz her şeyi raporunuza yazabilirsiniz.":
      "Hello, Commander. Your message was received and the signal quality is good. You can write anything you want to ask in your report.",
    "Rica ederiz Komutan. Görev Kontrol her an hattadır.":
      "You're welcome, Commander. Mission Control is always on the line.",
    "Sorunuzu kayda aldım; görev veritabanında doğrudan eşleşen bir konu bulamadım ve uzman ekiplere ilettim.":
      "I have logged your question; I found no direct match in the mission database and forwarded it to the expert teams.",
    "Sorunuzu kayda aldım; görev veritabanında doğrudan eşleşen bir konu bulamadım ve uzman ekiplere ilettim. Bu arada şu anki göreviniz: <b>{0}</b> — {1}.":
      "I have logged your question; I found no direct match in the mission database and forwarded it to the expert teams. Meanwhile, your current task: <b>{0}</b> — {1}.",
    '<div class="ai-qa"><div class="ai-q"><span>SORU {0}</span>«{1}»</div><div class="ai-a"><span>YANIT</span><p>{2}</p></div></div>':
      '<div class="ai-qa"><div class="ai-q"><span>QUESTION {0}</span>«{1}»</div><div class="ai-a"><span>ANSWER</span><p>{2}</p></div></div>',
    '<p>Sayın Komutan,</p>\n  <p><b>{0}</b> numaralı raporunuzdaki not, {1} anteni üzerinden alınarak <b>GDY-1 Görev Destek Yapay Zekâsı</b> tarafından canlı görev verileriyle (Sol {2} · {3}) değerlendirilmiştir. Yanıtlar aşağıdadır.</p>\n  {4}\n  <p class="ai-ft">Bu yanıt otomatik olarak hazırlanmış ve Görev Kontrol adına resmî bilgilendirme niteliğindedir. Uzman ekiplerin ayrıntılı değerlendirmesi rapor yanıtıyla ayrıca iletilecektir.</p>':
      '<p>Dear Commander,</p>\n  <p>The note in your report <b>{0}</b> was received via the {1} antenna and assessed with live mission data (Sol {2} · {3}) by <b>GDY-1, the Mission Support AI</b>. The answers are below.</p>\n  {4}\n  <p class="ai-ft">This reply was generated automatically and is an official notice on behalf of Mission Control. The expert teams\' detailed assessment will follow with the report reply.</p>',
    "Sorunuza yanıt · ": "Answer to your question · ",
    '<div class="ltr-dir"><b>TALİMATLAR</b><ol>{0}</ol></div>':
      '<div class="ltr-dir"><b>INSTRUCTIONS</b><ol>{0}</ol></div>',
    "Sol {0} fırtınasına ait verileriniz Uzay Hava Durumu Birimi tarafından incelendi. Yörünge görüntüleriyle karşılaştırıldığında bölgenizdeki toz yoğunluğunun optik derinlik <b>τ≈{1}</b> seviyesine ulaştığı anlaşılıyor.":
      "Your data from the sol {0} storm has been reviewed by the Space Weather Unit. Compared with orbital images, the dust density in your area appears to have reached an optical depth of <b>τ≈{1}</b>.",
    "Gönderdiğiniz fırtına gözlemleri, bu enlemde kaydedilen en yoğun yerel toz olaylarından biriyle uyumlu. Rüzgâr hızının anlık olarak <b>{0} km/sa</b>'e çıktığını tahmin ediyoruz.":
      "The storm observations you sent match one of the most intense local dust events recorded at this latitude. We estimate the wind speed briefly reached <b>{0} km/h</b>.",
    "Fırtına süresince toplanan basınç ve görüş verileri modelimizi doğrulamamızı sağladı; tahmin hatamız bu veriyle <b>%{0}</b> azaldı.":
      "The pressure and visibility data collected during the storm allowed us to validate our model; with this data our forecast error dropped by <b>{0}%</b>.",
    "Kayıtlar fırtına sırasında araç dışında yaklaşık <b>{0}</b> geçirdiğinizi gösteriyor. Bu, EVA güvenlik kuralının (GK-EVA-7) açıkça ihlalidir; lütfen bir daha tekrarlamayın.":
      "The logs show that you spent about <b>{0}</b> outside the vehicle during the storm. This is a clear violation of the EVA safety rule (GK-EVA-7); please do not repeat it.",
    "Fırtına boyunca araç içinde kalmanız prosedüre tam uygundur; teşekkür ederiz.":
      "Staying inside the vehicle throughout the storm is fully in line with procedure; thank you.",
    "Mürettebatın fırtınayı araç içinde geçirmesi doğru karardı.":
      "The crew's decision to ride out the storm inside the vehicle was the right one.",
    " Fırtınanın ana motora verdiği hasar ayrıca itki ekibine iletilmiştir.":
      " The damage the storm caused to the main engine has also been forwarded to the propulsion team.",
    "Fırtına uyarı kartı göründüğünde <b>45 saniye</b> içinde hava kilidine dönün.":
      "When the storm warning card appears, return to the airlock within <b>45 seconds</b>.",
    "Sonraki fırtına <b>Sol {0}</b>, {1} için öngörülüyor; o sol dış görevleri fırtına öncesine planlayın.":
      "The next storm is forecast for <b>Sol {0}</b>, {1}; plan that sol's EVAs before the storm.",
    "Fırtına öncesi çantanızdaki numuneleri kargoya yükleyin.":
      "Load the samples in your bag into the cargo bay before the storm.",
    "Fırtına sırasında komuta güvertesindeki ön camdan görüş gözlemi yapıp raporlayın.":
      "During the storm, observe visibility through the windshield on the command deck and report it.",
    "Fırtına sonrası oksijen tüpü seviyesini kontrol edin; filtreler tozla yüklenmiş olabilir.":
      "After the storm, check the oxygen tank level; the filters may be clogged with dust.",
    "İtki ekibimiz bildirdiğiniz arızayı telemetriyle eşleştirdi. Toz girişinin yakıt hattı vanasında basınç dalgalanmasına, ardından kontrol kartında aşırı akıma yol açtığı değerlendiriliyor.":
      "Our propulsion team matched the failure you reported with the telemetry. Dust ingress is believed to have caused pressure fluctuations at the fuel line valve, followed by overcurrent on the control board.",
    "Arıza raporunuz itki ekibinde öncelikli olarak ele alındı. Ön analiz: fırtına esnasındaki titreşim güç kablolarını soketlerinden kopardı, oluşan kısa devre sigortaları yaktı.":
      "Your failure report was handled as a priority by the propulsion team. Preliminary analysis: vibration during the storm tore the power cables from their sockets, and the resulting short circuit blew the fuses.",
    "Bildirdiğiniz motor arızası, test tesisimizdeki yedek motorda simüle edildi. Aynı belirtileri (duman, kalkış kilidi, kontrol kartı sessizliği) elde ettik; arıza tipi doğrulandı.":
      "The engine failure you reported was simulated on the backup engine at our test facility. We reproduced the same symptoms (smoke, launch lock, silent control board); the failure type is confirmed.",
    "<b>Bu yanıt hazırlanırken alınan telemetri motorun yeniden çevrimiçi olduğunu gösteriyor — tebrikler.</b>":
      "<b>Telemetry received while this reply was being prepared shows the engine is back online — congratulations.</b>",
    "<b>Güncel telemetri motorun hâlâ devre dışı olduğunu gösteriyor</b> (tamamlanan aşama: {0}/4). Onarım bitmeden dönüş penceresi açılmayacaktır.":
      "<b>Current telemetry shows the engine is still offline</b> (stages completed: {0}/4). The return window will not open until the repair is finished.",
    "Motor çalışırken makine dairesinde olağandışı ses ya da duman görürseniz derhal raporlayın.":
      "If you notice unusual noise or smoke in the engine room while the engine is running, report it immediately.",
    "Makine dairesinde ana motora ya da tamir tezgâhına <kbd>E</kbd> ile erişin.":
      "In the engine room, access the main engine or the workbench with <kbd>E</kbd>.",
    "Prosedür sırası: <b>kablolar → sigortalar + ana şalter → basınç kalibrasyonu → ateşleme</b>. Tamamlanan aşamalar kaydedilir.":
      "Procedure order: <b>cables → fuses + main switch → pressure calibration → ignition</b>. Completed stages are saved.",
    "Basınç aşamasında ibre yeşil bölgedeyken kilitleyin; acele etmeyin.":
      "In the pressure stage, lock while the needle is in the green zone; don't rush.",
    "Duman yoğunken uzun süre makine dairesinde kalmayın.":
      "Don't stay in the engine room for long while the smoke is heavy.",
    "Onarım kayıtlarınızı inceledik: tüm aşamalar nominal değerlerde tamamlanmış. Bu, Mars yüzeyinde mürettebat tarafından yapılan ilk tam itki onarımıdır; tebrikler.":
      "We reviewed your repair logs: all stages were completed at nominal values. This is the first full propulsion repair carried out by a crew on the surface of Mars; congratulations.",
    "Motorun yeniden çevrimiçi olması tüm kontrol odasında alkışla karşılandı. Onarım verileriniz üretici firmaya iletildi; sonraki araç tasarımında toz filtresi revize edilecek.":
      "The engine coming back online was met with applause across the control room. Your repair data has been passed to the manufacturer; the dust filter will be revised in the next vehicle design.",
    "Sonraki fırtınada motor bölmesinin sızdırmazlığını gözlemleyin.":
      "During the next storm, observe whether the engine compartment stays sealed.",
    "Onarım sırasında fark ettiğiniz her şeyi notunuza ekleyin; mühendislerimiz için çok değerli.":
      "Add everything you noticed during the repair to your note; it is very valuable to our engineers.",
    "Dozimetre verileriniz Uzay Hava Durumu Birimi ve Uçuş Cerrahı tarafından birlikte değerlendirildi.":
      "Your dosimeter data was assessed jointly by the Space Weather Unit and the Flight Surgeon.",
    "Parçacık dalgasına ait sensör verileriniz başarıyla işlendi; olay, Güneş'teki bir koronal kütle atımıyla eşleştirildi.":
      "Your sensor data from the particle wave was processed successfully; the event was matched to a coronal mass ejection on the Sun.",
    " Kayıtlara göre dalga sırasında araç dışında <b>{0}</b> kaldınız; tahmini alınan doz <b>~{1} mSv</b>. Bu değer yıllık limitinizin önemli bir kısmıdır. Sağlık kaydınıza işlendi.":
      " According to the logs you were outside the vehicle for <b>{0}</b> during the wave; the estimated dose received is <b>~{1} mSv</b>. This is a significant part of your annual limit. It has been entered in your health record.",
    " Dalga boyunca zırhlı gövde içinde kalmanız sayesinde aldığınız doz ihmal edilebilir düzeyde (<b>&lt;1 mSv</b>). Mükemmel.":
      " Because you stayed inside the armoured hull during the wave, the dose you received is negligible (<b>&lt;1 mSv</b>). Excellent.",
    "Sonraki radyasyon dalgası <b>Sol {0}</b>, {1}–{2} arasında bekleniyor.":
      "The next radiation wave is expected on <b>Sol {0}</b>, between {1}–{2}.",
    "Dalga sırasında araç içinde kalın; uyumak zamanı güvenle geçirmenin en iyi yolu.":
      "Stay inside the vehicle during the wave; sleeping is the best way to pass the time safely.",
    "Doz aldıysanız revirdeki medikiti kullanın.": "If you received a dose, use the medkit in the sick bay.",
    "Ekran yeşile döndüğünde ve kenarlarda ışıma başladığında derhal rokete dönün.":
      "When the screen turns green and the edges start to glow, return to the rocket immediately.",
    "Bildirdiğiniz <b>{0}</b> meteor çarpması bilim ekibinde büyük heyecan yarattı. Taze kraterler, Mars yüzeyinin yaşı ve iç yapısı hakkında eşsiz bilgi sağlıyor.":
      "The <b>{0}</b> meteor impacts you reported caused great excitement in the science team. Fresh craters provide unique information about the age and internal structure of the Martian surface.",
    "Gezegen Bilimi Ekibi, raporunuzdaki {0} çarpmayı yörünge sismik verileriyle eşleştirdi. Çarpışma enerjilerinin her biri için birkaç ton TNT eşdeğeri olduğu hesaplanıyor.":
      "The Planetary Science Team matched the {0} impacts in your report with orbital seismic data. The impact energy of each is calculated at several tonnes of TNT equivalent.",
    " Ancak en yakın çarpmanın yalnızca <b>~{0} m</b> mesafede olması ciddi bir risk; uçuş cerrahımız endişeli.":
      " However, the closest impact being only <b>~{0} m</b> away is a serious risk; our flight surgeon is concerned.",
    " En yakın çarpma ~{0} m mesafede; güvenli sınırlar içinde.":
      " The closest impact was ~{0} m away; within safe limits.",
    "Uğultu duyduğunuzda yerdeki <b>büyüyen gölgeyi</b> arayın ve ondan uzaklaşın.":
      "When you hear a rumble, look for the <b>growing shadow</b> on the ground and move away from it.",
    "Taze kraterler bir süre sıcak kalır; tütmesi bitince numune arayın.":
      "Fresh craters stay hot for a while; search for samples once they stop smoking.",
    "Kraterlerde bulduğunuz yıldız kristallerini öncelikle kargoya yükleyin.":
      "Load the star crystals you find in craters into the cargo bay first.",
    "Bildirdiğiniz <b>{0}</b> bulguları bilim ekibinde olağanüstü bir heyecan yarattı. Bu mineraller yörünge spektrometreleriyle yalnızca dolaylı olarak tespit edilmişti; yerinde analiz ilk kez yapıldı.":
      "The <b>{0}</b> finds you reported caused extraordinary excitement in the science team. These minerals had only been detected indirectly by orbital spectrometers; this is the first in-situ analysis.",
    "Gezegen Bilimi Ekibi raporladığınız {0} örneklerini inceledi. Kristal yapısı, bölgede geçmişte hidrotermal etkinlik olduğuna işaret ediyor.":
      "The Planetary Science Team examined the {0} specimens you reported. The crystal structure points to past hydrothermal activity in the area.",
    "Uzak bölgelerde tarayıcı sinyallerini takip etmeye devam edin; ancak oksijen seviyenizi dönüş için yeterli tutun.":
      "Keep following the scanner signals in remote areas, but keep enough oxygen for the return.",
    "Titanyum cevherini roket zırhı için, olivin kristallerini EVA giysisi için ayırın.":
      "Set aside the titanium ore for the rocket armour and the olivine crystals for the EVA suit.",
    "Ares taşı son derece nadir; bulduğunuz her parça bilimsel olarak paha biçilemez.":
      "Ares stone is extremely rare; every piece you find is scientifically priceless.",
    "Gönderdiğiniz {0} metal{1} numunesinin spektral ön verisi, yüksek demir-nikel oranına işaret ediyor.":
      "Preliminary spectral data from the {0} metal samples{1} you sent points to a high iron-nickel ratio.",
    ", {0} kristal": ", {0} crystals",
    "Numune verileriniz ({0} metal{1}) laboratuvarımızdaki Mars göktaşı koleksiyonuyla karşılaştırılıyor; ilk sonuçlar umut verici.":
      "Your sample data ({0} metal{1}) is being compared with the Martian meteorite collection in our laboratory; the first results are promising.",
    "Yıldız kristallerinin kökeni ekibimizde tartışma yarattı; hidratlı mineral olasılığı, geçmişte sıvı su bulunduğuna işaret edebilir.":
      "The origin of the star crystals has sparked debate in our team; the possibility of hydrated minerals may indicate that liquid water existed in the past.",
    "Kristallerin parlaklık spektrumu bilinen hiçbir Mars mineraliyle tam eşleşmiyor. Lütfen toplamaya devam edin.":
      "The brightness spectrum of the crystals doesn't fully match any known Martian mineral. Please keep collecting.",
    "Kargo hedefi: <b>{0}</b> birim · güncel durum <b>{1}/{2}</b>. Numuneleri komuta güvertesindeki stok terminalinden yükleyin.":
      "Cargo target: <b>{0}</b> units · current status <b>{1}/{2}</b>. Load the samples from the stock terminal on the command deck.",
    "Çürümenin nedeni toprağın yüksek radyasyonu. Ekimden önce radyasyon ölçerle toprağı ölçün.":
      "The rot is caused by high soil radiation. Measure the soil with the radiation meter before planting.",
    "Çürüyen hasat bildiriminiz biyoloji ekibine iletildi. Çürük patatesi kargo terminalinden bize gönderin, inceleyip sonucu bildirelim.":
      "Your rotten harvest report has been passed to the biology team. Send us a rotten potato from the cargo terminal and we will report back.",
    "Ekimden önce toprağı ölç: <b>1,0 µSv/h</b> altı güvenli.":
      "Measure the soil before planting: below <b>1.0 µSv/h</b> is safe.",
    "Çürük patates örneğini çantanızda tutun.": "Keep a rotten potato sample in your bag.",
    "Aynı parsele yeniden ekim yapmayın.": "Do not replant the same plot.",
    "Tarım verileriniz ({0} ekim, {1} hasat) Biyorejeneratif Yaşam Destek ekibinin en çok beklediği veriler arasında. Mars regolitinde patates yetiştirmek, uzun süreli görevlerin anahtarı.":
      "Your farming data ({0} plantings, {1} harvests) is among the data the Bioregenerative Life Support team has been waiting for most. Growing potatoes in Martian regolith is the key to long-duration missions.",
    "Biyoloji ekibi raporunuzdaki ekim/hasat oranını ({0}/{1}) Dünya'daki kontrol deneyiyle karşılaştırıyor. Regolitteki perkloratlara rağmen büyümenin sürmesi çok önemli bir bulgu.":
      "The biology team is comparing the planting/harvest ratio in your report ({0}/{1}) with the control experiment on Earth. That growth continues despite the perchlorates in the regolith is a very important finding.",
    "Parselleri düzenli sulayın; ıslak toprakta büyüme hızlanır.":
      "Water the plots regularly; growth speeds up in wet soil.",
    "Her hasattan gelen tohumu yeniden ekerek döngüyü sürdürün.":
      "Keep the cycle going by replanting the seed from every harvest.",
    "Uyurken mahsul de 2 kat hızlı büyür; gece ekim yapmayı düşünün.":
      "Crops also grow 2× faster while you sleep; consider planting at night.",
    "Fırtınadan sonra parselleri kontrol edin.": "Check the plots after the storm.",
    "Lojistik kayıtları güncellendi. Güncel kargo durumu <b>{0}/{1}</b>. ":
      "Logistics records updated. Current cargo status <b>{0}/{1}</b>. ",
    "Kargo hedefi tamamlandı; dönüş için yalnızca araç sistemlerinin hazır olması gerekiyor.":
      "The cargo target has been met; for the return, only the vehicle systems need to be ready.",
    "Hedefe ulaşmak için numune toplamaya devam edin.": "Keep collecting samples to reach the target.",
    "Mürettebat sağlığı birimi raporunuzdaki kritik değerleri ciddiyetle inceledi.":
      "The crew health unit reviewed the critical values in your report seriously.",
    "Yaşam destek uyarılarınız Uçuş Cerrahı'na öncelikli olarak iletildi.":
      "Your life support alerts were forwarded to the Flight Surgeon as a priority.",
    " Kayda geçen değerler: ": " Recorded values: ",
    "<b>erzak tükenmesi</b>": "<b>supplies exhausted</b>",
    "Giysi oksijeni %30'un altına inince dış görevi sonlandırın; O₂ tüpleri makine dairesinde.":
      "End the EVA when your suit oxygen drops below 30%; the O₂ tanks are in the engine room.",
    "Su seviyeniz için mutfaktan şişe alın ve çantanızda yedek taşıyın.":
      "For your water level, take bottles from the kitchen and carry spares in your bag.",
    "Tokluk düştüğünde mutfakta ya da yemek kapsülünde patates tüketin.":
      "When your food level drops, eat potatoes in the kitchen or at the food capsule.",
    "Can değeriniz düşükken revirde medikit kullanın ve dinlenin.":
      "When your health is low, use a medkit in the sick bay and rest.",
    "Erzak tükendi: önceliğiniz tarım olmalı. Su geri dönüştürücü stoku yavaşça yeniliyor.":
      "Supplies are exhausted: farming must be your priority. The water recycler slowly replenishes the stock.",
    "Notunuz ilgili birimlere dağıtıldı. Konuyu daha ayrıntılı açıklarsanız uzman ekiplerimiz size daha net yanıt verebilir.":
      "Your note has been distributed to the relevant units. If you explain the matter in more detail, our specialist teams can give you a clearer answer.",
    "Notunuzu kayda aldık ve görev günlüğüne işledik. Ekip toplantımızda ele alınacak.":
      "We have logged your note and entered it in the mission log. It will be discussed at our team meeting.",
    "Sorularınızın tümüne yanıt vermeye çalıştık; eksik kalan bir nokta olursa bir sonraki raporunuzda tekrar sorun.":
      "We tried to answer all of your questions; if anything was left out, ask again in your next report.",
    "Sorunuzu dikkate aldık. Daha fazla ayrıntı için bir sonraki raporunuzda bize koşullarınızı anlatın.":
      "We have taken note of your question. For more detail, describe your conditions in your next report.",
    "<h4>{0}. ✍ Mürettebat notunuz</h4>{1}": "<h4>{0}. ✍ Your crew note</h4>{1}",
    '<span class="ok">ÇEVRİMİÇİ</span>': '<span class="ok">ONLINE</span>',
    '<span class="bad">DEVRE DIŞI</span> · onarım ': '<span class="bad">OFFLINE</span> · repair ',
    "<li>Ana motor: {0}</li>": "<li>Main engine: {0}</li>",
    '<span class="bad">· KRİTİK</span>': '<span class="bad">· CRITICAL</span>',
    "<li>Erzak: su {0}, patates {1} {2}</li>": "<li>Supplies: water {0}, potatoes {1} {2}</li>",
    "<li>O₂ tüpü: %{0} · kargo: {1}/{2}</li>": "<li>O₂ tank: {0}% · cargo: {1}/{2}</li>",
    "ACİL önceliğiyle işaretlenen raporunuz alınır alınmaz görev ekibi toplandı ve tüm birimler raporunuzu öncelikli olarak inceledi.":
      "As soon as your report marked URGENT arrived, the mission team convened and all units reviewed it as a priority.",
    "ACİL raporunuz üzerine kontrol odasında olağanüstü vardiya başlatıldı.":
      "An emergency shift was started in the control room in response to your URGENT report.",
    "Raporunuz ilgili ekiplerimiz tarafından ayrıntılı olarak incelenmiştir.":
      "Your report has been reviewed in detail by the relevant teams.",
    "Raporunuz tüm birimlere dağıtılmış ve değerlendirilmiştir.":
      "Your report has been distributed to and assessed by all units.",
    "Gönderdiğiniz veriler kontrol odasında ekiplerimiz tarafından tek tek ele alındı.":
      "The data you sent was examined item by item by our teams in the control room.",
    "Sayın Komutan,": "Dear Commander,",
    "ARES-1 Komutanına,": "To the Commander of ARES-1,",
    "Değerli Komutanımız,": "Our esteemed Commander,",
    "Çalışmalarınız için tüm ekip adına teşekkür ederiz. Güvende kalın.":
      "On behalf of the whole team, thank you for your work. Stay safe.",
    "Dünya'da hepimiz sizinle gurur duyuyoruz. Bir sonraki raporunuzu bekliyoruz.":
      "All of us on Earth are proud of you. We look forward to your next report.",
    "Unutmayın: yalnız değilsiniz, her adımınızı izliyoruz. Bir sonraki raporunuzu bekliyoruz.":
      "Remember: you are not alone, we are following your every step. We look forward to your next report.",
    '<p>{0}</p>\n  <p><b>Sol {1}</b> tarihli <b>{2}</b> numaralı raporunuz {3} üzerinden <b>{4} MB</b> olarak eksiksiz alınmıştır. {5}</p>\n  {6}\n  <h4>{7}. 📊 Görev durumu değerlendirmesi</h4><ul class="ltr-ul">{8}</ul>\n  <p>Bilim ekibi bu paketi <b>{9} bilim puanı</b> olarak değerlendirdi. Görev bilim hedefinin <b>%{10}</b>\'i tamamlandı.</p>\n  <div class="ltr-sci"><i style="width:{11}%"></i></div>\n  <p>{12}</p>':
      '<p>{0}</p>\n  <p>Your report no. <b>{2}</b> dated <b>Sol {1}</b> was received in full via {3} as <b>{4} MB</b>. {5}</p>\n  {6}\n  <h4>{7}. 📊 Mission status assessment</h4><ul class="ltr-ul">{8}</ul>\n  <p>The science team rated this package at <b>{9} science points</b>. <b>{10}%</b> of the mission\'s science goal has been completed.</p>\n  <div class="ltr-sci"><i style="width:{11}%"></i></div>\n  <p>{12}</p>',
    "Yanıt: ": "Re: ",
    "Mürettebat notu": "Crew note",
    " (Sol ": " (Sol ",
    "EK-A · Önümüzdeki 5 sol tahmini": "ANNEX A · Forecast for the next 5 sols",
    Avustralya: "Australia",
    "Batı Avustralya · Perth'in 140 km kuzeyi": "Western Australia · 140 km north of Perth",
    İspanya: "Spain",
    "Ávila · Madrid'in 77 km batısı": "Ávila · 77 km west of Madrid",
    "Malargüe (DSA 3)": "Malargüe (DSA 3)",
    Arjantin: "Argentina",
    "Mendoza · Malargüe'nin 30 km güneyi": "Mendoza · 30 km south of Malargüe",
    "ARES Görev Kontrol Merkezi": "ARES Mission Control Center",
    "GÖREV YÖNETİMİ": "MISSION MANAGEMENT",
    "Uçuş direktörü ve iletişim sorumlusuyla görev takibi":
      "Mission monitoring with the Flight Director and the communications officer",
    "Raporları inceler, resmî yanıtları ve talimatları yazar":
      "Reviews reports and writes official replies and instructions",
    "Mürettebat sağlığı ve uzay hava durumu değerlendirmesi": "Crew health and space weather assessment",
    "Derin Uzay Anten Ağı": "Deep Space Antenna Network",
    "Avustralya · İspanya · Arjantin": "Australia · Spain · Argentina",
    "Üç 35 m anteni sırayla Mars'a yönlendirir": "Points the three 35 m antennas at Mars in turn",
    "Her ~8 Mars saatinde bir istasyon devri": "A station handover every ~8 Mars hours",
    "Delta-DOR ile hassas konum ve sinyal kalitesi takibi":
      "Precise positioning and signal quality tracking with Delta-DOR",
    "Kullanıcı segmenti": "User segment",
    "VERİ ALIMI": "DATA RECEPTION",
    "Gelen telemetri ve bilim paketlerinin işlenmesi":
      "Processing of incoming telemetry and science packages",
    "Numune, hava ve radyasyon verilerinin arşivlenmesi": "Archiving of sample, weather and radiation data",
    "Verilerin bilim ekiplerine dağıtılması": "Distribution of the data to the science teams",
    '<div class="np-crew"><div class="gs-mk sm">ARES</div><div><b>Komutan · ARES-1</b><small>ARES-1/CDR · Mars yüzey görevi</small></div></div>':
      '<div class="np-crew"><div class="gs-mk sm">ARES</div><div><b>Commander · ARES-1</b><small>ARES-1/CDR · Mars surface mission</small></div></div>',
    "⚖️ Kütle": "⚖️ Mass",
    "⚡ Güç": "⚡ Power",
    "Fırtına: panel üretimi düştü": "Storm: panel output has dropped",
    "Güneş panelleri": "Solar panels",
    "RTG · sabit güç": "RTG · constant power",
    "💰 Bütçe": "💰 Budget",
    "💾 Veri": "💾 Data",
    "Kapasite aşılıyor: bilimin %": "Over capacity: %",
    "'i kayıp": " of science lost",
    "📡 İletişim": "📡 Communications",
    "Gönderilen: ": "Sent: ",
    " gün transfer": " days of transfer",
    '<div class="gs-sec">Tasarım kaynakları · canlı</div>\n    <div class="ar-kv">{0}\n      {1}\n      {2}\n      {3}\n      {4}\n      {5}</div>':
      '<div class="gs-sec">Design resources · live</div>\n    <div class="ar-kv">{0}\n      {1}\n      {2}\n      {3}\n      {4}\n      {5}</div>',
    "Fırlatma segmenti": "Launch segment",
    "Görevi uzaya taşıyan fırlatma aracı ve fırlatma hizmetleri.":
      "The launch vehicle and launch services that place the mission in space.",
    Araç: "Vehicle",
    "ARES-1 iniş ve dönüş roketi": "ARES-1 landing and return rocket",
    Transfer: "Transfer",
    "≈ 214 gün · 225 milyon km": "≈ 214 days · 225 million km",
    Varış: "Arrival",
    "Mars · ekvator ovası": "Mars · equatorial plain",
    "Uzay segmenti": "Space segment",
    "Görevi yürüten araç, alet ve ekipman: roket, kıyafet ve numune sistemleri.":
      "The vehicle, instruments and equipment that carry out the mission: rocket, suit and sample systems.",
    NOMİNAL: "NOMINAL",
    ARIZA: "FAILURE",
    Çalışıyor: "Operational",
    "Arızalı · ": "Damaged · ",
    Kıyafet: "Suit",
    "Yer segmenti": "Ground segment",
    "İletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları ve görev kontrol merkezleri.":
      "Ground stations and mission control centers responsible for communications, data reception and mission management.",
    BAĞLI: "CONNECTED",
    KESİK: "DOWN",
    "Görev kontrol": "Mission control",
    "Işık gecikmesi": "Light delay",
    "Görev verilerini analiz eden ve kullanan bilim insanları ve diğer kullanıcılar.":
      "Scientists and other users who analyse and apply the mission's data.",
    "Gönderilen rapor": "Reports sent",
    "Gönderilen veri": "Data sent",
    "Bilim hedefi": "Science goal",
    "İlk görev fikri": "Initial mission idea",
    "Bilim sorusu: Mars'ta insan yaşamı mümkün mü?": "Science question: is human life possible on Mars?",
    "Tek kişilik mürettebat ve tek araçla görev mümkün mü?":
      "Is the mission possible with a one-person crew and a single vehicle?",
    "Ödünleşim çalışmaları": "Trade studies",
    "Güç, kütle, iletişim ve koruma seçeneklerinin karşılaştırılması":
      "Comparison of power, mass, communications and protection options",
    "Nokta tasarım": "Point design",
    "ARES-1 görev mimarisi": "ARES-1 mission architecture",
    '<div class="ar-cml now"><em>FAZ E</em><b>Operasyon</b><small>Mars yüzey operasyonları · Sol {0}</small></div>':
      '<div class="ar-cml now"><em>PHASE E</em><b>Operations</b><small>Mars surface operations · Sol {0}</small></div>',
    Kavram: "Concept",
    Fırlatma: "Launch",
    "214 gün": "214 days",
    "Giriş · İniş": "Entry · Landing",
    Yüzey: "Surface",
    Dönüş: "Return",
    "Rota açık": "Route open",
    Kilitli: "Locked",
    İtki: "Propulsion",
    "Ana motor çalışıyor": "Main engine running",
    "Ana motor arızalı": "Main engine failed",
    "Yaşam desteği": "Life support",
    "O₂ tüpü %": "O₂ tank %",
    " · su ": " · water ",
    " · patates ": " · potatoes ",
    "Isıl ve radyasyon koruması": "Thermal and radiation protection",
    " · radyasyon hasarı %": " · radiation damage %",
    Yapı: "Structure",
    "Fırtına kalkanı ": "Storm shield ",
    "Seviye ": "Level ",
    Yok: "None",
    " · arıza riski %": " · failure risk %",
    İletişim: "Communications",
    " · bağlı": " · connected",
    "Bağlantı kesik": "Link down",
    "Görev operasyonları": "Mission operations",
    "Görev ": "Mission ",
    Risk: "Risk",
    "Sonraki fırtına Sol ": "Next storm Sol ",
    " · radyasyon Sol ": " · radiation Sol ",
    '<div class="gs ar">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>ARES-1 GÖREV MİMARİSİ</b>\n      <p>ARES-1; fırlatma, uzay, yer ve kullanıcı segmentlerinden oluşur. Kavram, olgunluk seviyeleri boyunca fikirden nokta tasarıma geliştirildi. Alt sistemler mühendislik disiplinlerine göre ayrı ayrı izlenir.</p></div></div>\n    <div class="gs-sec">Görev segmentleri</div>\n    <div class="ar-segs">{0}</div>\n    {1}\n    <div class="gs-sec">Görev zaman çizelgesi</div>\n    <div class="ar-tls">{2}</div>\n    <div class="gs-sec">Kavram olgunluğu</div>\n    <div class="ar-cmls">{3}</div>\n    <div class="gs-sec">Alt sistem durumu</div>\n    <div class="ar-subs">{4}</div>\n  </div>':
      '<div class="gs ar">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>ARES-1 MISSION ARCHITECTURE</b>\n      <p>ARES-1 consists of the launch, space, ground and user segments. The concept was developed from an idea to a point design through maturity levels. Subsystems are tracked separately by engineering discipline.</p></div></div>\n    <div class="gs-sec">Mission segments</div>\n    <div class="ar-segs">{0}</div>\n    {1}\n    <div class="gs-sec">Mission timeline</div>\n    <div class="ar-tls">{2}</div>\n    <div class="gs-sec">Concept maturity</div>\n    <div class="ar-cmls">{3}</div>\n    <div class="gs-sec">Subsystem status</div>\n    <div class="ar-subs">{4}</div>\n  </div>',
    '<b class="sat-on">GÖRÜŞ ALANINDA</b>': '<b class="sat-on">IN VIEW</b>',
    '<b class="sat-off">UFUK ALTINDA</b>': '<b class="sat-off">BELOW HORIZON</b>',
    "Geçiş sürüyor · {0} kaldı": "Pass in progress · {0} left",
    "{0} sonra · {1} sürecek": "in {0} · lasts {1}",
    "ufkun altında (": "below horizon (",
    '<div class="sat">\n    <div class="sat-map">\n      <svg viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">\n        <defs><linearGradient id="satBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a2a1c"/><stop offset=".5" stop-color="#8a3f26"/><stop offset="1" stop-color="#4a2216"/></linearGradient>\n          <radialGradient id="satGl"><stop offset="0" stop-color="#7fe7ff" stop-opacity=".9"/><stop offset="1" stop-color="#7fe7ff" stop-opacity="0"/></radialGradient></defs>\n        <rect width="360" height="180" fill="url(#satBg)"/>\n        <g class="sat-grid">{0}</g>\n        <line x1="0" y1="90" x2="360" y2="90" class="sat-eq"/>\n        <ellipse cx="{1}" cy="{2}" rx="{3}" ry="{4}" class="sat-cov {5}"/>\n        {6}\n        {7}\n        {8}\n        <circle cx="{9}" cy="{10}" r="11" fill="url(#satGl)"/><g transform="translate({11},{12})" class="sat-ic"><rect x="-2.6" y="-2.6" width="5.2" height="5.2" rx="1"/><rect x="-9" y="-1.3" width="5" height="2.6"/><rect x="4" y="-1.3" width="5" height="2.6"/></g>\n      </svg>\n      <div class="sat-legend"><span><i class="lg-site"></i>ARES-1 · {13}</span><span><i class="lg-sat"></i>{14}</span><span><i class="lg-fut"></i>Sonraki tur</span><span><i class="lg-cov"></i>Görüş alanı</span></div>\n    </div>\n    <div class="sat-side">\n      <div class="sat-hd"><div><small>RÖLE UYDUSU</small><b>{15}</b></div>{16}</div>\n      <dl class="sat-dl">\n        <dt>Anlık konum</dt><dd>{17} · {18}</dd>\n        <dt>ARES-1\'e uzaklık</dt><dd>{19} km</dd>\n        <dt>Yükseliş açısı</dt><dd>{20}</dd>\n        <dt>Sonraki geçiş</dt><dd>{21}</dd>\n        <dt>Yörünge</dt><dd>Dairesel · {22} km · eğim {23}°</dd>\n        <dt>Periyot · hız</dt><dd>{24} dk · {25} km/s</dd>\n        <dt>Bağlantılar</dt><dd>UHF 401 MHz (yüzey) · X-bant (Dünya)</dd>\n        <dt>Mars–Dünya</dt><dd>{26} milyon km · {27} dk</dd>\n      </dl>\n    </div>\n  </div>':
      '<div class="sat">\n    <div class="sat-map">\n      <svg viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">\n        <defs><linearGradient id="satBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a2a1c"/><stop offset=".5" stop-color="#8a3f26"/><stop offset="1" stop-color="#4a2216"/></linearGradient>\n          <radialGradient id="satGl"><stop offset="0" stop-color="#7fe7ff" stop-opacity=".9"/><stop offset="1" stop-color="#7fe7ff" stop-opacity="0"/></radialGradient></defs>\n        <rect width="360" height="180" fill="url(#satBg)"/>\n        <g class="sat-grid">{0}</g>\n        <line x1="0" y1="90" x2="360" y2="90" class="sat-eq"/>\n        <ellipse cx="{1}" cy="{2}" rx="{3}" ry="{4}" class="sat-cov {5}"/>\n        {6}\n        {7}\n        {8}\n        <circle cx="{9}" cy="{10}" r="11" fill="url(#satGl)"/><g transform="translate({11},{12})" class="sat-ic"><rect x="-2.6" y="-2.6" width="5.2" height="5.2" rx="1"/><rect x="-9" y="-1.3" width="5" height="2.6"/><rect x="4" y="-1.3" width="5" height="2.6"/></g>\n      </svg>\n      <div class="sat-legend"><span><i class="lg-site"></i>ARES-1 · {13}</span><span><i class="lg-sat"></i>{14}</span><span><i class="lg-fut"></i>Next orbit</span><span><i class="lg-cov"></i>Visibility</span></div>\n    </div>\n    <div class="sat-side">\n      <div class="sat-hd"><div><small>RELAY SATELLITE</small><b>{15}</b></div>{16}</div>\n      <dl class="sat-dl">\n        <dt>Position</dt><dd>{17} · {18}</dd>\n        <dt>Range to ARES-1</dt><dd>{19} km</dd>\n        <dt>Elevation</dt><dd>{20}</dd>\n        <dt>Next pass</dt><dd>{21}</dd>\n        <dt>Orbit</dt><dd>Circular · {22} km · incl. {23}°</dd>\n        <dt>Period · speed</dt><dd>{24} min · {25} km/s</dd>\n        <dt>Links</dt><dd>UHF 401 MHz (surface) · X-band (Earth)</dd>\n        <dt>Mars–Earth</dt><dd>{26} million km · {27} min</dd>\n      </dl>\n    </div>\n  </div>',
    '<span class="st on">● MARS\'I İZLİYOR</span>': '<span class="st on">● TRACKING MARS</span>',
    '<span class="st err">● SİNYAL YOK</span>': '<span class="st err">● NO SIGNAL</span>',
    '<span class="st">BEKLEMEDE</span>': '<span class="st">STANDBY</span>',
    "<dt>Mars yükseliş açısı</dt><dd>{0}°</dd><dt>Veri hızı</dt><dd>{1}</dd>":
      "<dt>Mars elevation</dt><dd>{0}°</dd><dt>Data rate</dt><dd>{1}</dd>",
    '<div class="gs-card gs-st {0}">{1}<h5>{2}</h5><div class="loc">📍 {3} · {4}</div>\n      <dl class="gs-dl"><dt>Enlem</dt><dd>{5}</dd><dt>Boylam</dt><dd>{6}</dd><dt>Rakım</dt><dd>{7}</dd><dt>Çanak anten</dt><dd>{8} · ışın kılavuzlu</dd>\n      <dt>Gönderme</dt><dd>{9} bant</dd><dt>Alma</dt><dd>{10} bant</dd><dt>Hizmete giriş</dt><dd>{11}</dd>\n      {12}</dl></div>':
      '<div class="gs-card gs-st {0}">{1}<h5>{2}</h5><div class="loc">📍 {3} · {4}</div>\n      <dl class="gs-dl"><dt>Latitude</dt><dd>{5}</dd><dt>Longitude</dt><dd>{6}</dd><dt>Altitude</dt><dd>{7}</dd><dt>Dish</dt><dd>{8} · beam waveguide</dd>\n      <dt>Uplink</dt><dd>{9} band</dd><dt>Downlink</dt><dd>{10} band</dd><dt>In service</dt><dd>{11}</dd>\n      {12}</dl></div>',
    "Mars yüzeyi · yüksek kazançlı anten": "Mars surface · high-gain antenna",
    "X-bant": "X-band",
    "İstasyon ağı": "Station network",
    "İletişim operasyonu": "Communications operations",
    "Görev Kontrol": "Mission Control",
    "Görev yönetimi": "Mission management",
    "Bilim ekipleri": "Science teams",
    AKTİF: "ACTIVE",
    '<div class="gs">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>YER BİRİMİ · ARES-1</b>\n      <p>Yer birimi; iletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları ve görev kontrol merkezlerinden oluşur. ARES-1, boylamda yaklaşık 120° aralıklı üç gerçek 35 m derin uzay anteniyle (New Norcia, Cebreros, Malargüe) Dünya döndükçe kesintisiz izlenir.</p></div></div>\n    <div class="gs-sec">Veri yolu</div>\n    <div class="gs-path">\n      {0}{1}\n      {2}{3}\n      {4}{5}\n      {6}{7}\n      {8}\n    </div>\n    <div class="gs-sec">Röle uydusu · konum ve yörünge</div>\n    {9}\n    <div class="gs-kv">\n      <div><span>Bağlantı</span><b style="color:{10}">{11}</b></div>\n      <div><span>Işık gecikmesi</span><b>{12} dk</b></div>\n      <div><span>Gönderilen veri</span><b>{13} MB</b></div>\n      <div><span>Alınan mesaj</span><b>{14}</b></div></div>\n    <div class="gs-sec">Yer istasyonları</div>\n    <div class="gs-grid">{15}</div>\n    <div class="gs-kv" style="grid-template-columns:repeat(3,1fr)">\n      <div><span>Aktif istasyon</span><b>{16}</b></div>\n      <div><span>Sonraki devir</span><b>{17} · {18}</b></div>\n      <div><span>Veri kapasitesi</span><b>{19} MB/sol</b></div></div>\n    <div class="gs-sec">Görev kontrol merkezleri</div>\n    <div class="gs-grid">{20}</div>\n  </div>':
      '<div class="gs">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>GROUND SEGMENT · ARES-1</b>\n      <p>The ground segment consists of the ground stations and mission control centers responsible for communications, data reception and mission management. ARES-1 is tracked without interruption as Earth rotates by three real 35 m deep space antennas about 120° apart in longitude (New Norcia, Cebreros, Malargüe).</p></div></div>\n    <div class="gs-sec">Data path</div>\n    <div class="gs-path">\n      {0}{1}\n      {2}{3}\n      {4}{5}\n      {6}{7}\n      {8}\n    </div>\n    <div class="gs-sec">Relay satellite · position and orbit</div>\n    {9}\n    <div class="gs-kv">\n      <div><span>Link</span><b style="color:{10}">{11}</b></div>\n      <div><span>Light delay</span><b>{12} min</b></div>\n      <div><span>Data sent</span><b>{13} MB</b></div>\n      <div><span>Messages received</span><b>{14}</b></div></div>\n    <div class="gs-sec">Ground stations</div>\n    <div class="gs-grid">{15}</div>\n    <div class="gs-kv" style="grid-template-columns:repeat(3,1fr)">\n      <div><span>Active station</span><b>{16}</b></div>\n      <div><span>Next handover</span><b>{17} · {18}</b></div>\n      <div><span>Data capacity</span><b>{19} MB/sol</b></div></div>\n    <div class="gs-sec">Mission control centers</div>\n    <div class="gs-grid">{20}</div>\n  </div>',
    "YEREL AĞ": "LOCAL NETWORK",
    "RÖLE UYDUSU": "RELAY SATELLITE",
    "ANTEN TOZLA KAPALI": "ANTENNA BLOCKED BY DUST",
    "PARAZİT · ": "INTERFERENCE · ",
    "Gönderilecek bir şey yok — gözlem seç ya da not yaz":
      "Nothing to send — select an observation or write a note",
    "📡 Toz fırtınası yüksek kazançlı anteni kör ediyor — fırtına geçince gönder":
      "📡 The dust storm is blinding the high-gain antenna — send once the storm has passed",
    "Notun GDY-1'e iletildi — yanıt ~": "Your note was sent to GDY-1 — the reply will be in your inbox in ~",
    " içinde gelen kutunda": " ",
    "</b> Dünya'ya iletildi · yanıt beklenen: <b>": "</b> sent to Earth · reply expected: <b>",
    "📥 Gelen kutusu": "📥 Inbox",
    "📝 Rapor hazırla": "📝 Prepare report",
    "📤 Gönderilenler": "📤 Sent",
    "📡 Dünya'ya gönder": "📡 Send to Earth",
    "📡 Anten kapalı — fırtına bekleniyor": "📡 Antenna blocked — waiting for the storm",
    '<span class="mut">Raporda henüz içerik yok.</span>':
      '<span class="mut">The report has no content yet.</span>',
    " + not": " + note",
    "<div><span>İçerik</span><b>{0} gözlem{1}</b></div>\n    <div><span>Paket</span><b>{2} MB</b></div>\n    <div><span>Işık gecikmesi</span><b>~{3} dk</b></div>\n    <div><span>Tahmini yanıt</span><b>Sol {4} civarı</b></div>":
      "<div><span>Contents</span><b>{0} observations{1}</b></div>\n    <div><span>Package</span><b>{2} MB</b></div>\n    <div><span>Light delay</span><b>~{3} min</b></div>\n    <div><span>Expected reply</span><b>around Sol {4}</b></div>",
    "Yüksek kazançlı anten Dünya'ya hizalanıyor…": "Aligning the high-gain antenna with Earth…",
    "Paket sıkıştırılıyor ve AES-256 ile şifreleniyor…":
      "Compressing the package and encrypting it with AES-256…",
    " gözlem kaydı + ": " observation entries + ",
    "mürettebat notu": "crew note",
    "not yok": "no note",
    " paketlendi": " packed",
    "X-bandı iletim · ": "X-band transmission · ",
    "İletim tamamlandı · ışık gecikmesi ~": "Transmission complete · light delay ~",
    '<div class="cm-empty">📭 Saha günlüğünde gönderilmemiş kayıt yok.<br><small>Fırtına, radyasyon, meteor, arıza, numune toplama, tarım ve kritik yaşam değerleri burada otomatik kaydedilir.</small></div>':
      '<div class="cm-empty">📭 There are no unsent entries in the field log.<br><small>Storms, radiation, meteors, breakdowns, sample collection, farming and critical life values are recorded here automatically.</small></div>',
    "Patatesler çürüdü, neden olabilir?": "The potatoes rotted, what could be the cause?",
    "Motordan duman geliyor, ne yapmalıyım?": "Smoke is coming from the engine, what should I do?",
    "Erzak azalıyor": "Supplies are running low",
    "Fırtınada roket çok sarsıldı": "The rocket shook badly in the storm",
    "Radyasyon sırasında dışarıda kaldım": "I was outside during the radiation",
    "Kendimi yalnız hissediyorum": "I feel lonely",
    "Ne zaman Dünya'ya dönebilirim?": "When can I return to Earth?",
    '<div class="cm-cols">\n      <div class="cm-col"><div class="con-sec">Saha günlüğü · {0} kayıt</div><div class="cm-obs">{1}</div></div>\n      <div class="cm-col"><div class="con-sec">Mürettebat notu</div>\n        <textarea id="cmNote" maxlength="500" placeholder="Yaşadığın sorunları, gözlemlerini ya da sorularını yaz…">{2}</textarea>\n        <div class="cm-quick">{3}</div>\n        <div class="con-sec">Öncelik</div>\n        <div class="cm-prio"><button data-p="rutin" class="{4}">RUTİN<small>yanıt ≈ ½ sol</small></button><button data-p="acil" class="acil {5}">ACİL<small>yanıt ≈ ¼ sol</small></button></div>\n        <div class="cm-sum" id="cmSum"></div>\n        <button class="cbtn pri wide" id="cmSend">📡 Dünya\'ya gönder</button></div></div>':
      '<div class="cm-cols">\n      <div class="cm-col"><div class="con-sec">Field log · {0} entries</div><div class="cm-obs">{1}</div></div>\n      <div class="cm-col"><div class="con-sec">Crew note</div>\n        <textarea id="cmNote" maxlength="500" placeholder="Write about the problems you\'ve had, your observations or your questions…">{2}</textarea>\n        <div class="cm-quick">{3}</div>\n        <div class="con-sec">Priority</div>\n        <div class="cm-prio"><button data-p="rutin" class="{4}">ROUTINE<small>reply ≈ ½ sol</small></button><button data-p="acil" class="acil {5}">URGENT<small>reply ≈ ¼ sol</small></button></div>\n        <div class="cm-sum" id="cmSum"></div>\n        <button class="cbtn pri wide" id="cmSend">📡 Send to Earth</button></div></div>',
    YANIT: "REPLY",
    BÜLTEN: "BULLETIN",
    UYARI: "ALERT",
    BRİFİNG: "BRIEFING",
    TALEP: "REQUEST",
    ANALİZ: "ANALYSIS",
    "YZ YANITI": "AI REPLY",
    MESAJ: "MESSAGE",
    ACİL: "URGENT",
    '<div class="cm-empty">📭 Gelen kutusu boş.<br><small>Görev Kontrol\'ün brifingleri, bültenleri ve raporlarına verdiği yanıtlar burada görünür.</small></div>':
      '<div class="cm-empty">📭 The inbox is empty.<br><small>Mission Control\'s briefings, bulletins and replies to your reports appear here.</small></div>',
    Gönderildi: "Sent",
    "Dünya'ya ulaştı": "Reached Earth",
    İnceleniyor: "Under review",
    "Yanıt geldi": "Reply received",
    '<span class="badge err">ACİL</span>': '<span class="badge err">URGENT</span>',
    '<span class="badge mute">RUTİN</span>': '<span class="badge mute">ROUTINE</span>',
    "📨 Yanıt gelen kutunda": "📨 Reply is in your inbox",
    "⏳ Yanıt bekleniyor · <b>{0}</b> civarı · kalan ~{1} (oyun saati)":
      "⏳ Awaiting reply · around <b>{0}</b> · ~{1} left (game time)",
    '<div class="cm-empty">📤 Henüz rapor göndermedin.<br><small>“Rapor hazırla” sekmesinden saha günlüğünü ve notunu Dünya\'ya ilet.</small></div>':
      '<div class="cm-empty">📤 You haven\'t sent a report yet.<br><small>Send your field log and note to Earth from the “Prepare report” tab.</small></div>',
    '<span class="ci">📨</span><div><b>Dünya\'dan {0} yeni mesaj</b><small>Komuta güvertesi · iletişim terminali</small></div>':
      '<span class="ci">📨</span><div><b>{0} new message(s) from Earth</b><small>Command deck · communications terminal</small></div>',
    '<span class="ci">📡</span><div><b>Yanıt bekleniyor</b><small>{0} civarı</small></div>':
      '<span class="ci">📡</span><div><b>Awaiting reply</b><small>around {0}</small></div>',
    '<span class="ci">📝</span><div><b>{0} gözlem rapor bekliyor</b><small>İletişim terminalinden gönder</small></div>':
      '<span class="ci">📝</span><div><b>{0} observation(s) awaiting report</b><small>Send from the communications terminal</small></div>',
    "İnsanlık binlerce yıldır gece gökyüzündeki o kızıl noktaya baktı.":
      "For thousands of years humanity has looked up at that red dot in the night sky.",
    "Şimdi, ilk kez bir insan oraya gidiyor.": "Now, for the first time, a human is going there.",
    "Tek başına.": "Alone.",
    "UÇUŞ DİREKTÖRÜ · GÖREV KONTROL": "FLIGHT DIRECTOR · MISSION CONTROL",
    "ARES-1 görevi onaylandı. Mürettebat: tek kişi. Komutan sensin.":
      "The ARES-1 mission is approved. Crew: one person. You are the commander.",
    "Görevin: Mars'a in, oradaki yaşam koşullarını incele ve her bulguyu Dünya'ya aktar.":
      "Your mission: land on Mars, study the living conditions there and send every finding back to Earth.",
    "Orada yalnız olacaksın. Ama biz seni her an dinliyor olacağız.":
      "You will be alone out there. But we'll be listening to you every moment.",
    "YER İSTASYONU AĞI": "GROUND STATION NETWORK",
    "A, B ve C istasyonları hazır. Yolculuk boyunca üç istasyon seni sırayla izleyecek.":
      "Stations A, B and C are ready. Throughout the journey, the three stations will track you in turn.",
    "KALKIŞ KONTROL": "LAUNCH CONTROL",
    "Tüm sistemler hazır. Geri sayım başladı.": "All systems go. The countdown has begun.",
    "GÖREV KONTROL": "MISSION CONTROL",
    "Kalkış! ARES-1 kuleden ayrıldı.": "Liftoff! ARES-1 has cleared the tower.",
    "Yörüngeye giriş nominal. Mars yolu açık. İyi yolculuklar, Komutan.":
      "Orbit insertion nominal. The road to Mars is open. Safe travels, Commander.",
    "KOMUTANIN GÜNLÜĞÜ": "COMMANDER'S LOG",
    "Gün 12 — Dünya artık başparmağımın arkasına sığıyor.": "Day 12 — Earth now fits behind my thumb.",
    "Gün 97 — Buradaki tek ses, Görev Kontrol'den gelen cızırtılı mesajlar.":
      "Day 97 — The only sound here is the crackling messages from Mission Control.",
    "Gün 211 — Kızıl gezegen pencereyi dolduruyor. Neredeyse geldim.":
      "Day 211 — The red planet fills the window. I'm almost there.",
    "ARES-1, atmosfere girişe hazırlan. Isı kalkanı devrede.":
      "ARES-1, prepare for atmospheric entry. Heat shield engaged.",
    "Isı kalkanı 1.600 °C… sinyal… kesil—": "Heat shield at 1,600 °C… signal… breaking up—",
    "Retro motorlar ateşlendi… 40 metre… 20… 10…": "Retro engines fired… 40 metres… 20… 10…",
    "ARES-1, burası Görev Kontrol. A istasyonu sinyalini aldı, inişini doğruluyoruz. Mars'a hoş geldin, Komutan.":
      "ARES-1, this is Mission Control. Station A has your signal, we confirm your landing. Welcome to Mars, Commander.",
    "GÖREV DOSYASI": "MISSION FILE",
    KALKIŞ: "LAUNCH",
    "YOLCULUK · 214 GÜN": "JOURNEY · 214 DAYS",
    "ARES-1, Dünya'ya dönüş penceresi açık. Kalkış için onay verildi.":
      "ARES-1, the return window to Earth is open. You are cleared for launch.",
    "Motorlar ateşlendi… Mars, her şey için teşekkürler.": "Engines ignited… Mars, thank you for everything.",
    "Kalkış başarılı. Hoşça kal, Kızıl Gezegen.": "Liftoff successful. Farewell, Red Planet.",
    "ARES-R1 · RÖLE UYDUSU": "ARES-R1 · RELAY SATELLITE",
    "Son bağlantı: yüzey verilerinin tamamı aktarıldı. İyi yolculuklar, ARES-1.":
      "Final contact: all surface data has been transferred. Safe travels, ARES-1.",
    "Dünya'ya transfer ateşlemesi tamamlandı. Yeni rota: ev.":
      "Earth transfer burn complete. New course: home.",
    "Dönüş günü {0} — Mars arkamda küçülüyor. Kargo bölmesinde {1} numune var.":
      "Return day {0} — Mars is shrinking behind me. There are {1} samples in the cargo hold.",
    "Dönüş günü {0} — Ekip her mesajımda Mars'ta öğrendiklerimizi soruyor.":
      "Return day {0} — In every message the team asks about what we learned on Mars.",
    "Dönüş günü {0} — Pencerede mavi bir nokta büyüyor. Evim.":
      "Return day {0} — A blue dot is growing in the window. Home.",
    "ARES-1, Ay'ın yörüngesini geçtin. Kapsül ayrılmasına hazırlan.":
      "ARES-1, you have crossed the Moon's orbit. Prepare for capsule separation.",
    "Kapsül ayrıldı. Isı kalkanı Dünya'ya dönük.": "Capsule separated. Heat shield facing Earth.",
    "Atmosfere giriş. Hız saniyede 11 kilometre. İletişim kesintisi bekleniyor.":
      "Atmospheric entry. Speed 11 kilometres per second. Expect a communications blackout.",
    "Pencerenin dışı alev alev… dayan…": "It's all fire outside the window… hold on…",
    "KURTARMA EKİBİ": "RECOVERY TEAM",
    "Sinyal geri geldi! Paraşütler açıldı, üçü de sağlam.":
      "Signal is back! Parachutes deployed, all three are good.",
    "Kapsülü görüyoruz. Okyanusa iniş için hazırlan.":
      "We have the capsule in sight. Prepare for splashdown.",
    "ARES-1, suya iniş doğrulandı. Kurtarma gemisi yolda.":
      "ARES-1, splashdown confirmed. The recovery ship is on its way.",
    "Mars'ta {0} sol geçirdin. Dünya'ya hoş geldin, Komutan.":
      "You spent {0} sols on Mars. Welcome home to Earth, Commander.",
    "MARS · KALKIŞ": "MARS · LIFTOFF",
    "MARS YÖRÜNGESİ": "MARS ORBIT",
    "EVE DÖNÜŞ · {0} GÜN": "HOMEWARD · {0} DAYS",
    "ATMOSFERE GİRİŞ": "ATMOSPHERIC ENTRY",
    "OKYANUSA İNİŞ": "SPLASHDOWN",
    EVRE: "PHASE",
    "GERİ SAYIM": "COUNTDOWN",
    "MARS KALKIŞI": "MARS LIFTOFF",
    İRTİFA: "ALTITUDE",
    İTKİ: "THRUST",
    "DÜNYA'YA TRANSFER ATEŞLEMESİ": "EARTH TRANSFER BURN",
    "TRANSFER YÖRÜNGESİ": "TRANSFER ORBIT",
    HIZ: "VELOCITY",
    "DÖNÜŞ GÜNÜ": "RETURN DAY",
    "DÜNYA'YA UZAKLIK": "DISTANCE TO EARTH",
    " milyon km": " million km",
    "SİNYAL GECİKMESİ": "SIGNAL DELAY",
    KARGO: "CARGO",
    " numune": " samples",
    "YER İSTASYONU": "GROUND STATION",
    "KAPSÜL AYRILDI": "CAPSULE SEPARATED",
    "DÜNYA YAKLAŞMASI": "EARTH APPROACH",
    "ISI KALKANI": "HEAT SHIELD",
    SİNYAL: "SIGNAL",
    YOK: "NONE",
    "PARAŞÜTLER AÇIK": "PARACHUTES OPEN",
    "İNİŞ HIZI": "DESCENT RATE",
    "SUYA İNİŞ": "SPLASHDOWN",
    KONUM: "LOCATION",
    "Pasifik Okyanusu": "Pacific Ocean",
    KURTARMA: "RECOVERY",
    YOLDA: "EN ROUTE",
    "KAPSÜLE YAKLAŞIYOR": "CLOSING ON CAPSULE",
    "GÖREV TAMAMLANDI": "MISSION COMPLETE",
    "Mars'ta {0} sol · {1} numune · bilim hedefi %{2}": "{0} sols on Mars · {1} samples · science goal {2}%",
    "225 milyon km": "225 million km",
    "ARES PROGRAMI": "ARES PROGRAM",
    "ARES-1 · GÖREV PROFİLİ": "ARES-1 · MISSION PROFILE",
    "TRANSFER YÖRÜNGESİ · 214 GÜN": "TRANSFER ORBIT · 214 DAYS",
    "MÜRETTEBAT: 1": "CREW: 1",
    "● GÖREV ONAYLANDI": "● MISSION APPROVED",
    "ARES PROGRAMI — GÖREV DOSYASI": "ARES PROGRAM — MISSION FILE",
    "GİZLİLİK: ÜST DÜZEY": "CLASSIFICATION: TOP LEVEL",
    "KOMUTAN — SEN": "COMMANDER — YOU",
    "KİMLİK ARES-1/CDR": "ID ARES-1/CDR",
    GÖREV: "MISSION",
    "ARES-1 · Mars yüzey keşfi": "ARES-1 · Mars surface exploration",
    MÜRETTEBAT: "CREW",
    "1 kişi — Komutan (sen)": "1 person — Commander (you)",
    ARAÇ: "VEHICLE",
    "ARES-1 iniş ve dönüş roketi · 3 güverte": "ARES-1 landing and return rocket · 3 decks",
    YOLCULUK: "JOURNEY",
    HEDEF: "DESTINATION",
    "YER BİRİMİ": "GROUND SEGMENT",
    "Görev Kontrol · 3 yer istasyonu": "Mission Control · 3 ground stations",
    "Atmosferi, toprağı ve radyasyonu ölç, verileri topla":
      "Measure the atmosphere, soil and radiation, and collect the data",
    "Su, oksijen ve tarımla yaşam koşullarını test et":
      "Test living conditions with water, oxygen and farming",
    "Fırtına, radyasyon ve meteor gibi tehlikeleri raporla":
      "Report hazards such as storms, radiation and meteors",
    "Tüm bulguları iletişim terminalinden Dünya'ya aktar":
      "Transmit all findings to Earth from the communications terminal",
    "GÖREV AMAÇLARI": "MISSION OBJECTIVES",
    ONAYLANDI: "APPROVED",
    KALKIŞA: "TO LAUNCH",
    YAKIT: "FUEL",
    RÜZGÂR: "WIND",
    "6 km/sa": "6 km/h",
    DURUM: "STATUS",
    HAZIR: "READY",
    YÜKSELİŞ: "ASCENT",
    "KADEME AYRILMASI": "STAGE SEPARATION",
    YÖRÜNGE: "ORBIT",
    "GÖREV GÜNÜ": "MISSION DAY",
    "GÜÇLÜ İNİŞ": "POWERED DESCENT",
    "DİKEY HIZ": "VERTICAL SPEED",
    TEMAS: "CONTACT",
    İNİŞ: "LANDING",
    BAŞARILI: "SUCCESSFUL",
    "İSTASYON A · ALINDI": "STATION A · ACQUIRED",
    '<span><i class="dot"></i>CANLI</span><span>MARS YEREL <b>{0}:{1}</b></span><span>SICAKLIK <b>{2} °C</b></span><span>RÜZGÂR <b>{3} km/sa</b></span><span>BASINÇ <b>6,1 mbar</b></span><span>IŞIK GECİKMESİ <b>{4} dk</b></span>':
      '<span><i class="dot"></i>LIVE</span><span>MARS LOCAL <b>{0}:{1}</b></span><span>TEMPERATURE <b>{2} °C</b></span><span>WIND <b>{3} km/h</b></span><span>PRESSURE <b>6.1 mbar</b></span><span>LIGHT DELAY <b>{4} min</b></span>',
    "Görev başlıyor: Mars'ı incele, hayatta kal ve her şeyi Dünya'ya aktar.":
      "The mission begins: study Mars, survive and send everything back to Earth.",
    "ARES Standart": "ARES Standard",
    BAŞLANGIÇ: "STARTER",
    Dengeli: "Balanced",
    "Görevin standart EVA giysisi. Beyaz çok katmanlı kumaş, temel yaşam desteği. Kısa dış görevler için yeterli, uzun maruziyette yetersiz.":
      "The mission's standard EVA suit. White multi-layer fabric, basic life support. Enough for short EVAs, inadequate for long exposure.",
    "Kaşif Mk-I": "Explorer Mk-I",
    "Hafif · Çevik": "Light · Agile",
    "Kum rengi hafif kompozit dış katman ve geliştirilmiş CO₂ geri dönüştürücü. Uzun yürüyüşlerde daha az oksijen harcar, daha çevik hareket eder.":
      "Lightweight sand-coloured composite outer layer and an improved CO₂ recycler. Uses less oxygen on long walks and moves more nimbly.",
    "Ağırlıklı botlar": "Weighted boots",
    "Öncü Mk-II": "Pioneer Mk-II",
    "Karbon · Işık şeritli": "Carbon · Light strips",
    "Karbon-grafit gövde, ışık şeritli eklemler ve toz contalı bağlantılar. Fırtınada rüzgâra karşı daha sağlam, radyasyona karşı ara katmanlı.":
      "Carbon-graphite body, light-striped joints and dust-sealed connections. Sturdier against the wind in a storm, with an interlayer against radiation.",
    "Manyetik botlar": "Magnetic boots",
    "Kalkan Mk-III": "Shield Mk-III",
    "Zırhlı · Radyasyon kalkanı": "Armoured · Radiation shield",
    "Kurşun katkılı zırh plakaları, manyetik radyasyon kalkanı ve güçlendirilmiş motor destekli eklemler. Radyasyon dalgasında çok daha uzun dayanır.":
      "Lead-infused armour plates, a magnetic radiation shield and reinforced motor-assisted joints. Lasts much longer in a radiation wave.",
    "Jiroskop dengeleyici": "Gyro stabiliser",
    "Prototip · Altın vizör": "Prototype · Gold visor",
    "Görev Kontrol'ün gizli prototipi. Altın kaplı vizör, plazma çekirdekli yaşam desteği, tam fırtına zırhı ve güçlendirilmiş dış iskelet.":
      "Mission Control's secret prototype. Gold-plated visor, plasma-core life support, full storm armour and a reinforced exoskeleton.",
    "Aktif yerçekimi dengeleyici": "Active gravity stabiliser",
    "Klasik ARES": "Classic ARES",
    "Beyaz gövde, turuncu burun — görevin orijinal boyası.":
      "White body, orange nose — the mission's original paint job.",
    "Kutup Mavisi": "Polar Blue",
    "Buz beyazı gövde, lacivert burun, camgöbeği kanatlar ve ince hız şeritleri.":
      "Ice-white body, navy nose, cyan fins and thin racing stripes.",
    "Mars Kamuflajı": "Mars Camouflage",
    "Pas ve kum tonlarında desen, zeytin yeşili kanatlar. Mars'ta neredeyse görünmez.":
      "Pattern in rust and sand tones, olive-green fins. Almost invisible on Mars.",
    "Gece Kuzgunu": "Night Raven",
    "Mat siyah gövde, kızıl burun ve kanatlar, parlayan kırmızı çizgiler.":
      "Matte black body, crimson nose and fins, glowing red lines.",
    "Altın Çağ": "Golden Age",
    "Krom-altın kaplama, siyah burun ve şeritler, güneşte parıldayan yansımalar.":
      "Chrome-gold plating, black nose and stripes, reflections that glitter in the sun.",
    "Titanyum Plakalar": "Titanium Plates",
    "Alt gövdeye perçinli titanyum plakalar. Fırtınada motor arızası olasılığı %60 → %35.":
      "Titanium plates riveted to the lower hull. Chance of engine failure in a storm 60% → 35%.",
    "Kanat & Burun Zırhı": "Fin & Nose Armour",
    "Kanat kenar koruyucuları ve güçlendirilmiş burun başlığı. Arıza olasılığı %15'e iner, gövde daha az sarsılır.":
      "Fin edge guards and a reinforced nose cap. Failure chance drops to 15% and the hull shakes less.",
    "Deflektör Kalkanı": "Deflector Shield",
    "Manyetik toz deflektörü roketi enerji kalkanıyla sarar. Fırtına artık motoru bozamaz.":
      "A magnetic dust deflector wraps the rocket in an energy shield. Storms can no longer break the engine.",
    ATÖLYE: "WORKSHOP",
    "Oksijen tüketimi": "Oxygen consumption",
    " daha az": " less",
    "Yürüme hızı": "Walking speed",
    "Radyasyon koruması": "Radiation protection",
    " daha az hasar": " less damage",
    "Fırtına direnci": "Storm resistance",
    " daha az etki": " less effect",
    "Yerçekimi dengesi": "Gravity balance",
    " daha az sekme": " less bouncing",
    standart: "standard",
    '<span class="ug-cost ok">Ücretsiz</span>': '<span class="ug-cost ok">Free</span>',
    '<span><img src="{0}">Metal <b>{1}</b></span><span><img src="{2}">Kristal <b>{3}</b></span><span><i class="ug-au"></i>Altın <b>{4}</b></span>':
      '<span><img src="{0}">Metal <b>{1}</b></span><span><img src="{2}">Crystal <b>{3}</b></span><span><i class="ug-au"></i>Gold <b>{4}</b></span>',
    GİYİLİ: "WORN",
    SAHİP: "OWNED",
    KİLİTLİ: "LOCKED",
    '<div class="ug-feat">⚙ {0} · dışarıda yerçekiminden daha az etkilenirsin</div>':
      '<div class="ug-feat">⚙ {0} · low gravity affects you less outside</div>',
    "✓ Şu an giyili": "✓ Currently worn",
    Giy: "Wear",
    "Önce ": "Requires ",
    "Üret ve giy": "Build and wear",
    "Önce bir önceki seti üretmelisin": "You must build the previous set first",
    "Malzeme yetersiz — metal, yıldız kristali ve uzak bölgelerdeki nadir taşları topla":
      "Not enough materials — collect metal, star crystals and rare stones from remote areas",
    "</b> giyildi — ": "</b> equipped — ",
    '<button class="cbtn pri" data-armor="{0}">Kur</button>':
      '<button class="cbtn pri" data-armor="{0}">Install</button>',
    '<span class="ug-badge on">KURULU</span>': '<span class="ug-badge on">INSTALLED</span>',
    '<span class="ug-badge">KİLİTLİ</span>': '<span class="ug-badge">LOCKED</span>',
    "✓ Uygulandı": "✓ Applied",
    "Boyayı uygula": "Apply paint",
    "Satın al ve uygula": "Buy and apply",
    '<div class="ug-rk">\n      <div class="ug-rkstage" style="--g:#5ad1ff"><div class="ug-ring"></div><img class="ug-hero rk" src="{0}"><div class="ug-floor"></div>\n        <div class="ug-rkcap"><small>BOYA</small><b>{1}</b><p>{2}</p></div></div>\n      <div class="ug-rkside">\n        <div class="ug-sec">🛡️ FIRTINA KALKANI <span>Arıza olasılığı: <b>%{3}</b></span></div>\n        <div class="ug-armor">{4}</div>\n        <div class="ug-sec">🎨 GÖRÜNÜM <span>Altın parçalarıyla boya</span></div>\n        <div class="ug-skins">{5}</div>\n        <div class="ug-buy">{6}\n          <button class="cbtn pri wide" id="ugSk" {7}>{8}</button></div>\n      </div></div>':
      '<div class="ug-rk">\n      <div class="ug-rkstage" style="--g:#5ad1ff"><div class="ug-ring"></div><img class="ug-hero rk" src="{0}"><div class="ug-floor"></div>\n        <div class="ug-rkcap"><small>PAINT</small><b>{1}</b><p>{2}</p></div></div>\n      <div class="ug-rkside">\n        <div class="ug-sec">🛡️ STORM SHIELD <span>Failure chance: <b>{3}%</b></span></div>\n        <div class="ug-armor">{4}</div>\n        <div class="ug-sec">🎨 APPEARANCE <span>Paint with gold fragments</span></div>\n        <div class="ug-skins">{5}</div>\n        <div class="ug-buy">{6}\n          <button class="cbtn pri wide" id="ugSk" {7}>{8}</button></div>\n      </div></div>',
    "Malzeme yetersiz — altın (meteor kraterleri) ve titanyum cevheri (uzak bölgeler) topla":
      "Not enough materials — collect gold (meteor craters) and titanium ore (remote areas)",
    "</b> kuruldu — fırtınada arıza olasılığı %": "</b> installed — storm failure chance %",
    "Yeterli altın yok — meteor kraterlerinden altın parçası topla":
      "Not enough gold — collect gold fragments from meteor craters",
    "🎨 Roket boyandı: <b>": "🎨 Rocket painted: <b>",
    "Titanyum cevheri": "Titanium ore",
    "Roket zırhı · fırtına kalkanı": "Rocket armour · storm shield",
    "Olivin kristali": "Olivine crystal",
    "Kıyafet setleri · Öncü, Kalkan, Elite": "Suit sets · Pioneer, Shield, Elite",
    "Ares taşı": "Ares stone",
    "En üst seviye · ARES Elite + Deflektör kalkanı": "Top tier · ARES Elite + Deflector shield",
    "Hematit küreleri": "Hematite spherules",
    "Bilim numunesi · geçmişte su izi": "Science sample · sign of past water",
    "Jips kristali": "Gypsum crystal",
    "Bilim numunesi · kristal suyu içerir": "Science sample · contains crystal water",
    "Perklorat tuzu": "Perchlorate salt",
    "Bilim numunesi · zehirli, dikkatle taşı": "Science sample · toxic, handle with care",
    "Demir-nikel meteorit": "Iron-nickel meteorite",
    "Bilim numunesi · uzaydan gelen göktaşı": "Science sample · a meteorite from space",
    "Oksit minerali · ilmenit": "Oxide mineral · ilmenite",
    "Doğal radyoaktivite yok": "No natural radioactivity",
    "Tehlikesiz. Kesip öğütürken çıkan tozu solumayın.":
      "Harmless. Do not inhale the dust when cutting or grinding.",
    "Mars bazaltlarında yaygın titanyum kaynağıdır. Titanyum hafif ve çok dayanıklı olduğu için roket zırhı ve ısıl kalkan için en değerli yerel malzemelerden biridir.":
      "A common titanium source in Martian basalts. Titanium is light and very strong, making it one of the most valuable local materials for rocket armour and heat shields.",
    "Silikat minerali · forsterit–fayalit serisi": "Silicate mineral · forsterite–fayalite series",
    Diğer: "Other",
    "Olivin suyla temas edince kolayca ayrışır. Bu kadar taze olivin bulunması, bölgenin çok uzun süredir kuru kaldığını gösteriyor. Sert ve ısıya dayanıklı yapısıyla kıyafet katmanlarında kullanılabilir.":
      "Olivine breaks down easily in contact with water. Finding such fresh olivine shows the area has stayed dry for a very long time. Being hard and heat-resistant, it can be used in suit layers.",
    "Tanımlanamayan kristal yapı (Mars'a özgü)": "Unidentified crystal structure (unique to Mars)",
    "Si–Fe–O + nadir toprak elementleri": "Si–Fe–O + rare earth elements",
    "Zayıf radyoaktivite (doğal arka planın ~3 katı)": "Weak radioactivity (~3× natural background)",
    "Dikkat. Uzun süre çıplak elle tutmayın ve yatakhanede saklamayın. Kargo bölmesinde korumalı taşınabilir.":
      "Caution. Do not hold it bare-handed for long or keep it in the crew quarters. It can be carried shielded in the cargo hold.",
    "Dünya'da eşi bilinmeyen bir kristal örgü. Nadir toprak elementleri ve çok yüksek sertlik, onu kalkan sistemleri için eşsiz kılıyor. Ekiplerimiz kökenini araştırmayı sürdürüyor.":
      "A crystal lattice with no known equivalent on Earth. Its rare earth elements and very high hardness make it unique for shield systems. Our teams are still investigating its origin.",
    "Demir oksit · küresel konkresyon": "Iron oxide · spherical concretion",
    "Tehlikesiz.": "Harmless.",
    "Bu küçük demir oksit küreleri, kayaçların içinden geçen yeraltı suyunda yavaş yavaş oluşur. Yani bu bölgede çok uzun zaman önce sıvı su vardı. Meridiani Planum'da bulunan ünlü kürelerle aynı türden.":
      "These small iron oxide spheres form slowly in groundwater flowing through rock. So there was liquid water here a very long time ago. They are the same kind as the famous spherules of Meridiani Planum.",
    "Sülfat minerali · kalsiyum sülfat dihidrat": "Sulphate mineral · calcium sulphate dihydrate",
    "H₂O (kristal suyu)": "H₂O (crystal water)",
    "Tehlikesiz. Çok yumuşaktır, kolay kırılır.": "Harmless. Very soft and breaks easily.",
    "Jips, su buharlaşırken oluşan bir mineraldir ve yapısında %21 oranında su tutar. Isıtıldığında bu suyu bırakır; ileride Mars'ta su elde etmek için önemli bir kaynak olabilir.":
      "Gypsum forms as water evaporates and holds 21% water in its structure. It releases this water when heated, so it could become an important water source on Mars.",
    "Klor tuzu · magnezyum/kalsiyum perklorat": "Chlorine salt · magnesium/calcium perchlorate",
    "ClO₄⁻ (perklorat)": "ClO₄⁻ (perchlorate)",
    "Toprak + su": "Soil + water",
    "TEHLİKELİ. Perklorat insan için zehirlidir; tiroid bezinin çalışmasını bozar. Çıplak elle dokunmayın, tozunu solumayın, kabine sokmayın. Giysiyi kabine girmeden önce temizleyin.":
      "DANGEROUS. Perchlorate is toxic to humans and disrupts the thyroid gland. Do not touch it bare-handed, do not inhale its dust and do not bring it into the cabin. Clean your suit before entering the cabin.",
    "Perkloratlar Mars toprağında yaygındır (yaklaşık %0,5–1). Zehirli olsalar da parçalandıklarında oksijen açığa çıkardıkları için gelecekte oksijen üretiminde kullanılabilirler.":
      "Perchlorates are common in Martian soil (about 0.5–1%). Although toxic, they release oxygen when broken down, so they could be used to produce oxygen in the future.",
    "Demir meteorit · kamasit–tenit": "Iron meteorite · kamacite–taenite",
    "Fe–Ni alaşımı": "Fe–Ni alloy",
    "Kozmik ışınla oluşmuş izotop izleri (zararsız)": "Traces of cosmic-ray isotopes (harmless)",
    "Tehlikesiz. Çok ağırdır; taşırken dikkat edin.": "Harmless. Very heavy; take care when carrying it.",
    "Bu taş Mars'a uzaydan düşmüş bir göktaşı. Kesilip parlatıldığında çok yavaş soğumanın izi olan çapraz desenler görülür. Mars yüzeyinde bulunan demir meteoritler, atmosferin geçmişteki kalınlığı hakkında ipucu verir.":
      "This rock is a meteorite that fell onto Mars from space. Cut and polished, it shows criss-cross patterns left by very slow cooling. Iron meteorites on the Martian surface give clues about how thick the atmosphere used to be.",
    "Bilinmeyen taş": "Unknown stone",
    "BİLİNMEYEN TAŞ": "UNKNOWN STONE",
    "📡 Tarayıcı: yakında ": "📡 Scanner: signal from ",
    "<b>bilinmeyen bir mineral</b>": "<b>an unknown mineral</b>",
    " sinyali — haritadaki işarete git": " nearby — head to the marker on the map",
    "<b>Bilinmeyen taş</b> çantana alındı. Ne olduğunu ve tehlikeli olup olmadığını öğrenmek için roketteki <b>kargo terminalinden</b> analize gönder.":
      "<b>Unknown rock</b> added to your bag. To find out what it is and whether it is dangerous, send it for analysis from the rocket's <b>cargo terminal</b>.",
    "</b> (toplam ": "</b> (total ",
    "Bu taş zaten analizde": "This rock is already being analysed",
    "Taş numunesi <b>analiz için</b> Dünya'ya gönderildi. Laboratuvar sonucu birazdan gelen kutunda.":
      "Rock sample sent to Earth <b>for analysis</b>. The lab result will be in your inbox shortly.",
    GÜVENLİ: "SAFE",
    DİKKAT: "CAUTION",
    TEHLİKELİ: "DANGEROUS",
    '<p>Sayın Komutan,</p>\n  <p><b>Analiz için</b> gönderdiğiniz bilinmeyen taş numunesi laboratuvarımızda incelendi. Taşın adı ve özellikleri aşağıdadır.</p>\n  <div class="ltr-annex"><div class="ah">NUMUNE ANALİZ RAPORU · {0}</div>\n  <table class="mn-tbl">\n    <tr><td>Tanım</td><td><b>{1}</b></td></tr>\n    <tr><td>Mineral sınıfı</td><td>{2}</td></tr>\n    <tr><td>Kimyasal formül</td><td><b>{3}</b></td></tr>\n    <tr><td>Sertlik (Mohs)</td><td>{4}</td></tr>\n    <tr><td>Yoğunluk</td><td>{5}</td></tr>\n    <tr><td>Radyoaktivite</td><td>{6}</td></tr></table>\n  <b style="font-size:12px">Bileşim (ağırlıkça)</b>{7}\n  <div class="an">Yöntem: X-ışını kırınımı (XRD) · X-ışını floresansı (XRF) · gama spektrometrisi</div></div>\n  <div class="mn-hz {8}"><b>{9}</b><span>{10}</span></div>\n  <h4>Bilimsel değerlendirme</h4><p>{11}</p>\n  <p><b>Oyundaki kullanımı:</b> {12}.</p>':
      '<p>Dear Commander,</p>\n  <p>The unknown rock sample you sent <b>for analysis</b> has been examined in our laboratory. Its name and properties are below.</p>\n  <div class="ltr-annex"><div class="ah">SAMPLE ANALYSIS REPORT · {0}</div>\n  <table class="mn-tbl">\n    <tr><td>Identification</td><td><b>{1}</b></td></tr>\n    <tr><td>Mineral class</td><td>{2}</td></tr>\n    <tr><td>Chemical formula</td><td><b>{3}</b></td></tr>\n    <tr><td>Hardness (Mohs)</td><td>{4}</td></tr>\n    <tr><td>Density</td><td>{5}</td></tr>\n    <tr><td>Radioactivity</td><td>{6}</td></tr></table>\n  <b style="font-size:12px">Composition (by weight)</b>{7}\n  <div class="an">Method: X-ray diffraction (XRD) · X-ray fluorescence (XRF) · gamma spectrometry</div></div>\n  <div class="mn-hz {8}"><b>{9}</b><span>{10}</span></div>\n  <h4>Scientific assessment</h4><p>{11}</p>\n  <p><b>In-game use:</b> {12}.</p>',
    "Numune analizi · ": "Sample analysis · ",
    "🌀 Toz şeytanına yakalandın — uzaklaş!": "🌀 You're caught in a dust devil — get away!",
    "'e varıldı": " reached",
    '<span class="st on">🌪 FIRTINA</span>': '<span class="st on">🌪 STORM</span>',
    '<span class="st" title="Sonraki kum fırtınası">🌪 Gün ':
      '<span class="st" title="Next sandstorm">🌪 Day ',
    '<span class="rd on">☢ AKTİF</span>': '<span class="rd on">☢ ACTIVE</span>',
    '<span class="rd" title="Sonraki radyasyon dalgası">☢ Gün ':
      '<span class="rd" title="Next radiation wave">☢ Day ',
    '<div class="hd-top"><span class="hd-planet" style="{0}"></span>\n      <div class="hd-tt"><b>{1}</b><span>GÜN {2}</span></div>\n      <div class="hd-clock">{3} {4}</div></div>\n    <div class="hd-bar">{5}<em style="left:{6}%"></em></div>\n    <div class="hd-foot"><span>⏳ {7}</span><span class="hd-ev">{8}</span></div>':
      '<div class="hd-top"><span class="hd-planet" style="{0}"></span>\n      <div class="hd-tt"><b>{1}</b><span>DAY {2}</span></div>\n      <div class="hd-clock">{3} {4}</div></div>\n    <div class="hd-bar">{5}<em style="left:{6}%"></em></div>\n    <div class="hd-foot"><span>⏳ {7}</span><span class="hd-ev">{8}</span></div>',
    DIŞARI: "OUTSIDE",
    KABİN: "CABIN",
    "💧 Su": "💧 Water",
    "🥔 Patates": "🥔 Potato",
    "💊 Medikit": "💊 Medkit",
    "🌱 Tohum": "🌱 Seed",
    "🔩 Metal numune": "🔩 Metal sample",
    "⭐ Yıldız kırıntısı (2 numune)": "⭐ Star fragment (2 samples)",
    "Çürük patates (numune)": "Rotten potato (sample)",
    "Bu numarada henüz eşya yok — önce topla": "No item in this slot yet — collect one first",
    "Çapa elinde — yakındaki yere <b>sol tıkla</b>, toprağı kaz":
      "Hoe in hand — <b>left-click</b> nearby ground to dig",
    "Bu slot boş — (": "This slot is empty — (",
    "Susuzluğun zaten dolu": "You're not thirsty",
    "Su içildi (+": "Drank water (+",
    " susuzluk)": " water)",
    "Açlığın zaten dolu": "You're not hungry",
    "Patates yendi (+": "Ate a potato (+",
    " açlık)": " food)",
    "Radyasyon ölçer dışarıda, toprak üzerinde kullanılır":
      "The radiation meter is used outside, on the soil",
    "Çürük patates yenmez — roketteki kargo terminalinden Dünya'ya gönder":
      "Rotten potatoes can't be eaten — send it to Earth from the rocket's cargo terminal",
    "Tarla parselinin yakınına git": "Go near a farm plot",
    "Parsel dolu — önce hasat et (F)": "The plot is occupied — harvest it first (F)",
    "🌱 Ekildi": "🌱 Planted",
    "Numuneler roketin kargo bölmesine yüklenir — rokete götür (F)":
      "Samples are loaded into the rocket's cargo bay — take them to the rocket (F)",
    "Slot ": "Slot ",
    "🔓 Dünya rotası açıldı! Komuta güvertesindeki navigasyondan eve dön":
      "🔓 Route to Earth unlocked! Return home from the navigation on the command deck",
    '<div class="qd-n">Sıradaki görev: <b>{0} {1}</b></div>':
      '<div class="qd-n">Next mission: <b>{0} {1}</b></div>',
    '<div class="qd-n"><b>Tüm görevler bitti!</b></div>':
      '<div class="qd-n"><b>All missions completed!</b></div>',
    '<div class="qd-ck">✓</div><div class="qd-k">GÖREV TAMAMLANDI</div><div class="qd-t">{0} {1}</div>\n{2}':
      '<div class="qd-ck">✓</div><div class="qd-k">MISSION COMPLETE</div><div class="qd-t">{0} {1}</div>\n{2}',
    "GÖREV ": "MISSION ",
    "⏳ Fırtına bekleniyor: <b>Gün 2</b>, saat {0} civarı. O zamana kadar numune topla, tarım yap.":
      "⏳ Storm expected: <b>Day 2</b>, around {0}. Until then, collect samples and farm.",
    " yüzeyi · sol ": " surface · sol ",
    '<div class="ai">⚠️</div><div><b>Ana motor hasarlı — kalkış kilitli.</b><br>Makine dairesindeki ana motoru onar · aşama {0}/4</div>':
      '<div class="ai">⚠️</div><div><b>Main engine damaged — launch locked.</b><br>Repair the main engine in the engine room · stage {0}/4</div>',
    "Şu an buradasın": "You are here",
    '<span class="badge ok">BURADASIN</span>': '<span class="badge ok">YOU ARE HERE</span>',
    "Görevleri tamamla (": "Complete the missions (",
    '<span class="badge mute">🔒 KİLİTLİ</span>': '<span class="badge mute">🔒 LOCKED</span>',
    "Eve dönüş rotası hazır": "Route home is ready",
    "Daha önce ziyaret edildi": "Visited before",
    "Yeni rota": "New route",
    "🌍 EVE DÖN": "🌍 GO HOME",
    "🚀 KALKIŞ": "🚀 LAUNCH",
    "Ana motor hasarlı": "Main engine damaged",
    "Ana motor arızalı — makine dairesinde motoru onar":
      "Main engine broken — repair the engine in the engine room",
    "Roket yolculuğu sürüyor…": "Rocket journey in progress…",
    "Kargo Terminali": "Cargo Terminal",
    "Numuneleri kargo bölmesine yükle · erzak kapsüllerde":
      "Load samples into the cargo bay · supplies are in the capsules",
    "Dışarıdaki parsele ek": "Plant it in a plot outside",
    "Canı yeniler": "Restores health",
    '<div class="ri">{0}</div><div><div class="rn">{1}</div><div class="rd">{2}</div></div>\n      <div class="rp"><span>DEPO {3}</span><span class="rp-sub">ÇANTA {4}</span></div>':
      '<div class="ri">{0}</div><div><div class="rn">{1}</div><div class="rd">{2}</div></div>\n      <div class="rp"><span>STORE {3}</span><span class="rp-sub">BAG {4}</span></div>',
    Bırak: "Drop",
    '<span class="chip">🔩 Metal <b>×{0}</b> <i>+{1}</i></span>':
      '<span class="chip">🔩 Metal <b>×{0}</b> <i>+{1}</i></span>',
    '<span class="chip">⭐ Yıldız <b>×{0}</b> <i>+{1}</i></span>':
      '<span class="chip">⭐ Star <b>×{0}</b> <i>+{1}</i></span>',
    '<div class="con-note">Çantanda numune yok — dışarıda metal ve ⭐ topla, burada kargoya yükle.</div>':
      '<div class="con-note">No samples in your bag — collect metal and ⭐ outside, then load them into cargo here.</div>',
    "Dünya'ya gönderildi · laboratuvar inceliyor": "Sent to Earth · lab is examining it",
    "Ne olduğunu ve tehlikeli olup olmadığını öğrenmek için gönder":
      "Send it to find out what it is and whether it is dangerous",
    '<div class="ri"><img src="{0}" alt="" style="width:32px;height:32px;filter:{1}"></div><div><div class="rn">Bilinmeyen taş · {2}. tür<span class="ana-tag">ANALİZ İÇİN</span></div><div class="rd">{3}</div></div><div class="rp"><span>ÇANTA {4}</span></div>':
      '<div class="ri"><img src="{0}" alt="" style="width:32px;height:32px;filter:{1}"></div><div><div class="rn">Unknown rock · type {2}<span class="ana-tag">FOR ANALYSIS</span></div><div class="rd">{3}</div></div><div class="rp"><span>BAG {4}</span></div>',
    "Analizde…": "Analysing…",
    "Analize gönder": "Send for analysis",
    "Dünya'ya gönderildi · analiz bekleniyor": "Sent to Earth · awaiting analysis",
    "Kargoyla Dünya'ya gönder · neden çürüdüğünü incelesinler":
      "Send it to Earth by cargo · let them find out why it rotted",
    '<div class="ri"><img src="{0}" alt="" style="width:30px;height:30px"></div><div><div class="rn">Çürük patates<span class="ana-tag">ANALİZ İÇİN</span></div><div class="rd">{1}</div></div><div class="rp"><span>ÇANTA {2}</span></div>':
      '<div class="ri"><img src="{0}" alt="" style="width:30px;height:30px"></div><div><div class="rn">Rotten potato<span class="ana-tag">FOR ANALYSIS</span></div><div class="rd">{1}</div></div><div class="rp"><span>BAG {2}</span></div>',
    "Dünya'ya gönder": "Send to Earth",
    "📦 Numuneleri kargoya yükle · +": "📦 Load samples into cargo · +",
    "Yüklenecek numune yok": "No samples to load",
    " altın": " gold",
    "🪙 <b>Altın parçası</b> — roketteki geliştirme istasyonunda roketini güçlendirmek için kullan":
      "🪙 <b>Gold fragment</b> — use it at the upgrade station in the rocket to strengthen your rocket",
    "Envanter dolu! (": "Inventory full! (",
    "🌱 Tohumu eline aldın — ekmek için tekrar <b>F</b>":
      "🌱 You're holding the seed — press <b>F</b> again to plant",
    "Tohum yok — roketteki alet sandığından al": "No seeds — take some from the rocket's tool chest",
    "💧 Sulandı": "💧 Watered",
    "💧 Su şişesini eline aldın — sulamak için tekrar <b>F</b>":
      "💧 You're holding the water bottle — press <b>F</b> again to water",
    "Sulamak için su yok · büyüyor %": "No water for watering · growing %",
    " su)": " water)",
    "Tok durumdasın": "You're not hungry",
    " tokluk)": " food)",
    "Çapa elinde — su içmek için önce suyu eline al (numara tuşu)":
      "Hoe in hand — to drink, take the water first (number key)",
    "Yapılacak bir şey yok (F)": "Nothing to do here (F)",
    "Canın zaten dolu": "Your health is already full",
    "☢️ Radyasyon dalgası başladı — canın azalıyor, rokete gir!":
      "☢️ Radiation wave started — you're losing health, get into the rocket!",
    "☢️ Radyasyon dalgası geçti": "☢️ The radiation wave has passed",
    "Radyasyon dalgası · gövde zırhı koruyor": "Radiation wave · the hull armour is protecting you",
    "Dışarıda can azalıyor — rokete sığın!": "You're losing health outside — take shelter in the rocket!",
    "Radyasyon dalgası yaklaşıyor": "Radiation wave approaching",
    "Güneş patlaması · rokete yaklaş": "Solar flare · get close to the rocket",
    "<b>F</b>: Altın parçası topla · roket geliştirme": "<b>F</b>: Collect gold fragment · rocket upgrade",
    " — kazmayla kır": " — break it with the pickaxe",
    "Bilinmeyen taşı kazmayla kır": "Break the unknown stone with the pickaxe",
    " · <b style='color:#ff8a8a'>jeolog kazması gerekli</b>":
      " · <b style='color:#ff8a8a'>geologist's pickaxe needed</b>",
    "Çanta dolu (": "Bag full (",
    ") — rokete yükle": ") — load it into the rocket",
    "<b>F</b>: Metal numune topla": "<b>F</b>: Collect metal sample",
    "<b>F</b>: Yıldız kırıntısı topla (⭐ = 2 numune)": "<b>F</b>: Collect star fragment (⭐ = 2 samples)",
    "Taş kırılıyor…": "Breaking the stone…",
    "Sol tık: ölçümü kapat": "Left-click: close measurement",
    "Ölçülüyor… hareket etme": "Measuring… don't move",
    "<b>F</b>: Ölçüm bayrağını kaldır (": "<b>F</b>: Remove measurement flag (",
    "<b>E</b>: Rokete gir": "<b>E</b>: Enter the rocket",
    "  ·  <b>F</b>: Numuneleri kargoya yükle": "  ·  <b>F</b>: Load samples into cargo",
    "  ·  çürük patatesi kargo terminalinden gönder": "  ·  send the rotten potato from the cargo terminal",
    "<b>Sol tık</b>: toprağın radyasyonunu ölç  ·  <b>F</b>: önündeki toprağı ölç":
      "<b>Left-click</b>: measure soil radiation  ·  <b>F</b>: measure the soil in front of you",
    "<b>Sol tık</b>: yakındaki yere kaz — ilk parseli aç":
      "<b>Left click</b>: dig the ground nearby — open the first plot",
    "Çapayı eline al (numara tuşu) ya da yere tıkla": "Take the hoe in hand (number key) or click the ground",
    "Çapa roketteki alet sandığında (makine dairesi) — rokete gir: <b>E</b>":
      "The hoe is in the rocket's tool chest (engine room) — enter the rocket: <b>E</b>",
    "<b>F</b>: Tohum ek": "<b>F</b>: Plant seed",
    "<b>F</b>: Tohumu eline al": "<b>F</b>: Hold the seed",
    "<b>F</b>: Hasat et — yapraklar solmuş, bir terslik var":
      "<b>F</b>: Harvest — the leaves have wilted, something is wrong",
    "<b>F</b>: Hasat et 🥔": "<b>F</b>: Harvest 🥔",
    "<b>F</b>: Sula (hızlandırır)": "<b>F</b>: Water (speeds up growth)",
    "<b>F</b>: Suyu eline al (sulamak için)": "<b>F</b>: Hold the water (for watering)",
    "Büyüyor %": "Growing %",
    "<b>G</b>: Medikit kullan (": "<b>G</b>: Use medkit (",
    "Dikkat: canın düşük! Roketin revirinde iyileş":
      "Warning: your health is low! Heal in the rocket's sick bay",
    "Elinde: ": "Holding: ",
    "Çok uzak — tıkladığın yere daha yaklaş": "Too far — get closer to where you clicked",
    "Azami parsel sayısına ulaştın (": "You've reached the maximum number of plots (",
    "Buraya çok yakın — biraz aralık bırak": "Too close to another plot — leave some space",
    "İniş platformunu kazamazsın": "You can't dig the landing pad",
    "Dünyanın kenarını kazamazsın": "You can't dig at the edge of the world",
    "Tohumu ekmek için açtığın bir parsele tıkla": "Click a plot you've dug to plant the seed",
    "Sulamak için ekili bir parsele tıkla": "Click a planted plot to water it",
    "Bu parsel boş — önce tohum ek": "This plot is empty — plant a seed first",
    "Mahsul hazır — hasat için yanına git ve <b>F</b>":
      "Crop ready — walk up to it and press <b>F</b> to harvest",
    Sulandı: "Watered",
    "Yeni parsel: boş": "New plot: empty",
    "Yeni parsel hazır: <b>boş</b> — tohum ek (F)": "New plot ready: <b>empty</b> — plant a seed (F)",
    "Jeolog kazması yalnızca <b>bilinmeyen (?) taşları</b> kırar — kazmak için çapayı eline al":
      "The geologist's pickaxe only breaks <b>unknown (?) stones</b> — hold the hoe to dig",
    "Elinde başka bir eşya var — kazmak için çapayı eline al (numara tuşu)":
      "You're holding something else — take the hoe to dig (number key)",
    "Çapa rokette — makine dairesindeki alet sandığından al":
      "The hoe is in the rocket — take it from the tool chest in the engine room",
    "Çapayı eline aldın — kazmak için tekrar tıkla": "Hoe in hand — click again to dig",
    "Yaşanabilirlik araştırması": "Habitability study",
    "Mars'ta bir insanın hayatta kalıp kalamayacağını ölç. Fırtına, radyasyon ve yaşam desteği raporları daha değerli.":
      "Measure whether a human can survive on Mars. Storm, radiation and life support reports are worth more.",
    "Jeoloji ve nadir mineraller": "Geology and rare minerals",
    "Kayaçları ve bilinmeyen mineralleri incele. Numune ve nadir taş raporları daha değerli.":
      "Study rocks and unknown minerals. Sample and rare stone reports are worth more.",
    "Uzun süreli yaşam testi": "Long-duration living test",
    "Mars toprağında besin üretimini dene. Tarım ve yaşam desteği raporları daha değerli.":
      "Try producing food in Martian soil. Farming and life support reports are worth more.",
    Kolay: "Easy",
    Normal: "Normal",
    Zor: "Hard",
    "Orta sınıf roket": "Medium-lift rocket",
    "Ucuz ama taşıma kapasitesi sınırlı.": "Cheap, but its lift capacity is limited.",
    "Ağır roket": "Heavy-lift rocket",
    "Dengeli kapasite ve maliyet.": "Balanced capacity and cost.",
    "Süper ağır roket": "Super heavy-lift rocket",
    "Her şeyi taşır ama bütçeyi zorlar.": "Carries everything, but strains the budget.",
    "Hızlı transfer": "Fast transfer",
    "Daha çok yakıt (kütle) gerekir; mürettebat Mars'a erzakı dolu varır.":
      "Needs more propellant (mass); the crew reaches Mars with full supplies.",
    "Ekonomik transfer": "Economy transfer",
    "Az yakıt gerekir ama yolculuk uzar: erzak ve oksijen eksik başlar.":
      "Needs little propellant but the journey is longer: supplies and oxygen start lower.",
    "Kısa görev: bütçe dostu, az erzak.": "Short mission: budget-friendly, few supplies.",
    "Orta süre: ek erzak paketi.": "Medium duration: extra supply package.",
    "Uzun görev: bol erzak, yüksek maliyet.": "Long mission: plenty of supplies, high cost.",
    "Güç sistemi": "Power system",
    "Tüm sistemler elektrik ister. Güneş panelleri fırtınada tozla kaplanır; radyoizotop jeneratör (RTG) hep aynı gücü verir ama ağır ve pahalıdır.":
      "Every system needs electricity. Solar panels get covered in dust during storms; a radioisotope generator (RTG) always gives the same power but is heavy and expensive.",
    "Hafif ve ucuz; fırtınada üretim düşer.": "Light and cheap; output drops in storms.",
    "Geniş güneş panelleri": "Large solar panels",
    "Daha çok güç; fırtınada yine düşer.": "More power; still drops in storms.",
    "Radyoizotop jeneratör (RTG)": "Radioisotope generator (RTG)",
    "Fırtınadan etkilenmez; ağır ve pahalı.": "Unaffected by storms; heavy and expensive.",
    Batarya: "Battery",
    "Batarya, güneş paneli üretimi düştüğünde (fırtına) sistemleri ayakta tutar.":
      "The battery keeps systems running when solar panel output drops (storms).",
    "Standart batarya": "Standard battery",
    "Fırtınada kısa süre idare eder.": "Lasts a short time in a storm.",
    "Büyük batarya": "Large battery",
    "Fırtınada güç kaybının yarısını karşılar.": "Covers half of the power loss in a storm.",
    "Oksijen tüpünün kapasitesini ve kendini yenileme hızını belirler. Daha iyi sistem daha çok güç ve kütle ister.":
      "Sets the oxygen tank's capacity and how fast it refills itself. A better system needs more power and mass.",
    "Standart O₂ tüpü": "Standard O₂ tank",
    "Temel kapasite.": "Basic capacity.",
    "Genişletilmiş tüp": "Extended tank",
    "%40 daha fazla oksijen.": "40% more oxygen.",
    "Kapalı döngü rejeneratör": "Closed-loop regenerator",
    "Tüp neredeyse 2 kat hızlı dolar.": "The tank refills almost twice as fast.",
    "Yapı ve koruma": "Structure and protection",
    "Gövde zırhı fırtınada motorun bozulma olasılığını azaltır. Zırh ağırdır; fırlatma aracının kapasitesini zorlar.":
      "Hull armour reduces the chance of the engine failing in a storm. Armour is heavy and strains the launch vehicle's capacity.",
    "Hafif gövde": "Light hull",
    "Fırtınada motor arıza riski %60.": "Engine failure risk in storms: 60%.",
    "Takviyeli gövde": "Reinforced hull",
    "Arıza riski %35 ile başlar.": "Failure risk starts at 35%.",
    "Ağır zırhlı gövde": "Heavily armoured hull",
    "Arıza riski %15 ile başlar.": "Failure risk starts at 15%.",
    "Anten, günde Dünya'ya gönderilebilecek veri miktarını (MB/sol) ve yanıt süresini belirler. Bilim aletlerinin ürettiği veri bu kapasiteyi aşarsa bilimin bir kısmı kaybolur.":
      "The antenna sets how much data can be sent to Earth per day (MB/sol) and how fast replies come. If the instruments produce more data than this, part of the science is lost.",
    "Düşük kazançlı anten": "Low-gain antenna",
    "Ucuz; az veri, yavaş yanıt.": "Cheap; little data, slow replies.",
    "Yüksek kazançlı anten": "High-gain antenna",
    "Dengeli seçim.": "A balanced choice.",
    "Anten + Mars yörüngesinde röle uydusu": "Antenna + relay satellite in Mars orbit",
    "Çok veri, hızlı yanıt; fırtınada bile gönderim yapılır.":
      "Lots of data, fast replies; you can transmit even during storms.",
    "Aviyonik ve yönelim kontrolü": "Avionics and attitude control",
    "Araç bilgisayarı ve yönelim kontrolü; gelişmiş sistem tarayıcının menzilini artırır.":
      "The vehicle computer and attitude control; the advanced system increases the scanner's range.",
    "Standart bilgisayar": "Standard computer",
    "Temel tarayıcı menzili.": "Basic scanner range.",
    "Gelişmiş bilgisayar + yıldız izleyici": "Advanced computer + star tracker",
    "Tarayıcı menzili %35 artar.": "Scanner range +35%.",
    "Meteoroloji istasyonu": "Weather station",
    "Fırtına uyarısı 30 sn daha erken gelir.": "Storm warnings arrive 30 s earlier.",
    "Radyasyon dedektörü": "Radiation detector",
    "Radyasyon uyarısı 30 sn daha erken gelir.": "Radiation warnings arrive 30 s earlier.",
    "Kayaç spektrometresi": "Rock spectrometer",
    "Numune raporlarının bilim değeri %50 artar.": "Sample reports are worth 50% more science.",
    "Zemin radarı": "Ground-penetrating radar",
    "Bilinmeyen taşları %80 daha uzaktan bulursun.": "You find unknown stones from 80% farther away.",
    "Sera modülü": "Greenhouse module",
    "Bitkiler %50 daha hızlı büyür.": "Plants grow 50% faster.",
    "Panoramik kamera": "Panoramic camera",
    "Tüm raporların bilim değeri %15 artar; çok veri üretir.":
      "All reports are worth 15% more science; produces lots of data.",
    "Görev hedefi": "Mission objective",
    "Fırlatma ve yörünge": "Launch and trajectory",
    "Uzay aracı": "Spacecraft",
    "Bilim ve iletişim": "Science and communications",
    "Simülasyon ve fırlatma": "Simulation and launch",
    Rekorlar: "Records",
    "Kütle {0} t, fırlatma aracının kapasitesi {1} t. Daha güçlü bir roket seç ya da kütleyi azalt.":
      "Mass is {0} t, but the launch vehicle can carry {1} t. Choose a stronger rocket or reduce the mass.",
    "Güç tüketimi {0} kW, üretim {1} kW. Güç sistemini büyüt ya da alet çıkar.":
      "Power use is {0} kW, generation {1} kW. Enlarge the power system or remove an instrument.",
    "Maliyet {0} M$, bütçe {1} M$. Daha ucuz bileşenler seç.":
      "Cost is {0} M$, budget {1} M$. Choose cheaper components.",
    "Aletler günde {0} MB veri üretiyor, anten {1} MB gönderebiliyor. Bilimin yaklaşık %{2}'i kaybolacak.":
      "The instruments produce {0} MB of data per day, the antenna can send {1} MB. About {2}% of the science will be lost.",
    "Hiç bilim aleti yok: görev bilim değeri düşük olur.":
      "No science instruments: the mission's science value will be low.",
    "Güç payı çok az: fırtınada güneş panelleri yetersiz kalabilir.":
      "Very little power margin: solar panels may fall short during storms.",
    "{0} simülasyonda fırlatma başarısız oldu: fırlatma aracının güvenilirliği bunu belirler.":
      "The launch failed in {0} simulations: the launch vehicle's reliability determines this.",
    "{0} simülasyonda fırtına motoru onarılamaz şekilde bozdu: gövde zırhı bu riski düşürür.":
      "In {0} simulations a storm damaged the engine beyond repair: hull armour lowers this risk.",
    "{0} simülasyonda oksijen yetmedi: yaşam desteği ve güç sistemi bunu etkiler.":
      "In {0} simulations the oxygen ran out: life support and the power system affect this.",
    "{0} simülasyonda erzak bitti: görev süresi, transfer yörüngesi ve sera modülü bunu etkiler.":
      "In {0} simulations the supplies ran out: mission duration, transfer trajectory and the greenhouse module affect this.",
    "Simülasyonların hiçbirinde ciddi bir arıza görülmedi.": "No serious failure occurred in any simulation.",
    "Mars'a ilk adım": "First steps on Mars",
    "Mars'a yeni gelenler için. Kaynaklar daha yavaş tükenir, tehlikeler daha hafif vurur ve yaralar daha çabuk iyileşir. Keşfetmeye ve öğrenmeye odaklan.":
      "For newcomers to Mars. Resources run out more slowly, hazards hit more softly and wounds heal faster. Focus on exploring and learning.",
    "Dengeli görev": "Balanced mission",
    "Oyunun tasarlandığı denge. Hayatta kalmak için yemeğini, suyunu ve oksijenini planlaman gerekir ama küçük hatalara yer vardır.":
      "The balance the game was designed for. You need to plan your food, water and oxygen to survive, but there is room for small mistakes.",
    "Deneyimli komutan": "Veteran commander",
    "Her kaynak değerlidir. Açlık, susuzluk ve oksijen daha hızlı düşer; fırtınalar, radyasyon ve meteorlar daha sert vurur, iyileşme yavaşlar.":
      "Every resource counts. Hunger, thirst and oxygen drop faster; storms, radiation and meteors hit harder, and healing is slower.",
    "Açlık hızı": "Hunger rate",
    "Susuzluk hızı": "Thirst rate",
    "Radyasyon hasarı": "Radiation damage",
    "Fırtına etkisi": "Storm impact",
    "Meteor hasarı": "Meteor damage",
    "İyileşme hızı": "Healing rate",
    Standart: "Standard",
    "%{0} daha hızlı": "{0}% faster",
    "%{0} daha yavaş": "{0}% slower",
    "%{0} daha fazla": "{0}% more",
    "%{0} daha az": "{0}% less",
    "%{0} daha güçlü": "{0}% stronger",
    "%{0} daha zayıf": "{0}% weaker",
    "<h4>Görev özeti</h4><p>ARES-1 Mars'a doğru yola çıkıyor. İnişten sonra hayatta kal, keşfet ve bulgularını Dünya'ya raporla.</p>\n      <dl class=\"ng-dl\"><dt>Fırlatma aracı</dt><dd>{0}</dd><dt>Transfer</dt><dd>{1} · {2} gün</dd><dt>Güç</dt><dd>{3}</dd>\n      <dt>Yaşam desteği</dt><dd>{4}</dd><dt>Gövde</dt><dd>{5}</dd><dt>İletişim</dt><dd>{6}</dd>\n      <dt>Bilim aletleri</dt><dd>{7}</dd><dt>Görev süresi</dt><dd>{8} sol</dd></dl>":
      '<h4>Mission overview</h4><p>ARES-1 is on its way to Mars. After landing, survive, explore and report your findings to Earth.</p>\n      <dl class="ng-dl"><dt>Launch vehicle</dt><dd>{0}</dd><dt>Transfer</dt><dd>{1} · {2} days</dd><dt>Power</dt><dd>{3}</dd>\n      <dt>Life support</dt><dd>{4}</dd><dt>Hull</dt><dd>{5}</dd><dt>Communications</dt><dd>{6}</dd>\n      <dt>Science instruments</dt><dd>{7}</dd><dt>Mission duration</dt><dd>{8} sols</dd></dl>',
    '<div class="ng-left">\n      <label class="ng-lbl">Görev adı</label><input class="md-in ng-name" id="ngName" maxlength="24" placeholder="ARES-1" value="{0}">\n      <label class="ng-lbl">Zorluk</label>\n      <div class="ng-diffs">{1}</div>\n      <div class="ng-dbox" data-lv="{2}"><p id="ngDesc">{3}</p>\n        <div class="ng-rows">{4}</div>\n      </div>\n      <div class="ng-tg"><span><b>Açılış hikâyesi</b><small>Görev başlamadan önce ARES-1 sinemasını oynat.</small></span><div class="m2-tg {5}" id="ngIntro" role="switch"></div></div>\n    </div>\n    <div class="ng-right">{6}{7}</div>':
      '<div class="ng-left">\n      <label class="ng-lbl">Mission name</label><input class="md-in ng-name" id="ngName" maxlength="24" placeholder="ARES-1" value="{0}">\n      <label class="ng-lbl">Difficulty</label>\n      <div class="ng-diffs">{1}</div>\n      <div class="ng-dbox" data-lv="{2}"><p id="ngDesc">{3}</p>\n        <div class="ng-rows">{4}</div>\n      </div>\n      <div class="ng-tg"><span><b>Opening story</b><small>Play the ARES-1 cinematic before the mission starts.</small></span><div class="m2-tg {5}" id="ngIntro" role="switch"></div></div>\n    </div>\n    <div class="ng-right">{6}{7}</div>',
    "Aletlerin ürettiği veri anten kapasitesini aştı; bilimin %{0}'i Dünya'ya ulaşamadı.":
      "The instruments' data exceeded the antenna capacity; {0}% of the science never reached Earth.",
    "Görev planlanan {0} solu {1} sol aştı: erzak ve bütçe zorlandı.":
      "The mission exceeded the planned {0} sols by {1} sols: supplies and budget were stretched.",
    "{0} kez kritik yaşam değeri kaydedildi: oksijen, su veya yiyecek tükenmeye yaklaştı.":
      "A critical life value was logged {0} times: oxygen, water or food was close to running out.",
    "Bilim hedefinin yarısına ulaşılmadı: daha çok rapor göndermek ve hedefe uygun gözlem yapmak puanı artırır.":
      "Less than half of the science goal was reached: sending more reports and making observations that match the objective raises the score.",
    "Görev başarısı": "Mission success",
    "Bilim değeri": "Science value",
    "Kaynak verimliliği": "Resource efficiency",
    "Zaman yönetimi": "Time management",
    Atla: "Skip",
    Turkish: "Turkish",
    İngilizce: "English",
    Almanca: "German",
    İspanyolca: "Spanish",
    Genel: "General",
    Ses: "Audio",
    Görüntü: "Graphics",
    Arayüz: "Interface",
    Erişilebilirlik: "Accessibility",
    Kontroller: "Controls",
    Dil: "Language",
    Oynanış: "Gameplay",
    Zorluk: "Difficulty",
    "Açlık, susuzluk ve oksijen tüketimini; radyasyon, fırtına ve meteor hasarını ve iyileşme hızını belirler.":
      "Sets hunger, thirst and oxygen consumption; radiation, storm and meteor damage; and healing speed.",
    "Etkileşim ipuçları": "Interaction hints",
    "Ekranın altındaki “F: topla”, “E: kullan” gibi ipuçlarını göster.":
      "Show hints such as “F: collect” and “E: use” at the bottom of the screen.",
    "Hasar ve kazanç sayıları": "Damage and gain numbers",
    "Oyuncunun üzerinde beliren +/− sayılarını göster.": "Show the +/− numbers that appear above the player.",
    "Açılış hikâyesi": "Opening story",
    "Her yeni görevde ARES-1 açılış sinemasını oynat.":
      "Play the ARES-1 opening cinematic for every new mission.",
    "Otomatik kayıt": "Autosave",
    "Görevi belirli aralıklarla kendiliğinden kaydet.":
      "Save the mission automatically at regular intervals.",
    Kapalı: "Off",
    "Ses düzeyleri": "Volume levels",
    "Genel ses": "Master volume",
    Müzik: "Music",
    Efektler: "Effects",
    "Çapa, toplama, meteor, telsiz ve arayüz sesleri.": "Hoe, pickup, meteor, radio and interface sounds.",
    "Ortam sesi": "Ambient sound",
    "Rüzgâr ve kum fırtınası uğultusu.": "Wind and sandstorm howl.",
    "Grafik kalitesi": "Graphics quality",
    "Ultra grafik (WebGL)": "Ultra graphics (WebGL)",
    "Ana menü manzarası ve hikâyedeki gezegenler ekran kartıyla işlenir. Zayıf bilgisayarlarda kapatabilirsin.":
      "The main menu landscape and the planets in the story are rendered by the graphics card. You can turn this off on weaker computers.",
    "Parçacık yoğunluğu": "Particle density",
    "Toz, duman, kıvılcım ve patlama parçacıkları.": "Dust, smoke, spark and explosion particles.",
    Düşük: "Low",
    Orta: "Medium",
    Yüksek: "High",
    "Atmosfer efektleri": "Atmosphere effects",
    "Ufuk pusu, süzülen toz perdeleri ve havadaki zerreler.":
      "Horizon haze, drifting dust veils and airborne particles.",
    "Film greni": "Film grain",
    "Menü ve hikâyede sinematik gren dokusu.": "Cinematic grain texture in the menu and the story.",
    Ekran: "Display",
    "FPS sınırı": "FPS limit",
    "Ekran yenilemesiyle eşitle.": "Sync with the display refresh rate.",
    "Tam ekran": "Fullscreen",
    "Arayüz ölçeği": "Interface scale",
    "Gün kartı, görev kartı, durum barları ve envanter boyutu.":
      "Size of the day card, mission card, status bars and inventory.",
    Küçük: "Small",
    Büyük: "Large",
    "Harita boyutu": "Map size",
    "Altyazı boyutu": "Subtitle size",
    "Açılış hikâyesindeki altyazılar.": "Subtitles in the opening story.",
    "Hikâye anları": "Story moments",
    "İlk fırtına, radyasyon, nadir taş gibi anlarda kısa sahne ve iç ses. Kapalıyken yalnızca acil hedef gösterilir.":
      "Short scenes and inner voice at key moments like the first storm, radiation or a rare stone. When off, only the urgent goal is shown.",
    "Ekran sarsıntısı": "Screen shake",
    "Meteor, fırtına ve patlamalarda kamera sarsıntısının şiddeti.":
      "Intensity of camera shake from meteors, storms and explosions.",
    "Parlamaları azalt": "Reduce flashes",
    "Meteor çarpması ve patlamalardaki beyaz ekran parlamalarını yumuşat.":
      "Soften the white screen flashes from meteor impacts and explosions.",
    "Yüksek kontrast": "High contrast",
    "Arayüz metinlerini ve panelleri daha belirgin yap.": "Make interface text and panels more distinct.",
    Etkin: "Enabled",
    '<div class="m2-sec">Klavye</div><div class="m2-keys">':
      '<div class="m2-sec">Keyboard</div><div class="m2-keys">',
    Hareket: "Movement",
    Koş: "Run",
    "Etkileşim / rokete gir": "Interact / enter rocket",
    "Topla · ek · sula · hasat": "Collect · plant · water · harvest",
    "Medikit kullan": "Use medkit",
    "Rehber kitap": "Guide book",
    "Çapayla kaz": "Dig with the hoe",
    "Sol tık": "Left click",
    "Eşyayı eline al": "Hold item",
    Merdiven: "Ladder",
    Duraklat: "Pause",
    "Hikâyeyi geç": "Skip story",
    "Space (basılı)": "Space (hold)",
    Harita: "Map",
    "sağ üst": "top right",
    '</div>\n      <div class="m2-sec">Dokunmatik</div><div class="m2-keys"><div><span>Hareket</span><kbd>sol joystick</kbd></div><div><span>Eylemler</span><kbd>sağ düğmeler</kbd></div></div>':
      '</div>\n      <div class="m2-sec">Touch</div><div class="m2-keys"><div><span>Movement</span><kbd>left joystick</kbd></div><div><span>Actions</span><kbd>right buttons</kbd></div></div>',
    "ROKET İÇİ": "INSIDE THE ROCKET",
    '<h4>GÖREV DURUMU</h4>\n    <div class="m2-bars">{0}{1}{2}{3}</div>\n    <dl class="m2-kv"><dt>Görev</dt><dd>{4}</dd><dt>Kıyafet</dt><dd>{5}</dd>\n      <dt>Ana motor</dt><dd style="color:{6}">{7}</dd>\n      <dt>Fırtına kalkanı</dt><dd>{8}</dd><dt>Roket boyası</dt><dd>{9}</dd>\n      <dt>Kargo</dt><dd>{10} / {11}</dd><dt>Oynama süresi</dt><dd>{12}</dd></dl>\n    <h4>KAYNAKLAR</h4>\n    <div class="m2-res"><span><img src="{13}">{14}</span><span><img src="{15}">{16}</span><span><i class="ug-au"></i>{17}</span>{18}</div>':
      '<h4>MISSION STATUS</h4>\n    <div class="m2-bars">{0}{1}{2}{3}</div>\n    <dl class="m2-kv"><dt>Mission</dt><dd>{4}</dd><dt>Suit</dt><dd>{5}</dd>\n      <dt>Main engine</dt><dd style="color:{6}">{7}</dd>\n      <dt>Storm shield</dt><dd>{8}</dd><dt>Rocket paint</dt><dd>{9}</dd>\n      <dt>Cargo</dt><dd>{10} / {11}</dd><dt>Play time</dt><dd>{12}</dd></dl>\n    <h4>RESOURCES</h4>\n    <div class="m2-res"><span><img src="{13}">{14}</span><span><img src="{15}">{16}</span><span><i class="ug-au"></i>{17}</span>{18}</div>',
    "Motoru onardın, numuneleri yükledin ve <b>Dünya'ya geri döndün!</b><br><br>":
      "You repaired the engine, loaded the samples and <b>returned to Earth!</b><br><br>",
    "⏱ Süre: <b>": "⏱ Time: <b>",
    "🌍 Ziyaret edilen gezegen: <b>": "🌍 Planets visited: <b>",
    "📦 Getirilen numune: <b>": "📦 Samples brought back: <b>",
    "</b><br>📅 Mars'ta geçen gün: <b>": "</b><br>📅 Days spent on Mars: <b>",
    "📋 Tamamlanan görev: <b>": "📋 Missions completed: <b>",
    '<h4 style="margin:6px 0;color:#fff;text-align:left">Görev sonrası analiz</h4><ul class="wr-why">{0}</ul>':
      '<h4 style="margin:6px 0;color:#fff;text-align:left">Post-mission analysis</h4><ul class="wr-why">{0}</ul>',
    "Hava kilidinden dışarı çık — <b>E</b>": "Exit through the airlock — <b>E</b>",
    "Haritadaki ◆ işaretine yürü": "Walk to a ◆ marker on the map",
    "Numunenin yanında <b>F</b>'ye bas": "Press <b>F</b> next to the sample",
    "Toplam <b>5</b> numune topla": "Collect <b>5</b> samples in total",
    "Merdivenden makine dairesine in — <b>S</b>": "Climb down to the engine room — <b>S</b>",
    "<b>ALET SANDIĞI</b> → <b>E</b> → Çapa: <b>Al</b>": "<b>TOOL CHEST</b> → <b>E</b> → Hoe: <b>Take</b>",
    "Alet sandığından <b>tohum</b> al": "Take <b>seeds</b> from the tool chest",
    "Dışarıda yere <b>sol tıkla</b> — çapayla kaz":
      "Outside, <b>left-click</b> the ground — dig with the hoe",
    "Çukurun yanında <b>F</b> ile tohum ek": "Press <b>F</b> next to the hole to plant a seed",
    "Su şişesini eline al — alttaki numara tuşu": "Hold the water bottle — number key below",
    "<b>F</b> ile iç (ya da roketin mutfağında <b>İç</b>)":
      "Drink with <b>F</b> (or <b>Drink</b> in the rocket's kitchen)",
    "Rokete gir, komuta güvertesine çık": "Enter the rocket, climb to the command deck",
    "Soldaki <b>İLETİŞİM</b> masasında <b>E</b>": "<b>E</b> at the <b>COMMS</b> desk on the left",
    "<b>Rapor hazırla</b> → gözlem seç, not yaz → <b>Dünya'ya gönder</b>":
      "<b>Prepare report</b> → pick observations, write a note → <b>Send to Earth</b>",
    "Turuncu fırtına uyarısını bekle (Gün 2, ": "Wait for the orange storm warning (Day 2, ",
    "Uyarı çıkınca 45 sn içinde rokete gir": "When it appears, get in the rocket within 45 s",
    "Fırtına bitene kadar içeride kal": "Stay inside until the storm ends",
    "Fırtınanın motoru bozması — duman çıkar": "The storm damages the engine — smoke appears",
    "4 onarım aşamasını tamamla": "Complete the 4 repair stages",
    "Yeşil radyasyon uyarısını bekle (Gün 3)": "Wait for the green radiation warning (Day 3)",
    "Dalga geçene kadar içeride kal": "Stay inside until the wave passes",
    "Su şişesini eline al, parselin yanında <b>F</b> ile sula":
      "Hold the water bottle and press <b>F</b> by the plot to water",
    "Halka sarıya dönene kadar bekle": "Wait until the ring turns yellow",
    "Dünya'nın yanıtını bekle (~½ sol)": "Wait for Earth's reply (~½ sol)",
    "Komuta güvertesi → <b>İLETİŞİM</b> → <b>E</b>": "Command deck → <b>COMMS</b> → <b>E</b>",
    "Gelen kutusu → <b>YANIT</b> etiketli mesajı aç": "Inbox → open the message tagged <b>REPLY</b>",
    "Çürük patates çantanda olsun (hasattan çıkar)": "Have a rotten potato in your bag (from a harvest)",
    "Çürük patates → <b>Dünya'ya gönder</b>": "Rotten potato → <b>Send to Earth</b>",
    "Laboratuvar inceliyor — kısa sürede yanıt gelir": "The lab is examining it — a reply comes soon",
    "Gelen kutusu → <b>ANALİZ</b> mesajı: çürümenin nedeni": "Inbox → <b>ANALYSIS</b> message: why it rotted",
    "Alet sandığından <b>radyasyon ölçeri</b> al": "Take the <b>radiation meter</b> from the tool chest",
    "Ölçeri eline al — numara tuşu": "Hold the meter — number key",
    "Toprağa <b>sol tıkla</b> — 3 farklı yer": "<b>Left-click</b> the soil — 3 different spots",
    "Yeşil bayraklı yer bul (1,0 µSv/h altı)": "Find a green-flag spot (below 1.0 µSv/h)",
    "Sula, büyüt ve sağlıklı hasat al": "Water it, let it grow and get a healthy harvest",
    "Meteor düşmesini bekle — uğultu ve gölge": "Wait for a meteor — rumble and shadow",
    "Kraterin çevresindeki sarı parçaları <b>F</b> ile topla (3)":
      "Collect the yellow pieces around the crater with <b>F</b> (3)",
    "Alet sandığından <b>jeolog kazmasını</b> al": "Take the <b>geologist's pickaxe</b> from the tool chest",
    "Roketten uzaklaş, haritadaki <b>?</b> işaretine git":
      "Move away from the rocket, go to the <b>?</b> marker on the map",
    "Taşın yanında <b>F</b> — kazmayla 3 vuruşta kır": "<b>F</b> next to the stone — break it in 3 swings",
    "Bilinmeyen taşı çapayla çıkar": "Dig out an unknown stone with the hoe",
    "Rokete gir → komuta güvertesi → <b>Kargo terminali</b>":
      "Enter the rocket → command deck → <b>Cargo terminal</b>",
    "<b>ANALİZ İÇİN</b> satırında <b>Analize gönder</b>":
      "On the <b>FOR ANALYSIS</b> row, <b>Send for analysis</b>",
    "Malzeme topla: 8 metal, 1 ⭐, 2 olivin": "Gather materials: 8 metal, 1 ⭐, 2 olivine",
    "Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b>":
      "Living deck → <b>FABRICATION WORKSHOP</b> → <b>E</b>",
    "Kıyafet setleri → <b>Öncü Mk-II</b> → Üret ve giy": "Suit sets → <b>Pioneer Mk-II</b> → Build and wear",
    "Malzeme topla: 10 altın, 3 titanyum": "Gather materials: 10 gold, 3 titanium",
    "Atölye → <b>Roket geliştirme</b> sekmesi": "Workshop → <b>Rocket upgrades</b> tab",
    "<b>Titanyum Plakalar</b> → <b>Kur</b>": "<b>Titanium Plates</b> → <b>Install</b>",
    "Kıyafet setleri → <b>Kaşif Mk-I</b> → Üret ve giy": "Suit sets → <b>Explorer Mk-I</b> → Build and wear",
    "Roketin yanında <b>F</b> ile kargoya yükle (10)":
      "Load into cargo with <b>F</b> next to the rocket (10)",
    "Komuta güvertesi → <b>NAVİGASYON</b> → <b>E</b>": "Command deck → <b>NAVIGATION</b> → <b>E</b>",
    "<b>EVE DÖN</b>'e bas": "Press <b>GO HOME</b>",
    "UYKU KAPSÜLÜ": "SLEEP POD",
    "Bu taşı kırmak için <b>jeolog kazması</b> gerekli — makine dairesindeki <b>alet sandığından</b> al":
      "You need the <b>geologist's pickaxe</b> to break this stone — take it from the <b>tool chest</b> in the engine room",
    "JENERATÖR ARIZALI": "GENERATOR FAILED",
    "YAPAY YERÇEKİMİ": "ARTIFICIAL GRAVITY",
    "⚠️ <b>Yapay yerçekimi jeneratörü durdu</b> — roketin içi de Mars yerçekiminde (0,38 g). Motoru onarınca geri gelir.":
      "⚠️ <b>Artificial gravity generator stopped</b> — the rocket's interior is now at Mars gravity too (0.38 g). It comes back once the engine is repaired.",
    "✅ Yapay yerçekimi yeniden aktif (1 g)": "✅ Artificial gravity active again (1 g)",
    "🪐 <b>Mars yerçekimi: 0,38 g</b> — adımların seker, durması zordur. <b>Space</b> ile zıpla.":
      "🪐 <b>Mars gravity: 0.38 g</b> — your steps bounce and stopping is hard. Press <b>Space</b> to jump.",
    "Uff… Uzun bir uykuydu. ARES-1 yerde, ben de sağ salimim.":
      "Phew… That was a long sleep. ARES-1 is down, and I'm safe and sound.",
    "Burada hayatta kalmalı, Mars'ı araştırmalı ve sonunda eve dönmeliyim.":
      "I have to survive here, explore Mars and, in the end, get back home.",
    "Önce makine dairesindeki alet sandığından ekipmanımı alayım. Sol üstteki görev kartı yolu gösterir.":
      "First I'll grab my gear from the tool chest in the engine room. The mission card at the top left shows the way.",
    "Bu uğultu da ne?… Rüzgâr bir anda döndü!": "What's that roar?… The wind turned out of nowhere!",
    "Kum her yeri yutuyor, önümü göremiyorum… Bu hıza dayanamam.":
      "Sand is swallowing everything, I can't see ahead… I can't take winds this fast.",
    "Bir dahakine bu rüzgâra dayanmak için atölyede kıyafetimi ve roketimi güçlendirmeliyim.":
      "Next time, to withstand this wind, I need to upgrade my suit and the rocket in the workshop.",
    "Ama şimdi hemen rokete gitmeliyim!": "But right now I have to get to the rocket!",
    "Fırtınadan korun — rokete sığın": "Escape the storm — shelter in the rocket",
    "Kapağı son anda kapattım… Gövde zangır zangır titriyor.":
      "I shut the hatch at the last second… The hull is rattling hard.",
    "Dışarıda kalsam rüzgâr beni savururdu. Bir dahakine uyarı kartını görünce erkenden döneceğim.":
      "Out there the wind would have thrown me around. Next time I'll head back as soon as I see the warning card.",
    "Gövde zangır zangır titriyor… Dışarıda kum fırtınası kopmuş.":
      "The hull is rattling hard… A sandstorm has broken loose outside.",
    "İyi ki içerideyim. Fırtına bitene kadar buradan çıkmıyorum.":
      "Good thing I'm inside. I'm not leaving until the storm is over.",
    "ARES-1, telemetride ana motor arızası görüyoruz!": "ARES-1, telemetry shows a main engine failure!",
    "Fırtına motoru vurmuş… Bu motor olmadan eve dönüş yok.":
      "The storm hit the engine… Without it, there's no way home.",
    "Fırtına diner dinmez makine dairesine inip onarmalıyım.":
      "As soon as the storm dies down, I need to get to the engine room and fix it.",
    "Başım dönüyor… Canım neden bu kadar hızlı azalıyor?": "I'm dizzy… Why is my health dropping so fast?",
    "Dozimetre çıldırmış — güneş patlaması! Bu radyasyon kıyafetimden geçiyor.":
      "The dosimeter is going crazy — a solar flare! This radiation is getting through my suit.",
    "Bir dahakine etkilenmemek için atölyede astronot kıyafetimi geliştirmeliyim.":
      "So it doesn't hit me next time, I need to upgrade my spacesuit in the workshop.",
    "Şimdilik tek çare roketin kalın gövdesi. Hemen içeri!":
      "For now the only shelter is the rocket's thick hull. Inside, now!",
    "Gövde zırhı radyasyonu kesiyor, değerler düşüyor.":
      "The hull armour is blocking the radiation, the readings are dropping.",
    "Dalga geçene kadar içerideyim. En iyisi uyku kabininde dinlenmek.":
      "I'm staying inside until the wave passes. Best to rest in the sleep pod.",
    "Dozimetre bir anda yükseldi… Dışarıda güneş patlaması var.":
      "The dosimeter suddenly spiked… There's a solar flare outside.",
    "Gövde zırhı beni koruyor. Dalga geçene kadar dışarı çıkmayacağım.":
      "The hull armour is protecting me. I won't go out until the wave passes.",
    "Motor yeniden çalışıyor… Ama bir sonraki fırtınada yine bozulabilir.":
      "The engine is running again… But the next storm could break it again.",
    "Atölyedeki roket geliştirmeden gövdeye titanyum zırh takmalıyım. Bunun için altın ve titanyum gerek.":
      "I should fit titanium armour to the hull from the workshop's rocket upgrades. That takes gold and titanium.",
    "Canım çok hızlı eridi… Bu standart kıyafet radyasyonu durdurmuyor.":
      "My health melted away so fast… This standard suit doesn't stop radiation.",
    "Atölyede radyasyon katmanlı bir kıyafet üretmeliyim. Bir sonraki dalgaya hazırlıklı olacağım.":
      "I need to build a radiation-shielded suit in the workshop. I'll be ready for the next wave.",
    "Bu ne?… Patatesler kararmış, yumuşamış.": "What's this?… The potatoes have turned dark and soft.",
    "Suyu da verdim, ışığı da aldı. Sorun toprakta olmalı ama bunu burada çözemem.":
      "I watered them and they got light. It must be the soil, but I can't figure it out here.",
    "Çürük patates çantamda. Rokete dönüp komuta güvertesindeki kargo terminalinden Dünya'ya göndereyim.":
      "The rotten potato is in my bag. I'll go back to the rocket and send it to Earth from the cargo terminal on the command deck.",
    "Laboratuvar inceleyip neden çürüdüğünü bana yazar.":
      "The lab will examine it and tell me why it rotted.",
    "Rokete dön": "Return to the rocket",
    "Komuta güvertesine çık — merdivende W": "Climb to the command deck — W on the ladder",
    "Kargo terminalinde E'ye bas": "Press E at the cargo terminal",
    "Çürük patates → Dünya'ya gönder": "Rotten potato → Send to Earth",
    "ARES-1, burası Dünya laboratuvarı. Patates numunen elimize ulaştı.":
      "ARES-1, this is the Earth lab. Your potato sample has arrived.",
    "Çürümenin nedenini bulduk. Raporu gelen kutuna yolladık, hemen oku.":
      "We've found why it rotted. The report is in your inbox — read it now.",
    "Komuta güvertesi → İLETİŞİM masası → E": "Command deck → COMMS desk → E",
    "Gelen kutusu → ANALİZ mesajını aç": "Inbox → open the ANALYSIS message",
    "Demek sebep toprağın radyasyonuymuş… Mikrop değil.": "So it was the soil's radiation… not germs.",
    "Bundan sonra ekmeden önce radyasyon ölçerle toprağı ölçüp yeşil çıkan yere ekeceğim.":
      "From now on I'll measure the soil with the radiation meter before planting, and only plant where it reads green.",
    "Aman Allah'ım… Bu taş kendi kendine ışık saçıyor!": "Oh my God… This stone is glowing all by itself!",
    "Böyle bir mineral hiçbir kayıtta yok. İçinde ne var bunun?":
      "No mineral like this is on record. What's inside it?",
    "Hemen rokete götürüp kargo terminalinden Dünya'ya analize göndermeliyim!":
      "I have to take it to the rocket and send it to Earth for analysis from the cargo terminal!",
    "Taşı rokete götür": "Take the stone to the rocket",
    "Parlayan taş → Analize gönder": "Glowing stone → Send for analysis",
    "Vay… İçinden ışık sızan bir taş! Böylesini hiç görmedim.":
      "Whoa… A stone with light seeping out of it! I've never seen anything like it.",
    "Çok güzel… ama ne olduğunu bilmeden kullanmamalıyım.":
      "It's beautiful… but I shouldn't use it without knowing what it is.",
    "Rokete götürüp kargo terminalinden Dünya'ya analize göndermeliyim. İnceleyip bana bildirsinler.":
      "I'll take it to the rocket and send it to Earth for analysis from the cargo terminal. They can examine it and tell me.",
    "Bilinmeyen taş → Analize gönder": "Unknown stone → Send for analysis",
    "ARES-1, numunen laboratuvara ulaştı. Ona bir ad verdik: ":
      "ARES-1, your sample reached the lab. We've given it a name: ",
    "Bileşimi, ne kadar tehlikeli olduğu ve ne işe yarayacağı raporda. Gelen kutuna yolladık.":
      "Its composition, how dangerous it is and what it's good for are in the report. It's in your inbox.",
    "… Demek adı buymuş. Artık bu taşı tanıyorum.": "… So that's its name. Now I know this stone.",
    "Haritada da adıyla görünüyor. Başka bilinmeyen taş bulursam onları da kırıp göndereceğim.":
      "It shows up by name on the map now too. If I find more unknown stones, I'll break them and send them as well.",
    "ARES-1, gönderdiğin parlayan taşın analizi bitti.":
      "ARES-1, the analysis of the glowing stone you sent is done.",
    "Ekip şaşkın — sonuçlar gelen kutunda. Okumadan o taşa dokunma!":
      "The team is stunned — the results are in your inbox. Don't touch that stone before reading!",
    "Gelen kutusu → Ares taşı analizini aç": "Inbox → open the Ares stone analysis",
    "ARES-1, görevlerin tamam. Dünya'ya dönüş penceresi açıldı.":
      "ARES-1, your missions are complete. The return window to Earth is open.",
    "Eve dönme zamanı… Komuta güvertesinde navigasyonu açıp EVE DÖN'e basacağım.":
      "Time to go home… I'll open navigation on the command deck and press GO HOME.",
    "Navigasyondan EVE DÖN": "Press GO HOME in navigation",
    Devam: "Continue",
    "GÖREV KONTROL · TELSİZ": "MISSION CONTROL · RADIO",
    "KOMUTAN · İÇ SES": "COMMANDER · INNER VOICE",
    "ACİL HEDEF": "URGENT GOAL",
    "ACİL HEDEF · ": "URGENT GOAL · ",
    "⏸ GÖREV BEKLEMEDE · ÖNCE ACİL HEDEF": "⏸ MISSION ON HOLD · URGENT GOAL FIRST",
    "Bayrak kaldırıldı. Ölçtüğün yerleri istediğin zaman temizleyebilirsin.":
      "Flag removed. You can clear measured spots whenever you like.",
    "🌅 Gün ": "🌅 Day ",
    " başladı": " has begun",
    "Bitkin düştün, revire taşındın.": "You collapsed from exhaustion and were carried to the sick bay.",
    "🌲 Mahsul hazır! (F ile hasat)": "🌲 Crop ready! (harvest with F)",
    "SİNYAL ZAYIF": "WEAK SIGNAL",
    "HARİTA · ": "MAP · ",
    "Ekim için uygun": "Suitable for planting",
    "Patates çürür": "Potatoes rot",
    YÜKSEK: "HIGH",
    "Patatesler çürümüş!": "The potatoes have rotted!",
    "Patatesler çürük çıktı, bir tanesi çantanda. Roketteki <b>kargo terminalinden</b> Dünya'ya gönder, incelesinler.":
      "The potatoes came out rotten; one is in your bag. Send it to Earth from the rocket's <b>cargo terminal</b> so they can examine it.",
    "Bu toprak radyasyonlu, patatesler yine çürüdü. Ekmeden önce radyasyon ölçerle ölç":
      "This soil is radioactive, the potatoes rotted again. Measure with the radiation meter before planting",
    "Patatesler yine çürüdü": "The potatoes rotted again",
    "Çok uzak — ölçmek istediğin yere biraz yaklaş":
      "Too far — move a little closer to where you want to measure",
    "İniş platformu metal — ölçümü toprak üzerinde yap": "The landing pad is metal — measure on the soil",
    "<b>Güvenli toprak</b> (": "<b>Safe soil</b> (",
    " µSv/h) — buraya kazıp patates ekebilirsin. Yeşil bayrak yeri işaretliyor.":
      " µSv/h) — you can dig here and plant potatoes. The green flag marks the spot.",
    "Bu toprakta patates çürür (": "Potatoes rot in this soil (",
    " µSv/h). <b>1,0 µSv/h altını</b> ara — biraz uzaklaşıp yeniden ölç.":
      " µSv/h). Look for <b>below 1.0 µSv/h</b> — move away a bit and measure again.",
    "Toprağı ölçmek için <b>radyasyon ölçeri</b> makine dairesindeki <b>alet sandığından</b> al.":
      "To measure the soil, take the <b>radiation meter</b> from the <b>tool chest</b> in the engine room.",
    "Prob toprağa hizalanıyor…": "Aligning probe with the soil…",
    "Ölçülüyor… <b>%{0}</b>": "Measuring… <b>{0}%</b>",
    '<span class="rd-vd"><b>RADYASYON {0}</b><small>{1} µSv/h · {2}</small></span>':
      '<span class="rd-vd"><b>RADIATION {0}</b><small>{1} µSv/h · {2}</small></span>',
    '<p>Komutan,</p>\n  <p>Gönderdiğin çürük patatesi inceledik. Mikrop ya da aşırı sulama izi yok. Neden <b>toprağın radyasyonu</b>: patatesin ekildiği yer yüksek radyasyonlu.</p>\n  <div class="ltr-dir"><b>NE YAPMALI?</b><ol>\n    <li>Roketteki alet sandığından <b>radyasyon ölçeri</b> al.</li>\n    <li>Ekmeden önce toprağı ölç: ölçeri eline al ve toprağa <b>sol tıkla</b>.</li>\n    <li>Ekranda <b>RADYASYON NORMAL</b> yazan yere ek. Yüksek çıkan yerde patates çürür.</li></ol></div>\n  <div class="ltr-scale"><span style="flex:1;background:#4ade80">0 – 1,0 NORMAL</span><span style="flex:1;background:#fbbf24">1,0 – 2,0 DİKKAT</span><span style="flex:1;background:#ff5d5d">2,0+ YÜKSEK</span></div>':
      '<p>Commander,</p>\n  <p>We examined the rotten potato you sent. There is no sign of microbes or overwatering. The cause is <b>soil radiation</b>: the spot where the potato was planted has high radiation.</p>\n  <div class="ltr-dir"><b>WHAT TO DO</b><ol>\n    <li>Take the <b>radiation meter</b> from the rocket\'s tool chest.</li>\n    <li>Measure the soil before planting: hold the meter and <b>left-click</b> the soil.</li>\n    <li>Plant where the screen shows <b>RADIATION NORMAL</b>. Potatoes rot where it reads high.</li></ol></div>\n  <div class="ltr-scale"><span style="flex:1;background:#4ade80">0 – 1.0 NORMAL</span><span style="flex:1;background:#fbbf24">1.0 – 2.0 CAUTION</span><span style="flex:1;background:#ff5d5d">2.0+ HIGH</span></div>',
    "Çürük patates analizi": "Rotten potato analysis",
    "Önceki kargo hâlâ inceleniyor — Dünya'nın cevabını bekle":
      "The previous cargo is still being examined — wait for Earth's reply",
    "Çantanda çürük patates yok": "No rotten potato in your bag",
    "Çürük patates kargoyla Dünya'ya gönderildi. Cevap birazdan gelen kutunda.":
      "Rotten potato sent to Earth by cargo. The reply will be in your inbox shortly.",
    "Mars yüzey görevi": "Mars surface mission",
    "Mars'ta hayatta kal · keşfet · Dünya'ya raporla": "Survive on Mars · explore · report to Earth",
    "Oyuna Başla": "Start Game",
    "Yeni görev · açılış hikâyesiyle": "New mission · with the opening story",
    "Devam Et": "Resume",
    Kaydedilenler: "Saved games",
    "Görev kayıtlarını yükle ya da sil": "Load or delete mission saves",
    Ayarlar: "Settings",
    "Ses, görüntü ve performans": "Audio, graphics and performance",
    "hareket ·": "move ·",
    koş: "run",
    "etkileşim / rokete gir": "interact / enter rocket",
    "topla · ek · sula · hasat": "collect · plant · water · harvest",
    medikit: "medkit",
    "çapayla kaz": "dig with the hoe",
    "eşyayı eline al": "hold item",
    "rehber kitap": "guide book",
    duraklat: "pause",
    "Görev Kontrol bağlantısı: AKTİF": "Mission Control link: ACTIVE",
    Geç: "Skip",
    "basılı tut ·": "(hold) ·",
    "ARES-1 · ARŞİV": "ARES-1 · ARCHIVE",
    "ARES-1 · SİSTEM": "ARES-1 · SYSTEM",
    "Varsayılana döndür": "Restore defaults",
    "ARES-1 · GÖREV DURAKLATILDI": "ARES-1 · MISSION PAUSED",
    Duraklatıldı: "Paused",
    "Göreve geri dön · Esc": "Return to the mission · Esc",
    Kaydet: "Save",
    "Görevin şu anki durumunu kaydet": "Save the current state of the mission",
    "Tehlikeler, sistemler ve ipuçları · R": "Hazards, systems and tips · R",
    "Dil, zorluk, ses, görüntü, arayüz": "Language, difficulty, audio, graphics, interface",
    "Ana menüye dön": "Return to main menu",
    "Kaydedilmemiş ilerleme kaybolur": "Unsaved progress will be lost",
    "ARES-1 · KAYIT": "ARES-1 · SAVE",
    "Kaydı adlandır": "Name your save",
    Vazgeç: "Cancel",
    "ARES-1 · DİL": "ARES-1 · LANGUAGE",
    "Dil değiştiriliyor": "Changing language",
    "Dil değişikliğinin uygulanması için oyun yeniden başlatılacak. Görevin otomatik olarak kaydedilecek.":
      "The game will restart to apply the language change. Your mission will be saved automatically.",
    "Uygula ve yeniden başlat": "Apply and restart",
    "Navigasyon Bilgisayarı": "Navigation Computer",
    Rota: "Route",
    kapat: "close",
    "Tedarik & Ticaret": "Supply & Trade",
    "Erzak deposu": "Supply store",
    "📦 Kargo bölmesi · Dünya'ya götürülecek numuneler": "📦 Cargo bay · samples to take to Earth",
    "Numuneleri yükle": "Load samples",
    "Uyku Kabini": "Sleeping Cabin",
    "Yataktan kalk": "Get out of bed",
    kalk: "get up",
    "UYKUDA ZAMAN 2×": "TIME 2× WHILE ASLEEP",
    "Kapat (R)": "Close (R)",
    Kapsül: "Capsule",
    İçerik: "Contents",
    "kapat · Al = çantaya · Koy =": "close · Take = to bag · Put = to",
    "Fabrikasyon Atölyesi": "Fabrication Workshop",
    "3B üretim ünitesi · EVA donanımı ve araç modifikasyonu":
      "3D fabrication unit · EVA equipment and vehicle modification",
    "🧑‍🚀 Kıyafet setleri": "🧑‍🚀 Suit sets",
    "🚀 Roket geliştirme": "🚀 Rocket upgrades",
    "kapat · kıyafet: metal + kristal + olivin · roket: altın + titanyum · en üst seviye: Ares taşı":
      "close · suit: metal + crystal + olivine · rocket: gold + titanium · top tier: Ares stone",
    "ARES-1 · MODİFİKASYON": "ARES-1 · MODIFICATION",
    "İletişim Terminali · Dünya": "Communications Terminal · Earth",
    "Komuta güvertesi · yüksek kazançlı anten · yer istasyonu ağı":
      "Command deck · high-gain antenna · ground station network",
    "🛰️ Yer Birimi": "🛰️ Ground Segment",
    "📐 Görev Mimarisi": "📐 Mission Architecture",
    "kapat · yanıtlar ~½ sol (ACİL ~¼ sol) sonra gelir":
      "close · replies arrive after ~½ sol (URGENT ~¼ sol)",
    "ARES-1 · GÖREV KONTROL HATTI": "ARES-1 · MISSION CONTROL LINE",
    "Ana Motor · Onarım": "Main Engine · Repair",
    "Makine dairesi · ARES-1 itki çekirdeği": "Engine room · ARES-1 propulsion core",
    "AŞAMA 1/4": "STAGE 1/4",
    "çık · tamamlanan aşamalar kaydedilir": "exit · completed stages are saved",
    "Yeni görev": "New mission",
    İptal: "Cancel",
    "Görevi başlat": "Start mission",
    "RADYASYON ÖLÇER": "RADIATION METER",
    "Dünyaya Hoş Geldin!": "Welcome to Earth!",
    "Oyuna Devam Et": "Continue Playing",
    "Ana Menüye Dön": "Return to Main Menu",
    "GÖREV 1/8": "MISSION 1/8",
    Görev: "Mission",
    VÜCUT: "BODY",
    NABIZ: "PULSE",
    YERÇEKİMİ: "GRAVITY",
    RADYASYON: "RADIATION",
    "MARS'A ULAŞILDI": "MARS REACHED",
    "MERIDIANI PLANUM · 1,95° G · 5,53° B": "MERIDIANI PLANUM · 1.95° S · 5.53° W",
    "ARES-1, iniş doğrulandı. Mars'a hoş geldin, Komutan.":
      "ARES-1, landing confirmed. Welcome to Mars, Commander.",
    "Kayıt adı": "Save name",
    "Kapat (E)": "Close (E)",
    "Kalk (E)": "Get up (E)",
    "Önceki (←)": "Previous (←)",
    "Sonraki (→)": "Next (→)",
    "Çık (E)": "Exit (E)",
    '<h2><small>Bölüm 5</small>Tarım {0}</h2>\n    <ol><li>Alet sandığından {1} <b>çapayı</b> al. Çapayı eline al ve yere <b>sol tıkla</b>.</li>\n    <li>{2} <b>Tohumu</b> eline al, çukurun yanında <kbd>F</kbd>.</li>\n    <li>{3} <b>Suyu</b> eline al, <kbd>F</kbd> ile sula. Islak toprak bitkiyi 2,4 kat hızlı büyütür.</li>\n    <li>Halka <b>sarı</b> olunca <kbd>F</kbd> ile hasat et: 1–2 patates + 1 tohumluk patates. Çürük hasattan tohum çıkmaz.</li></ol>\n    <p>Büyümesi sulamadan yaklaşık 75 saniye sürer. Bitki aşamaları: filiz → fide → çiçekli bitki → hasat.</p>\n    <div class="warn">Kum fırtınasında bitkiler sallanır ama zarar görmez. Parselleri roketin yakınına aç ki fırtınada kaybolmayasın.</div>':
      '<h2><small>Chapter 5</small>Farming {0}</h2>\n    <ol><li>Take the {1} <b>hoe</b> from the tool chest. Hold the hoe and <b>left-click</b> the ground.</li>\n    <li>Hold a {2} <b>seed</b> and press <kbd>F</kbd> next to the hole.</li>\n    <li>Hold {3} <b>water</b> and water it with <kbd>F</kbd>. Wet soil makes the plant grow 2.4 times faster.</li>\n    <li>When the ring turns <b>yellow</b>, harvest with <kbd>F</kbd>: 1–2 potatoes + 1 seed potato. A rotten harvest gives no seed.</li></ol>\n    <p>Without watering it takes about 75 seconds to grow. Plant stages: sprout → seedling → flowering plant → harvest.</p>\n    <div class="warn">During a sandstorm plants sway but are not damaged. Dig your plots close to the rocket so you don\'t get lost in a storm.</div>',
  },
  de: {
    Donanım: "Ausrüstung",
    "Roketteki alet sandığından <b>çapayı</b> al": "Nimm die <b>Hacke</b> aus der Werkzeugkiste der Rakete",
    "Roketin yanında <b>E</b> ile gir → makine dairesi → <b>ALET SANDIĞI</b> → <b>E</b> → Çapa: <b>Al</b>.":
      "Neben der Rakete mit <b>E</b> einsteigen → Maschinenraum → <b>WERKZEUGKISTE</b> → <b>E</b> → Hacke: <b>Nehmen</b>.",
    Toplayıcı: "Sammler",
    "Etrafa saçılmış <b>5 metal numune</b> topla": "Sammle <b>5 Metallproben</b> in der Umgebung",
    "Haritadaki ◆ işaretlerine yürü, numunenin yanında <b>F</b>'ye bas.":
      "Geh zu den ◆-Markierungen auf der Karte und drücke neben einer Probe <b>F</b>.",
    Çiftçi: "Bauer",
    "Toprağı kaz ve <b>tohum ek</b>": "Grabe den Boden um und <b>pflanze einen Samen</b>",
    "Dışarıda yere <b>sol tıkla</b> (kaz), çukurun yanında <b>F</b> ile ek. Tohum alet sandığında.":
      "Klicke draußen <b>links</b> auf den Boden (graben) und pflanze mit <b>F</b> neben dem Loch. Samen sind in der Werkzeugkiste.",
    Susuzluk: "Durst",
    "Bir şişe <b>su iç</b>": "<b>Trink</b> eine Flasche Wasser",
    "Su şişesini eline al (alttaki numara tuşu), sonra <b>F</b>'ye bas. Ya da roketteki <b>mutfakta</b> <b>İç</b>.":
      "Nimm die Wasserflasche in die Hand (Zahlentaste unten), dann drücke <b>F</b>. Oder <b>Trinken</b> in der <b>Küche</b> der Rakete.",
    "İlk Rapor": "Erster Bericht",
    "Dünya'ya <b>ilk raporunu gönder</b>": "<b>Sende deinen ersten Bericht</b> zur Erde",
    "Komuta güvertesi → solda <b>İLETİŞİM</b> masası → <b>E</b> → <b>Rapor hazırla</b> → gözlem seç, not yaz → <b>Dünya'ya gönder</b>.":
      "Kommandodeck → <b>KOMM</b>-Pult links → <b>E</b> → <b>Bericht erstellen</b> → Beobachtungen auswählen, Notiz schreiben → <b>Zur Erde senden</b>.",
    Sığınak: "Unterschlupf",
    "Kum fırtınasını <b>roketin içinde atlat</b>": "<b>Überstehe einen Sandsturm in der Rakete</b>",
    "İlk fırtına <b>2. gün</b> gelir. Turuncu uyarı kartı çıkınca 45 sn içinde rokete gir ve fırtına bitene kadar içeride kal.":
      "Der erste Sturm kommt an <b>Tag 2</b>. Wenn die orange Warnkarte erscheint, geh innerhalb von 45 s in die Rakete und bleib drinnen, bis der Sturm vorbei ist.",
    Mühendis: "Ingenieur",
    "Kum fırtınasından sonra <b>ana motoru onar</b>":
      "<b>Repariere das Haupttriebwerk</b> nach dem Sandsturm",
    "2. gün gelen fırtına motoru bozar. Makine dairesi → <b>ANA MOTOR</b> → <b>E</b> → 4 aşamayı tamamla.":
      "Der Sturm an Tag 2 beschädigt das Triebwerk. Maschinenraum → <b>HAUPTTRIEBWERK</b> → <b>E</b> → alle 4 Phasen abschließen.",
    Kalkan: "Schutzraum",
    "Radyasyon dalgasını <b>roketin içinde atlat</b>": "<b>Überstehe eine Strahlungswelle in der Rakete</b>",
    "İlk dalga <b>3. günün</b> başında gelir. Yeşil uyarı kartı çıkınca rokete gir; en kolayı uyku kabininde uyumak.":
      "Die erste Welle kommt zu Beginn von <b>Tag 3</b>. Wenn die grüne Warnkarte erscheint, geh in die Rakete; am einfachsten schläfst du in der Schlafkabine.",
    Hasatçı: "Ernter",
    "Patatesi büyüt ve <b>hasat et</b>": "Zieh eine Kartoffel groß und <b>ernte sie</b>",
    "Parseli <b>F</b> ile sula (hızlandırır). Halka sarı olunca <b>F</b> ile hasat et.":
      "Gieße das Beet mit <b>F</b> (beschleunigt das Wachstum). Wenn der Ring gelb wird, mit <b>F</b> ernten.",
    Haberleşme: "Funkverkehr",
    "Dünya'nın raporuna verdiği <b>resmî yanıtı oku</b>":
      "<b>Lies die offizielle Antwort der Erde</b> auf deinen Bericht",
    "Yanıt raporundan ~½ sol sonra gelir (ACİL: ~¼ sol). İletişim terminali → <b>Gelen kutusu</b> → YANIT etiketli mesajı aç.":
      "Die Antwort kommt ~½ Sol nach deinem Bericht (DRINGEND: ~¼ Sol). Kommunikationsterminal → <b>Posteingang</b> → öffne die Nachricht mit dem Etikett ANTWORT.",
    "Çürük Kargo": "Faule Fracht",
    "Çürük patatesi <b>kargoyla Dünya'ya gönder</b>":
      "Schicke die verfaulte Kartoffel <b>per Fracht zur Erde</b>",
    "Radyasyonu yüksek toprağa ekilen patates çürük çıkar. Çürük patatesi rokete götür → komuta güvertesi → <b>Kargo terminali</b> → <b>Dünya'ya gönder</b>.":
      "Kartoffeln aus stark strahlendem Boden verfaulen. Bring die verfaulte Kartoffel zur Rakete → Kommandodeck → <b>Frachtterminal</b> → <b>Zur Erde senden</b>.",
    "Dünya'nın Cevabı": "Antwort der Erde",
    "Dünya'dan gelen <b>analiz mesajını</b> oku": "Lies die <b>Analyse-Nachricht</b> von der Erde",
    "Kargo ulaşınca Dünya kısa süre içinde cevap yazar. İletişim terminali → <b>Gelen kutusu</b> → ANALİZ etiketli mesaj.":
      "Wenn die Fracht ankommt, antwortet die Erde bald. Kommunikationsterminal → <b>Posteingang</b> → Nachricht mit dem Etikett ANALYSE.",
    Ölçüm: "Messung",
    "Radyasyon ölçerle <b>3 farklı yerde</b> toprağı ölç":
      "Miss den Boden an <b>3 verschiedenen Stellen</b> mit dem Strahlungsmessgerät",
    "Roketteki <b>alet sandığından</b> radyasyon ölçeri al. Dışarıda eline al (numara tuşu) ve toprağa <b>sol tıkla</b>. Her ölçüm yere renkli bir bayrak diker.":
      "Nimm das Strahlungsmessgerät aus der <b>Werkzeugkiste</b> der Rakete. Halte es draußen in der Hand (Zifferntaste) und <b>klicke links</b> auf den Boden. Jede Messung setzt eine farbige Fahne.",
    "Temiz Toprak": "Sauberer Boden",
    "Güvenli toprağa ek ve <b>sağlıklı hasat</b> al":
      "Pflanze in sicheren Boden und erziele eine <b>gesunde Ernte</b>",
    "<b>1,0 µSv/h</b> altında ölçülen (yeşil bayraklı) yere kaz, tohum ek, sula ve hasat et.":
      "Grabe dort, wo du unter <b>1,0 µSv/h</b> gemessen hast (grüne Fahne), säe, gieße und ernte.",
    "Altın Avcısı": "Goldsucher",
    "Meteor kraterlerinden <b>3 altın parçası</b> topla":
      "Sammle <b>3 Goldfragmente</b> aus Meteoritenkratern",
    "Meteor düştükten sonra kraterin çevresinde parlayan sarı parçaları ara, yanında <b>F</b>'ye bas.":
      "Such nach einem Meteoriteneinschlag rund um den Krater nach glitzernden gelben Fragmenten und drücke daneben <b>F</b>.",
    Jeolog: "Geologe",
    "Uzak bölgelerde <b>bilinmeyen bir taş</b> çıkar":
      "Baue in abgelegenen Gebieten <b>ein unbekanntes Gestein</b> ab",
    "Alet sandığından <b>jeolog kazmasını</b> al. Tarayıcı bip sesi verince haritadaki <b>?</b> işaretine git ve taşı <b>F</b> ile kır.":
      "Nimm die <b>Geologenspitzhacke</b> aus der Werkzeugkiste. Wenn der Scanner piept, geh zur <b>?</b>-Markierung auf der Karte und zerschlage den Stein mit <b>F</b>.",
    "Numune Analizi": "Probenanalyse",
    "Bilinmeyen taşı <b>analiz için Dünya'ya gönder</b>":
      "Schicke den unbekannten Stein <b>zur Analyse zur Erde</b>",
    "Komuta güvertesi → <b>Kargo terminali</b> → ANALİZ İÇİN satırında <b>Analize gönder</b>.":
      "Kommandodeck → <b>Frachtterminal</b> → in der Zeile ZUR ANALYSE <b>Zur Analyse senden</b>.",
    Terzi: "Schneider",
    "Fabrikasyon atölyesinde <b>yeni bir kıyafet</b> üret":
      "Fertige in der Fertigungswerkstatt <b>einen neuen Anzug</b>",
    "Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b> → Kıyafet setleri → <b>Kaşif Mk-I</b> → Üret ve giy (4 metal).":
      "Wohndeck → <b>FERTIGUNGSWERKSTATT</b> → <b>E</b> → Anzugsets → <b>Entdecker Mk-I</b> → Fertigen und anziehen (4 Metall).",
    "Radyasyon Zırhı": "Strahlenschutz",
    "Radyasyona dayanıklı <b>Öncü Mk-II</b> kıyafetini üret":
      "Stelle den strahlungsfesten Anzug <b>Pionier Mk-II</b> her",
    "Fabrikasyon atölyesi → Kıyafet setleri → <b>Öncü Mk-II</b> (radyasyon hasarı %40 azalır).":
      "Fertigungswerkstatt → Anzugsets → <b>Pionier Mk-II</b> (Strahlenschaden −40 %).",
    "Zırh Ustası": "Panzerschmied",
    "Rokete <b>Titanyum Plakalar</b> zırhını tak":
      "Bringe die Panzerung <b>Titanplatten</b> an der Rakete an",
    "Fabrikasyon atölyesi → <b>Roket geliştirme</b> → Titanyum Plakalar (fırtınada arıza olasılığı %60 → %35).":
      "Fertigungswerkstatt → <b>Raketen-Upgrades</b> → Titanplatten (Ausfallrisiko im Sturm 60 % → 35 %).",
    Kargo: "Fracht",
    "Roketin kargosuna <b>10 numune</b> yükle": "Lade <b>10 Proben</b> in den Frachtraum der Rakete",
    "Metal = 1, ⭐ yıldız = 2 numune. Roketin yanında <b>F</b>'ye bas.":
      "Metall = 1, ⭐ Stern = 2 Proben. Drücke neben der Rakete <b>F</b>.",
    "Eve Dönüş": "Heimkehr",
    "Roketle <b>Dünya'ya dön</b>": "<b>Kehre mit der Rakete zur Erde zurück</b>",
    "Komuta güvertesi (en üst kat) → <b>NAVİGASYON</b> → <b>E</b> → <b>EVE DÖN</b>.":
      "Kommandodeck (oberste Ebene) → <b>NAVIGATION</b> → <b>E</b> → <b>HEIMKEHR</b>.",
    Dünya: "Erde",
    Mars: "Mars",
    "Son kayıt: ": "Letzter Spielstand: ",
    görev: "Mission",
    " · Gün ": " · Tag ",
    "Kayıtlı görev yok": "Keine gespeicherten Missionen",
    '<div class="empty-note">Henüz kayıt yok.</div>': '<div class="empty-note">Noch keine Spielstände.</div>',
    Yükle: "Laden",
    Sil: "Löschen",
    "Kayıt yüklendi": "Spielstand geladen",
    "Kayıt ": "Spielstand ",
    "💾 Otomatik kaydedildi": "💾 Automatisch gespeichert",
    "💾 Kaydedildi": "💾 Gespeichert",
    "MAKİNE DAİRESİ": "MASCHINENRAUM",
    "YAŞAM GÜVERTESİ": "WOHNDECK",
    "KOMUTA GÜVERTESİ": "KOMMANDODECK",
    "Hava kilidi": "Luftschleuse",
    "<b>E</b>: Dışarı çık": "<b>E</b>: Nach draußen",
    "Alet sandığı": "Werkzeugkiste",
    "<b>E</b>: Alet sandığını aç": "<b>E</b>: Werkzeugkiste öffnen",
    "O₂ tüpü": "O₂-Tank",
    "<b>E</b>: Oksijen doldur": "<b>E</b>: Sauerstoff auffüllen",
    "Ana motor": "Haupttriebwerk",
    "<b>E</b>: Ana motoru onar": "<b>E</b>: Haupttriebwerk reparieren",
    "Tamir tezgâhı": "Werkbank",
    "<b>E</b>: Motor onarımı": "<b>E</b>: Triebwerksreparatur",
    "Uyku kapsülü": "Schlafkapsel",
    "<b>E</b>: Yat / uyu (zaman 2×)": "<b>E</b>: Hinlegen / schlafen (Zeit 2×)",
    "Fabrikasyon atölyesi": "Fertigungswerkstatt",
    "<b>E</b>: Atölye · kıyafet & roket geliştirme": "<b>E</b>: Werkstatt · Anzug- & Raketen-Upgrades",
    Mutfak: "Küche",
    "<b>E</b>: Mutfağı aç · <b>F</b>: hızlı ye/iç":
      "<b>E</b>: Küche öffnen · <b>F</b>: schnell essen/trinken",
    Revir: "Krankenstation",
    "<b>E</b>: Revir dolabını aç": "<b>E</b>: Medizinschrank öffnen",
    "Yemek kapsülü": "Nahrungskapsel",
    "<b>E</b>: Yemek kapsülünü aç": "<b>E</b>: Nahrungskapsel öffnen",
    "İletişim terminali": "Kommunikationsterminal",
    "<b>E</b>: Dünya iletişim terminali": "<b>E</b>: Kommunikationsterminal zur Erde",
    Navigasyon: "Navigation",
    "<b>E</b>: Navigasyon bilgisayarı": "<b>E</b>: Navigationscomputer",
    "Kargo terminali": "Frachtterminal",
    "<b>E</b>: Kargo terminali": "<b>E</b>: Frachtterminal",
    "🚀 Roketin içindesin — <b>A/D</b> yürü · merdivende <b>W/S</b> · <b>E</b> kullan":
      "🚀 Du bist in der Rakete — <b>A/D</b> gehen · auf Leitern <b>W/S</b> · <b>E</b> benutzen",
    "Hava kilidinden çıktın": "Du bist durch die Luftschleuse hinausgegangen",
    "Yakında kullanılacak bir istasyon yok": "Keine Station in der Nähe",
    "Numuneleri komuta güvertesindeki <b>stok terminalinden</b> kargoya yükle":
      "Lade die Proben am <b>Lagerterminal</b> auf dem Kommandodeck in den Frachtraum",
    "Çantanda numune yok — dışarıda metal ve ⭐ topla":
      "Keine Proben in deiner Tasche — sammle draußen Metall und ⭐",
    " numune kargoya yüklendi · kargo ": " Proben in den Frachtraum geladen · Fracht ",
    "🍽️ Yemek kapsülü stoku: 💧": "🍽️ Vorrat der Nahrungskapsel: 💧",
    "Şu an aç ya da susuz değilsin": "Du bist gerade weder hungrig noch durstig",
    "Yemek kapsülü boş — patates yetiştir, su geri dönüştürücüyü bekle":
      "Die Nahrungskapsel ist leer — bau Kartoffeln an und warte auf den Wasserrecycler",
    "Çapa sırtında — dışarıda yere <b>sol tıkla</b>, toprağı kaz":
      "Hacke auf dem Rücken — klicke draußen <b>links</b> auf den Boden, um zu graben",
    "Çapa alet sandığına bırakıldı": "Hacke in die Werkzeugkiste gelegt",
    "Açlık/susuzluktan uyandın — mutfağa git": "Du bist vor Hunger/Durst aufgewacht — geh in die Küche",
    "🌅 Yeni güne uyandın": "🌅 Du bist in einen neuen Tag aufgewacht",
    "😴 Uyuyorsun…": "😴 Du schläfst…",
    "Gün ": "Tag ",
    " · sabaha ": " · bis zum Morgen ",
    " · zaman 2× hızlı": " · Zeit 2× schneller",
    "E: uyan": "E: aufwachen",
    CAN: "GESUNDHEIT",
    TOKLUK: "SÄTTIGUNG",
    SU: "WASSER",
    "Uyuyorsun; oyun zamanı 2× hızlanıyor. Roket gövdesi radyasyonu keser.":
      "Du schläfst; die Spielzeit läuft 2× schneller. Die Raketenhülle schirmt Strahlung ab.",
    "☢️ Dışarıda radyasyon var. Roket içindeyken güvendesin.":
      "☢️ Draußen herrscht Strahlung. In der Rakete bist du sicher.",
    "Uyumak zamanı 2× hızlandırır: mahsul daha çabuk büyür, can hızla yenilenir. Sabah olunca kendiliğinden uyanırsın.":
      "Schlafen lässt die Zeit 2× schneller vergehen: Pflanzen wachsen schneller und die Gesundheit regeneriert sich rasch. Am Morgen wachst du automatisch auf.",
    "☀️ Uyan": "☀️ Aufwachen",
    "🛌 Uyu": "🛌 Schlafen",
    Uyandın: "Du bist aufgewacht",
    "Uyku başladı — zaman 2× hızlanıyor": "Schlaf begonnen — die Zeit läuft 2× schneller",
    "<b>E</b>: Oksijen doldur · giysi %": "<b>E</b>: Sauerstoff auffüllen · Anzug %",
    " · tüp %": " · Tank %",
    " öğe": " Gegenstände",
    "<b>E</b>: İletişim terminali": "<b>E</b>: Kommunikationsterminal",
    " yeni mesaj": " neue Nachrichten",
    " gözlem": " Beobachtungen",
    " · <b>F</b>: numuneleri yükle": " · <b>F</b>: Proben laden",
    " — motor çalışıyor ✔": " — Triebwerk läuft ✔",
    "<b>E</b>: Ana motoru onar · aşama ": "<b>E</b>: Haupttriebwerk reparieren · Phase ",
    " · medikit ": " · Medikits ",
    " · çanta ": " · Tasche ",
    " · <b>G</b>: hızlı kullan": " · <b>G</b>: schnell benutzen",
    " · metal ": " · Metall ",
    " · altın ": " · Gold ",
    "<b>W</b>/<b>S</b>: Merdivenle ": "<b>W</b>/<b>S</b>: Leiter ",
    "yukarı çık": "hinauf",
    "aşağı in": "hinunter",
    "PARAŞÜT / YÜK BÖLMESİ": "FALLSCHIRM- / NUTZLASTBUCHT",
    "HAVA KİLİDİ": "LUFTSCHLEUSE",
    "ANA MOTOR": "HAUPTTRIEBWERK",
    "MOTOR: ÇALIŞIYOR": "TRIEBWERK: LÄUFT",
    "ONARIM ": "REPARATUR ",
    "MOTOR: ONARIM": "TRIEBWERK: REPARATUR",
    MUTFAK: "KÜCHE",
    "MEDİKİT ×": "MEDIKIT ×",
    REVİR: "KRANKENSTATION",
    "UPLINK ": "UPLINK ",
    " YENİ MESAJ": " NEUE NACHRICHTEN",
    "AĞ · AKTİF": "NETZ · AKTIV",
    İLETİŞİM: "KOMMUNIKATION",
    MARS: "MARS",
    DÜNYA: "ERDE",
    "NAV v2.1 · SOL ": "NAV v2.1 · SOL ",
    " · KARGO ": " · FRACHT ",
    "SİSTEM: HAZIR": "SYSTEM: BEREIT",
    "KALKIŞ KİLİTLİ": "START GESPERRT",
    NAVİGASYON: "NAVIGATION",
    "KARGO ": "FRACHT ",
    STOK: "LAGER",
    Kablolar: "Kabel",
    Sigortalar: "Sicherungen",
    Basınç: "Druck",
    Ateşleme: "Zündung",
    "✅ Ana motor çalışıyor — onarım gerekmiyor": "✅ Das Haupttriebwerk läuft — keine Reparatur nötig",
    "AŞAMA ": "PHASE ",
    "İLERLEME ": "FORTSCHRITT ",
    TAMAMLANDI: "ABGESCHLOSSEN",
    "İLERLEME 100%": "FORTSCHRITT 100%",
    "Tüm sistemler <b>çevrimiçi</b>. Roket kalkışa hazır.":
      "Alle Systeme <b>online</b>. Die Rakete ist startbereit.",
    "MOTOR ÇEVRİMİÇİ": "TRIEBWERK ONLINE",
    "İTKİ ÇEKİRDEĞİ STABİL · KALKIŞ KİLİDİ AÇIK": "SCHUBKERN STABIL · STARTSPERRE AUFGEHOBEN",
    "Harika — kapat": "Super — schließen",
    "🔧 Ana motor onarıldı — roket kalkışa hazır!":
      "🔧 Haupttriebwerk repariert — die Rakete ist startbereit!",
    "Kopan <b>güç kablolarını</b> aynı renkteki motor soketlerine sürükle (ya da önce kabloya, sonra sokete tıkla).":
      "Ziehe die gerissenen <b>Stromkabel</b> zu den Triebwerksbuchsen in derselben Farbe (oder klicke erst auf ein Kabel, dann auf eine Buchse).",
    "GÜÇ ÜNİTESİ": "STROMEINHEIT",
    "⚠ DEVRE AÇIK": "⚠ STROMKREIS OFFEN",
    "✔ DEVRE KAPALI": "✔ STROMKREIS GESCHLOSSEN",
    "Kablolar bağlandı": "Kabel verbunden",
    "Kısa devre <b>sigortaları yaktı</b>. Kararmış olanlara tıklayıp değiştir, sonra <b>ana şalteri</b> kaldır. Sağlamlara dokunma!":
      "Der Kurzschluss hat <b>die Sicherungen durchbrennen lassen</b>. Klicke die geschwärzten an, um sie zu ersetzen, und lege dann den <b>Hauptschalter</b> um. Die intakten nicht anfassen!",
    "SİGORTA PANOSU · 40A": "SICHERUNGSKASTEN · 40A",
    "YANIK: ": "DURCHGEBRANNT: ",
    "ŞALTERİ KALDIR": "SCHALTER UMLEGEN",
    "ANA ŞALTER": "HAUPTSCHALTER",
    "YANIK: 4": "DURCHGEBRANNT: 4",
    "GÜÇ VAR": "STROM AN",
    "Sigortalar değiştirildi": "Sicherungen ersetzt",
    "İbre <b>yeşil bölgedeyken</b> KİLİTLE'ye bas (ya da <b>Space</b>). 3 başarılı kilit gerekli; her kilitte bölge daralır.":
      "Drücke SPERREN, solange die Nadel <b>im grünen Bereich</b> ist (oder <b>Leertaste</b>). 3 erfolgreiche Sperren nötig; der Bereich wird jedes Mal schmaler.",
    "YAKIT HATTI BASINCI · kPa": "DRUCK DER TREIBSTOFFLEITUNG · kPa",
    "KİLİT 0/3": "SPERRE 0/3",
    KİLİTLE: "SPERREN",
    "KİLİT ": "SPERRE ",
    "Basınç kalibre edildi": "Druck kalibriert",
    "Ateşleme dizisini <b>izle</b>, sonra düğmelere <b>aynı sırayla</b> bas.":
      "<b>Beobachte</b> die Zündsequenz und drücke die Tasten dann <b>in derselben Reihenfolge</b>.",
    "↻ TEKRAR İZLE": "↻ NOCHMAL ANSEHEN",
    İZLE: "ANSEHEN",
    "Dizi oynatılıyor…": "Sequenz wird abgespielt…",
    "SIRA SENDE": "DU BIST DRAN",
    HATA: "FEHLER",
    "Dizi yeniden oynatılıyor": "Sequenz wird erneut abgespielt",
    ATEŞLEME: "ZÜNDUNG",
    "İtki çekirdeği aktif": "Schubkern aktiv",
    "Ateşleme dizisi doğru": "Zündsequenz korrekt",
    "🛡️ Fırtına kalkanı roketi korudu — motor sağlam":
      "🛡️ Der Sturmschild hat die Rakete geschützt — Triebwerk intakt",
    "💥 Şiddetli bir esinti roketi savurdu — motordan duman yükseliyor!":
      "💥 Eine heftige Böe hat die Rakete erschüttert — aus dem Triebwerk steigt Rauch auf!",
    "Kum fırtınası yaklaşıyor": "Sandsturm im Anmarsch",
    "Roketin içindesin — güvendesin": "Du bist in der Rakete — du bist sicher",
    "Rüzgâr hızlanıyor · görüş azalacak": "Der Wind frischt auf · die Sicht wird schlechter",
    "Roket içi güvenli": "In der Rakete sicher",
    "Dışarıda kum fırtınası · rüzgâr ": "Draußen tobt ein Sandsturm · Wind ",
    "Kum fırtınası": "Sandsturm",
    "Rüzgâr ": "Wind ",
    " km/s · görüş çok düşük": " km/h · Sicht sehr schlecht",
    "Jeolog kazması": "Geologenspitzhacke",
    "Çürük patates": "Verfaulte Kartoffel",
    "DZ-7 radyasyon ölçer": "DZ-7-Strahlungsmessgerät",
    "Su şişesi": "Wasserflasche",
    Patates: "Kartoffel",
    "Patates tohumu": "Kartoffelsamen",
    Medikit: "Medikit",
    Çapa: "Hacke",
    "Metal numune": "Metallprobe",
    "Yıldız kristali": "Sternkristall",
    "🫁 Oksijen %30 — rokete dönüp tüpten doldur":
      "🫁 Sauerstoff bei 30 % — kehr zur Rakete zurück und füll am Tank auf",
    "⚠️ Oksijen kritik! Hemen rokete dön": "⚠️ Sauerstoff kritisch! Sofort zurück zur Rakete",
    "🫁 Giysi oksijeni zaten dolu": "🫁 Der Anzugsauerstoff ist bereits voll",
    "O₂ tüpü boş — jeneratör dolduruyor, biraz bekle":
      "O₂-Tank leer — der Generator füllt ihn auf, warte kurz",
    "🫁 Oksijen dolu · tüp %": "🫁 Sauerstoff voll · Tank %",
    "O₂ tüpü boşaldı — jeneratör dolduruyor": "O₂-Tank leer — der Generator füllt ihn auf",
    OKSİJEN: "SAUERSTOFF",
    "Alet Sandığı": "Werkzeugkiste",
    "Toprağı kazar ve parsel açar": "Gräbt den Boden um und legt Beete an",
    "Yalnızca bilinmeyen (?) taşları kırar": "Zerschlägt nur unbekannte (?) Steine",
    "Toprağın radyasyonunu ölçer · ekimden önce kullan":
      "Misst die Bodenstrahlung · vor dem Pflanzen benutzen",
    "Dışarıdaki parsele ekilir": "Wird draußen ins Beet gepflanzt",
    "Yaşam güvertesi · tıbbi dolap ve sedye": "Wohndeck · Medizinschrank und Trage",
    "Canı +": "Stellt Gesundheit wieder her +",
    " yeniler · yanında taşıyıp G ile kullan": " · mitnehmen und mit G benutzen",
    "Yaşam güvertesi · dolaplar, su sebili ve buzdolabı":
      "Wohndeck · Schränke, Wasserspender und Kühlschrank",
    "Şişe su · su sebilinden geri dönüştürülür": "Wasser in Flaschen · vom Wasserspender recycelt",
    "Haşlanmış patates · açlığı giderir": "Gekochte Kartoffel · stillt den Hunger",
    "Yemek Kapsülü": "Nahrungskapsel",
    "Yaşam güvertesi · soğuk saklama + su geri dönüştürücü": "Wohndeck · Kühllager + Wasserrecycler",
    "Susuzluğu giderir · geri dönüştürülür": "Stillt den Durst · wird recycelt",
    "Açlığı giderir · tarladan yetişir": "Stillt den Hunger · wächst auf dem Feld",
    sandığa: "Kiste",
    kapsüle: "Kapsel",
    SANDIK: "KISTE",
    KAPSÜL: "KAPSEL",
    '<div class="cap-art"><img src="{0}" alt=""><span class="cap-n">×{1}</span></div>\n      <div class="cap-nm">{2}</div><div class="cap-ds">{3}</div>\n      <div class="cap-bar"><i style="width:{4}%"></i></div>\n      <div class="cap-meta"><span>{5} {6}/{7}</span><span>ÇANTA {8}</span></div>':
      '<div class="cap-art"><img src="{0}" alt=""><span class="cap-n">×{1}</span></div>\n      <div class="cap-nm">{2}</div><div class="cap-ds">{3}</div>\n      <div class="cap-bar"><i style="width:{4}%"></i></div>\n      <div class="cap-meta"><span>{5} {6}/{7}</span><span>TASCHE {8}</span></div>',
    Al: "Nehmen",
    Koy: "Ablegen",
    Kullan: "Benutzen",
    "❤️ Revirde tedavi oldun · +": "❤️ Du wurdest auf der Krankenstation behandelt · +",
    " can": " Gesundheit",
    İç: "Trinken",
    Ye: "Essen",
    "CAN %": "GESUNDHEIT %",
    "💧 +1 su / ": "💧 +1 Wasser / ",
    " dk": " Min.",
    "KİLİT: AÇIK": "VERRIEGELUNG: OFFEN",
    " ÖĞE": " GEGENSTÄNDE",
    "YEMEK KAPSÜLÜ": "NAHRUNGSKAPSEL",
    "KİT KAPSÜLÜ": "KITKAPSEL",
    "ALET SANDIĞI": "WERKZEUGKISTE",
    '<span class="ev rd">☢ Radyasyon · 00:00–01:30</span>':
      '<span class="ev rd">☢ Strahlung · 00:00–01:30</span>',
    '<span class="ev st">🌪 Kum fırtınası · 01:30–04:00</span>':
      '<span class="ev st">🌪 Sandsturm · 01:30–04:00</span>',
    "<span class='ev ok'>Sakin</span>": "<span class='ev ok'>Ruhig</span>",
    '<tr class="{0}"><td>Gün {1}{2}</td><td>{3}</td></tr>':
      '<tr class="{0}"><td>Tag {1}{2}</td><td>{3}</td></tr>',
    '<div class="pg-cover"><div class="emb"><span>ARES-1</span><i></i></div>\n    <h1>SAHA REHBERİ</h1><div class="sub">Mars Yüzey Operasyonları El Kitabı</div>\n    <p class="c">Bu kitap çantanda hep durur. <kbd>R</kbd> ile aç / kapat.</p>\n    <p class="c sm">Sayfa çevirmek için ◀ ▶ düğmeleri ya da klavyede <kbd>←</kbd> <kbd>→</kbd>.</p>\n    <p class="c sm">Kitap açıkken oyun zamanı durur.</p>\n    <div class="sig">— ARES-1 Görev Kontrol</div></div>':
      '<div class="pg-cover"><div class="emb"><span>ARES-1</span><i></i></div>\n    <h1>FELDHANDBUCH</h1><div class="sub">Handbuch für Einsätze auf der Marsoberfläche</div>\n    <p class="c">Dieses Buch bleibt immer in deiner Tasche. Öffnen / schließen mit <kbd>R</kbd>.</p>\n    <p class="c sm">Blättere mit den Tasten ◀ ▶ oder <kbd>←</kbd> <kbd>→</kbd>.</p>\n    <p class="c sm">Solange das Buch offen ist, steht die Spielzeit still.</p>\n    <div class="sig">— ARES-1-Missionskontrolle</div></div>',
    "İlk adımlar ve kontroller": "Erste Schritte und Steuerung",
    Oksijen: "Sauerstoff",
    "Yemek ve su": "Nahrung und Wasser",
    "Roketin içi": "In der Rakete",
    Tarım: "Landwirtschaft",
    "Numuneler ve kargo": "Proben und Fracht",
    "⚠ Kum fırtınası": "⚠ Sandsturm",
    "⚠ Radyasyon dalgası": "⚠ Strahlungswelle",
    "⚠ Meteor yağmuru": "⚠ Meteoritenschauer",
    "Motor onarımı": "Triebwerksreparatur",
    "Uyku ve zaman": "Schlaf und Zeit",
    "Felaket takvimi": "Katastrophenkalender",
    "Dünya ile iletişim": "Kommunikation mit der Erde",
    "Kıyafet & roket geliştirme": "Anzug- & Raketen-Upgrades",
    "Acil durum listesi": "Notfall-Checkliste",
    "Görev mimarisi": "Missionsarchitektur",
    '<h2>İçindekiler</h2><ol class="toc">{0}</ol>\n    <div class="note">İpucu: bir başlığa tıklarsan o sayfaya gidersin.</div>':
      '<h2>Inhalt</h2><ol class="toc">{0}</ol>\n    <div class="note">Tipp: Klicke auf eine Überschrift, um zu dieser Seite zu springen.</div>',
    '<h2><small>Bölüm 1</small>İlk adımlar</h2>\n    <table class="keys"><tr><td><kbd>W A S D</kbd></td><td>Yürü · <kbd>Shift</kbd> koş</td></tr>\n    <tr><td><kbd>1</kbd>…<kbd>7</kbd></td><td>Eşyayı eline al · aynı tuşa tekrar bas = kullan</td></tr>\n    <tr><td><kbd>F</kbd></td><td>Topla · elindekiyle ek, sula, iç, ye</td></tr>\n    <tr><td><kbd>E</kbd></td><td>Rokete gir · istasyonu kullan</td></tr>\n    <tr><td><kbd>G</kbd></td><td>Medikit kullan</td></tr>\n    <tr><td>Sol tık</td><td>Çapa elindeyken yeri kaz</td></tr>\n    <tr><td><kbd>R</kbd></td><td>Bu rehberi aç</td></tr></table>\n    <div class="tip"><b>Altın kural:</b> sadece <u>elindeki</u> eşyayı kullanırsın. Çapa elindeyken su içemezsin; önce suyu eline al.</div>\n    <p>Sol üstte <b>gün ve saat</b>, altında <b>görev kartı</b> var. Görev kartındaki 💡 satırı ne yapacağını adım adım söyler.</p>':
      '<h2><small>Kapitel 1</small>Erste Schritte</h2>\n    <table class="keys"><tr><td><kbd>W A S D</kbd></td><td>Gehen · <kbd>Shift</kbd> rennen</td></tr>\n    <tr><td><kbd>1</kbd>…<kbd>7</kbd></td><td>Gegenstand in die Hand nehmen · dieselbe Taste erneut = benutzen</td></tr>\n    <tr><td><kbd>F</kbd></td><td>Aufheben · mit dem Gegenstand in der Hand pflanzen, gießen, trinken, essen</td></tr>\n    <tr><td><kbd>E</kbd></td><td>Rakete betreten · Station benutzen</td></tr>\n    <tr><td><kbd>G</kbd></td><td>Medkit benutzen</td></tr>\n    <tr><td>Linksklick</td><td>Mit der Hacke in der Hand den Boden umgraben</td></tr>\n    <tr><td><kbd>R</kbd></td><td>Dieses Handbuch öffnen</td></tr></table>\n    <div class="tip"><b>Goldene Regel:</b> Du kannst nur den Gegenstand <u>in deiner Hand</u> benutzen. Mit der Hacke in der Hand kannst du kein Wasser trinken; nimm zuerst das Wasser.</div>\n    <p>Oben links siehst du <b>Tag und Uhrzeit</b>, darunter die <b>Missionskarte</b>. Die 💡-Zeile auf der Missionskarte sagt dir Schritt für Schritt, was zu tun ist.</p>',
    "<h2><small>Bölüm 2</small>Oksijen {0}</h2>\n    <p>Mars'ın havası solunamaz. Giysindeki oksijen dışarıda yaklaşık <b>3,5 dakikada</b> biter. Koşarken %35, fırtınada %25 daha hızlı azalır.</p>\n    <ul><li><b>%30</b>'da uyarı alırsın, <b>%10</b>'da alarm çalar.</li>\n    <li><b>%0</b>'da her saniye ~5 can kaybedersin, ekran kararır.</li>\n    <li>Roketin içinde oksijen azalmaz.</li></ul>\n    <div class=\"tip\"><b>Doldurma:</b> rokete gir → makine dairesi → <b>O₂ tüpleri</b> → <kbd>E</kbd>. Hortum sırt çantana bağlanır ve giysi dolar.</div>\n    <p>Tüplerin de bir kapasitesi var. Boşalırsa oksijen jeneratörü onları yavaşça yeniden doldurur; tüp göstergesini takip et.</p>":
      '<h2><small>Kapitel 2</small>Sauerstoff {0}</h2>\n    <p>Die Marsluft ist nicht atembar. Der Sauerstoff deines Anzugs reicht draußen etwa <b>3,5 Minuten</b>. Beim Rennen sinkt er 35 % schneller, im Sturm 25 % schneller.</p>\n    <ul><li>Bei <b>30 %</b> bekommst du eine Warnung, bei <b>10 %</b> einen Alarm.</li>\n    <li>Bei <b>0 %</b> verlierst du ~5 Gesundheit pro Sekunde und der Bildschirm wird dunkel.</li>\n    <li>In der Rakete wird kein Sauerstoff verbraucht.</li></ul>\n    <div class="tip"><b>Auffüllen:</b> Rakete betreten → Maschinenraum → <b>O₂-Tanks</b> → <kbd>E</kbd>. Der Schlauch wird an deinen Rucksack angeschlossen und füllt deinen Anzug.</div>\n    <p>Auch die Tanks haben eine begrenzte Kapazität. Wenn sie leer sind, füllt der Sauerstoffgenerator sie langsam wieder auf; behalte die Tankanzeige im Blick.</p>',
    "<h2><small>Bölüm 3</small>Yemek ve su {0}</h2>\n    <p><b>Su</b> yaklaşık 4, <b>tokluk</b> yaklaşık 5,5 dakikada biter. Biri sıfırlanırsa saniyede 4 can gider.</p>\n    <ul><li>{1} <b>Su şişesi:</b> +35 su. Eline al ve <kbd>F</kbd>'ye bas.</li>\n    <li>{2} <b>Patates:</b> +35 tokluk. Eline al ve <kbd>F</kbd>'ye bas.</li></ul>\n    <div class=\"tip\"><b>Mutfak:</b> yaşam güvertesindeki mutfakta <kbd>E</kbd> → envanteri açılır. Oradan çantana alabilir ya da hemen içip yiyebilirsin.</div>\n    <p>Su stoku sınırlıdır ama <b>su geri dönüştürücü</b> her 2,5 dakikada 1 şişe üretir. Patatesi ise tarlada sen yetiştirirsin.</p>":
      '<h2><small>Kapitel 3</small>Nahrung und Wasser {0}</h2>\n    <p><b>Wasser</b> reicht etwa 4 Minuten, <b>Nahrung</b> etwa 5,5 Minuten. Fällt einer der Werte auf null, verlierst du 4 Gesundheit pro Sekunde.</p>\n    <ul><li>{1} <b>Wasserflasche:</b> +35 Wasser. In die Hand nehmen und <kbd>F</kbd> drücken.</li>\n    <li>{2} <b>Kartoffel:</b> +35 Nahrung. In die Hand nehmen und <kbd>F</kbd> drücken.</li></ul>\n    <div class="tip"><b>Küche:</b> Drücke an der Küche auf dem Wohndeck <kbd>E</kbd> → ihr Inventar öffnet sich. Du kannst Gegenstände in deine Tasche nehmen oder sofort essen und trinken.</div>\n    <p>Der Wasservorrat ist begrenzt, aber der <b>Wasser-Recycler</b> erzeugt alle 2,5 Minuten 1 Flasche. Kartoffeln baust du selbst auf dem Feld an.</p>',
    '<h2><small>Bölüm 4</small>Roketin içi</h2>\n    <p>Roket 3 katlıdır. Merdivenin yanında <kbd>W</kbd>/<kbd>S</kbd> ile kat değiştirirsin.</p>\n    <div class="deck"><b>3 · Komuta güvertesi</b><span>Navigasyon (kalkış) · Kargo terminali</span></div>\n    <div class="deck"><b>2 · Yaşam güvertesi</b><span>Uyku kabini · Mutfak · Revir · Yemek kapsülü</span></div>\n    <div class="deck"><b>1 · Makine dairesi</b><span>Hava kilidi (çıkış) · Alet sandığı · O₂ tüpleri · Ana motor · Tamir tezgâhı</span></div>\n    <div class="tip">Roketin gövdesi seni <b>radyasyondan, fırtınadan ve meteorlardan</b> korur. Bir felaket yaklaşırken en güvenli yer burasıdır.</div>':
      '<h2><small>Kapitel 4</small>In der Rakete</h2>\n    <p>Die Rakete hat 3 Decks. Wechsle neben einer Leiter mit <kbd>W</kbd>/<kbd>S</kbd> das Deck.</p>\n    <div class="deck"><b>3 · Kommandodeck</b><span>Navigation (Start) · Frachtterminal</span></div>\n    <div class="deck"><b>2 · Wohndeck</b><span>Schlafkabine · Küche · Krankenstation · Nahrungskapsel</span></div>\n    <div class="deck"><b>1 · Maschinenraum</b><span>Luftschleuse (Ausgang) · Werkzeugkiste · O₂-Tanks · Haupttriebwerk · Werkbank</span></div>\n    <div class="tip">Die Hülle der Rakete schützt dich vor <b>Strahlung, Stürmen und Meteoriten</b>. Wenn eine Katastrophe naht, ist dies der sicherste Ort.</div>',
    '<h2><small>Bölüm 5</small>Tarım {0}</h2>\n    <ol><li>Alet sandığından {1} <b>çapayı</b> al. Çapayı eline al ve yere <b>sol tıkla</b>.</li>\n    <li>{2} <b>Tohumu</b> eline al, çukurun yanında <kbd>F</kbd>.</li>\n    <li>{3} <b>Suyu</b> eline al, <kbd>F</kbd> ile sula. Islak toprak bitkiyi 2,4 kat hızlı büyütür.</li>\n    <li>Halka <b>sarı</b> olunca <kbd>F</kbd> ile hasat et: 1–2 patates + 1 tohum.</li></ol>\n    <p>Büyümesi sulamadan yaklaşık 75 saniye sürer. Bitki aşamaları: filiz → fide → çiçekli bitki → hasat.</p>\n    <div class="warn">Kum fırtınasında bitkiler sallanır ama zarar görmez. Parselleri roketin yakınına aç ki fırtınada kaybolmayasın.</div>':
      '<h2><small>Kapitel 5</small>Landwirtschaft {0}</h2>\n    <ol><li>Nimm die {1} <b>Hacke</b> aus der Werkzeugkiste. Nimm die Hacke in die Hand und <b>klicke links</b> auf den Boden.</li>\n    <li>Nimm einen {2} <b>Samen</b> in die Hand und drücke neben dem Loch <kbd>F</kbd>.</li>\n    <li>Nimm {3} <b>Wasser</b> in die Hand und gieße mit <kbd>F</kbd>. Auf feuchtem Boden wächst die Pflanze 2,4-mal schneller.</li>\n    <li>Wenn der Ring <b>gelb</b> wird, ernte mit <kbd>F</kbd>: 1–2 Kartoffeln + 1 Samen.</li></ol>\n    <p>Ohne Gießen dauert das Wachstum etwa 75 Sekunden. Pflanzenstadien: Keim → Setzling → blühende Pflanze → Ernte.</p>\n    <div class="warn">Bei einem Sandsturm schwanken die Pflanzen, nehmen aber keinen Schaden. Lege deine Beete nahe der Rakete an, damit du dich im Sturm nicht verirrst.</div>',
    '<h2><small>Bölüm 6</small>Numuneler ve kargo {0}</h2>\n    <p>Görevin bilimsel amacı Mars numunelerini Dünya\'ya götürmek.</p>\n    <ul><li>{1} <b>Metal numune</b> = 1 puan. Haritada ◆ olarak görünür.</li>\n    <li>{2} <b>Yıldız kristali</b> = 2 puan. Meteor çarpınca kraterde kalabilir.</li></ul>\n    <div class="tip">Roketin yanında <kbd>F</kbd> ya da komuta güvertesindeki <b>kargo terminali</b> ile kargoya yükle. Hedef: <b>10 numune</b>.</div>\n    <p>Çantana en fazla {3} metal numune sığar. Dolunca rokete dönüp boşalt.</p>':
      '<h2><small>Kapitel 6</small>Proben und Fracht {0}</h2>\n    <p>Das wissenschaftliche Ziel der Mission ist es, Marsproben zur Erde zu bringen.</p>\n    <ul><li>{1} <b>Metallprobe</b> = 1 Punkt. Auf der Karte als ◆ dargestellt.</li>\n    <li>{2} <b>Sternkristall</b> = 2 Punkte. Kann nach einem Meteoriteneinschlag im Krater zurückbleiben.</li></ul>\n    <div class="tip">Lade sie mit <kbd>F</kbd> neben der Rakete oder am <b>Frachtterminal</b> auf dem Kommandodeck in den Frachtraum. Ziel: <b>10 Proben</b>.</div>\n    <p>Deine Tasche fasst höchstens {3} Metallproben. Wenn sie voll ist, kehre zur Rakete zurück und lade aus.</p>',
    '<h2 class="danger"><small>Bölüm 7 · Felaket</small>🌪 Kum fırtınası (1/2)</h2>\n    <p><b>Ne zaman?</b> İlki <b>2. gün</b> gelir, sonra <b>her 5 günde bir</b> tekrarlar (7, 12, 17…). Günün 01:30\'unda başlar, <b>2,5 dakika</b> sürer.</p>\n    <p><b>Uyarı:</b> başlamadan <b>45 saniye</b> önce turuncu bir kart çıkar ve geri sayar.</p>\n    <p><b>Neler olur?</b></p>\n    <ul><li>Görüş birkaç metreye düşer, gökyüzü kararır.</li>\n    <li>Rüzgâr (130 km/s\'ye kadar) seni savurur, rüzgâra karşı yürümek zorlaşır.</li>\n    <li>Harita sinyali kaybolur: "SİNYAL ZAYIF".</li>\n    <li>Oksijen %25 daha hızlı tükenir.</li>\n    <li>Ani esintiler ekranı sarsar.</li></ul>':
      '<h2 class="danger"><small>Kapitel 7 · Katastrophe</small>🌪 Sandsturm (1/2)</h2>\n    <p><b>Wann?</b> Der erste kommt an <b>Tag 2</b>, danach <b>alle 5 Tage</b> (7, 12, 17 …). Er beginnt um 01:30 und dauert <b>2,5 Minuten</b>.</p>\n    <p><b>Warnung:</b> <b>45 Sekunden</b> vor Beginn erscheint eine orange Karte mit Countdown.</p>\n    <p><b>Was passiert?</b></p>\n    <ul><li>Die Sicht sinkt auf wenige Meter, der Himmel verdunkelt sich.</li>\n    <li>Der Wind (bis zu 130 km/h) schiebt dich herum; gegen ihn zu gehen ist schwer.</li>\n    <li>Das Kartensignal fällt aus: „SCHWACHES SIGNAL“.</li>\n    <li>Der Sauerstoff sinkt 25 % schneller.</li>\n    <li>Plötzliche Böen erschüttern den Bildschirm.</li></ul>',
    '<h2 class="danger"><small>Bölüm 7 · Felaket</small>🌪 Kum fırtınası (2/2)</h2>\n    <div class="warn"><b>İLK FIRTINA ROKETİ VURUR!</b> 2. gündeki fırtına zirvedeyken sert bir esinti roketi savurur ve <b>ana motor bozulur</b>. Motordan duman yükselir, kalkış kilitlenir.</div>\n    <p><b>Ne yapmalı?</b></p>\n    <ol><li>Uyarı kartını görünce işini bırak, <b>rokete dön</b>.</li>\n    <li>Fırtına bitene kadar içeride kal. Bu arada ye, iç, oksijen doldur.</li>\n    <li>Dışarıda yakalanırsan haritadaki roket okunu takip et.</li>\n    <li>Fırtına bitince motoru onar (Bölüm 10).</li></ol>\n    <p class="sm">Sonraki fırtınalarda motor <b>%60</b> olasılıkla yeniden bozulabilir; fırtına kalkanı bu riski azaltır (Bölüm 14).</p>':
      '<h2 class="danger"><small>Kapitel 7 · Katastrophe</small>🌪 Sandsturm (2/2)</h2>\n    <div class="warn"><b>DER ERSTE STURM TRIFFT DIE RAKETE!</b> Auf dem Höhepunkt des Sturms an Tag 2 erschüttert eine heftige Böe die Rakete und <b>das Haupttriebwerk fällt aus</b>. Aus dem Triebwerk steigt Rauch auf, der Start ist gesperrt.</div>\n    <p><b>Was tun?</b></p>\n    <ol><li>Sobald du die Warnkarte siehst, lass alles liegen und <b>kehre zur Rakete zurück</b>.</li>\n    <li>Bleib drinnen, bis der Sturm vorbei ist. Iss, trink und fülle in der Zwischenzeit Sauerstoff auf.</li>\n    <li>Wenn du draußen überrascht wirst, folge dem Raketenpfeil auf der Karte.</li>\n    <li>Wenn der Sturm vorbei ist, repariere das Triebwerk (Kapitel 10).</li></ol>\n    <p class="sm">Bei späteren Stürmen kann das Triebwerk mit <b>60 %</b> Wahrscheinlichkeit erneut ausfallen; der Sturmschild senkt dieses Risiko (Kapitel 14).</p>',
    '<h2 class="danger"><small>Bölüm 8 · Felaket</small>☢ Radyasyon dalgası</h2>\n    <p><b>Ne zaman?</b> Güneş patlaması <b>3. günden itibaren her 3 günde bir</b> (3, 6, 9…), günün en başında (00:00) gelir ve <b>1,5 dakika</b> sürer.</p>\n    <p><b>Uyarı:</b> önceki günün bitmesine <b>40 saniye</b> kala yeşil kart çıkar.</p>\n    <ul><li>Dışarıdaysan ekran <b>yeşile</b> döner ve saniyede ~3 can kaybedersin — standart giysiyle 30 saniyede ölürsün! Kalkan Mk-III ve ARES Elite setleri hasarı büyük ölçüde azaltır.</li>\n    <li>Başının üstünde "☢" hasar yazıları belirir.</li>\n    <li>Dalganın tamamını dışarıda geçirmek kesin ölümdür!</li></ul>\n    <div class="tip"><b>Korunma:</b> rokete gir. Gövde zırhı radyasyonu tamamen keser, içeride can kaybetmezsin. En iyi taktik: dalga gecesinde roketin <b>uyku kabininde</b> uyumak.</div>':
      '<h2 class="danger"><small>Kapitel 8 · Katastrophe</small>☢ Strahlungswelle</h2>\n    <p><b>Wann?</b> Ab <b>Tag 3 alle 3 Tage</b> (3, 6, 9 …) trifft ganz zu Tagesbeginn (00:00) eine Sonneneruption ein und dauert <b>1,5 Minuten</b>.</p>\n    <p><b>Warnung:</b> <b>40 Sekunden</b> vor Ende des vorherigen Tages erscheint eine grüne Karte.</p>\n    <ul><li>Bist du draußen, wird der Bildschirm <b>grün</b> und du verlierst ~3 Gesundheit pro Sekunde — im Standardanzug stirbst du innerhalb von 30 Sekunden! Die Sets Schild Mk-III und ARES Elite verringern den Schaden stark.</li>\n    <li>Über deinem Kopf erscheinen „☢“-Schadenszahlen.</li>\n    <li>Die ganze Welle draußen zu verbringen bedeutet den sicheren Tod!</li></ul>\n    <div class="tip"><b>Schutz:</b> Betritt die Rakete. Die Hüllenpanzerung blockiert die Strahlung vollständig; drinnen verlierst du keine Gesundheit. Beste Taktik: In der Nacht der Welle in der <b>Schlafkabine</b> der Rakete schlafen.</div>',
    '<h2 class="danger"><small>Bölüm 9 · Felaket</small>☄ Meteor yağmuru</h2>\n    <p>Meteorlar <b>uyarı vermeden</b>, rastgele zamanlarda 1–3 tane düşer. Kum fırtınası sırasında düşmez.</p>\n    <p><b>Belirtiler:</b> önce yükselen bir uğultu duyulur. Gökyüzünde iz bırakan bir ateş topu belirir ve yerde <b>büyüyen bir gölge</b> oluşur. Gölge çarpma noktasıdır!</p>\n    <ul><li>Çarpma yarıçapı ~9 m, hasar <b>26 can</b>.</li>\n    <li>Çarpma kalıcı bir krater bırakır. Krater bir süre sıcak kalır ve tüter.</li></ul>\n    <div class="tip"><b>Fırsat:</b> kraterlerde sık sık {0} <b>yıldız kristali</b> ya da metal numune kalır. Gölgeden uzaklaş, çarpmadan sonra topla.</div>':
      '<h2 class="danger"><small>Kapitel 9 · Katastrophe</small>☄ Meteoritenschauer</h2>\n    <p>Meteoriten fallen <b>ohne Vorwarnung</b>, 1–3 auf einmal, zu zufälligen Zeitpunkten. Während eines Sandsturms fallen keine.</p>\n    <p><b>Anzeichen:</b> Zuerst hörst du ein anschwellendes Grollen. Am Himmel erscheint ein Feuerball mit Schweif, und auf dem Boden bildet sich ein <b>wachsender Schatten</b>. Der Schatten ist der Einschlagspunkt!</p>\n    <ul><li>Einschlagradius ~9 m, Schaden <b>26 Gesundheit</b>.</li>\n    <li>Der Einschlag hinterlässt einen bleibenden Krater. Der Krater bleibt eine Weile heiß und raucht.</li></ul>\n    <div class="tip"><b>Chance:</b> In Kratern findet sich oft ein {0} <b>Sternkristall</b> oder eine Metallprobe. Entferne dich vom Schatten und sammle nach dem Einschlag.</div>',
    '<h2><small>Bölüm 10</small>Motor onarımı 🔧</h2>\n    <p>Makine dairesinde <b>ANA MOTOR</b> → <kbd>E</kbd>. Onarım 4 aşamadır; tamamladığın aşamalar kaydedilir.</p>\n    <ol><li><b>Kablolar:</b> renkli kabloları aynı renkteki sokete sürükle.</li>\n    <li><b>Sigortalar:</b> kararmış sigortalara tıkla, sonra ana şalteri kaldır. Sağlamlara dokunma!</li>\n    <li><b>Basınç:</b> ibre yeşil bölgedeyken KİLİTLE ya da <kbd>Space</kbd>. 3 kez başarman gerekir.</li>\n    <li><b>Ateşleme:</b> ışık dizisini izle, aynı sırayla bas.</li></ol>\n    <div class="tip">Onarım bitince kalkış kilidi açılır ve görevler seni Dünya\'ya yönlendirir.</div>':
      '<h2><small>Kapitel 10</small>Triebwerksreparatur 🔧</h2>\n    <p>Im Maschinenraum: <b>HAUPTTRIEBWERK</b> → <kbd>E</kbd>. Die Reparatur hat 4 Stufen; abgeschlossene Stufen werden gespeichert.</p>\n    <ol><li><b>Kabel:</b> Ziehe die farbigen Kabel zur Buchse derselben Farbe.</li>\n    <li><b>Sicherungen:</b> Klicke die geschwärzten Sicherungen an und lege dann den Hauptschalter um. Fass die intakten nicht an!</li>\n    <li><b>Druck:</b> Drücke SPERREN oder <kbd>Leertaste</kbd>, während der Zeiger im grünen Bereich ist. Du musst es 3-mal schaffen.</li>\n    <li><b>Zündung:</b> Beobachte die Lichtfolge und drücke in derselben Reihenfolge.</li></ol>\n    <div class="tip">Nach der Reparatur wird die Startsperre aufgehoben, und die Missionen führen dich zurück zur Erde.</div>',
    '<h2><small>Bölüm 11</small>Uyku ve zaman</h2>\n    <p>Mars\'ta <b>1 gün = 6 dakika</b>. Sol üstteki çubuk günün ilerleyişini, turuncu çizgiler olayları gösterir.</p>\n    <ul><li>Uyku kabininde uyursan <b>zaman 2 kat hızlanır</b>, can hızla yenilenir.</li>\n    <li>Sabah olunca kendiliğinden uyanırsın. Aç ya da susuz kalırsan erken uyanırsın.</li>\n    <li>Uyurken mahsul de 2 kat hızlı büyür.</li></ul>\n    <div class="tip">Radyasyon gecesinde ya da uzun bir fırtınada uyumak, tehlikeyi güvenle atlatmanın en kolay yolu.</div>':
      '<h2><small>Kapitel 11</small>Schlaf und Zeit</h2>\n    <p>Auf dem Mars gilt <b>1 Tag = 6 Minuten</b>. Der Balken oben links zeigt den Tagesfortschritt; orange Markierungen zeigen Ereignisse.</p>\n    <ul><li>Wenn du in der Schlafkabine schläfst, <b>vergeht die Zeit 2× schneller</b> und die Gesundheit regeneriert sich rasch.</li>\n    <li>Morgens wachst du automatisch auf. Wenn du Hunger oder Durst bekommst, wachst du früher auf.</li>\n    <li>Auch die Pflanzen wachsen im Schlaf 2× schneller.</li></ul>\n    <div class="tip">Eine Strahlungsnacht oder einen langen Sturm zu verschlafen ist der einfachste Weg, die Gefahr sicher zu überstehen.</div>',
    '<h2><small>Bölüm 12</small>Felaket takvimi</h2>\n    <p class="sm">Bugün: <b>Gün {0}</b> · gün bitimine <b>{1}</b> · sonraki fırtına <b>Gün {2}</b></p>\n    <table class="cal">{3}</table>\n    <p class="sm">Meteorlar takvime girmez: her an düşebilir.</p>':
      '<h2><small>Kapitel 12</small>Katastrophenkalender</h2>\n    <p class="sm">Heute: <b>Tag {0}</b> · bis Tagesende <b>{1}</b> · nächster Sturm <b>Tag {2}</b></p>\n    <table class="cal">{3}</table>\n    <p class="sm">Meteoriten stehen nicht im Kalender: Sie können jederzeit fallen.</p>',
    "<h2><small>Bölüm 13</small>Dünya ile iletişim 📡</h2>\n    <p>Görevin asıl amacı: Mars'ta yaşadıklarını ve topladığın bilgileri <b>Dünya'ya aktarmak</b>. Komuta güvertesinin solundaki <b>İLETİŞİM</b> masasına <kbd>E</kbd>.</p>\n    <ul><li><b>Saha günlüğü</b> fırtına, radyasyon, meteor, arıza, numune, tarım ve kritik değerleri <b>otomatik</b> kaydeder.</li>\n    <li>Kayıtları seç, kendi notunu yaz (sorunlarını, sorularını), öncelik belirle ve gönder.</li>\n    <li>Görev Kontrol <b>~½ sol</b> sonra (ACİL: ~¼ sol) resmî bir yanıt yollar: analiz, talimatlar ve 5 sollük tahmin.</li>\n    <li>Kum fırtınası sırasında anten tozla kapanır, <b>gönderim yapılamaz</b>.</li>\n    <li><b>🛰️ Yer Birimi</b> sekmesi, raporlarını alan yer istasyonlarını ve görev kontrol merkezlerini gösterir.</li></ul>\n    <div class=\"tip\">Görev Kontrol bazen kendiliğinden yazar: hava bültenleri, telemetri uyarıları, rapor talepleri. Sağ üstteki rozet yeni mesajı gösterir.</div>":
      '<h2><small>Kapitel 13</small>Kommunikation mit der Erde 📡</h2>\n    <p>Das eigentliche Ziel der Mission: das, was du auf dem Mars erlebst, und die gesammelten Daten <b>zur Erde zu übertragen</b>. Drücke am <b>KOMM</b>-Pult links auf dem Kommandodeck <kbd>E</kbd>.</p>\n    <ul><li>Das <b>Feldprotokoll</b> zeichnet Stürme, Strahlung, Meteoriten, Ausfälle, Proben, Landwirtschaft und kritische Werte <b>automatisch</b> auf.</li>\n    <li>Wähle Einträge aus, schreib deine eigene Notiz (deine Probleme, deine Fragen), lege eine Priorität fest und sende.</li>\n    <li>Die Missionskontrolle schickt nach <b>~½ Sol</b> eine offizielle Antwort (DRINGEND: ~¼ Sol): Analyse, Anweisungen und eine 5-Sol-Vorhersage.</li>\n    <li>Während eines Sandsturms ist die Antenne mit Staub zugesetzt und es kann <b>nichts gesendet werden</b>.</li>\n    <li>Der Reiter <b>🛰️ Bodensegment</b> zeigt die Bodenstationen und Missionskontrollzentren, die deine Berichte empfangen.</li></ul>\n    <div class="tip">Die Missionskontrolle schreibt manchmal von sich aus: Wetterbulletins, Telemetriewarnungen, Berichtsanfragen. Das Abzeichen oben rechts zeigt neue Nachrichten an.</div>',
    '<h2><small>Bölüm 14</small>Kıyafet & roket geliştirme 🧬</h2>\n    <p>Yaşam güvertesindeki <b>Fabrikasyon Atölyesi</b> <kbd>E</kbd> ile açılır.</p>\n    <ul><li><b>Kıyafet setleri</b> (Kaşif → Öncü → Kalkan → ARES Elite) metal numune, yıldız kristali ve nadir taşlarla sırayla üretilir. Her set oksijen tüketimini, yürüme hızını, radyasyon ve fırtına korumasını artırır.</li>\n    <li><b>Roket geliştirme</b> meteor kraterlerinin çevresine saçılan <b>altın parçaları</b> ve titanyum cevheriyle yapılır. Fırtına kalkanı 3 seviyedir; son seviyede fırtına motoru bozamaz.</li>\n    <li>İlk fırtınadan sonraki her fırtınada motor <b>%60</b> olasılıkla bozulur — kalkan bunu azaltır.</li>\n    <li>Altınla rokete yeni boyalar da alabilirsin.</li></ul>\n    <div class="tip">Meteor düştükten sonra krater çevresini tara: parıldayan sarı parçalar altındır. Uzak bölgelerde tarayıcının bip sesini takip et: <b>bilinmeyen taşlar</b> (titanyum, olivin, Ares taşı) üst seviye geliştirmeler için şart — çıkarmak için saha kiti gerekir.</div>':
      '<h2><small>Kapitel 14</small>Anzug- & Raketen-Upgrades 🧬</h2>\n    <p>Die <b>Fertigungswerkstatt</b> auf dem Wohndeck öffnest du mit <kbd>E</kbd>.</p>\n    <ul><li><b>Anzugsets</b> (Entdecker → Pionier → Schild → ARES Elite) werden der Reihe nach aus Metallproben, Sternkristallen und seltenen Gesteinen gefertigt. Jedes Set verbessert Sauerstoffverbrauch, Gehgeschwindigkeit sowie Strahlungs- und Sturmschutz.</li>\n    <li><b>Raketen-Upgrades</b> werden mit den <b>Goldfragmenten</b> rund um Meteoritenkrater und mit Titanerz hergestellt. Der Sturmschild hat 3 Stufen; auf der letzten Stufe können Stürme das Triebwerk nicht mehr beschädigen.</li>\n    <li>Bei jedem Sturm nach dem ersten fällt das Triebwerk mit <b>60 %</b> Wahrscheinlichkeit aus — der Schild senkt dies.</li>\n    <li>Mit Gold kannst du auch neue Lackierungen für die Rakete kaufen.</li></ul>\n    <div class="tip">Nach einem Meteoriteneinschlag such rund um den Krater: Die glitzernden gelben Fragmente sind Gold. In abgelegenen Gebieten folge dem Piepen des Scanners: <b>unbekannte Gesteine</b> (Titan, Olivin, Aresstein) werden für die höchsten Upgrades benötigt — zum Abbauen brauchst du das Feldkit.</div>',
    '<h2><small>Bölüm 15</small>Acil durum listesi</h2>\n    <table class="emg"><tr><td>🫁 Oksijen &lt; %30</td><td>Rokete dön → O₂ tüpleri</td></tr>\n    <tr><td>❤ Can düşük</td><td>Medikit (<kbd>G</kbd>), revir ya da uyku</td></tr>\n    <tr><td>💧 / 🍽 bitti</td><td>Mutfak ya da yemek kapsülü</td></tr>\n    <tr><td>🌪 Turuncu kart</td><td>45 sn içinde rokete gir</td></tr>\n    <tr><td>☢ Yeşil kart</td><td>Rokete gir, mümkünse uyu</td></tr>\n    <tr><td>☄ Uğultu + gölge</td><td>Gölgeden uzaklaş</td></tr>\n    <tr><td>💨 Motordan duman</td><td>Ana motoru onar</td></tr></table>\n    <h3>Eve dönüş</h3><p>Sol üstteki görev kartını takip et: numune → kit → tarım → ilk rapor → fırtına → motor onarımı → radyasyon → hasat → Dünya\'nın yanıtı → altın → nadir taş → yeni kıyafet → kargo (10). Sonra komuta güvertesinde <b>NAVİGASYON</b> → <b>EVE DÖN</b>.</p>':
      '<h2><small>Kapitel 15</small>Notfall-Checkliste</h2>\n    <table class="emg"><tr><td>🫁 Sauerstoff &lt; 30 %</td><td>Zurück zur Rakete → O₂-Tanks</td></tr>\n    <tr><td>❤ Wenig Gesundheit</td><td>Medkit (<kbd>G</kbd>), Krankenstation oder Schlaf</td></tr>\n    <tr><td>💧 / 🍽 leer</td><td>Küche oder Nahrungskapsel</td></tr>\n    <tr><td>🌪 Orange Karte</td><td>Innerhalb von 45 s in die Rakete</td></tr>\n    <tr><td>☢ Grüne Karte</td><td>In die Rakete, wenn möglich schlafen</td></tr>\n    <tr><td>☄ Grollen + Schatten</td><td>Vom Schatten entfernen</td></tr>\n    <tr><td>💨 Rauch aus dem Triebwerk</td><td>Haupttriebwerk reparieren</td></tr></table>\n    <h3>Heimkehr</h3><p>Folge der Missionskarte oben links: Proben → Kit → Anbau → erster Bericht → Sturm → Triebwerksreparatur → Strahlung → Ernte → Antwort der Erde → Gold → seltenes Gestein → neuer Anzug → Fracht (10). Dann auf dem Kommandodeck: <b>NAVIGATION</b> → <b>HEIMKEHR</b>.</p>',
    '<h2><small>Bölüm 16</small>Görev mimarisi 📐</h2>\n    <p>ARES-1 bir uzay görevinin tüm parçalarıyla tasarlandı. İletişim terminalindeki <b>📐 Görev Mimarisi</b> sekmesi bunları canlı gösterir.</p>\n    <ul><li><b>Görev segmentleri:</b> fırlatma, uzay, yer ve kullanıcı segmentleri birlikte çalışır.</li>\n    <li><b>Kavram olgunluğu:</b> görev bir fikirle başlar; fizibilite analizi ve ödünleşim çalışmalarından geçerek nokta tasarıma ulaşır.</li>\n    <li><b>Alt sistemler:</b> itki, yaşam desteği, ısıl koruma, yapı ve iletişim ayrı ayrı izlenir.</li></ul>\n    <div class="tip">ARES-1 kurgusal bir görevdir; oyundaki sayılar oyun için basitleştirilmiştir.</div>':
      '<h2><small>Kapitel 16</small>Missionsarchitektur 📐</h2>\n    <p>ARES-1 wurde mit allen Teilen einer Weltraummission entworfen. Der Reiter <b>📐 Missionsarchitektur</b> im Kommunikationsterminal zeigt sie live.</p>\n    <ul><li><b>Missionssegmente:</b> Start-, Raum-, Boden- und Nutzersegment arbeiten zusammen.</li>\n    <li><b>Konzeptreife:</b> Eine Mission beginnt als Idee und erreicht über Machbarkeitsanalyse und Trade-Studien einen Punktentwurf.</li>\n    <li><b>Teilsysteme:</b> Antrieb, Lebenserhaltung, Thermalschutz, Struktur und Kommunikation werden einzeln überwacht.</li></ul>\n    <div class="tip">ARES-1 ist eine erfundene Mission; die Zahlen im Spiel sind vereinfacht.</div>',
    "Uçuş Direktörü": "Flugdirektor",
    "Mürettebat İletişim Sorumlusu": "Verantwortlicher für Crew-Kommunikation",
    "İtki Sistemleri Şefi": "Leiter Antriebssysteme",
    "Uzay Hava Durumu Birimi": "Abteilung Weltraumwetter",
    "Gezegen Bilimi Ekibi Lideri": "Leiter Planetenwissenschaft",
    "Biyorejeneratif Yaşam Destek": "Bioregenerative Lebenserhaltung",
    "Uçuş Cerrahı": "Flugarzt",
    "Davranış Sağlığı Uzmanı": "Fachkraft für Verhaltensgesundheit",
    "Lojistik ve Kargo Planlama": "Logistik und Frachtplanung",
    "Görev Destek Yapay Zekâsı": "Missionsunterstützungs-KI",
    "Uzay hava durumu": "Weltraumwetter",
    "Ana motor arızası": "Ausfall des Haupttriebwerks",
    "Araç sistemleri": "Fahrzeugsysteme",
    "Radyasyon dalgası": "Strahlungswelle",
    "Meteor düşüşü": "Meteoriteneinschlag",
    "Gezegen bilimi": "Planetenwissenschaft",
    "Jeolojik numune": "Geologische Probe",
    "Tarım deneyi": "Anbauexperiment",
    "Yaşam bilimi": "Lebenswissenschaften",
    "Kargo yüklemesi": "Frachtverladung",
    Lojistik: "Logistik",
    "Yaşam destek uyarısı": "Lebenserhaltungswarnung",
    "Mürettebat sağlığı": "Crew-Gesundheit",
    "Nadir mineral": "Seltenes Mineral",
    "Çürüyen hasat": "Verfaulte Ernte",
    KRİTİK: "KRITISCH",
    ÖNEMLİ: "WICHTIG",
    OLUMLU: "POSITIV",
    RUTİN: "ROUTINE",
    Su: "Wasser",
    Tokluk: "Nahrung",
    Can: "Gesundheit",
    Erzak: "Vorräte",
    " sa ": " Std. ",
    "{0}. solda ~{1} süren yerel toz fırtınası. Görüş sıfıra yakın, gövde sarsıntısı yüksek. ":
      "Lokaler Staubsturm an Sol {0}, Dauer ~{1}. Sicht nahe null, starke Erschütterungen am Rumpf. ",
    "Fırtına sırasında araç dışında {0} geçirildi. ":
      "{0} während des Sturms außerhalb des Fahrzeugs verbracht. ",
    "Mürettebat fırtına boyunca araç içinde kaldı. ":
      "Die Crew blieb während des gesamten Sturms im Fahrzeug. ",
    "Fırtına ana motoru devre dışı bıraktı.": "Der Sturm hat das Haupttriebwerk außer Betrieb gesetzt.",
    "Araçta yeni hasar gözlenmedi.": "Keine neuen Schäden am Fahrzeug festgestellt.",
    "{0}. solda fırtına esnasında itki çekirdeğinde arıza. Makine dairesinde yoğun duman, kalkış kilitli.":
      "Ausfall im Schubkern während des Sturms an Sol {0}. Starker Rauch im Maschinenraum, Start gesperrt.",
    "Ana motor 4 aşamalı prosedürle onarıldı (kablolar, sigortalar, basınç, ateşleme). Sistem çevrimiçi.":
      "Haupttriebwerk mit dem 4-stufigen Verfahren (Kabel, Sicherungen, Druck, Zündung) repariert. System online.",
    "Güneş kaynaklı parçacık dalgası (~{0}). ": "Solare Teilchenwelle (~{0}). ",
    "Dışarıda {0} maruz kalındı, ~{1} can kaybı.": "{0} Exposition im Freien, ~{1} Gesundheit verloren.",
    "Mürettebat zırhlı gövdede korundu, doz alınmadı.":
      "Die Crew war durch den gepanzerten Rumpf geschützt; keine Dosis erhalten.",
    "{0} meteor çarpması gözlendi": "{0} Meteoriteneinschläge beobachtet",
    ", en yakını ~{0} m mesafede.": ", der nächste ~{0} m entfernt.",
    " Taze kraterler oluştu.": " Frische Krater sind entstanden.",
    " ve {0} yıldız kristali": " und {0} Sternkristall(e)",
    "{0} metal{1} numunesi toplandı.": "{0} Metallproben{1} gesammelt.",
    " parsele tohum ekildi": " Beete eingesät",
    " hasat alındı": " Ernten eingebracht",
    "Kargo bölmesine {0} birim numune yüklendi (toplam {1}/{2}).":
      "{0} Probeneinheiten in den Frachtraum geladen (gesamt {1}/{2}).",
    " çıkarıldı ve analiz edildi.": " abgebaut und analysiert.",
    "{0} parselden alınan patates yumruları kararmış ve yumuşamış halde çıktı. Yapraklar hasattan önce solmuştu. Nedeni bilinmiyor.":
      "Die Kartoffelknollen aus {0} Parzelle(n) waren geschwärzt und weich. Die Blätter waren vor der Ernte verwelkt. Die Ursache ist unbekannt.",
    "Kritik değerler: ": "Kritische Werte: ",
    "erzak tükendi": "Vorräte erschöpft",
    "📝 Saha günlüğüne eklendi: <b>": "📝 Zum Feldprotokoll hinzugefügt: <b>",
    "</b> — komuta güvertesindeki <b>iletişim terminalinden</b> Dünya'ya raporla":
      "</b> — melde es über das <b>Kommunikationsterminal</b> auf dem Kommandodeck an die Erde",
    "📨 <b>Dünya'dan resmî mesaj:</b> ": "📨 <b>Offizielle Nachricht von der Erde:</b> ",
    " — iletişim terminalinden oku": " — lies sie am Kommunikationsterminal",
    "ACİL · ": "DRINGEND · ",
    '<div class="ltr-cc"><b>Bilgi:</b> {0}</div>': '<div class="ltr-cc"><b>Kopie an:</b> {0}</div>',
    '<div class="ltr">\n  <div class="ltr-hd"><div class="ltr-seal"><b>ARES</b><span>GK</span></div>\n    <div class="ltr-org"><b>ARES-1 GÖREV KONTROL MERKEZİ</b><span>Yer istasyonu ağı üzerinden</span></div>\n    <div class="ltr-cls {0}">{1}RESMİ<br><small>MÜRETTEBATA ÖZEL</small></div></div>\n  <table class="ltr-meta">\n    <tr><td>Belge No</td><td>{2}</td><td>Tarih</td><td>{3} (Mars yerel)</td></tr>\n    <tr><td>Kime</td><td>ARES-1 Komutanı</td><td>İlgi</td><td>{4}</td></tr>\n    <tr><td>Konu</td><td colspan="3"><b>{5}</b></td></tr></table>\n  <div class="ltr-body">{6}</div>\n  {7}\n  <div class="ltr-sign">{8}</div>\n  {9}\n  <div class="ltr-ft">Bu ileti {10} dk ışık gecikmesiyle iletilmiştir · Şifreli kanal AES-256 · {11}</div>\n</div>':
      '<div class="ltr">\n  <div class="ltr-hd"><div class="ltr-seal"><b>ARES</b><span>MC</span></div>\n    <div class="ltr-org"><b>ARES-1 MISSIONSKONTROLLZENTRUM</b><span>Über das Bodenstationsnetz</span></div>\n    <div class="ltr-cls {0}">{1}OFFIZIELL<br><small>NUR FÜR DIE CREW</small></div></div>\n  <table class="ltr-meta">\n    <tr><td>Dokument-Nr.</td><td>{2}</td><td>Datum</td><td>{3} (Mars-Ortszeit)</td></tr>\n    <tr><td>An</td><td>Kommandant ARES-1</td><td>Bezug</td><td>{4}</td></tr>\n    <tr><td>Betreff</td><td colspan="3"><b>{5}</b></td></tr></table>\n  <div class="ltr-body">{6}</div>\n  {7}\n  <div class="ltr-sign">{8}</div>\n  {9}\n  <div class="ltr-ft">Diese Nachricht wurde mit {10} Min. Lichtlaufzeit übertragen · Verschlüsselter Kanal AES-256 · {11}</div>\n</div>',
    '<span class="fx rd">☢ Radyasyon · {0}–{1}</span>': '<span class="fx rd">☢ Strahlung · {0}–{1}</span>',
    '<span class="fx st">🌪 Kum fırtınası · {0}–{1}</span>':
      '<span class="fx st">🌪 Sandsturm · {0}–{1}</span>',
    '<span class="fx ok">Açık · dış görev uygun</span>': '<span class="fx ok">Klar · geeignet für EVA</span>',
    "EK-A · Uzay hava durumu tahmini": "ANHANG A · Weltraumwettervorhersage",
    '<div class="ltr-annex"><div class="ah">{0}</div><table>{1}</table><div class="an">Meteor düşüşleri öngörülemez; tahmine dahil değildir.</div></div>':
      '<div class="ltr-annex"><div class="ah">{0}</div><table>{1}</table><div class="an">Meteoriteneinschläge lassen sich nicht vorhersagen und sind nicht in der Vorhersage enthalten.</div></div>',
    "<p>Sayın Komutan,</p>\n  <p>ARES-1 aracının Mars yüzeyine başarılı inişini tebrik ederiz. Tüm Görev Kontrol ekibi şu an sizi izliyor ve iniş telemetrisini eksiksiz aldık.</p>\n  <p>Görevinizin temel amacı, yüzeyde <b>bilimsel veri toplamak</b> ve yaşadığınız her olayı — özellikle tehlikeli olanları — Dünya'ya <b>raporlamaktır</b>. Burada hiçbir insanın daha önce yaşamadığı koşulları yaşayacaksınız; gözlemleriniz gelecekteki mürettebatların hayatını kurtaracak.</p>\n  <ol><li>Fırtına, radyasyon, meteor, arıza, numune ve tarım olayları aracın <b>saha günlüğüne</b> otomatik kaydedilir.</li>\n  <li>Komuta güvertesindeki <b>İletişim Terminali</b>nden bu kayıtları seçip kendi notunuzu ekleyerek rapor gönderin.</li>\n  <li>Raporlar ekiplerimiz tarafından incelenir; resmî yanıtımız yaklaşık <b>½ sol</b> içinde ulaşır. Hayati durumlarda raporu <b>ACİL</b> işaretleyin; yanıt süresi ~¼ sole iner.</li></ol>\n  <p>Uydu verilerimiz bölgenizde gelişmekte olan bir toz sistemi gösteriyor. Yoğunluğu hakkında henüz kesin bilgimiz yok; lütfen aracın çevresinden çok uzaklaşmayın.</p>\n  <p>Size güveniyoruz. Dünya'dan selamlar.</p>":
      "<p>Sehr geehrter Kommandant,</p>\n  <p>herzlichen Glückwunsch zur erfolgreichen Landung von ARES-1 auf der Marsoberfläche. Das gesamte Team der Missionskontrolle verfolgt Sie in diesem Moment, und wir haben die Landetelemetrie vollständig empfangen.</p>\n  <p>Das Hauptziel Ihrer Mission ist es, auf der Oberfläche <b>wissenschaftliche Daten zu sammeln</b> und jedes Ereignis — besonders die gefährlichen — an die Erde zu <b>melden</b>. Sie werden Bedingungen erleben, die noch kein Mensch erlebt hat; Ihre Beobachtungen werden künftigen Crews das Leben retten.</p>\n  <ol><li>Stürme, Strahlung, Meteoriten, Ausfälle, Proben und Anbauereignisse werden automatisch im <b>Feldprotokoll</b> des Fahrzeugs erfasst.</li>\n  <li>Senden Sie Berichte über das <b>Kommunikationsterminal</b> auf dem Kommandodeck, indem Sie diese Einträge auswählen und eine eigene Notiz hinzufügen.</li>\n  <li>Die Berichte werden von unseren Teams geprüft; unsere offizielle Antwort trifft in etwa <b>½ Sol</b> ein. Markieren Sie den Bericht in kritischen Situationen als <b>DRINGEND</b>; die Antwortzeit sinkt dann auf ~¼ Sol.</li></ol>\n  <p>Unsere Satellitendaten zeigen ein Staubsystem, das sich in Ihrer Region entwickelt. Seine Stärke kennen wir noch nicht; bitte entfernen Sie sich nicht weit vom Fahrzeug.</p>\n  <p>Wir vertrauen Ihnen. Grüße von der Erde.</p>",
    "Görev başlangıç brifingi": "Briefing zum Missionsbeginn",
    "Yörünge görüntüleri bölgenize doğru ilerleyen bir toz cephesi gösteriyor.":
      "Orbitalaufnahmen zeigen eine Staubfront, die sich auf Ihre Region zubewegt.",
    "Basınç modellerimiz yerel bir toz fırtınasının oluşacağını öngörüyor.":
      "Unsere Druckmodelle sagen die Bildung eines lokalen Staubsturms voraus.",
    "Hellas havzasından yükselen bir toz sistemi konumunuza yaklaşıyor.":
      "Ein aus dem Hellas-Becken aufsteigendes Staubsystem nähert sich Ihrer Position.",
    "<li><b>Sol {0} · Kum fırtınası:</b> {1} Beklenen başlangıç <b>{2}</b>, süre yaklaşık <b>{3}</b>. Rüzgâr hızı {4} km/sa'e ulaşabilir.</li>":
      "<li><b>Sol {0} · Sandsturm:</b> {1} Erwarteter Beginn <b>{2}</b>, Dauer etwa <b>{3}</b>. Die Windgeschwindigkeit kann {4} km/h erreichen.</li>",
    "Güneş yüzeyinde X sınıfı bir patlama kaydedildi.":
      "Auf der Sonnenoberfläche wurde eine Eruption der X-Klasse registriert.",
    "SOHO gözlemleri yüksek enerjili bir koronal kütle atımı gösteriyor.":
      "SOHO-Beobachtungen zeigen einen energiereichen koronalen Massenauswurf.",
    "Güneş rüzgârı parçacık akısında ani artış bekleniyor.":
      "Ein plötzlicher Anstieg des Teilchenflusses im Sonnenwind wird erwartet.",
    "<li><b>Sol {0} · Radyasyon dalgası:</b> {1} Parçacık akısı <b>{2}–{3}</b> arasında zirve yapacak. Bu sürede <b>araç dışına çıkmayın</b>.</li>":
      "<li><b>Sol {0} · Strahlungswelle:</b> {1} Der Teilchenfluss erreicht seinen Höhepunkt zwischen <b>{2}–{3}</b>. <b>Verlassen Sie in dieser Zeit nicht das Fahrzeug</b>.</li>",
    "Uzay hava durumu biriminin günlük değerlendirmesi aşağıdadır.":
      "Nachfolgend die tägliche Einschätzung der Abteilung Weltraumwetter.",
    "Önümüzdeki iki sol için risk değerlendirmemiz ekte sunulmuştur.":
      "Unsere Risikobewertung für die nächsten zwei Sols liegt bei.",
    "Rutin uzay hava durumu bülteni bilgilerinize sunulur.":
      "Das routinemäßige Weltraumwetterbulletin wird Ihnen zur Information übermittelt.",
    "Dış görevlerinizi bu pencerelerin dışına planlamanızı öneriyoruz.":
      "Wir empfehlen, Ihre EVAs außerhalb dieser Zeitfenster zu planen.",
    "Numunelerinizi olay öncesinde kargoya yüklemenizi öneriyoruz.":
      "Wir empfehlen, Ihre Proben vor dem Ereignis in den Frachtraum zu laden.",
    "Olay sırasındaki gözlemlerinizi raporlamanız modellerimizi iyileştirecektir.":
      "Wenn Sie Ihre Beobachtungen während des Ereignisses melden, verbessern sich unsere Modelle.",
    '<p>ARES-1 mürettebatına,</p><p>{0}</p>\n  <ul class="ltr-ul">{1}</ul>\n  <p>{2}</p>':
      '<p>An die Crew von ARES-1,</p><p>{0}</p>\n  <ul class="ltr-ul">{1}</ul>\n  <p>{2}</p>',
    "Uzay hava durumu bülteni · Sol ": "Weltraumwetterbulletin · Sol ",
    "Uzay hava durumu bülteni": "Weltraumwetterbulletin",
    '<p>Sayın Komutan,</p>\n  <p>Araç telemetrisinde <b>itki sisteminde anomali</b> tespit ettik: ana motor kontrol kartından veri alınamıyor, yakıt hattında basınç dalgalanması görülüyor. Bu tablo, son fırtınada ciddi bir hasar oluştuğuna işaret ediyor.</p>\n  <p>Henüz sizden bu konuda bir rapor almadık. Lütfen <b>en kısa sürede durum raporu gönderin</b> ve makine dairesindeki tamir tezgâhından onarım prosedürünü başlatın.</p>\n  <div class="ltr-dir"><b>TALİMATLAR</b><ol><li>Makine dairesine inin, ana motora <kbd>E</kbd> ile erişin.</li><li>Prosedürü sırayla uygulayın: kablolar → sigortalar → basınç → ateşleme.</li><li>Duman yoğunsa oksijen seviyenizi kontrol edin.</li></ol></div>':
      '<p>Sehr geehrter Kommandant,</p>\n  <p>wir haben in der Fahrzeugtelemetrie eine <b>Anomalie im Antriebssystem</b> festgestellt: Von der Steuerplatine des Haupttriebwerks kommen keine Daten, und in der Treibstoffleitung treten Druckschwankungen auf. Dieses Bild deutet auf einen ernsten Schaden beim letzten Sturm hin.</p>\n  <p>Wir haben dazu noch keinen Bericht von Ihnen erhalten. Bitte <b>senden Sie so bald wie möglich einen Statusbericht</b> und beginnen Sie das Reparaturverfahren an der Werkbank im Maschinenraum.</p>\n  <div class="ltr-dir"><b>ANWEISUNGEN</b><ol><li>Gehen Sie in den Maschinenraum und greifen Sie mit <kbd>E</kbd> auf das Haupttriebwerk zu.</li><li>Führen Sie das Verfahren der Reihe nach durch: Kabel → Sicherungen → Druck → Zündung.</li><li>Bei starkem Rauch prüfen Sie Ihren Sauerstoffstand.</li></ol></div>',
    "Telemetri anomalisi · itki sistemi": "Telemetrieanomalie · Antriebssystem",
    "<p>Komutan,</p><p>Son <b>{0} soldur</b> sizden rapor alamadık. Telemetri aracın çalıştığını gösteriyor, ancak saha günlüğünüzde <b>{1} gönderilmemiş kayıt</b> birikmiş durumda.</p>\n  <p>Bilim ekibimiz ve mürettebat sağlığı birimimiz verilerinizi bekliyor. Kısa da olsa bir durum raporu göndermenizi rica ederiz. Nasıl hissettiğinizi bir iki cümleyle yazmanız da bizim için değerlidir.</p>":
      "<p>Kommandant,</p><p>seit <b>{0} Sols</b> haben wir keinen Bericht von Ihnen erhalten. Die Telemetrie zeigt, dass das Fahrzeug arbeitet, aber in Ihrem Feldprotokoll haben sich <b>{1} nicht gesendete Einträge</b> angesammelt.</p>\n  <p>Unser Wissenschaftsteam und unsere Abteilung für Crew-Gesundheit warten auf Ihre Daten. Wir bitten Sie, einen Statusbericht zu senden, auch wenn er kurz ist. Ein, zwei Sätze darüber, wie Sie sich fühlen, sind für uns ebenfalls wertvoll.</p>",
    "Rapor talebi": "Berichtsanfrage",
    "<p>Sayın Komutan,</p><p>Telemetri ana motorun çevrimiçi olduğunu ve kargo bölmesinin <b>{0}/{1}</b> dolduğunu doğruluyor. <b>Dünya'ya dönüş penceresi açılmıştır.</b></p>\n  <p>Komuta güvertesindeki navigasyon bilgisayarından dönüş rotasını onaylayabilirsiniz. Kalkıştan önce yaşadıklarınızı içeren son bir rapor göndermeniz, görev arşivi için çok değerli olacaktır.</p><p>Eve hoş geleceksiniz.</p>":
      "<p>Sehr geehrter Kommandant,</p><p>die Telemetrie bestätigt, dass das Haupttriebwerk online ist und der Frachtraum zu <b>{0}/{1}</b> gefüllt ist. <b>Das Rückkehrfenster zur Erde ist geöffnet.</b></p>\n  <p>Sie können den Rückkehrkurs am Navigationscomputer auf dem Kommandodeck bestätigen. Ein letzter Bericht über Ihre Erlebnisse vor dem Start wäre für das Missionsarchiv sehr wertvoll.</p><p>Willkommen zu Hause — schon jetzt.</p>",
    "Dönüş penceresi açıldı": "Rückkehrfenster geöffnet",
    "Çürüyen patatesleri biyoloji ekibi inceleyecek. Çürük patatesi kargo terminalinden bize gönderin.":
      "Das Biologieteam wird die verfaulten Kartoffeln untersuchen. Schickt uns eine verfaulte Kartoffel über das Frachtterminal.",
    "Fırtınalar konusundaki endişenizi anlıyoruz. Fırtınalar her 5 solda bir, sabah saatlerinde başlıyor; uyarı kartı göründüğünde 45 saniyeniz var.":
      "Wir verstehen Ihre Sorge wegen der Stürme. Sie beginnen alle 5 Sols in den Morgenstunden; sobald die Warnkarte erscheint, haben Sie 45 Sekunden.",
    "Toz fırtınası sırasında aracın gövdesi tasarım sınırları içinde kalıyor; içeride güvendesiniz. Sarsıntı normaldir.":
      "Während eines Staubsturms bleibt der Rumpf des Fahrzeugs innerhalb seiner Auslegungsgrenzen; drinnen sind Sie sicher. Die Erschütterungen sind normal.",
    "Motor konusunda yazdıklarınızı itki ekibine ilettik. Duman, kontrol kartındaki yanık sigortalardan ve kopan güç kablolarından kaynaklanıyor; onarım prosedürü bu sırayı izliyor.":
      "Was Sie über das Triebwerk geschrieben haben, haben wir an das Antriebsteam weitergeleitet. Der Rauch stammt von durchgebrannten Sicherungen auf der Steuerplatine und abgerissenen Stromkabeln; das Reparaturverfahren folgt dieser Reihenfolge.",
    "İtki ekibi, onarım sırasında aşamaları atlamamanızı rica ediyor: önce kablolar, sonra sigortalar ve ana şalter, ardından basınç kalibrasyonu ve son olarak ateşleme dizisi.":
      "Das Antriebsteam bittet Sie, bei der Reparatur keine Stufen zu überspringen: zuerst die Kabel, dann die Sicherungen und der Hauptschalter, danach die Druckkalibrierung und zuletzt die Zündsequenz.",
    "Oksijen yönetimi hayati önemde: giysi oksijeni %30'un altına indiğinde dış görevi bitirin. Makine dairesindeki O₂ tüpleri kendini yavaşça yeniliyor; tüp seviyesini de takip edin.":
      "Das Sauerstoffmanagement ist lebenswichtig: Beenden Sie den Außeneinsatz, wenn der Anzugsauerstoff unter 30 % fällt. Die O₂-Tanks im Maschinenraum füllen sich langsam selbst wieder auf; behalten Sie auch den Tankstand im Blick.",
    "Su geri dönüştürücü düzenli çalışıyor; stok yavaş da olsa kendiliğinden yenileniyor. Mutfaktan şişe alıp çantanızda taşıyabilirsiniz.":
      "Der Wasser-Recycler arbeitet normal; der Vorrat füllt sich von selbst wieder auf, wenn auch langsam. Sie können Flaschen aus der Küche nehmen und in Ihrer Tasche tragen.",
    "Erzak durumunuzu yakından izliyoruz. Patates yetiştirmek uzun vadeli tek gıda kaynağınız; her hasat ek tohum da veriyor. Mutfak ve yemek kapsülündeki stoku dengeli kullanın.":
      "Wir beobachten Ihre Vorratslage genau. Der Kartoffelanbau ist Ihre einzige langfristige Nahrungsquelle; jede Ernte liefert zusätzlich Samen. Gehen Sie mit dem Vorrat in Küche und Nahrungskapsel sparsam um.",
    "Radyasyon dalgaları her 3 solda bir, günün ilk saatlerinde geliyor. Aracın gövde zırhı sizi tamamen koruyor; dalga boyunca içeride kalmanız ya da uyumanız yeterli.":
      "Strahlungswellen kommen alle 3 Sols in den ersten Stunden des Tages. Die Rumpfpanzerung des Fahrzeugs schützt Sie vollständig; es genügt, während der Welle drinnen zu bleiben oder zu schlafen.",
    "Meteorlar öngörülemez, ancak düşmeden önce bir uğultu ve yerde büyüyen bir gölge oluşuyor. Gölgeden uzaklaşın; çarpmadan sonra kraterlerde değerli numuneler bulabilirsiniz.":
      "Meteoriten sind unvorhersehbar, doch vor dem Einschlag gibt es ein Grollen und einen wachsenden Schatten auf dem Boden. Entfernen Sie sich vom Schatten; nach dem Einschlag können Sie in den Kratern wertvolle Proben finden.",
    "Yazdıklarınızı dikkatle okudum. Bu duyguların izole ve yüksek riskli bir ortamda çok doğal olduğunu bilmenizi isterim; zayıflık değil, insan olmanın bir parçası.":
      "Ich habe aufmerksam gelesen, was Sie geschrieben haben. Sie sollen wissen, dass diese Gefühle in einer isolierten Umgebung mit hohem Risiko völlig natürlich sind; sie sind keine Schwäche, sondern Teil des Menschseins.",
    "Günlük bir rutin kurmanızı öneriyorum: düzenli uyku, öğünler ve her sol kısa da olsa bir rapor. Bize yazmak da bir bağ kurmaktır; her mesajınızı okuyoruz. Aileniz iyi ve size selamlarını iletiyorlar.":
      "Ich empfehle Ihnen eine tägliche Routine: regelmäßiger Schlaf, feste Mahlzeiten und jeden Sol ein Bericht, auch wenn er kurz ist. Uns zu schreiben ist auch eine Form der Verbindung; wir lesen jede Ihrer Nachrichten. Ihrer Familie geht es gut, sie lässt Sie grüßen.",
    "Sağlık durumunuzu kayda aldık. Can değeriniz düştüğünde revirdeki medikitleri kullanın; uyku da iyileşmeyi belirgin şekilde hızlandırıyor.":
      "Wir haben Ihren Gesundheitszustand erfasst. Verwenden Sie die Medkits in der Krankenstation, wenn Ihre Gesundheit sinkt; auch Schlaf beschleunigt die Genesung deutlich.",
    "Tarım denemeniz biyoloji ekibinin en çok takip ettiği konu. Parsellerinizi sulamayı unutmayın; ıslak toprakta büyüme belirgin şekilde hızlanıyor.":
      "Ihr Anbauexperiment ist das Thema, das das Biologieteam am genauesten verfolgt. Vergessen Sie nicht, Ihre Beete zu gießen; auf feuchtem Boden wachsen die Pflanzen deutlich schneller.",
    "Dönüş için iki koşul gerekiyor: ana motorun çalışır olması ve kargo bölmesinin {0} birim numuneyle dolması. Bu sağlandığında navigasyon bilgisayarı dönüş rotasını açacak.":
      "Für die Rückkehr sind zwei Bedingungen nötig: ein funktionierendes Haupttriebwerk und ein mit {0} Probeneinheiten gefüllter Frachtraum. Sobald beides erfüllt ist, gibt der Navigationscomputer den Rückkehrkurs frei.",
    "Asıl biz teşekkür ederiz. Kontrol odasında her raporunuz okunurken herkes ekranın başına toplanıyor.":
      "Wir sind es, die Ihnen danken müssen. Wann immer einer Ihrer Berichte vorgelesen wird, versammeln sich alle im Kontrollraum vor dem Bildschirm.",
    "Numune toplama çalışmanız bilim ekibinin önceliği. Yıldız kristalleri metal numunelerin iki katı değerinde; kargoya yüklerken bunu göz önünde bulundurun.":
      "Ihre Probensammlung hat für das Wissenschaftsteam Priorität. Sternkristalle sind doppelt so wertvoll wie Metallproben; berücksichtigen Sie das beim Beladen des Frachtraums.",
    "Patatesler, ekildikleri toprağın radyasyonu <b>1,0 µSv/h</b> ve üzerindeyse hasatta çürük çıkar. Roketteki <b>alet sandığından</b> radyasyon ölçeri alın ve ekmeden önce toprağı ölçün; ekranda <b>RADYASYON NORMAL</b> görünen yere ekin. Bugüne kadar {0} ölçüm yaptınız, bunların {1} tanesi normal çıktı.":
      "Kartoffeln verfaulen bei der Ernte, wenn der Boden <b>1,0 µSv/h</b> oder mehr aufweist. Nimm das Strahlungsmessgerät aus der <b>Werkzeugkiste</b> der Rakete und miss den Boden vor dem Pflanzen; pflanze dort, wo <b>STRAHLUNG NORMAL</b> angezeigt wird. Bisher hast du {0} Messungen gemacht, davon {1} normal.",
    "Giysi oksijeniniz şu anda <b>%{0}</b>, roketteki O₂ tüpü <b>%{1}</b> dolu. Giysi oksijeni %30'un altına düştüğünde rokete dönün ve makine dairesindeki O₂ istasyonundan doldurun. Koşmak tüketimi artırır.":
      "Dein Anzugsauerstoff liegt bei <b>{0} %</b>, der O₂-Tank der Rakete ist zu <b>{1} %</b> gefüllt. Fällt der Anzugsauerstoff unter 30 %, kehre zur Rakete zurück und fülle an der O₂-Station im Maschinenraum nach. Rennen erhöht den Verbrauch.",
    "Çantanızda <b>{0}</b>, depoda <b>{1}</b> şişe su var; susuzluk göstergeniz %{2}. Su geri dönüştürücü yaklaşık her {3} dakikada bir şişe üretir. Şişeleri kargo terminalinden ya da mutfaktan alabilirsiniz.":
      "Du hast <b>{0}</b> Flaschen Wasser im Gepäck und <b>{1}</b> im Lager; deine Durstanzeige steht bei {2} %. Der Wasserrecycler erzeugt etwa alle {3} Minuten eine Flasche. Flaschen gibt es am Frachtterminal oder in der Küche.",
    "Tokluğunuz %{0}. Çantanızda <b>{1}</b>, depoda <b>{2}</b> patates ve toplam <b>{3}</b> tohum var. Erzak azalıyorsa radyasyonu normal toprağa patates ekin; düzenli sulama büyümeyi hızlandırır.":
      "Deine Sättigung liegt bei {0} %. Du hast <b>{1}</b> Kartoffeln im Gepäck, <b>{2}</b> im Lager und insgesamt <b>{3}</b> Samen. Werden die Vorräte knapp, pflanze Kartoffeln in Boden mit normaler Strahlung; regelmäßiges Gießen beschleunigt das Wachstum.",
    "Bir sonraki toz fırtınası <b>Sol {0}</b> için öngörülüyor. Fırtına sırasında anten kapanabilir ve dışarıdaki ana motor arızalanabilir. Uyarı gelince rokete girin ve fırtına geçene kadar dışarı çıkmayın.":
      "Der nächste Staubsturm wird für <b>Sol {0}</b> erwartet. Während eines Sturms kann die Antenne blockiert werden und das Haupttriebwerk ausfallen. Geh bei der Warnung in die Rakete und bleib drinnen, bis der Sturm vorbei ist.",
    "Bir sonraki güneş kaynaklı radyasyon dalgası <b>Sol {0}</b> için öngörülüyor. Dalga sırasında dışarıda kalmak can kaybettirir; roketin gövdesi koruma sağlar. Şu anki ortam radyasyonu <b>{1} µSv/h</b>.":
      "Die nächste solare Strahlungswelle wird für <b>Sol {0}</b> erwartet. Wer während der Welle draußen bleibt, verliert Gesundheit; die Raketenhülle schützt dich. Die aktuelle Umgebungsstrahlung beträgt <b>{1} µSv/h</b>.",
    "Ana motor şu anda <b>çevrimiçi</b>. Fırtınalarda arızalanabileceği için fırtına uyarısında rokete girmeniz yeterlidir.":
      "Das Haupttriebwerk ist derzeit <b>online</b>. Es kann bei Stürmen ausfallen; geh bei einer Sturmwarnung einfach in die Rakete.",
    "Ana motor şu anda <b>devre dışı</b>; onarım {0}/4 aşamada. Makine dairesindeki onarım istasyonuna gidip adımları sırasıyla tamamlayın.":
      "Das Haupttriebwerk ist derzeit <b>offline</b>; die Reparatur steht bei Schritt {0}/4. Geh zur Reparaturstation im Maschinenraum und erledige die Schritte der Reihe nach.",
    çevrimiçi: "online",
    "devre dışı": "offline",
    "Dünya'ya dönüş için iki koşul gerekiyor: ana motorun çevrimiçi olması (şu an: <b>{0}</b>) ve kargoda en az <b>{1}</b> numune bulunması (şu an: <b>{2}/{3}</b>).":
      "Für die Rückkehr zur Erde braucht es zwei Dinge: ein funktionierendes Haupttriebwerk (jetzt: <b>{0}</b>) und mindestens <b>{1}</b> Proben im Frachtraum (jetzt: <b>{2}/{3}</b>).",
    "Kargo bölmesinde <b>{0}/{1}</b> numune var. Metal numune 1, yıldız kırıntısı 2 puan sayılır; numuneleri roketin yanında <b>F</b> ile ya da kargo terminalinden yükleyin.":
      "Im Frachtraum sind <b>{0}/{1}</b> Proben. Eine Metallprobe zählt 1, ein Sternsplitter 2; lade Proben neben der Rakete mit <b>F</b> oder über das Frachtterminal.",
    "Canınız <b>%{0}</b>. Toplam <b>{1}</b> medikitiniz var; revirden alıp kullanabilirsiniz. Uyumak da canı yavaşça yeniler.":
      "Deine Gesundheit liegt bei <b>{0} %</b>. Du hast insgesamt <b>{1}</b> Medikits; hol sie aus der Krankenstation. Schlafen stellt die Gesundheit ebenfalls langsam wieder her.",
    "Yatakhanedeki ranzada uyuyabilirsiniz. Uyurken zaman hızlanır, can yenilenir; oksijen ve erzak tüketimi devam eder, bu yüzden uyumadan önce stoklarınızı kontrol edin.":
      "Du kannst in der Koje im Mannschaftsquartier schlafen. Im Schlaf vergeht die Zeit schneller und die Gesundheit erholt sich; Sauerstoff und Vorräte werden weiter verbraucht, prüfe also vorher deine Bestände.",
    "Şu an <b>Sol {0}</b>, Mars yerel saati <b>{1}</b>. Bir Mars günü (sol) yaklaşık 24 saat 40 dakika sürer.":
      "Es ist <b>Sol {0}</b>, Mars-Ortszeit <b>{1}</b>. Ein Marstag (Sol) dauert etwa 24 Stunden 40 Minuten.",
    "Dış sıcaklık şu anda yaklaşık <b>{0} °C</b>. Giysinizin ısıl kontrolü vücut sıcaklığınızı <b>{1} °C</b> civarında tutuyor; gece sıcaklık −75 °C'ye kadar düşebilir.":
      "Die Außentemperatur beträgt etwa <b>{0} °C</b>. Die Wärmeregelung deines Anzugs hält deine Körpertemperatur bei etwa <b>{1} °C</b>; nachts kann es bis −75 °C kalt werden.",
    "Mesajlarınız Mars ile Dünya arasında tek yönde yaklaşık <b>{0} dakikada</b> iletiliyor. Şu an sizi <b>{1}</b> derin uzay anteni izliyor; istasyonlar Dünya döndükçe sırayla devralır.":
      "Deine Nachrichten brauchen zwischen Mars und Erde einfach etwa <b>{0} Minuten</b>. Derzeit verfolgt dich die Deep-Space-Antenne <b>{1}</b>; die Stationen übernehmen nacheinander, während sich die Erde dreht.",
    "Meteorlar önceden kesin olarak bilinemez. Düşmeden önce bir uğultu duyulur ve yerde büyüyen bir gölge oluşur; gölgeyi görünce hemen uzaklaşın.":
      "Meteore lassen sich nicht genau vorhersagen. Vor dem Einschlag hörst du ein Grollen und am Boden wächst ein Schatten; geh sofort weg, wenn du ihn siehst.",
    "Şu anda <b>{0}</b> altınınız var. Roketteki geliştirme istasyonunda altınla roketinizi ve ekipmanınızı güçlendirebilirsiniz.":
      "Du hast <b>{0}</b> Gold. Nutze es an der Upgrade-Station der Rakete, um Rakete und Ausrüstung zu verbessern.",
    "Tüm görevleri tamamladınız. Dönüş penceresi açıksa rokete binip Dünya'ya dönebilirsiniz.":
      "Du hast alle Aufgaben erledigt. Ist das Rückkehrfenster offen, steig in die Rakete und fliege zur Erde zurück.",
    "Şu anki göreviniz: <b>{0}</b> — {1}. Önerimiz: {2}":
      "Deine aktuelle Aufgabe: <b>{0}</b> — {1}. Unser Rat: {2}",
    "Duygularınızı paylaştığınız için teşekkür ederiz. Uzun görevlerde bu çok doğal. Davranış sağlığı ekibimiz sizi takip ediyor; düzenli uyku, kısa molalar ve hedeflerinizi küçük adımlara bölmek yardımcı olur. Yalnız değilsiniz, her mesajınız burada okunuyor.":
      "Danke, dass du deine Gefühle teilst. Auf langen Missionen ist das ganz normal. Unser Team für Verhaltensgesundheit begleitet dich; regelmäßiger Schlaf, kurze Pausen und kleine Zwischenziele helfen. Du bist nicht allein, jede Nachricht wird hier gelesen.",
    "Ben <b>GDY-1</b>, ARES Görev Kontrol Merkezi'nin görev destek yapay zekâsıyım. Raporlarınızdaki soruları canlı görev verileriyle eşleştirip resmî yanıt hazırlıyorum; ayrıntılı değerlendirmeler uzman ekiplerden ayrıca gelir.":
      "Ich bin <b>GDY-1</b>, die Missionsunterstützungs-KI der ARES-Missionskontrolle. Ich gleiche die Fragen in deinen Berichten mit Live-Missionsdaten ab und erstelle offizielle Antworten; ausführliche Bewertungen kommen separat von den Fachteams.",
    "Merhaba Komutan. Mesajınız alındı; sinyal kalitesi iyi. Sormak istediğiniz her şeyi raporunuza yazabilirsiniz.":
      "Hallo, Kommandant. Deine Nachricht ist angekommen, die Signalqualität ist gut. Schreib alles, was du fragen willst, in deinen Bericht.",
    "Rica ederiz Komutan. Görev Kontrol her an hattadır.":
      "Gern geschehen, Kommandant. Die Missionskontrolle ist jederzeit erreichbar.",
    "Sorunuzu kayda aldım; görev veritabanında doğrudan eşleşen bir konu bulamadım ve uzman ekiplere ilettim.":
      "Ich habe deine Frage erfasst; in der Missionsdatenbank gab es keinen direkten Treffer, daher habe ich sie an die Fachteams weitergeleitet.",
    "Sorunuzu kayda aldım; görev veritabanında doğrudan eşleşen bir konu bulamadım ve uzman ekiplere ilettim. Bu arada şu anki göreviniz: <b>{0}</b> — {1}.":
      "Ich habe deine Frage erfasst; in der Missionsdatenbank gab es keinen direkten Treffer, daher habe ich sie an die Fachteams weitergeleitet. Deine aktuelle Aufgabe: <b>{0}</b> — {1}.",
    '<div class="ai-qa"><div class="ai-q"><span>SORU {0}</span>«{1}»</div><div class="ai-a"><span>YANIT</span><p>{2}</p></div></div>':
      '<div class="ai-qa"><div class="ai-q"><span>FRAGE {0}</span>«{1}»</div><div class="ai-a"><span>ANTWORT</span><p>{2}</p></div></div>',
    '<p>Sayın Komutan,</p>\n  <p><b>{0}</b> numaralı raporunuzdaki not, {1} anteni üzerinden alınarak <b>GDY-1 Görev Destek Yapay Zekâsı</b> tarafından canlı görev verileriyle (Sol {2} · {3}) değerlendirilmiştir. Yanıtlar aşağıdadır.</p>\n  {4}\n  <p class="ai-ft">Bu yanıt otomatik olarak hazırlanmış ve Görev Kontrol adına resmî bilgilendirme niteliğindedir. Uzman ekiplerin ayrıntılı değerlendirmesi rapor yanıtıyla ayrıca iletilecektir.</p>':
      '<p>Sehr geehrter Kommandant,</p>\n  <p>Die Notiz in deinem Bericht <b>{0}</b> wurde über die Antenne {1} empfangen und von <b>GDY-1, der Missionsunterstützungs-KI</b>, mit Live-Missionsdaten (Sol {2} · {3}) ausgewertet. Die Antworten folgen unten.</p>\n  {4}\n  <p class="ai-ft">Diese Antwort wurde automatisch erstellt und ist eine offizielle Mitteilung im Namen der Missionskontrolle. Die ausführliche Bewertung der Fachteams folgt mit der Berichtsantwort.</p>',
    "Sorunuza yanıt · ": "Antwort auf deine Frage · ",
    '<div class="ltr-dir"><b>TALİMATLAR</b><ol>{0}</ol></div>':
      '<div class="ltr-dir"><b>ANWEISUNGEN</b><ol>{0}</ol></div>',
    "Sol {0} fırtınasına ait verileriniz Uzay Hava Durumu Birimi tarafından incelendi. Yörünge görüntüleriyle karşılaştırıldığında bölgenizdeki toz yoğunluğunun optik derinlik <b>τ≈{1}</b> seviyesine ulaştığı anlaşılıyor.":
      "Ihre Daten zum Sturm an Sol {0} wurden von der Abteilung Weltraumwetter ausgewertet. Im Vergleich mit Orbitalaufnahmen hat die Staubdichte in Ihrer Region offenbar eine optische Tiefe von <b>τ≈{1}</b> erreicht.",
    "Gönderdiğiniz fırtına gözlemleri, bu enlemde kaydedilen en yoğun yerel toz olaylarından biriyle uyumlu. Rüzgâr hızının anlık olarak <b>{0} km/sa</b>'e çıktığını tahmin ediyoruz.":
      "Ihre Sturmbeobachtungen stimmen mit einem der stärksten lokalen Staubereignisse überein, die in dieser Breite verzeichnet wurden. Wir schätzen, dass die Windgeschwindigkeit kurzzeitig <b>{0} km/h</b> erreichte.",
    "Fırtına süresince toplanan basınç ve görüş verileri modelimizi doğrulamamızı sağladı; tahmin hatamız bu veriyle <b>%{0}</b> azaldı.":
      "Die während des Sturms gesammelten Druck- und Sichtdaten haben es uns ermöglicht, unser Modell zu validieren; mit diesen Daten sank unser Vorhersagefehler um <b>{0} %</b>.",
    "Kayıtlar fırtına sırasında araç dışında yaklaşık <b>{0}</b> geçirdiğinizi gösteriyor. Bu, EVA güvenlik kuralının (GK-EVA-7) açıkça ihlalidir; lütfen bir daha tekrarlamayın.":
      "Die Aufzeichnungen zeigen, dass Sie während des Sturms etwa <b>{0}</b> außerhalb des Fahrzeugs verbracht haben. Das ist ein klarer Verstoß gegen die EVA-Sicherheitsregel (GK-EVA-7); bitte wiederholen Sie das nicht.",
    "Fırtına boyunca araç içinde kalmanız prosedüre tam uygundur; teşekkür ederiz.":
      "Dass Sie während des gesamten Sturms im Fahrzeug geblieben sind, entspricht voll und ganz dem Verfahren; vielen Dank.",
    "Mürettebatın fırtınayı araç içinde geçirmesi doğru karardı.":
      "Die Entscheidung der Crew, den Sturm im Fahrzeug abzuwarten, war richtig.",
    " Fırtınanın ana motora verdiği hasar ayrıca itki ekibine iletilmiştir.":
      " Der Schaden, den der Sturm am Haupttriebwerk verursacht hat, wurde zusätzlich an das Antriebsteam weitergeleitet.",
    "Fırtına uyarı kartı göründüğünde <b>45 saniye</b> içinde hava kilidine dönün.":
      "Wenn die Sturmwarnkarte erscheint, kehren Sie innerhalb von <b>45 Sekunden</b> zur Luftschleuse zurück.",
    "Sonraki fırtına <b>Sol {0}</b>, {1} için öngörülüyor; o sol dış görevleri fırtına öncesine planlayın.":
      "Der nächste Sturm wird für <b>Sol {0}</b>, {1} vorhergesagt; planen Sie die Außeneinsätze an diesem Sol vor dem Sturm.",
    "Fırtına öncesi çantanızdaki numuneleri kargoya yükleyin.":
      "Laden Sie vor dem Sturm die Proben aus Ihrer Tasche in den Frachtraum.",
    "Fırtına sırasında komuta güvertesindeki ön camdan görüş gözlemi yapıp raporlayın.":
      "Beobachten Sie während des Sturms die Sicht durch die Frontscheibe auf dem Kommandodeck und melden Sie sie.",
    "Fırtına sonrası oksijen tüpü seviyesini kontrol edin; filtreler tozla yüklenmiş olabilir.":
      "Prüfen Sie nach dem Sturm den Stand der Sauerstofftanks; die Filter könnten mit Staub belastet sein.",
    "İtki ekibimiz bildirdiğiniz arızayı telemetriyle eşleştirdi. Toz girişinin yakıt hattı vanasında basınç dalgalanmasına, ardından kontrol kartında aşırı akıma yol açtığı değerlendiriliyor.":
      "Unser Antriebsteam hat den von Ihnen gemeldeten Ausfall mit der Telemetrie abgeglichen. Vermutlich hat eindringender Staub Druckschwankungen am Ventil der Treibstoffleitung und anschließend Überstrom auf der Steuerplatine verursacht.",
    "Arıza raporunuz itki ekibinde öncelikli olarak ele alındı. Ön analiz: fırtına esnasındaki titreşim güç kablolarını soketlerinden kopardı, oluşan kısa devre sigortaları yaktı.":
      "Ihre Störungsmeldung wurde vom Antriebsteam vorrangig bearbeitet. Vorläufige Analyse: Die Vibrationen während des Sturms haben die Stromkabel aus ihren Buchsen gerissen, und der entstandene Kurzschluss hat die Sicherungen durchbrennen lassen.",
    "Bildirdiğiniz motor arızası, test tesisimizdeki yedek motorda simüle edildi. Aynı belirtileri (duman, kalkış kilidi, kontrol kartı sessizliği) elde ettik; arıza tipi doğrulandı.":
      "Der von Ihnen gemeldete Triebwerksausfall wurde am Ersatztriebwerk in unserer Testanlage simuliert. Wir haben dieselben Symptome (Rauch, Startsperre, stumme Steuerplatine) erhalten; der Fehlertyp ist bestätigt.",
    "<b>Bu yanıt hazırlanırken alınan telemetri motorun yeniden çevrimiçi olduğunu gösteriyor — tebrikler.</b>":
      "<b>Die während der Erstellung dieser Antwort empfangene Telemetrie zeigt, dass das Triebwerk wieder online ist — herzlichen Glückwunsch.</b>",
    "<b>Güncel telemetri motorun hâlâ devre dışı olduğunu gösteriyor</b> (tamamlanan aşama: {0}/4). Onarım bitmeden dönüş penceresi açılmayacaktır.":
      "<b>Die aktuelle Telemetrie zeigt, dass das Triebwerk noch außer Betrieb ist</b> (abgeschlossene Stufen: {0}/4). Vor Abschluss der Reparatur öffnet sich das Rückkehrfenster nicht.",
    "Motor çalışırken makine dairesinde olağandışı ses ya da duman görürseniz derhal raporlayın.":
      "Wenn Sie bei laufendem Triebwerk im Maschinenraum ungewöhnliche Geräusche oder Rauch bemerken, melden Sie das sofort.",
    "Makine dairesinde ana motora ya da tamir tezgâhına <kbd>E</kbd> ile erişin.":
      "Greifen Sie im Maschinenraum mit <kbd>E</kbd> auf das Haupttriebwerk oder die Werkbank zu.",
    "Prosedür sırası: <b>kablolar → sigortalar + ana şalter → basınç kalibrasyonu → ateşleme</b>. Tamamlanan aşamalar kaydedilir.":
      "Reihenfolge des Verfahrens: <b>Kabel → Sicherungen + Hauptschalter → Druckkalibrierung → Zündung</b>. Abgeschlossene Stufen werden gespeichert.",
    "Basınç aşamasında ibre yeşil bölgedeyken kilitleyin; acele etmeyin.":
      "Sperren Sie in der Druckstufe, während der Zeiger im grünen Bereich steht; überstürzen Sie nichts.",
    "Duman yoğunken uzun süre makine dairesinde kalmayın.":
      "Bleiben Sie bei starkem Rauch nicht lange im Maschinenraum.",
    "Onarım kayıtlarınızı inceledik: tüm aşamalar nominal değerlerde tamamlanmış. Bu, Mars yüzeyinde mürettebat tarafından yapılan ilk tam itki onarımıdır; tebrikler.":
      "Wir haben Ihre Reparaturprotokolle geprüft: Alle Stufen wurden mit Nennwerten abgeschlossen. Dies ist die erste vollständige Antriebsreparatur, die von einer Crew auf der Marsoberfläche durchgeführt wurde; herzlichen Glückwunsch.",
    "Motorun yeniden çevrimiçi olması tüm kontrol odasında alkışla karşılandı. Onarım verileriniz üretici firmaya iletildi; sonraki araç tasarımında toz filtresi revize edilecek.":
      "Dass das Triebwerk wieder online ist, wurde im ganzen Kontrollraum mit Applaus aufgenommen. Ihre Reparaturdaten wurden an den Hersteller weitergeleitet; beim nächsten Fahrzeugentwurf wird der Staubfilter überarbeitet.",
    "Sonraki fırtınada motor bölmesinin sızdırmazlığını gözlemleyin.":
      "Beobachten Sie beim nächsten Sturm die Dichtheit des Triebwerksraums.",
    "Onarım sırasında fark ettiğiniz her şeyi notunuza ekleyin; mühendislerimiz için çok değerli.":
      "Notieren Sie alles, was Ihnen bei der Reparatur aufgefallen ist; das ist für unsere Ingenieure sehr wertvoll.",
    "Dozimetre verileriniz Uzay Hava Durumu Birimi ve Uçuş Cerrahı tarafından birlikte değerlendirildi.":
      "Ihre Dosimeterdaten wurden von der Abteilung Weltraumwetter und dem Flugarzt gemeinsam ausgewertet.",
    "Parçacık dalgasına ait sensör verileriniz başarıyla işlendi; olay, Güneş'teki bir koronal kütle atımıyla eşleştirildi.":
      "Ihre Sensordaten zur Teilchenwelle wurden erfolgreich verarbeitet; das Ereignis wurde einem koronalen Massenauswurf auf der Sonne zugeordnet.",
    " Kayıtlara göre dalga sırasında araç dışında <b>{0}</b> kaldınız; tahmini alınan doz <b>~{1} mSv</b>. Bu değer yıllık limitinizin önemli bir kısmıdır. Sağlık kaydınıza işlendi.":
      " Laut den Aufzeichnungen waren Sie während der Welle <b>{0}</b> außerhalb des Fahrzeugs; die geschätzte erhaltene Dosis beträgt <b>~{1} mSv</b>. Das ist ein erheblicher Teil Ihres Jahresgrenzwerts. Es wurde in Ihre Gesundheitsakte eingetragen.",
    " Dalga boyunca zırhlı gövde içinde kalmanız sayesinde aldığınız doz ihmal edilebilir düzeyde (<b>&lt;1 mSv</b>). Mükemmel.":
      " Da Sie während der Welle im gepanzerten Rumpf geblieben sind, ist die erhaltene Dosis vernachlässigbar (<b>&lt;1 mSv</b>). Ausgezeichnet.",
    "Sonraki radyasyon dalgası <b>Sol {0}</b>, {1}–{2} arasında bekleniyor.":
      "Die nächste Strahlungswelle wird an <b>Sol {0}</b> zwischen {1}–{2} erwartet.",
    "Dalga sırasında araç içinde kalın; uyumak zamanı güvenle geçirmenin en iyi yolu.":
      "Bleiben Sie während der Welle im Fahrzeug; Schlafen ist der beste Weg, die Zeit sicher zu überbrücken.",
    "Doz aldıysanız revirdeki medikiti kullanın.":
      "Wenn Sie eine Dosis erhalten haben, verwenden Sie das Medkit in der Krankenstation.",
    "Ekran yeşile döndüğünde ve kenarlarda ışıma başladığında derhal rokete dönün.":
      "Wenn der Bildschirm grün wird und die Ränder zu leuchten beginnen, kehren Sie sofort zur Rakete zurück.",
    "Bildirdiğiniz <b>{0}</b> meteor çarpması bilim ekibinde büyük heyecan yarattı. Taze kraterler, Mars yüzeyinin yaşı ve iç yapısı hakkında eşsiz bilgi sağlıyor.":
      "Die <b>{0}</b> von Ihnen gemeldeten Meteoriteneinschläge haben im Wissenschaftsteam große Begeisterung ausgelöst. Frische Krater liefern einzigartige Informationen über das Alter und den inneren Aufbau der Marsoberfläche.",
    "Gezegen Bilimi Ekibi, raporunuzdaki {0} çarpmayı yörünge sismik verileriyle eşleştirdi. Çarpışma enerjilerinin her biri için birkaç ton TNT eşdeğeri olduğu hesaplanıyor.":
      "Das Team Planetenwissenschaft hat die {0} Einschläge aus Ihrem Bericht mit seismischen Orbitaldaten abgeglichen. Die Einschlagsenergie wird für jeden auf mehrere Tonnen TNT-Äquivalent berechnet.",
    " Ancak en yakın çarpmanın yalnızca <b>~{0} m</b> mesafede olması ciddi bir risk; uçuş cerrahımız endişeli.":
      " Dass der nächste Einschlag jedoch nur <b>~{0} m</b> entfernt war, ist ein ernstes Risiko; unser Flugarzt ist besorgt.",
    " En yakın çarpma ~{0} m mesafede; güvenli sınırlar içinde.":
      " Der nächste Einschlag war ~{0} m entfernt; innerhalb der sicheren Grenzen.",
    "Uğultu duyduğunuzda yerdeki <b>büyüyen gölgeyi</b> arayın ve ondan uzaklaşın.":
      "Wenn Sie ein Grollen hören, suchen Sie den <b>wachsenden Schatten</b> auf dem Boden und entfernen Sie sich davon.",
    "Taze kraterler bir süre sıcak kalır; tütmesi bitince numune arayın.":
      "Frische Krater bleiben eine Weile heiß; suchen Sie nach Proben, wenn sie nicht mehr rauchen.",
    "Kraterlerde bulduğunuz yıldız kristallerini öncelikle kargoya yükleyin.":
      "Laden Sie die in Kratern gefundenen Sternkristalle vorrangig in den Frachtraum.",
    "Bildirdiğiniz <b>{0}</b> bulguları bilim ekibinde olağanüstü bir heyecan yarattı. Bu mineraller yörünge spektrometreleriyle yalnızca dolaylı olarak tespit edilmişti; yerinde analiz ilk kez yapıldı.":
      "Ihre gemeldeten <b>{0}</b>-Funde haben im Wissenschaftsteam außerordentliche Begeisterung ausgelöst. Diese Minerale waren bisher nur indirekt mit Orbitalspektrometern nachgewiesen worden; dies ist die erste Analyse vor Ort.",
    "Gezegen Bilimi Ekibi raporladığınız {0} örneklerini inceledi. Kristal yapısı, bölgede geçmişte hidrotermal etkinlik olduğuna işaret ediyor.":
      "Das Team Planetenwissenschaft hat die von Ihnen gemeldeten {0}-Proben untersucht. Die Kristallstruktur deutet auf frühere hydrothermale Aktivität in der Region hin.",
    "Uzak bölgelerde tarayıcı sinyallerini takip etmeye devam edin; ancak oksijen seviyenizi dönüş için yeterli tutun.":
      "Folgen Sie in abgelegenen Gebieten weiter den Scannersignalen, behalten Sie aber genug Sauerstoff für die Rückkehr.",
    "Titanyum cevherini roket zırhı için, olivin kristallerini EVA giysisi için ayırın.":
      "Legen Sie das Titanerz für die Raketenpanzerung und die Olivinkristalle für den EVA-Anzug beiseite.",
    "Ares taşı son derece nadir; bulduğunuz her parça bilimsel olarak paha biçilemez.":
      "Aresstein ist äußerst selten; jedes Stück, das Sie finden, ist wissenschaftlich unbezahlbar.",
    "Gönderdiğiniz {0} metal{1} numunesinin spektral ön verisi, yüksek demir-nikel oranına işaret ediyor.":
      "Die vorläufigen Spektraldaten der von Ihnen gesendeten {0} Metallproben{1} deuten auf einen hohen Eisen-Nickel-Anteil hin.",
    ", {0} kristal": ", {0} Kristalle",
    "Numune verileriniz ({0} metal{1}) laboratuvarımızdaki Mars göktaşı koleksiyonuyla karşılaştırılıyor; ilk sonuçlar umut verici.":
      "Ihre Probendaten ({0} Metall{1}) werden mit der Sammlung von Marsmeteoriten in unserem Labor verglichen; die ersten Ergebnisse sind vielversprechend.",
    "Yıldız kristallerinin kökeni ekibimizde tartışma yarattı; hidratlı mineral olasılığı, geçmişte sıvı su bulunduğuna işaret edebilir.":
      "Der Ursprung der Sternkristalle hat in unserem Team eine Debatte ausgelöst; die Möglichkeit hydratisierter Minerale könnte darauf hindeuten, dass es früher flüssiges Wasser gab.",
    "Kristallerin parlaklık spektrumu bilinen hiçbir Mars mineraliyle tam eşleşmiyor. Lütfen toplamaya devam edin.":
      "Das Helligkeitsspektrum der Kristalle stimmt mit keinem bekannten Marsmineral vollständig überein. Bitte sammeln Sie weiter.",
    "Kargo hedefi: <b>{0}</b> birim · güncel durum <b>{1}/{2}</b>. Numuneleri komuta güvertesindeki stok terminalinden yükleyin.":
      "Frachtziel: <b>{0}</b> Einheiten · aktueller Stand <b>{1}/{2}</b>. Laden Sie die Proben über das Lagerterminal auf dem Kommandodeck.",
    "Çürümenin nedeni toprağın yüksek radyasyonu. Ekimden önce radyasyon ölçerle toprağı ölçün.":
      "Die Fäulnis kommt von der hohen Bodenstrahlung. Messt den Boden vor dem Pflanzen mit dem Strahlungsmessgerät.",
    "Çürüyen hasat bildiriminiz biyoloji ekibine iletildi. Çürük patatesi kargo terminalinden bize gönderin, inceleyip sonucu bildirelim.":
      "Eure Meldung über die verfaulte Ernte ging an das Biologieteam. Schickt uns eine verfaulte Kartoffel über das Frachtterminal, dann melden wir uns.",
    "Ekimden önce toprağı ölç: <b>1,0 µSv/h</b> altı güvenli.":
      "Miss den Boden vor dem Pflanzen: unter <b>1,0 µSv/h</b> ist sicher.",
    "Çürük patates örneğini çantanızda tutun.": "Behaltet eine verfaulte Kartoffel als Probe im Gepäck.",
    "Aynı parsele yeniden ekim yapmayın.": "Bepflanzt dieselbe Parzelle nicht erneut.",
    "Tarım verileriniz ({0} ekim, {1} hasat) Biyorejeneratif Yaşam Destek ekibinin en çok beklediği veriler arasında. Mars regolitinde patates yetiştirmek, uzun süreli görevlerin anahtarı.":
      "Ihre Anbaudaten ({0} Aussaaten, {1} Ernten) gehören zu den Daten, auf die das Team für Bioregenerative Lebenserhaltung am meisten gewartet hat. Kartoffelanbau im Marsregolith ist der Schlüssel zu Langzeitmissionen.",
    "Biyoloji ekibi raporunuzdaki ekim/hasat oranını ({0}/{1}) Dünya'daki kontrol deneyiyle karşılaştırıyor. Regolitteki perkloratlara rağmen büyümenin sürmesi çok önemli bir bulgu.":
      "Das Biologieteam vergleicht das Verhältnis von Aussaat zu Ernte in Ihrem Bericht ({0}/{1}) mit dem Kontrollexperiment auf der Erde. Dass das Wachstum trotz der Perchlorate im Regolith anhält, ist ein sehr wichtiger Befund.",
    "Parselleri düzenli sulayın; ıslak toprakta büyüme hızlanır.":
      "Gießen Sie die Beete regelmäßig; auf feuchtem Boden wachsen die Pflanzen schneller.",
    "Her hasattan gelen tohumu yeniden ekerek döngüyü sürdürün.":
      "Halten Sie den Kreislauf in Gang, indem Sie den Samen aus jeder Ernte wieder aussäen.",
    "Uyurken mahsul de 2 kat hızlı büyür; gece ekim yapmayı düşünün.":
      "Im Schlaf wachsen auch die Pflanzen 2× schneller; erwägen Sie, nachts zu säen.",
    "Fırtınadan sonra parselleri kontrol edin.": "Kontrollieren Sie die Beete nach dem Sturm.",
    "Lojistik kayıtları güncellendi. Güncel kargo durumu <b>{0}/{1}</b>. ":
      "Die Logistikdaten wurden aktualisiert. Aktueller Frachtstand <b>{0}/{1}</b>. ",
    "Kargo hedefi tamamlandı; dönüş için yalnızca araç sistemlerinin hazır olması gerekiyor.":
      "Das Frachtziel ist erreicht; für die Rückkehr müssen nur noch die Fahrzeugsysteme bereit sein.",
    "Hedefe ulaşmak için numune toplamaya devam edin.":
      "Sammeln Sie weiter Proben, um das Ziel zu erreichen.",
    "Mürettebat sağlığı birimi raporunuzdaki kritik değerleri ciddiyetle inceledi.":
      "Die Abteilung für Crew-Gesundheit hat die kritischen Werte in Ihrem Bericht ernsthaft geprüft.",
    "Yaşam destek uyarılarınız Uçuş Cerrahı'na öncelikli olarak iletildi.":
      "Ihre Lebenserhaltungswarnungen wurden vorrangig an den Flugarzt weitergeleitet.",
    " Kayda geçen değerler: ": " Erfasste Werte: ",
    "<b>erzak tükenmesi</b>": "<b>Vorräte erschöpft</b>",
    "Giysi oksijeni %30'un altına inince dış görevi sonlandırın; O₂ tüpleri makine dairesinde.":
      "Beenden Sie den Außeneinsatz, wenn der Anzugsauerstoff unter 30 % fällt; die O₂-Tanks befinden sich im Maschinenraum.",
    "Su seviyeniz için mutfaktan şişe alın ve çantanızda yedek taşıyın.":
      "Für Ihren Wasserstand nehmen Sie Flaschen aus der Küche und tragen Sie Reserven in Ihrer Tasche.",
    "Tokluk düştüğünde mutfakta ya da yemek kapsülünde patates tüketin.":
      "Wenn Ihr Sättigungswert sinkt, essen Sie Kartoffeln in der Küche oder an der Nahrungskapsel.",
    "Can değeriniz düşükken revirde medikit kullanın ve dinlenin.":
      "Wenn Ihre Gesundheit niedrig ist, verwenden Sie ein Medkit in der Krankenstation und ruhen Sie sich aus.",
    "Erzak tükendi: önceliğiniz tarım olmalı. Su geri dönüştürücü stoku yavaşça yeniliyor.":
      "Die Vorräte sind erschöpft: Der Anbau muss Ihre Priorität sein. Der Wasser-Recycler füllt den Vorrat langsam wieder auf.",
    "Notunuz ilgili birimlere dağıtıldı. Konuyu daha ayrıntılı açıklarsanız uzman ekiplerimiz size daha net yanıt verebilir.":
      "Ihre Notiz wurde an die zuständigen Abteilungen verteilt. Wenn Sie die Sache ausführlicher schildern, können unsere Fachteams Ihnen klarer antworten.",
    "Notunuzu kayda aldık ve görev günlüğüne işledik. Ekip toplantımızda ele alınacak.":
      "Wir haben Ihre Notiz erfasst und in das Missionsprotokoll eingetragen. Sie wird in unserer Teambesprechung behandelt.",
    "Sorularınızın tümüne yanıt vermeye çalıştık; eksik kalan bir nokta olursa bir sonraki raporunuzda tekrar sorun.":
      "Wir haben versucht, alle Ihre Fragen zu beantworten; falls etwas offen geblieben ist, fragen Sie in Ihrem nächsten Bericht erneut.",
    "Sorunuzu dikkate aldık. Daha fazla ayrıntı için bir sonraki raporunuzda bize koşullarınızı anlatın.":
      "Wir haben Ihre Frage zur Kenntnis genommen. Für mehr Details schildern Sie uns in Ihrem nächsten Bericht Ihre Bedingungen.",
    "<h4>{0}. ✍ Mürettebat notunuz</h4>{1}": "<h4>{0}. ✍ Ihre Crew-Notiz</h4>{1}",
    '<span class="ok">ÇEVRİMİÇİ</span>': '<span class="ok">ONLINE</span>',
    '<span class="bad">DEVRE DIŞI</span> · onarım ': '<span class="bad">AUSSER BETRIEB</span> · Reparatur ',
    "<li>Ana motor: {0}</li>": "<li>Haupttriebwerk: {0}</li>",
    '<span class="bad">· KRİTİK</span>': '<span class="bad">· KRITISCH</span>',
    "<li>Erzak: su {0}, patates {1} {2}</li>": "<li>Vorräte: Wasser {0}, Kartoffeln {1} {2}</li>",
    "<li>O₂ tüpü: %{0} · kargo: {1}/{2}</li>": "<li>O₂-Tank: {0} % · Fracht: {1}/{2}</li>",
    "ACİL önceliğiyle işaretlenen raporunuz alınır alınmaz görev ekibi toplandı ve tüm birimler raporunuzu öncelikli olarak inceledi.":
      "Sobald Ihr als DRINGEND markierter Bericht eintraf, trat das Missionsteam zusammen, und alle Abteilungen haben ihn vorrangig geprüft.",
    "ACİL raporunuz üzerine kontrol odasında olağanüstü vardiya başlatıldı.":
      "Auf Ihren DRINGENDEN Bericht hin wurde im Kontrollraum eine Sonderschicht eingelegt.",
    "Raporunuz ilgili ekiplerimiz tarafından ayrıntılı olarak incelenmiştir.":
      "Ihr Bericht wurde von den zuständigen Teams eingehend geprüft.",
    "Raporunuz tüm birimlere dağıtılmış ve değerlendirilmiştir.":
      "Ihr Bericht wurde an alle Abteilungen verteilt und ausgewertet.",
    "Gönderdiğiniz veriler kontrol odasında ekiplerimiz tarafından tek tek ele alındı.":
      "Die von Ihnen gesendeten Daten wurden von unseren Teams im Kontrollraum Punkt für Punkt behandelt.",
    "Sayın Komutan,": "Sehr geehrter Kommandant,",
    "ARES-1 Komutanına,": "An den Kommandanten von ARES-1,",
    "Değerli Komutanımız,": "Verehrter Kommandant,",
    "Çalışmalarınız için tüm ekip adına teşekkür ederiz. Güvende kalın.":
      "Im Namen des gesamten Teams danken wir Ihnen für Ihre Arbeit. Bleiben Sie in Sicherheit.",
    "Dünya'da hepimiz sizinle gurur duyuyoruz. Bir sonraki raporunuzu bekliyoruz.":
      "Wir alle auf der Erde sind stolz auf Sie. Wir freuen uns auf Ihren nächsten Bericht.",
    "Unutmayın: yalnız değilsiniz, her adımınızı izliyoruz. Bir sonraki raporunuzu bekliyoruz.":
      "Vergessen Sie nicht: Sie sind nicht allein, wir verfolgen jeden Ihrer Schritte. Wir freuen uns auf Ihren nächsten Bericht.",
    '<p>{0}</p>\n  <p><b>Sol {1}</b> tarihli <b>{2}</b> numaralı raporunuz {3} üzerinden <b>{4} MB</b> olarak eksiksiz alınmıştır. {5}</p>\n  {6}\n  <h4>{7}. 📊 Görev durumu değerlendirmesi</h4><ul class="ltr-ul">{8}</ul>\n  <p>Bilim ekibi bu paketi <b>{9} bilim puanı</b> olarak değerlendirdi. Görev bilim hedefinin <b>%{10}</b>\'i tamamlandı.</p>\n  <div class="ltr-sci"><i style="width:{11}%"></i></div>\n  <p>{12}</p>':
      '<p>{0}</p>\n  <p>Ihr Bericht Nr. <b>{2}</b> vom <b>Sol {1}</b> wurde über {3} vollständig mit <b>{4} MB</b> empfangen. {5}</p>\n  {6}\n  <h4>{7}. 📊 Bewertung des Missionsstatus</h4><ul class="ltr-ul">{8}</ul>\n  <p>Das Wissenschaftsteam hat dieses Paket mit <b>{9} Wissenschaftspunkten</b> bewertet. <b>{10} %</b> des wissenschaftlichen Missionsziels sind erreicht.</p>\n  <div class="ltr-sci"><i style="width:{11}%"></i></div>\n  <p>{12}</p>',
    "Yanıt: ": "AW: ",
    "Mürettebat notu": "Crew-Notiz",
    " (Sol ": " (Sol ",
    "EK-A · Önümüzdeki 5 sol tahmini": "ANHANG A · Vorhersage für die nächsten 5 Sols",
    Avustralya: "Australien",
    "Batı Avustralya · Perth'in 140 km kuzeyi": "Westaustralien · 140 km nördlich von Perth",
    İspanya: "Spanien",
    "Ávila · Madrid'in 77 km batısı": "Ávila · 77 km westlich von Madrid",
    "Malargüe (DSA 3)": "Malargüe (DSA 3)",
    Arjantin: "Argentinien",
    "Mendoza · Malargüe'nin 30 km güneyi": "Mendoza · 30 km südlich von Malargüe",
    "ARES Görev Kontrol Merkezi": "ARES-Missionskontrollzentrum",
    "GÖREV YÖNETİMİ": "MISSIONSFÜHRUNG",
    "Uçuş direktörü ve iletişim sorumlusuyla görev takibi":
      "Missionsüberwachung mit Flugdirektor und Kommunikationsverantwortlichem",
    "Raporları inceler, resmî yanıtları ve talimatları yazar":
      "Prüft Berichte und verfasst offizielle Antworten und Anweisungen",
    "Mürettebat sağlığı ve uzay hava durumu değerlendirmesi":
      "Bewertung der Crew-Gesundheit und des Weltraumwetters",
    "Derin Uzay Anten Ağı": "Deep-Space-Antennennetz",
    "Avustralya · İspanya · Arjantin": "Australien · Spanien · Argentinien",
    "Üç 35 m anteni sırayla Mars'a yönlendirir":
      "Richtet die drei 35-m-Antennen nacheinander auf den Mars aus",
    "Her ~8 Mars saatinde bir istasyon devri": "Alle ~8 Marsstunden eine Stationsübergabe",
    "Delta-DOR ile hassas konum ve sinyal kalitesi takibi":
      "Präzise Ortung und Signalqualitätsüberwachung mit Delta-DOR",
    "Kullanıcı segmenti": "Nutzersegment",
    "VERİ ALIMI": "DATENEMPFANG",
    "Gelen telemetri ve bilim paketlerinin işlenmesi":
      "Verarbeitung eingehender Telemetrie- und Wissenschaftspakete",
    "Numune, hava ve radyasyon verilerinin arşivlenmesi":
      "Archivierung von Proben-, Wetter- und Strahlungsdaten",
    "Verilerin bilim ekiplerine dağıtılması": "Verteilung der Daten an die Wissenschaftsteams",
    '<div class="np-crew"><div class="gs-mk sm">ARES</div><div><b>Komutan · ARES-1</b><small>ARES-1/CDR · Mars yüzey görevi</small></div></div>':
      '<div class="np-crew"><div class="gs-mk sm">ARES</div><div><b>Kommandant · ARES-1</b><small>ARES-1/CDR · Mission auf der Marsoberfläche</small></div></div>',
    "⚖️ Kütle": "⚖️ Masse",
    "⚡ Güç": "⚡ Energie",
    "Fırtına: panel üretimi düştü": "Sturm: Paneelleistung gesunken",
    "Güneş panelleri": "Solarpaneele",
    "RTG · sabit güç": "RTG · konstante Leistung",
    "💰 Bütçe": "💰 Budget",
    "💾 Veri": "💾 Daten",
    "Kapasite aşılıyor: bilimin %": "Kapazität überschritten: %",
    "'i kayıp": " der Wissenschaft verloren",
    "📡 İletişim": "📡 Kommunikation",
    "Gönderilen: ": "Gesendet: ",
    " gün transfer": " Tage Transfer",
    '<div class="gs-sec">Tasarım kaynakları · canlı</div>\n    <div class="ar-kv">{0}\n      {1}\n      {2}\n      {3}\n      {4}\n      {5}</div>':
      '<div class="gs-sec">Designressourcen · live</div>\n    <div class="ar-kv">{0}\n      {1}\n      {2}\n      {3}\n      {4}\n      {5}</div>',
    "Fırlatma segmenti": "Startsegment",
    "Görevi uzaya taşıyan fırlatma aracı ve fırlatma hizmetleri.":
      "Trägerrakete und Startdienste, die die Mission ins All bringen.",
    Araç: "Fahrzeug",
    "ARES-1 iniş ve dönüş roketi": "ARES-1 Lande- und Rückkehrrakete",
    Transfer: "Transfer",
    "≈ 214 gün · 225 milyon km": "≈ 214 Tage · 225 Millionen km",
    Varış: "Ankunft",
    "Mars · ekvator ovası": "Mars · Äquatorebene",
    "Uzay segmenti": "Raumsegment",
    "Görevi yürüten araç, alet ve ekipman: roket, kıyafet ve numune sistemleri.":
      "Fahrzeug, Instrumente und Ausrüstung, die die Mission durchführen: Rakete, Anzug und Probensysteme.",
    NOMİNAL: "NOMINAL",
    ARIZA: "AUSFALL",
    Çalışıyor: "In Betrieb",
    "Arızalı · ": "Defekt · ",
    Kıyafet: "Anzug",
    "Yer segmenti": "Bodensegment",
    "İletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları ve görev kontrol merkezleri.":
      "Bodenstationen und Missionskontrollzentren, die für Kommunikation, Datenempfang und Missionsführung zuständig sind.",
    BAĞLI: "VERBUNDEN",
    KESİK: "GETRENNT",
    "Görev kontrol": "Missionskontrolle",
    "Işık gecikmesi": "Lichtlaufzeit",
    "Görev verilerini analiz eden ve kullanan bilim insanları ve diğer kullanıcılar.":
      "Wissenschaftler und andere Nutzer, die die Missionsdaten auswerten und anwenden.",
    "Gönderilen rapor": "Gesendete Berichte",
    "Gönderilen veri": "Gesendete Daten",
    "Bilim hedefi": "Wissenschaftsziel",
    "İlk görev fikri": "Erste Missionsidee",
    "Bilim sorusu: Mars'ta insan yaşamı mümkün mü?":
      "Wissenschaftliche Frage: Ist menschliches Leben auf dem Mars möglich?",
    "Tek kişilik mürettebat ve tek araçla görev mümkün mü?":
      "Ist die Mission mit einer Ein-Personen-Crew und einem einzigen Fahrzeug möglich?",
    "Ödünleşim çalışmaları": "Trade-Studien",
    "Güç, kütle, iletişim ve koruma seçeneklerinin karşılaştırılması":
      "Vergleich der Optionen für Energie, Masse, Kommunikation und Schutz",
    "Nokta tasarım": "Punktentwurf",
    "ARES-1 görev mimarisi": "ARES-1-Missionsarchitektur",
    '<div class="ar-cml now"><em>FAZ E</em><b>Operasyon</b><small>Mars yüzey operasyonları · Sol {0}</small></div>':
      '<div class="ar-cml now"><em>PHASE E</em><b>Betrieb</b><small>Betrieb auf der Marsoberfläche · Sol {0}</small></div>',
    Kavram: "Konzept",
    Fırlatma: "Start",
    "214 gün": "214 Tage",
    "Giriş · İniş": "Eintritt · Landung",
    Yüzey: "Oberfläche",
    Dönüş: "Rückkehr",
    "Rota açık": "Route frei",
    Kilitli: "Gesperrt",
    İtki: "Antrieb",
    "Ana motor çalışıyor": "Haupttriebwerk läuft",
    "Ana motor arızalı": "Haupttriebwerk defekt",
    "Yaşam desteği": "Lebenserhaltung",
    "O₂ tüpü %": "O₂-Tank %",
    " · su ": " · Wasser ",
    " · patates ": " · Kartoffeln ",
    "Isıl ve radyasyon koruması": "Thermal- und Strahlenschutz",
    " · radyasyon hasarı %": " · Strahlungsschaden %",
    Yapı: "Struktur",
    "Fırtına kalkanı ": "Sturmschild ",
    "Seviye ": "Stufe ",
    Yok: "Keiner",
    " · arıza riski %": " · Ausfallrisiko %",
    İletişim: "Kommunikation",
    " · bağlı": " · verbunden",
    "Bağlantı kesik": "Verbindung getrennt",
    "Görev operasyonları": "Missionsbetrieb",
    "Görev ": "Mission ",
    Risk: "Risiko",
    "Sonraki fırtına Sol ": "Nächster Sturm Sol ",
    " · radyasyon Sol ": " · Strahlung Sol ",
    '<div class="gs ar">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>ARES-1 GÖREV MİMARİSİ</b>\n      <p>ARES-1; fırlatma, uzay, yer ve kullanıcı segmentlerinden oluşur. Kavram, olgunluk seviyeleri boyunca fikirden nokta tasarıma geliştirildi. Alt sistemler mühendislik disiplinlerine göre ayrı ayrı izlenir.</p></div></div>\n    <div class="gs-sec">Görev segmentleri</div>\n    <div class="ar-segs">{0}</div>\n    {1}\n    <div class="gs-sec">Görev zaman çizelgesi</div>\n    <div class="ar-tls">{2}</div>\n    <div class="gs-sec">Kavram olgunluğu</div>\n    <div class="ar-cmls">{3}</div>\n    <div class="gs-sec">Alt sistem durumu</div>\n    <div class="ar-subs">{4}</div>\n  </div>':
      '<div class="gs ar">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>ARES-1 MISSIONSARCHITEKTUR</b>\n      <p>ARES-1 besteht aus Start-, Raum-, Boden- und Nutzersegment. Das Konzept wurde über mehrere Reifestufen von der Idee bis zum Punktentwurf entwickelt. Die Teilsysteme werden nach technischen Disziplinen getrennt überwacht.</p></div></div>\n    <div class="gs-sec">Missionssegmente</div>\n    <div class="ar-segs">{0}</div>\n    {1}\n    <div class="gs-sec">Missionszeitplan</div>\n    <div class="ar-tls">{2}</div>\n    <div class="gs-sec">Konzeptreife</div>\n    <div class="ar-cmls">{3}</div>\n    <div class="gs-sec">Teilsystemstatus</div>\n    <div class="ar-subs">{4}</div>\n  </div>',
    '<b class="sat-on">GÖRÜŞ ALANINDA</b>': '<b class="sat-on">IN SICHT</b>',
    '<b class="sat-off">UFUK ALTINDA</b>': '<b class="sat-off">UNTER DEM HORIZONT</b>',
    "Geçiş sürüyor · {0} kaldı": "Überflug läuft · noch {0}",
    "{0} sonra · {1} sürecek": "in {0} · dauert {1}",
    "ufkun altında (": "unter dem Horizont (",
    '<div class="sat">\n    <div class="sat-map">\n      <svg viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">\n        <defs><linearGradient id="satBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a2a1c"/><stop offset=".5" stop-color="#8a3f26"/><stop offset="1" stop-color="#4a2216"/></linearGradient>\n          <radialGradient id="satGl"><stop offset="0" stop-color="#7fe7ff" stop-opacity=".9"/><stop offset="1" stop-color="#7fe7ff" stop-opacity="0"/></radialGradient></defs>\n        <rect width="360" height="180" fill="url(#satBg)"/>\n        <g class="sat-grid">{0}</g>\n        <line x1="0" y1="90" x2="360" y2="90" class="sat-eq"/>\n        <ellipse cx="{1}" cy="{2}" rx="{3}" ry="{4}" class="sat-cov {5}"/>\n        {6}\n        {7}\n        {8}\n        <circle cx="{9}" cy="{10}" r="11" fill="url(#satGl)"/><g transform="translate({11},{12})" class="sat-ic"><rect x="-2.6" y="-2.6" width="5.2" height="5.2" rx="1"/><rect x="-9" y="-1.3" width="5" height="2.6"/><rect x="4" y="-1.3" width="5" height="2.6"/></g>\n      </svg>\n      <div class="sat-legend"><span><i class="lg-site"></i>ARES-1 · {13}</span><span><i class="lg-sat"></i>{14}</span><span><i class="lg-fut"></i>Sonraki tur</span><span><i class="lg-cov"></i>Görüş alanı</span></div>\n    </div>\n    <div class="sat-side">\n      <div class="sat-hd"><div><small>RÖLE UYDUSU</small><b>{15}</b></div>{16}</div>\n      <dl class="sat-dl">\n        <dt>Anlık konum</dt><dd>{17} · {18}</dd>\n        <dt>ARES-1\'e uzaklık</dt><dd>{19} km</dd>\n        <dt>Yükseliş açısı</dt><dd>{20}</dd>\n        <dt>Sonraki geçiş</dt><dd>{21}</dd>\n        <dt>Yörünge</dt><dd>Dairesel · {22} km · eğim {23}°</dd>\n        <dt>Periyot · hız</dt><dd>{24} dk · {25} km/s</dd>\n        <dt>Bağlantılar</dt><dd>UHF 401 MHz (yüzey) · X-bant (Dünya)</dd>\n        <dt>Mars–Dünya</dt><dd>{26} milyon km · {27} dk</dd>\n      </dl>\n    </div>\n  </div>':
      '<div class="sat">\n    <div class="sat-map">\n      <svg viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">\n        <defs><linearGradient id="satBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a2a1c"/><stop offset=".5" stop-color="#8a3f26"/><stop offset="1" stop-color="#4a2216"/></linearGradient>\n          <radialGradient id="satGl"><stop offset="0" stop-color="#7fe7ff" stop-opacity=".9"/><stop offset="1" stop-color="#7fe7ff" stop-opacity="0"/></radialGradient></defs>\n        <rect width="360" height="180" fill="url(#satBg)"/>\n        <g class="sat-grid">{0}</g>\n        <line x1="0" y1="90" x2="360" y2="90" class="sat-eq"/>\n        <ellipse cx="{1}" cy="{2}" rx="{3}" ry="{4}" class="sat-cov {5}"/>\n        {6}\n        {7}\n        {8}\n        <circle cx="{9}" cy="{10}" r="11" fill="url(#satGl)"/><g transform="translate({11},{12})" class="sat-ic"><rect x="-2.6" y="-2.6" width="5.2" height="5.2" rx="1"/><rect x="-9" y="-1.3" width="5" height="2.6"/><rect x="4" y="-1.3" width="5" height="2.6"/></g>\n      </svg>\n      <div class="sat-legend"><span><i class="lg-site"></i>ARES-1 · {13}</span><span><i class="lg-sat"></i>{14}</span><span><i class="lg-fut"></i>Nächster Umlauf</span><span><i class="lg-cov"></i>Sichtbereich</span></div>\n    </div>\n    <div class="sat-side">\n      <div class="sat-hd"><div><small>RELAISSATELLIT</small><b>{15}</b></div>{16}</div>\n      <dl class="sat-dl">\n        <dt>Position</dt><dd>{17} · {18}</dd>\n        <dt>Abstand zu ARES-1</dt><dd>{19} km</dd>\n        <dt>Elevation</dt><dd>{20}</dd>\n        <dt>Nächster Überflug</dt><dd>{21}</dd>\n        <dt>Umlaufbahn</dt><dd>Kreisförmig · {22} km · Inkl. {23}°</dd>\n        <dt>Periode · Tempo</dt><dd>{24} Min. · {25} km/s</dd>\n        <dt>Verbindungen</dt><dd>UHF 401 MHz (Oberfläche) · X-Band (Erde)</dd>\n        <dt>Mars–Erde</dt><dd>{26} Mio. km · {27} Min.</dd>\n      </dl>\n    </div>\n  </div>',
    '<span class="st on">● MARS\'I İZLİYOR</span>': '<span class="st on">● VERFOLGT MARS</span>',
    '<span class="st err">● SİNYAL YOK</span>': '<span class="st err">● KEIN SIGNAL</span>',
    '<span class="st">BEKLEMEDE</span>': '<span class="st">BEREITSCHAFT</span>',
    "<dt>Mars yükseliş açısı</dt><dd>{0}°</dd><dt>Veri hızı</dt><dd>{1}</dd>":
      "<dt>Mars-Elevation</dt><dd>{0}°</dd><dt>Datenrate</dt><dd>{1}</dd>",
    '<div class="gs-card gs-st {0}">{1}<h5>{2}</h5><div class="loc">📍 {3} · {4}</div>\n      <dl class="gs-dl"><dt>Enlem</dt><dd>{5}</dd><dt>Boylam</dt><dd>{6}</dd><dt>Rakım</dt><dd>{7}</dd><dt>Çanak anten</dt><dd>{8} · ışın kılavuzlu</dd>\n      <dt>Gönderme</dt><dd>{9} bant</dd><dt>Alma</dt><dd>{10} bant</dd><dt>Hizmete giriş</dt><dd>{11}</dd>\n      {12}</dl></div>':
      '<div class="gs-card gs-st {0}">{1}<h5>{2}</h5><div class="loc">📍 {3} · {4}</div>\n      <dl class="gs-dl"><dt>Breite</dt><dd>{5}</dd><dt>Länge</dt><dd>{6}</dd><dt>Höhe</dt><dd>{7}</dd><dt>Parabolantenne</dt><dd>{8} · Strahlwellenleiter</dd>\n      <dt>Uplink</dt><dd>{9} Band</dd><dt>Downlink</dt><dd>{10} Band</dd><dt>In Betrieb seit</dt><dd>{11}</dd>\n      {12}</dl></div>',
    "Mars yüzeyi · yüksek kazançlı anten": "Marsoberfläche · Richtantenne",
    "X-bant": "X-Band",
    "İstasyon ağı": "Stationsnetz",
    "İletişim operasyonu": "Kommunikationsbetrieb",
    "Görev Kontrol": "Missionskontrolle",
    "Görev yönetimi": "Missionsführung",
    "Bilim ekipleri": "Wissenschaftsteams",
    AKTİF: "AKTIV",
    '<div class="gs">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>YER BİRİMİ · ARES-1</b>\n      <p>Yer birimi; iletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları ve görev kontrol merkezlerinden oluşur. ARES-1, boylamda yaklaşık 120° aralıklı üç gerçek 35 m derin uzay anteniyle (New Norcia, Cebreros, Malargüe) Dünya döndükçe kesintisiz izlenir.</p></div></div>\n    <div class="gs-sec">Veri yolu</div>\n    <div class="gs-path">\n      {0}{1}\n      {2}{3}\n      {4}{5}\n      {6}{7}\n      {8}\n    </div>\n    <div class="gs-sec">Röle uydusu · konum ve yörünge</div>\n    {9}\n    <div class="gs-kv">\n      <div><span>Bağlantı</span><b style="color:{10}">{11}</b></div>\n      <div><span>Işık gecikmesi</span><b>{12} dk</b></div>\n      <div><span>Gönderilen veri</span><b>{13} MB</b></div>\n      <div><span>Alınan mesaj</span><b>{14}</b></div></div>\n    <div class="gs-sec">Yer istasyonları</div>\n    <div class="gs-grid">{15}</div>\n    <div class="gs-kv" style="grid-template-columns:repeat(3,1fr)">\n      <div><span>Aktif istasyon</span><b>{16}</b></div>\n      <div><span>Sonraki devir</span><b>{17} · {18}</b></div>\n      <div><span>Veri kapasitesi</span><b>{19} MB/sol</b></div></div>\n    <div class="gs-sec">Görev kontrol merkezleri</div>\n    <div class="gs-grid">{20}</div>\n  </div>':
      '<div class="gs">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>BODENSEGMENT · ARES-1</b>\n      <p>Das Bodensegment besteht aus den Bodenstationen und Missionskontrollzentren, die für Kommunikation, Datenempfang und Missionsführung zuständig sind. ARES-1 wird von drei echten 35-m-Deep-Space-Antennen, die in der Länge etwa 120° auseinanderliegen (New Norcia, Cebreros, Malargüe), ohne Unterbrechung verfolgt, während sich die Erde dreht.</p></div></div>\n    <div class="gs-sec">Datenweg</div>\n    <div class="gs-path">\n      {0}{1}\n      {2}{3}\n      {4}{5}\n      {6}{7}\n      {8}\n    </div>\n    <div class="gs-sec">Relaissatellit · Position und Umlaufbahn</div>\n    {9}\n    <div class="gs-kv">\n      <div><span>Verbindung</span><b style="color:{10}">{11}</b></div>\n      <div><span>Lichtlaufzeit</span><b>{12} Min.</b></div>\n      <div><span>Gesendete Daten</span><b>{13} MB</b></div>\n      <div><span>Empfangene Nachrichten</span><b>{14}</b></div></div>\n    <div class="gs-sec">Bodenstationen</div>\n    <div class="gs-grid">{15}</div>\n    <div class="gs-kv" style="grid-template-columns:repeat(3,1fr)">\n      <div><span>Aktive Station</span><b>{16}</b></div>\n      <div><span>Nächste Übergabe</span><b>{17} · {18}</b></div>\n      <div><span>Datenkapazität</span><b>{19} MB/sol</b></div></div>\n    <div class="gs-sec">Missionskontrollzentren</div>\n    <div class="gs-grid">{20}</div>\n  </div>',
    "YEREL AĞ": "LOKALES NETZ",
    "RÖLE UYDUSU": "RELAISSATELLIT",
    "ANTEN TOZLA KAPALI": "ANTENNE DURCH STAUB BLOCKIERT",
    "PARAZİT · ": "STÖRUNG · ",
    "Gönderilecek bir şey yok — gözlem seç ya da not yaz":
      "Nichts zu senden — wähle eine Beobachtung oder schreib eine Notiz",
    "📡 Toz fırtınası yüksek kazançlı anteni kör ediyor — fırtına geçince gönder":
      "📡 Der Staubsturm blendet die Richtantenne — sende, wenn der Sturm vorbei ist",
    "Notun GDY-1'e iletildi — yanıt ~": "Deine Notiz ging an GDY-1 — die Antwort ist in ~",
    " içinde gelen kutunda": " in deinem Posteingang",
    "</b> Dünya'ya iletildi · yanıt beklenen: <b>": "</b> zur Erde gesendet · erwartete Antwort: <b>",
    "📥 Gelen kutusu": "📥 Posteingang",
    "📝 Rapor hazırla": "📝 Bericht erstellen",
    "📤 Gönderilenler": "📤 Gesendet",
    "📡 Dünya'ya gönder": "📡 Zur Erde senden",
    "📡 Anten kapalı — fırtına bekleniyor": "📡 Antenne blockiert — warte auf das Ende des Sturms",
    '<span class="mut">Raporda henüz içerik yok.</span>':
      '<span class="mut">Der Bericht hat noch keinen Inhalt.</span>',
    " + not": " + Notiz",
    "<div><span>İçerik</span><b>{0} gözlem{1}</b></div>\n    <div><span>Paket</span><b>{2} MB</b></div>\n    <div><span>Işık gecikmesi</span><b>~{3} dk</b></div>\n    <div><span>Tahmini yanıt</span><b>Sol {4} civarı</b></div>":
      "<div><span>Inhalt</span><b>{0} Beobachtungen{1}</b></div>\n    <div><span>Paket</span><b>{2} MB</b></div>\n    <div><span>Lichtlaufzeit</span><b>~{3} Min.</b></div>\n    <div><span>Erwartete Antwort</span><b>um Sol {4}</b></div>",
    "Yüksek kazançlı anten Dünya'ya hizalanıyor…": "Die Richtantenne wird auf die Erde ausgerichtet …",
    "Paket sıkıştırılıyor ve AES-256 ile şifreleniyor…":
      "Paket wird komprimiert und mit AES-256 verschlüsselt …",
    " gözlem kaydı + ": " Beobachtungseinträge + ",
    "mürettebat notu": "Crew-Notiz",
    "not yok": "keine Notiz",
    " paketlendi": " verpackt",
    "X-bandı iletim · ": "X-Band-Übertragung · ",
    "İletim tamamlandı · ışık gecikmesi ~": "Übertragung abgeschlossen · Lichtlaufzeit ~",
    '<div class="cm-empty">📭 Saha günlüğünde gönderilmemiş kayıt yok.<br><small>Fırtına, radyasyon, meteor, arıza, numune toplama, tarım ve kritik yaşam değerleri burada otomatik kaydedilir.</small></div>':
      '<div class="cm-empty">📭 Im Feldprotokoll gibt es keine ungesendeten Einträge.<br><small>Stürme, Strahlung, Meteoriten, Ausfälle, Probensammlung, Anbau und kritische Lebenswerte werden hier automatisch erfasst.</small></div>',
    "Patatesler çürüdü, neden olabilir?": "Die Kartoffeln sind verfault, was könnte die Ursache sein?",
    "Motordan duman geliyor, ne yapmalıyım?": "Aus dem Triebwerk kommt Rauch, was soll ich tun?",
    "Erzak azalıyor": "Die Vorräte werden knapp",
    "Fırtınada roket çok sarsıldı": "Die Rakete wurde im Sturm stark durchgeschüttelt",
    "Radyasyon sırasında dışarıda kaldım": "Ich war während der Strahlung draußen",
    "Kendimi yalnız hissediyorum": "Ich fühle mich einsam",
    "Ne zaman Dünya'ya dönebilirim?": "Wann kann ich zur Erde zurückkehren?",
    '<div class="cm-cols">\n      <div class="cm-col"><div class="con-sec">Saha günlüğü · {0} kayıt</div><div class="cm-obs">{1}</div></div>\n      <div class="cm-col"><div class="con-sec">Mürettebat notu</div>\n        <textarea id="cmNote" maxlength="500" placeholder="Yaşadığın sorunları, gözlemlerini ya da sorularını yaz…">{2}</textarea>\n        <div class="cm-quick">{3}</div>\n        <div class="con-sec">Öncelik</div>\n        <div class="cm-prio"><button data-p="rutin" class="{4}">RUTİN<small>yanıt ≈ ½ sol</small></button><button data-p="acil" class="acil {5}">ACİL<small>yanıt ≈ ¼ sol</small></button></div>\n        <div class="cm-sum" id="cmSum"></div>\n        <button class="cbtn pri wide" id="cmSend">📡 Dünya\'ya gönder</button></div></div>':
      '<div class="cm-cols">\n      <div class="cm-col"><div class="con-sec">Feldprotokoll · {0} Einträge</div><div class="cm-obs">{1}</div></div>\n      <div class="cm-col"><div class="con-sec">Crew-Notiz</div>\n        <textarea id="cmNote" maxlength="500" placeholder="Schreib über deine Probleme, Beobachtungen oder Fragen …">{2}</textarea>\n        <div class="cm-quick">{3}</div>\n        <div class="con-sec">Priorität</div>\n        <div class="cm-prio"><button data-p="rutin" class="{4}">ROUTINE<small>Antwort ≈ ½ Sol</small></button><button data-p="acil" class="acil {5}">DRINGEND<small>Antwort ≈ ¼ Sol</small></button></div>\n        <div class="cm-sum" id="cmSum"></div>\n        <button class="cbtn pri wide" id="cmSend">📡 Zur Erde senden</button></div></div>',
    YANIT: "ANTWORT",
    BÜLTEN: "BULLETIN",
    UYARI: "WARNUNG",
    BRİFİNG: "BRIEFING",
    TALEP: "ANFRAGE",
    ANALİZ: "ANALYSE",
    "YZ YANITI": "KI-ANTWORT",
    MESAJ: "NACHRICHT",
    ACİL: "DRINGEND",
    '<div class="cm-empty">📭 Gelen kutusu boş.<br><small>Görev Kontrol\'ün brifingleri, bültenleri ve raporlarına verdiği yanıtlar burada görünür.</small></div>':
      '<div class="cm-empty">📭 Der Posteingang ist leer.<br><small>Briefings, Bulletins und Antworten der Missionskontrolle auf deine Berichte erscheinen hier.</small></div>',
    Gönderildi: "Gesendet",
    "Dünya'ya ulaştı": "Erde erreicht",
    İnceleniyor: "Wird geprüft",
    "Yanıt geldi": "Antwort eingegangen",
    '<span class="badge err">ACİL</span>': '<span class="badge err">DRINGEND</span>',
    '<span class="badge mute">RUTİN</span>': '<span class="badge mute">ROUTINE</span>',
    "📨 Yanıt gelen kutunda": "📨 Antwort in deinem Posteingang",
    "⏳ Yanıt bekleniyor · <b>{0}</b> civarı · kalan ~{1} (oyun saati)":
      "⏳ Antwort ausstehend · etwa <b>{0}</b> · noch ~{1} (Spielzeit)",
    '<div class="cm-empty">📤 Henüz rapor göndermedin.<br><small>“Rapor hazırla” sekmesinden saha günlüğünü ve notunu Dünya\'ya ilet.</small></div>':
      '<div class="cm-empty">📤 Du hast noch keinen Bericht gesendet.<br><small>Sende dein Feldprotokoll und deine Notiz über den Reiter „Bericht erstellen“ zur Erde.</small></div>',
    '<span class="ci">📨</span><div><b>Dünya\'dan {0} yeni mesaj</b><small>Komuta güvertesi · iletişim terminali</small></div>':
      '<span class="ci">📨</span><div><b>{0} neue Nachricht(en) von der Erde</b><small>Kommandodeck · Kommunikationsterminal</small></div>',
    '<span class="ci">📡</span><div><b>Yanıt bekleniyor</b><small>{0} civarı</small></div>':
      '<span class="ci">📡</span><div><b>Antwort ausstehend</b><small>etwa {0}</small></div>',
    '<span class="ci">📝</span><div><b>{0} gözlem rapor bekliyor</b><small>İletişim terminalinden gönder</small></div>':
      '<span class="ci">📝</span><div><b>{0} Beobachtung(en) warten auf einen Bericht</b><small>Über das Kommunikationsterminal senden</small></div>',
    "İnsanlık binlerce yıldır gece gökyüzündeki o kızıl noktaya baktı.":
      "Seit Jahrtausenden blickt die Menschheit zu diesem roten Punkt am Nachthimmel hinauf.",
    "Şimdi, ilk kez bir insan oraya gidiyor.": "Jetzt fliegt zum ersten Mal ein Mensch dorthin.",
    "Tek başına.": "Allein.",
    "UÇUŞ DİREKTÖRÜ · GÖREV KONTROL": "FLUGDIREKTOR · MISSIONSKONTROLLE",
    "ARES-1 görevi onaylandı. Mürettebat: tek kişi. Komutan sensin.":
      "Die Mission ARES-1 ist genehmigt. Crew: eine Person. Du bist der Kommandant.",
    "Görevin: Mars'a in, oradaki yaşam koşullarını incele ve her bulguyu Dünya'ya aktar.":
      "Deine Aufgabe: auf dem Mars landen, die Lebensbedingungen dort untersuchen und jede Erkenntnis zur Erde übermitteln.",
    "Orada yalnız olacaksın. Ama biz seni her an dinliyor olacağız.":
      "Dort draußen wirst du allein sein. Aber wir hören dir jeden Augenblick zu.",
    "YER İSTASYONU AĞI": "BODENSTATIONSNETZ",
    "A, B ve C istasyonları hazır. Yolculuk boyunca üç istasyon seni sırayla izleyecek.":
      "Die Stationen A, B und C sind bereit. Während der Reise verfolgen dich die drei Stationen abwechselnd.",
    "KALKIŞ KONTROL": "STARTKONTROLLE",
    "Tüm sistemler hazır. Geri sayım başladı.": "Alle Systeme bereit. Der Countdown läuft.",
    "GÖREV KONTROL": "MISSIONSKONTROLLE",
    "Kalkış! ARES-1 kuleden ayrıldı.": "Abheben! ARES-1 hat den Turm verlassen.",
    "Yörüngeye giriş nominal. Mars yolu açık. İyi yolculuklar, Komutan.":
      "Einschuss in die Umlaufbahn nominal. Der Weg zum Mars ist frei. Gute Reise, Kommandant.",
    "KOMUTANIN GÜNLÜĞÜ": "LOGBUCH DES KOMMANDANTEN",
    "Gün 12 — Dünya artık başparmağımın arkasına sığıyor.":
      "Tag 12 — Die Erde passt jetzt hinter meinen Daumen.",
    "Gün 97 — Buradaki tek ses, Görev Kontrol'den gelen cızırtılı mesajlar.":
      "Tag 97 — Das einzige Geräusch hier sind die knisternden Nachrichten der Missionskontrolle.",
    "Gün 211 — Kızıl gezegen pencereyi dolduruyor. Neredeyse geldim.":
      "Tag 211 — Der rote Planet füllt das Fenster aus. Ich bin fast da.",
    "ARES-1, atmosfere girişe hazırlan. Isı kalkanı devrede.":
      "ARES-1, bereit machen für den Atmosphäreneintritt. Hitzeschild aktiviert.",
    "Isı kalkanı 1.600 °C… sinyal… kesil—": "Hitzeschild bei 1.600 °C … Signal … bricht ab—",
    "Retro motorlar ateşlendi… 40 metre… 20… 10…": "Bremstriebwerke gezündet … 40 Meter … 20 … 10 …",
    "ARES-1, burası Görev Kontrol. A istasyonu sinyalini aldı, inişini doğruluyoruz. Mars'a hoş geldin, Komutan.":
      "ARES-1, hier Missionskontrolle. Station A hat dein Signal, wir bestätigen deine Landung. Willkommen auf dem Mars, Kommandant.",
    "GÖREV DOSYASI": "MISSIONSAKTE",
    KALKIŞ: "START",
    "YOLCULUK · 214 GÜN": "REISE · 214 TAGE",
    "ARES-1, Dünya'ya dönüş penceresi açık. Kalkış için onay verildi.":
      "ARES-1, das Rückkehrfenster zur Erde ist offen. Start freigegeben.",
    "Motorlar ateşlendi… Mars, her şey için teşekkürler.": "Triebwerke gezündet… Mars, danke für alles.",
    "Kalkış başarılı. Hoşça kal, Kızıl Gezegen.": "Start erfolgreich. Leb wohl, Roter Planet.",
    "ARES-R1 · RÖLE UYDUSU": "ARES-R1 · RELAISSATELLIT",
    "Son bağlantı: yüzey verilerinin tamamı aktarıldı. İyi yolculuklar, ARES-1.":
      "Letzter Kontakt: Alle Oberflächendaten wurden übertragen. Gute Reise, ARES-1.",
    "Dünya'ya transfer ateşlemesi tamamlandı. Yeni rota: ev.":
      "Transferzündung zur Erde abgeschlossen. Neuer Kurs: nach Hause.",
    "Dönüş günü {0} — Mars arkamda küçülüyor. Kargo bölmesinde {1} numune var.":
      "Rückflugtag {0} — Der Mars wird hinter mir kleiner. Im Frachtraum liegen {1} Proben.",
    "Dönüş günü {0} — Ekip her mesajımda Mars'ta öğrendiklerimizi soruyor.":
      "Rückflugtag {0} — In jeder Nachricht fragt das Team, was wir auf dem Mars gelernt haben.",
    "Dönüş günü {0} — Pencerede mavi bir nokta büyüyor. Evim.":
      "Rückflugtag {0} — Im Fenster wächst ein blauer Punkt. Mein Zuhause.",
    "ARES-1, Ay'ın yörüngesini geçtin. Kapsül ayrılmasına hazırlan.":
      "ARES-1, du hast die Mondbahn passiert. Bereite die Kapseltrennung vor.",
    "Kapsül ayrıldı. Isı kalkanı Dünya'ya dönük.": "Kapsel getrennt. Hitzeschild zur Erde gerichtet.",
    "Atmosfere giriş. Hız saniyede 11 kilometre. İletişim kesintisi bekleniyor.":
      "Atmosphäreneintritt. Geschwindigkeit 11 Kilometer pro Sekunde. Funkausfall erwartet.",
    "Pencerenin dışı alev alev… dayan…": "Draußen vor dem Fenster nur Flammen… durchhalten…",
    "KURTARMA EKİBİ": "BERGUNGSTEAM",
    "Sinyal geri geldi! Paraşütler açıldı, üçü de sağlam.":
      "Signal ist zurück! Fallschirme offen, alle drei intakt.",
    "Kapsülü görüyoruz. Okyanusa iniş için hazırlan.":
      "Wir sehen die Kapsel. Bereite dich auf die Wasserung vor.",
    "ARES-1, suya iniş doğrulandı. Kurtarma gemisi yolda.":
      "ARES-1, Wasserung bestätigt. Das Bergungsschiff ist unterwegs.",
    "Mars'ta {0} sol geçirdin. Dünya'ya hoş geldin, Komutan.":
      "Du hast {0} Sols auf dem Mars verbracht. Willkommen zurück auf der Erde, Kommandant.",
    "MARS · KALKIŞ": "MARS · START",
    "MARS YÖRÜNGESİ": "MARSUMLAUFBAHN",
    "EVE DÖNÜŞ · {0} GÜN": "HEIMREISE · {0} TAGE",
    "ATMOSFERE GİRİŞ": "ATMOSPHÄRENEINTRITT",
    "OKYANUSA İNİŞ": "WASSERUNG",
    EVRE: "PHASE",
    "GERİ SAYIM": "COUNTDOWN",
    "MARS KALKIŞI": "MARSSTART",
    İRTİFA: "HÖHE",
    İTKİ: "SCHUB",
    "DÜNYA'YA TRANSFER ATEŞLEMESİ": "TRANSFERZÜNDUNG ERDE",
    "TRANSFER YÖRÜNGESİ": "TRANSFERBAHN",
    HIZ: "GESCHWINDIGKEIT",
    "DÖNÜŞ GÜNÜ": "RÜCKFLUGTAG",
    "DÜNYA'YA UZAKLIK": "ENTFERNUNG ZUR ERDE",
    " milyon km": " Mio. km",
    "SİNYAL GECİKMESİ": "SIGNALVERZÖGERUNG",
    KARGO: "FRACHT",
    " numune": " Proben",
    "YER İSTASYONU": "BODENSTATION",
    "KAPSÜL AYRILDI": "KAPSEL GETRENNT",
    "DÜNYA YAKLAŞMASI": "ERDANFLUG",
    "ISI KALKANI": "HITZESCHILD",
    SİNYAL: "SIGNAL",
    YOK: "KEINES",
    "PARAŞÜTLER AÇIK": "FALLSCHIRME OFFEN",
    "İNİŞ HIZI": "SINKRATE",
    "SUYA İNİŞ": "WASSERUNG",
    KONUM: "POSITION",
    "Pasifik Okyanusu": "Pazifischer Ozean",
    KURTARMA: "BERGUNG",
    YOLDA: "UNTERWEGS",
    "KAPSÜLE YAKLAŞIYOR": "NÄHERT SICH DER KAPSEL",
    "GÖREV TAMAMLANDI": "MISSION ABGESCHLOSSEN",
    "Mars'ta {0} sol · {1} numune · bilim hedefi %{2}":
      "{0} Sols auf dem Mars · {1} Proben · Wissenschaftsziel {2} %",
    "225 milyon km": "225 Millionen km",
    "ARES PROGRAMI": "ARES-PROGRAMM",
    "ARES-1 · GÖREV PROFİLİ": "ARES-1 · MISSIONSPROFIL",
    "TRANSFER YÖRÜNGESİ · 214 GÜN": "TRANSFERBAHN · 214 TAGE",
    "MÜRETTEBAT: 1": "CREW: 1",
    "● GÖREV ONAYLANDI": "● MISSION GENEHMIGT",
    "ARES PROGRAMI — GÖREV DOSYASI": "ARES-PROGRAMM — MISSIONSAKTE",
    "GİZLİLİK: ÜST DÜZEY": "GEHEIMHALTUNG: HÖCHSTE STUFE",
    "KOMUTAN — SEN": "KOMMANDANT — DU",
    "KİMLİK ARES-1/CDR": "KENNUNG ARES-1/CDR",
    GÖREV: "MISSION",
    "ARES-1 · Mars yüzey keşfi": "ARES-1 · Erkundung der Marsoberfläche",
    MÜRETTEBAT: "CREW",
    "1 kişi — Komutan (sen)": "1 Person — Kommandant (du)",
    ARAÇ: "FAHRZEUG",
    "ARES-1 iniş ve dönüş roketi · 3 güverte": "ARES-1 Lande- und Rückkehrrakete · 3 Decks",
    YOLCULUK: "REISE",
    HEDEF: "ZIEL",
    "YER BİRİMİ": "BODENSEGMENT",
    "Görev Kontrol · 3 yer istasyonu": "Missionskontrolle · 3 Bodenstationen",
    "Atmosferi, toprağı ve radyasyonu ölç, verileri topla":
      "Atmosphäre, Boden und Strahlung messen und Daten sammeln",
    "Su, oksijen ve tarımla yaşam koşullarını test et":
      "Lebensbedingungen mit Wasser, Sauerstoff und Anbau testen",
    "Fırtına, radyasyon ve meteor gibi tehlikeleri raporla":
      "Gefahren wie Stürme, Strahlung und Meteoriten melden",
    "Tüm bulguları iletişim terminalinden Dünya'ya aktar":
      "Alle Erkenntnisse über das Kommunikationsterminal zur Erde übermitteln",
    "GÖREV AMAÇLARI": "MISSIONSZIELE",
    ONAYLANDI: "GENEHMIGT",
    KALKIŞA: "BIS ZUM START",
    YAKIT: "TREIBSTOFF",
    RÜZGÂR: "WIND",
    "6 km/sa": "6 km/h",
    DURUM: "STATUS",
    HAZIR: "BEREIT",
    YÜKSELİŞ: "AUFSTIEG",
    "KADEME AYRILMASI": "STUFENTRENNUNG",
    YÖRÜNGE: "UMLAUFBAHN",
    "GÖREV GÜNÜ": "MISSIONSTAG",
    "GÜÇLÜ İNİŞ": "ANGETRIEBENER ABSTIEG",
    "DİKEY HIZ": "SINKRATE",
    TEMAS: "BODENKONTAKT",
    İNİŞ: "LANDUNG",
    BAŞARILI: "ERFOLGREICH",
    "İSTASYON A · ALINDI": "STATION A · EMPFANGEN",
    '<span><i class="dot"></i>CANLI</span><span>MARS YEREL <b>{0}:{1}</b></span><span>SICAKLIK <b>{2} °C</b></span><span>RÜZGÂR <b>{3} km/sa</b></span><span>BASINÇ <b>6,1 mbar</b></span><span>IŞIK GECİKMESİ <b>{4} dk</b></span>':
      '<span><i class="dot"></i>LIVE</span><span>MARS-ORTSZEIT <b>{0}:{1}</b></span><span>TEMPERATUR <b>{2} °C</b></span><span>WIND <b>{3} km/h</b></span><span>DRUCK <b>6,1 mbar</b></span><span>LICHTLAUFZEIT <b>{4} Min.</b></span>',
    "Görev başlıyor: Mars'ı incele, hayatta kal ve her şeyi Dünya'ya aktar.":
      "Die Mission beginnt: Erkunde den Mars, überlebe und übermittle alles zur Erde.",
    "ARES Standart": "ARES Standard",
    BAŞLANGIÇ: "START",
    Dengeli: "Ausgewogen",
    "Görevin standart EVA giysisi. Beyaz çok katmanlı kumaş, temel yaşam desteği. Kısa dış görevler için yeterli, uzun maruziyette yetersiz.":
      "Der Standard-EVA-Anzug der Mission. Weißes mehrlagiges Gewebe, grundlegende Lebenserhaltung. Ausreichend für kurze Außeneinsätze, ungenügend bei langer Exposition.",
    "Kaşif Mk-I": "Entdecker Mk-I",
    "Hafif · Çevik": "Leicht · Wendig",
    "Kum rengi hafif kompozit dış katman ve geliştirilmiş CO₂ geri dönüştürücü. Uzun yürüyüşlerde daha az oksijen harcar, daha çevik hareket eder.":
      "Leichte sandfarbene Verbund-Außenschicht und ein verbesserter CO₂-Recycler. Verbraucht auf langen Wegen weniger Sauerstoff und bewegt sich wendiger.",
    "Ağırlıklı botlar": "Beschwerte Stiefel",
    "Öncü Mk-II": "Pionier Mk-II",
    "Karbon · Işık şeritli": "Carbon · Leuchtstreifen",
    "Karbon-grafit gövde, ışık şeritli eklemler ve toz contalı bağlantılar. Fırtınada rüzgâra karşı daha sağlam, radyasyona karşı ara katmanlı.":
      "Karbon-Graphit-Körper, Gelenke mit Leuchtstreifen und staubdichte Verbindungen. Stabiler gegen den Wind im Sturm, mit Zwischenschicht gegen Strahlung.",
    "Manyetik botlar": "Magnetstiefel",
    "Kalkan Mk-III": "Schild Mk-III",
    "Zırhlı · Radyasyon kalkanı": "Gepanzert · Strahlenschild",
    "Kurşun katkılı zırh plakaları, manyetik radyasyon kalkanı ve güçlendirilmiş motor destekli eklemler. Radyasyon dalgasında çok daha uzun dayanır.":
      "Bleiversetzte Panzerplatten, ein magnetischer Strahlenschild und verstärkte motorunterstützte Gelenke. Hält in einer Strahlungswelle viel länger durch.",
    "Jiroskop dengeleyici": "Gyrostabilisator",
    "Prototip · Altın vizör": "Prototyp · Goldvisier",
    "Görev Kontrol'ün gizli prototipi. Altın kaplı vizör, plazma çekirdekli yaşam desteği, tam fırtına zırhı ve güçlendirilmiş dış iskelet.":
      "Der geheime Prototyp der Missionskontrolle. Vergoldetes Visier, Lebenserhaltung mit Plasmakern, vollständige Sturmpanzerung und ein verstärktes Exoskelett.",
    "Aktif yerçekimi dengeleyici": "Aktiver Schwerkraftstabilisator",
    "Klasik ARES": "Klassisch ARES",
    "Beyaz gövde, turuncu burun — görevin orijinal boyası.":
      "Weißer Rumpf, orange Spitze — die Originallackierung der Mission.",
    "Kutup Mavisi": "Polarblau",
    "Buz beyazı gövde, lacivert burun, camgöbeği kanatlar ve ince hız şeritleri.":
      "Eisweißer Rumpf, marineblaue Spitze, cyanfarbene Finnen und schmale Rennstreifen.",
    "Mars Kamuflajı": "Mars-Tarnung",
    "Pas ve kum tonlarında desen, zeytin yeşili kanatlar. Mars'ta neredeyse görünmez.":
      "Muster in Rost- und Sandtönen, olivgrüne Finnen. Auf dem Mars fast unsichtbar.",
    "Gece Kuzgunu": "Nachtrabe",
    "Mat siyah gövde, kızıl burun ve kanatlar, parlayan kırmızı çizgiler.":
      "Mattschwarzer Rumpf, karminrote Spitze und Finnen, leuchtend rote Linien.",
    "Altın Çağ": "Goldenes Zeitalter",
    "Krom-altın kaplama, siyah burun ve şeritler, güneşte parıldayan yansımalar.":
      "Chrom-Gold-Beschichtung, schwarze Spitze und Streifen, Reflexe, die in der Sonne glitzern.",
    "Titanyum Plakalar": "Titanplatten",
    "Alt gövdeye perçinli titanyum plakalar. Fırtınada motor arızası olasılığı %60 → %35.":
      "Auf den unteren Rumpf genietete Titanplatten. Wahrscheinlichkeit eines Triebwerksausfalls im Sturm 60 % → 35 %.",
    "Kanat & Burun Zırhı": "Finnen- & Nasenpanzerung",
    "Kanat kenar koruyucuları ve güçlendirilmiş burun başlığı. Arıza olasılığı %15'e iner, gövde daha az sarsılır.":
      "Kantenschutz für die Finnen und eine verstärkte Nasenkappe. Die Ausfallwahrscheinlichkeit sinkt auf 15 %, der Rumpf wird weniger erschüttert.",
    "Deflektör Kalkanı": "Deflektorschild",
    "Manyetik toz deflektörü roketi enerji kalkanıyla sarar. Fırtına artık motoru bozamaz.":
      "Ein magnetischer Staubdeflektor hüllt die Rakete in einen Energieschild. Stürme können das Triebwerk nicht mehr beschädigen.",
    ATÖLYE: "WERKSTATT",
    "Oksijen tüketimi": "Sauerstoffverbrauch",
    " daha az": " weniger",
    "Yürüme hızı": "Gehgeschwindigkeit",
    "Radyasyon koruması": "Strahlenschutz",
    " daha az hasar": " weniger Schaden",
    "Fırtına direnci": "Sturmresistenz",
    " daha az etki": " weniger Wirkung",
    "Yerçekimi dengesi": "Schwerkraftbalance",
    " daha az sekme": " weniger Springen",
    standart: "Standard",
    '<span class="ug-cost ok">Ücretsiz</span>': '<span class="ug-cost ok">Kostenlos</span>',
    '<span><img src="{0}">Metal <b>{1}</b></span><span><img src="{2}">Kristal <b>{3}</b></span><span><i class="ug-au"></i>Altın <b>{4}</b></span>':
      '<span><img src="{0}">Metall <b>{1}</b></span><span><img src="{2}">Kristall <b>{3}</b></span><span><i class="ug-au"></i>Gold <b>{4}</b></span>',
    GİYİLİ: "GETRAGEN",
    SAHİP: "IM BESITZ",
    KİLİTLİ: "GESPERRT",
    '<div class="ug-feat">⚙ {0} · dışarıda yerçekiminden daha az etkilenirsin</div>':
      '<div class="ug-feat">⚙ {0} · draußen wirkt die geringe Schwerkraft schwächer auf dich</div>',
    "✓ Şu an giyili": "✓ Wird getragen",
    Giy: "Anziehen",
    "Önce ": "Erst ",
    "Üret ve giy": "Fertigen und anziehen",
    "Önce bir önceki seti üretmelisin": "Du musst zuerst das vorherige Set fertigen",
    "Malzeme yetersiz — metal, yıldız kristali ve uzak bölgelerdeki nadir taşları topla":
      "Nicht genug Material — sammle Metall, Sternkristalle und seltene Gesteine aus abgelegenen Gebieten",
    "</b> giyildi — ": "</b> angezogen — ",
    '<button class="cbtn pri" data-armor="{0}">Kur</button>':
      '<button class="cbtn pri" data-armor="{0}">Einbauen</button>',
    '<span class="ug-badge on">KURULU</span>': '<span class="ug-badge on">EINGEBAUT</span>',
    '<span class="ug-badge">KİLİTLİ</span>': '<span class="ug-badge">GESPERRT</span>',
    "✓ Uygulandı": "✓ Angewendet",
    "Boyayı uygula": "Lackierung anwenden",
    "Satın al ve uygula": "Kaufen und anwenden",
    '<div class="ug-rk">\n      <div class="ug-rkstage" style="--g:#5ad1ff"><div class="ug-ring"></div><img class="ug-hero rk" src="{0}"><div class="ug-floor"></div>\n        <div class="ug-rkcap"><small>BOYA</small><b>{1}</b><p>{2}</p></div></div>\n      <div class="ug-rkside">\n        <div class="ug-sec">🛡️ FIRTINA KALKANI <span>Arıza olasılığı: <b>%{3}</b></span></div>\n        <div class="ug-armor">{4}</div>\n        <div class="ug-sec">🎨 GÖRÜNÜM <span>Altın parçalarıyla boya</span></div>\n        <div class="ug-skins">{5}</div>\n        <div class="ug-buy">{6}\n          <button class="cbtn pri wide" id="ugSk" {7}>{8}</button></div>\n      </div></div>':
      '<div class="ug-rk">\n      <div class="ug-rkstage" style="--g:#5ad1ff"><div class="ug-ring"></div><img class="ug-hero rk" src="{0}"><div class="ug-floor"></div>\n        <div class="ug-rkcap"><small>LACKIERUNG</small><b>{1}</b><p>{2}</p></div></div>\n      <div class="ug-rkside">\n        <div class="ug-sec">🛡️ STURMSCHILD <span>Ausfallwahrscheinlichkeit: <b>{3} %</b></span></div>\n        <div class="ug-armor">{4}</div>\n        <div class="ug-sec">🎨 AUSSEHEN <span>Lackierung mit Goldfragmenten</span></div>\n        <div class="ug-skins">{5}</div>\n        <div class="ug-buy">{6}\n          <button class="cbtn pri wide" id="ugSk" {7}>{8}</button></div>\n      </div></div>',
    "Malzeme yetersiz — altın (meteor kraterleri) ve titanyum cevheri (uzak bölgeler) topla":
      "Nicht genug Material — sammle Gold (Meteoritenkrater) und Titanerz (abgelegene Gebiete)",
    "</b> kuruldu — fırtınada arıza olasılığı %": "</b> eingebaut — Ausfallwahrscheinlichkeit im Sturm %",
    "Yeterli altın yok — meteor kraterlerinden altın parçası topla":
      "Nicht genug Gold — sammle Goldfragmente aus Meteoritenkratern",
    "🎨 Roket boyandı: <b>": "🎨 Rakete lackiert: <b>",
    "Titanyum cevheri": "Titanerz",
    "Roket zırhı · fırtına kalkanı": "Raketenpanzerung · Sturmschild",
    "Olivin kristali": "Olivinkristall",
    "Kıyafet setleri · Öncü, Kalkan, Elite": "Anzugsets · Pionier, Schild, Elite",
    "Ares taşı": "Aresstein",
    "En üst seviye · ARES Elite + Deflektör kalkanı": "Höchste Stufe · ARES Elite + Deflektorschild",
    "Hematit küreleri": "Hämatit-Kügelchen",
    "Bilim numunesi · geçmişte su izi": "Wissenschaftsprobe · Spur früheren Wassers",
    "Jips kristali": "Gipskristall",
    "Bilim numunesi · kristal suyu içerir": "Wissenschaftsprobe · enthält Kristallwasser",
    "Perklorat tuzu": "Perchloratsalz",
    "Bilim numunesi · zehirli, dikkatle taşı": "Wissenschaftsprobe · giftig, vorsichtig tragen",
    "Demir-nikel meteorit": "Eisen-Nickel-Meteorit",
    "Bilim numunesi · uzaydan gelen göktaşı": "Wissenschaftsprobe · ein Meteorit aus dem All",
    "Oksit minerali · ilmenit": "Oxidmineral · Ilmenit",
    "Doğal radyoaktivite yok": "Keine natürliche Radioaktivität",
    "Tehlikesiz. Kesip öğütürken çıkan tozu solumayın.":
      "Ungefährlich. Beim Schneiden oder Mahlen den Staub nicht einatmen.",
    "Mars bazaltlarında yaygın titanyum kaynağıdır. Titanyum hafif ve çok dayanıklı olduğu için roket zırhı ve ısıl kalkan için en değerli yerel malzemelerden biridir.":
      "Eine häufige Titanquelle in Marsbasalten. Titan ist leicht und sehr fest und damit eines der wertvollsten lokalen Materialien für Raketenpanzerung und Hitzeschilde.",
    "Silikat minerali · forsterit–fayalit serisi": "Silikatmineral · Forsterit-Fayalit-Reihe",
    Diğer: "Sonstige",
    "Olivin suyla temas edince kolayca ayrışır. Bu kadar taze olivin bulunması, bölgenin çok uzun süredir kuru kaldığını gösteriyor. Sert ve ısıya dayanıklı yapısıyla kıyafet katmanlarında kullanılabilir.":
      "Olivin zerfällt bei Kontakt mit Wasser leicht. Dass es hier so frisch ist, zeigt, dass die Gegend sehr lange trocken war. Hart und hitzebeständig eignet es sich für Anzugschichten.",
    "Tanımlanamayan kristal yapı (Mars'a özgü)": "Nicht identifizierte Kristallstruktur (nur auf dem Mars)",
    "Si–Fe–O + nadir toprak elementleri": "Si–Fe–O + Seltene Erden",
    "Zayıf radyoaktivite (doğal arka planın ~3 katı)":
      "Schwache Radioaktivität (~3-fache natürliche Hintergrundstrahlung)",
    "Dikkat. Uzun süre çıplak elle tutmayın ve yatakhanede saklamayın. Kargo bölmesinde korumalı taşınabilir.":
      "Vorsicht. Nicht lange mit bloßen Händen halten und nicht im Quartier lagern. Im Frachtraum kann sie abgeschirmt transportiert werden.",
    "Dünya'da eşi bilinmeyen bir kristal örgü. Nadir toprak elementleri ve çok yüksek sertlik, onu kalkan sistemleri için eşsiz kılıyor. Ekiplerimiz kökenini araştırmayı sürdürüyor.":
      "Ein Kristallgitter ohne bekanntes Gegenstück auf der Erde. Seltene Erden und sehr hohe Härte machen es einzigartig für Schildsysteme. Unsere Teams erforschen weiter seinen Ursprung.",
    "Demir oksit · küresel konkresyon": "Eisenoxid · kugelförmige Konkretion",
    "Tehlikesiz.": "Ungefährlich.",
    "Bu küçük demir oksit küreleri, kayaçların içinden geçen yeraltı suyunda yavaş yavaş oluşur. Yani bu bölgede çok uzun zaman önce sıvı su vardı. Meridiani Planum'da bulunan ünlü kürelerle aynı türden.":
      "Diese kleinen Eisenoxidkugeln bilden sich langsam in Grundwasser, das durch Gestein fließt. Hier gab es also vor sehr langer Zeit flüssiges Wasser. Sie gleichen den berühmten Kügelchen von Meridiani Planum.",
    "Sülfat minerali · kalsiyum sülfat dihidrat": "Sulfatmineral · Calciumsulfat-Dihydrat",
    "H₂O (kristal suyu)": "H₂O (Kristallwasser)",
    "Tehlikesiz. Çok yumuşaktır, kolay kırılır.": "Ungefährlich. Sehr weich, bricht leicht.",
    "Jips, su buharlaşırken oluşan bir mineraldir ve yapısında %21 oranında su tutar. Isıtıldığında bu suyu bırakır; ileride Mars'ta su elde etmek için önemli bir kaynak olabilir.":
      "Gips entsteht beim Verdunsten von Wasser und enthält 21 % Wasser in seiner Struktur. Beim Erhitzen gibt er es frei und könnte so eine wichtige Wasserquelle auf dem Mars werden.",
    "Klor tuzu · magnezyum/kalsiyum perklorat": "Chlorsalz · Magnesium-/Calciumperchlorat",
    "ClO₄⁻ (perklorat)": "ClO₄⁻ (Perchlorat)",
    "Toprak + su": "Boden + Wasser",
    "TEHLİKELİ. Perklorat insan için zehirlidir; tiroid bezinin çalışmasını bozar. Çıplak elle dokunmayın, tozunu solumayın, kabine sokmayın. Giysiyi kabine girmeden önce temizleyin.":
      "GEFÄHRLICH. Perchlorat ist für Menschen giftig und stört die Schilddrüse. Nicht mit bloßen Händen berühren, Staub nicht einatmen, nicht in die Kabine bringen. Den Anzug vor dem Betreten der Kabine reinigen.",
    "Perkloratlar Mars toprağında yaygındır (yaklaşık %0,5–1). Zehirli olsalar da parçalandıklarında oksijen açığa çıkardıkları için gelecekte oksijen üretiminde kullanılabilirler.":
      "Perchlorate sind im Marsboden häufig (etwa 0,5–1 %). Obwohl giftig, setzen sie beim Zerfall Sauerstoff frei und könnten künftig zur Sauerstoffgewinnung dienen.",
    "Demir meteorit · kamasit–tenit": "Eisenmeteorit · Kamacit–Taenit",
    "Fe–Ni alaşımı": "Fe-Ni-Legierung",
    "Kozmik ışınla oluşmuş izotop izleri (zararsız)": "Spuren kosmogener Isotope (harmlos)",
    "Tehlikesiz. Çok ağırdır; taşırken dikkat edin.": "Ungefährlich. Sehr schwer; beim Tragen aufpassen.",
    "Bu taş Mars'a uzaydan düşmüş bir göktaşı. Kesilip parlatıldığında çok yavaş soğumanın izi olan çapraz desenler görülür. Mars yüzeyinde bulunan demir meteoritler, atmosferin geçmişteki kalınlığı hakkında ipucu verir.":
      "Dieser Stein ist ein Meteorit, der aus dem All auf den Mars fiel. Geschnitten und poliert zeigt er Kreuzmuster als Spur sehr langsamer Abkühlung. Eisenmeteorite auf dem Mars geben Hinweise auf die frühere Dichte der Atmosphäre.",
    "Bilinmeyen taş": "Unbekanntes Gestein",
    "BİLİNMEYEN TAŞ": "UNBEKANNTER STEIN",
    "📡 Tarayıcı: yakında ": "📡 Scanner: Signal von ",
    "<b>bilinmeyen bir mineral</b>": "<b>einem unbekannten Mineral</b>",
    " sinyali — haritadaki işarete git": " in der Nähe — gehe zur Markierung auf der Karte",
    "<b>Bilinmeyen taş</b> çantana alındı. Ne olduğunu ve tehlikeli olup olmadığını öğrenmek için roketteki <b>kargo terminalinden</b> analize gönder.":
      "<b>Unbekannter Stein</b> eingepackt. Um zu erfahren, was er ist und ob er gefährlich ist, schick ihn über das <b>Frachtterminal</b> der Rakete zur Analyse.",
    "</b> (toplam ": "</b> (gesamt ",
    "Bu taş zaten analizde": "Dieser Stein wird bereits analysiert",
    "Taş numunesi <b>analiz için</b> Dünya'ya gönderildi. Laboratuvar sonucu birazdan gelen kutunda.":
      "Gesteinsprobe <b>zur Analyse</b> zur Erde geschickt. Das Laborergebnis kommt bald in deinen Posteingang.",
    GÜVENLİ: "SICHER",
    DİKKAT: "VORSICHT",
    TEHLİKELİ: "GEFÄHRLICH",
    '<p>Sayın Komutan,</p>\n  <p><b>Analiz için</b> gönderdiğiniz bilinmeyen taş numunesi laboratuvarımızda incelendi. Taşın adı ve özellikleri aşağıdadır.</p>\n  <div class="ltr-annex"><div class="ah">NUMUNE ANALİZ RAPORU · {0}</div>\n  <table class="mn-tbl">\n    <tr><td>Tanım</td><td><b>{1}</b></td></tr>\n    <tr><td>Mineral sınıfı</td><td>{2}</td></tr>\n    <tr><td>Kimyasal formül</td><td><b>{3}</b></td></tr>\n    <tr><td>Sertlik (Mohs)</td><td>{4}</td></tr>\n    <tr><td>Yoğunluk</td><td>{5}</td></tr>\n    <tr><td>Radyoaktivite</td><td>{6}</td></tr></table>\n  <b style="font-size:12px">Bileşim (ağırlıkça)</b>{7}\n  <div class="an">Yöntem: X-ışını kırınımı (XRD) · X-ışını floresansı (XRF) · gama spektrometrisi</div></div>\n  <div class="mn-hz {8}"><b>{9}</b><span>{10}</span></div>\n  <h4>Bilimsel değerlendirme</h4><p>{11}</p>\n  <p><b>Oyundaki kullanımı:</b> {12}.</p>':
      '<p>Sehr geehrter Kommandant,</p>\n  <p>Die unbekannte Gesteinsprobe, die du <b>zur Analyse</b> geschickt hast, wurde in unserem Labor untersucht. Name und Eigenschaften folgen unten.</p>\n  <div class="ltr-annex"><div class="ah">PROBENANALYSEBERICHT · {0}</div>\n  <table class="mn-tbl">\n    <tr><td>Bestimmung</td><td><b>{1}</b></td></tr>\n    <tr><td>Mineralklasse</td><td>{2}</td></tr>\n    <tr><td>Chemische Formel</td><td><b>{3}</b></td></tr>\n    <tr><td>Härte (Mohs)</td><td>{4}</td></tr>\n    <tr><td>Dichte</td><td>{5}</td></tr>\n    <tr><td>Radioaktivität</td><td>{6}</td></tr></table>\n  <b style="font-size:12px">Zusammensetzung (Gewicht)</b>{7}\n  <div class="an">Methode: Röntgenbeugung (XRD) · Röntgenfluoreszenz (XRF) · Gammaspektrometrie</div></div>\n  <div class="mn-hz {8}"><b>{9}</b><span>{10}</span></div>\n  <h4>Wissenschaftliche Bewertung</h4><p>{11}</p>\n  <p><b>Verwendung im Spiel:</b> {12}.</p>',
    "Numune analizi · ": "Probenanalyse · ",
    "🌀 Toz şeytanına yakalandın — uzaklaş!": "🌀 Du bist in eine Staubhose geraten — weg hier!",
    "'e varıldı": " erreicht",
    '<span class="st on">🌪 FIRTINA</span>': '<span class="st on">🌪 STURM</span>',
    '<span class="st" title="Sonraki kum fırtınası">🌪 Gün ':
      '<span class="st" title="Nächster Sandsturm">🌪 Tag ',
    '<span class="rd on">☢ AKTİF</span>': '<span class="rd on">☢ AKTIV</span>',
    '<span class="rd" title="Sonraki radyasyon dalgası">☢ Gün ':
      '<span class="rd" title="Nächste Strahlungswelle">☢ Tag ',
    '<div class="hd-top"><span class="hd-planet" style="{0}"></span>\n      <div class="hd-tt"><b>{1}</b><span>GÜN {2}</span></div>\n      <div class="hd-clock">{3} {4}</div></div>\n    <div class="hd-bar">{5}<em style="left:{6}%"></em></div>\n    <div class="hd-foot"><span>⏳ {7}</span><span class="hd-ev">{8}</span></div>':
      '<div class="hd-top"><span class="hd-planet" style="{0}"></span>\n      <div class="hd-tt"><b>{1}</b><span>TAG {2}</span></div>\n      <div class="hd-clock">{3} {4}</div></div>\n    <div class="hd-bar">{5}<em style="left:{6}%"></em></div>\n    <div class="hd-foot"><span>⏳ {7}</span><span class="hd-ev">{8}</span></div>',
    DIŞARI: "AUSSEN",
    KABİN: "KABINE",
    "💧 Su": "💧 Wasser",
    "🥔 Patates": "🥔 Kartoffel",
    "💊 Medikit": "💊 Medkit",
    "🌱 Tohum": "🌱 Samen",
    "🔩 Metal numune": "🔩 Metallprobe",
    "⭐ Yıldız kırıntısı (2 numune)": "⭐ Sternsplitter (2 Proben)",
    "Çürük patates (numune)": "Verfaulte Kartoffel (Probe)",
    "Bu numarada henüz eşya yok — önce topla": "In diesem Platz ist noch nichts — sammle zuerst etwas",
    "Çapa elinde — yakındaki yere <b>sol tıkla</b>, toprağı kaz":
      "Hacke in der Hand — <b>klicke links</b> auf den Boden in der Nähe, um zu graben",
    "Bu slot boş — (": "Dieser Platz ist leer — (",
    "Susuzluğun zaten dolu": "Du hast keinen Durst",
    "Su içildi (+": "Wasser getrunken (+",
    " susuzluk)": " Wasser)",
    "Açlığın zaten dolu": "Du hast keinen Hunger",
    "Patates yendi (+": "Kartoffel gegessen (+",
    " açlık)": " Nahrung)",
    "Radyasyon ölçer dışarıda, toprak üzerinde kullanılır":
      "Das Strahlungsmessgerät wird draußen auf dem Boden benutzt",
    "Çürük patates yenmez — roketteki kargo terminalinden Dünya'ya gönder":
      "Verfaulte Kartoffeln kann man nicht essen — schick sie über das Frachtterminal der Rakete zur Erde",
    "Tarla parselinin yakınına git": "Geh näher an ein Beet heran",
    "Parsel dolu — önce hasat et (F)": "Das Beet ist belegt — ernte zuerst (F)",
    "🌱 Ekildi": "🌱 Gepflanzt",
    "Numuneler roketin kargo bölmesine yüklenir — rokete götür (F)":
      "Proben werden in den Frachtraum der Rakete geladen — bring sie zur Rakete (F)",
    "Slot ": "Platz ",
    "🔓 Dünya rotası açıldı! Komuta güvertesindeki navigasyondan eve dön":
      "🔓 Route zur Erde freigeschaltet! Kehre über die Navigation auf dem Kommandodeck heim",
    '<div class="qd-n">Sıradaki görev: <b>{0} {1}</b></div>':
      '<div class="qd-n">Nächste Mission: <b>{0} {1}</b></div>',
    '<div class="qd-n"><b>Tüm görevler bitti!</b></div>':
      '<div class="qd-n"><b>Alle Missionen erledigt!</b></div>',
    '<div class="qd-ck">✓</div><div class="qd-k">GÖREV TAMAMLANDI</div><div class="qd-t">{0} {1}</div>\n{2}':
      '<div class="qd-ck">✓</div><div class="qd-k">MISSION ERFÜLLT</div><div class="qd-t">{0} {1}</div>\n{2}',
    "GÖREV ": "MISSION ",
    "⏳ Fırtına bekleniyor: <b>Gün 2</b>, saat {0} civarı. O zamana kadar numune topla, tarım yap.":
      "⏳ Sturm erwartet: <b>Tag 2</b>, gegen {0}. Bis dahin Proben sammeln und anbauen.",
    " yüzeyi · sol ": " – Oberfläche · Sol ",
    '<div class="ai">⚠️</div><div><b>Ana motor hasarlı — kalkış kilitli.</b><br>Makine dairesindeki ana motoru onar · aşama {0}/4</div>':
      '<div class="ai">⚠️</div><div><b>Haupttriebwerk beschädigt — Start gesperrt.</b><br>Repariere das Haupttriebwerk im Maschinenraum · Stufe {0}/4</div>',
    "Şu an buradasın": "Du bist hier",
    '<span class="badge ok">BURADASIN</span>': '<span class="badge ok">DU BIST HIER</span>',
    "Görevleri tamamla (": "Missionen abschließen (",
    '<span class="badge mute">🔒 KİLİTLİ</span>': '<span class="badge mute">🔒 GESPERRT</span>',
    "Eve dönüş rotası hazır": "Heimroute bereit",
    "Daha önce ziyaret edildi": "Bereits besucht",
    "Yeni rota": "Neue Route",
    "🌍 EVE DÖN": "🌍 HEIMKEHR",
    "🚀 KALKIŞ": "🚀 START",
    "Ana motor hasarlı": "Haupttriebwerk beschädigt",
    "Ana motor arızalı — makine dairesinde motoru onar":
      "Haupttriebwerk defekt — repariere das Triebwerk im Maschinenraum",
    "Roket yolculuğu sürüyor…": "Raketenreise läuft …",
    "Kargo Terminali": "Frachtterminal",
    "Numuneleri kargo bölmesine yükle · erzak kapsüllerde":
      "Proben in den Frachtraum laden · Vorräte in den Kapseln",
    "Dışarıdaki parsele ek": "In ein Beet draußen pflanzen",
    "Canı yeniler": "Stellt Gesundheit wieder her",
    '<div class="ri">{0}</div><div><div class="rn">{1}</div><div class="rd">{2}</div></div>\n      <div class="rp"><span>DEPO {3}</span><span class="rp-sub">ÇANTA {4}</span></div>':
      '<div class="ri">{0}</div><div><div class="rn">{1}</div><div class="rd">{2}</div></div>\n      <div class="rp"><span>LAGER {3}</span><span class="rp-sub">TASCHE {4}</span></div>',
    Bırak: "Ablegen",
    '<span class="chip">🔩 Metal <b>×{0}</b> <i>+{1}</i></span>':
      '<span class="chip">🔩 Metall <b>×{0}</b> <i>+{1}</i></span>',
    '<span class="chip">⭐ Yıldız <b>×{0}</b> <i>+{1}</i></span>':
      '<span class="chip">⭐ Stern <b>×{0}</b> <i>+{1}</i></span>',
    '<div class="con-note">Çantanda numune yok — dışarıda metal ve ⭐ topla, burada kargoya yükle.</div>':
      '<div class="con-note">Keine Proben in deiner Tasche — sammle draußen Metall und ⭐ und lade sie hier in den Frachtraum.</div>',
    "Dünya'ya gönderildi · laboratuvar inceliyor": "Zur Erde geschickt · Labor untersucht",
    "Ne olduğunu ve tehlikeli olup olmadığını öğrenmek için gönder":
      "Schick ihn, um zu erfahren, was er ist und ob er gefährlich ist",
    '<div class="ri"><img src="{0}" alt="" style="width:32px;height:32px;filter:{1}"></div><div><div class="rn">Bilinmeyen taş · {2}. tür<span class="ana-tag">ANALİZ İÇİN</span></div><div class="rd">{3}</div></div><div class="rp"><span>ÇANTA {4}</span></div>':
      '<div class="ri"><img src="{0}" alt="" style="width:32px;height:32px;filter:{1}"></div><div><div class="rn">Unbekannter Stein · Typ {2}<span class="ana-tag">ZUR ANALYSE</span></div><div class="rd">{3}</div></div><div class="rp"><span>TASCHE {4}</span></div>',
    "Analizde…": "Wird analysiert…",
    "Analize gönder": "Zur Analyse senden",
    "Dünya'ya gönderildi · analiz bekleniyor": "Zur Erde gesendet · Analyse ausstehend",
    "Kargoyla Dünya'ya gönder · neden çürüdüğünü incelesinler":
      "Per Fracht zur Erde schicken · dort wird die Ursache untersucht",
    '<div class="ri"><img src="{0}" alt="" style="width:30px;height:30px"></div><div><div class="rn">Çürük patates<span class="ana-tag">ANALİZ İÇİN</span></div><div class="rd">{1}</div></div><div class="rp"><span>ÇANTA {2}</span></div>':
      '<div class="ri"><img src="{0}" alt="" style="width:30px;height:30px"></div><div><div class="rn">Verfaulte Kartoffel<span class="ana-tag">ZUR ANALYSE</span></div><div class="rd">{1}</div></div><div class="rp"><span>TASCHE {2}</span></div>',
    "Dünya'ya gönder": "Zur Erde senden",
    "📦 Numuneleri kargoya yükle · +": "📦 Proben in den Frachtraum laden · +",
    "Yüklenecek numune yok": "Keine Proben zum Laden",
    " altın": " Gold",
    "🪙 <b>Altın parçası</b> — roketteki geliştirme istasyonunda roketini güçlendirmek için kullan":
      "🪙 <b>Goldfragment</b> — verwende es an der Upgrade-Station in der Rakete, um deine Rakete zu verstärken",
    "Envanter dolu! (": "Inventar voll! (",
    "🌱 Tohumu eline aldın — ekmek için tekrar <b>F</b>":
      "🌱 Du hältst den Samen — drücke erneut <b>F</b> zum Pflanzen",
    "Tohum yok — roketteki alet sandığından al": "Keine Samen — nimm welche aus der Werkzeugkiste der Rakete",
    "💧 Sulandı": "💧 Gegossen",
    "💧 Su şişesini eline aldın — sulamak için tekrar <b>F</b>":
      "💧 Du hältst die Wasserflasche — drücke erneut <b>F</b> zum Gießen",
    "Sulamak için su yok · büyüyor %": "Kein Wasser zum Gießen · wächst %",
    " su)": " Wasser)",
    "Tok durumdasın": "Du hast keinen Hunger",
    " tokluk)": " Nahrung)",
    "Çapa elinde — su içmek için önce suyu eline al (numara tuşu)":
      "Hacke in der Hand — zum Trinken zuerst das Wasser nehmen (Zifferntaste)",
    "Yapılacak bir şey yok (F)": "Hier gibt es nichts zu tun (F)",
    "Canın zaten dolu": "Deine Gesundheit ist bereits voll",
    "☢️ Radyasyon dalgası başladı — canın azalıyor, rokete gir!":
      "☢️ Strahlungswelle hat begonnen — du verlierst Gesundheit, geh in die Rakete!",
    "☢️ Radyasyon dalgası geçti": "☢️ Die Strahlungswelle ist vorüber",
    "Radyasyon dalgası · gövde zırhı koruyor": "Strahlungswelle · die Rumpfpanzerung schützt dich",
    "Dışarıda can azalıyor — rokete sığın!": "Draußen verlierst du Gesundheit — such Schutz in der Rakete!",
    "Radyasyon dalgası yaklaşıyor": "Strahlungswelle naht",
    "Güneş patlaması · rokete yaklaş": "Sonneneruption · geh in die Nähe der Rakete",
    "<b>F</b>: Altın parçası topla · roket geliştirme": "<b>F</b>: Goldfragment aufheben · Raketen-Upgrade",
    " — kazmayla kır": " — mit der Spitzhacke zerschlagen",
    "Bilinmeyen taşı kazmayla kır": "Zerschlage den unbekannten Stein mit der Spitzhacke",
    " · <b style='color:#ff8a8a'>jeolog kazması gerekli</b>":
      " · <b style='color:#ff8a8a'>Geologenspitzhacke nötig</b>",
    "Çanta dolu (": "Tasche voll (",
    ") — rokete yükle": ") — in die Rakete laden",
    "<b>F</b>: Metal numune topla": "<b>F</b>: Metallprobe aufheben",
    "<b>F</b>: Yıldız kırıntısı topla (⭐ = 2 numune)": "<b>F</b>: Sternsplitter aufheben (⭐ = 2 Proben)",
    "Taş kırılıyor…": "Stein wird zerschlagen…",
    "Sol tık: ölçümü kapat": "Linksklick: Messung schließen",
    "Ölçülüyor… hareket etme": "Messung läuft… nicht bewegen",
    "<b>F</b>: Ölçüm bayrağını kaldır (": "<b>F</b>: Messfahne entfernen (",
    "<b>E</b>: Rokete gir": "<b>E</b>: Rakete betreten",
    "  ·  <b>F</b>: Numuneleri kargoya yükle": "  ·  <b>F</b>: Proben in den Frachtraum laden",
    "  ·  çürük patatesi kargo terminalinden gönder":
      "  ·  verfaulte Kartoffel über das Frachtterminal senden",
    "<b>Sol tık</b>: toprağın radyasyonunu ölç  ·  <b>F</b>: önündeki toprağı ölç":
      "<b>Linksklick</b>: Bodenstrahlung messen  ·  <b>F</b>: Boden vor dir messen",
    "<b>Sol tık</b>: yakındaki yere kaz — ilk parseli aç":
      "<b>Linksklick</b>: Boden in der Nähe umgraben — erstes Beet anlegen",
    "Çapayı eline al (numara tuşu) ya da yere tıkla":
      "Nimm die Hacke in die Hand (Zifferntaste) oder klicke auf den Boden",
    "Çapa roketteki alet sandığında (makine dairesi) — rokete gir: <b>E</b>":
      "Die Hacke ist in der Werkzeugkiste der Rakete (Maschinenraum) — Rakete betreten: <b>E</b>",
    "<b>F</b>: Tohum ek": "<b>F</b>: Samen pflanzen",
    "<b>F</b>: Tohumu eline al": "<b>F</b>: Samen in die Hand nehmen",
    "<b>F</b>: Hasat et — yapraklar solmuş, bir terslik var":
      "<b>F</b>: Ernten — die Blätter sind verwelkt, etwas stimmt nicht",
    "<b>F</b>: Hasat et 🥔": "<b>F</b>: Ernten 🥔",
    "<b>F</b>: Sula (hızlandırır)": "<b>F</b>: Gießen (beschleunigt das Wachstum)",
    "<b>F</b>: Suyu eline al (sulamak için)": "<b>F</b>: Wasser in die Hand nehmen (zum Gießen)",
    "Büyüyor %": "Wächst %",
    "<b>G</b>: Medikit kullan (": "<b>G</b>: Medkit benutzen (",
    "Dikkat: canın düşük! Roketin revirinde iyileş":
      "Achtung: deine Gesundheit ist niedrig! Heile dich in der Krankenstation der Rakete",
    "Elinde: ": "In der Hand: ",
    "Çok uzak — tıkladığın yere daha yaklaş": "Zu weit weg — geh näher an die angeklickte Stelle",
    "Azami parsel sayısına ulaştın (": "Du hast die maximale Anzahl an Beeten erreicht (",
    "Buraya çok yakın — biraz aralık bırak": "Zu nah an einem anderen Beet — lass etwas Abstand",
    "İniş platformunu kazamazsın": "Die Landeplattform kannst du nicht umgraben",
    "Dünyanın kenarını kazamazsın": "Am Rand der Welt kannst du nicht graben",
    "Tohumu ekmek için açtığın bir parsele tıkla":
      "Klicke auf eine gegrabene Parzelle, um den Samen zu pflanzen",
    "Sulamak için ekili bir parsele tıkla": "Klicke auf eine bepflanzte Parzelle, um sie zu gießen",
    "Bu parsel boş — önce tohum ek": "Diese Parzelle ist leer — säe zuerst",
    "Mahsul hazır — hasat için yanına git ve <b>F</b>": "Ernte bereit — geh hin und drücke <b>F</b>",
    Sulandı: "Gegossen",
    "Yeni parsel: boş": "Neue Parzelle: leer",
    "Yeni parsel hazır: <b>boş</b> — tohum ek (F)": "Neues Beet bereit: <b>leer</b> — Samen pflanzen (F)",
    "Jeolog kazması yalnızca <b>bilinmeyen (?) taşları</b> kırar — kazmak için çapayı eline al":
      "Die Geologenspitzhacke zerschlägt nur <b>unbekannte (?) Steine</b> — zum Graben nimm die Hacke",
    "Elinde başka bir eşya var — kazmak için çapayı eline al (numara tuşu)":
      "Du hältst etwas anderes — nimm zum Graben die Hacke (Zifferntaste)",
    "Çapa rokette — makine dairesindeki alet sandığından al":
      "Die Hacke ist in der Rakete — nimm sie aus der Werkzeugkiste im Maschinenraum",
    "Çapayı eline aldın — kazmak için tekrar tıkla": "Hacke in der Hand — zum Graben erneut klicken",
    "Yaşanabilirlik araştırması": "Bewohnbarkeitsstudie",
    "Mars'ta bir insanın hayatta kalıp kalamayacağını ölç. Fırtına, radyasyon ve yaşam desteği raporları daha değerli.":
      "Miss, ob ein Mensch auf dem Mars überleben kann. Berichte zu Stürmen, Strahlung und Lebenserhaltung sind mehr wert.",
    "Jeoloji ve nadir mineraller": "Geologie und seltene Minerale",
    "Kayaçları ve bilinmeyen mineralleri incele. Numune ve nadir taş raporları daha değerli.":
      "Untersuche Gesteine und unbekannte Minerale. Berichte zu Proben und seltenen Gesteinen sind mehr wert.",
    "Uzun süreli yaşam testi": "Langzeit-Lebenstest",
    "Mars toprağında besin üretimini dene. Tarım ve yaşam desteği raporları daha değerli.":
      "Versuche, im Marsboden Nahrung zu erzeugen. Berichte zu Anbau und Lebenserhaltung sind mehr wert.",
    Kolay: "Leicht",
    Normal: "Normal",
    Zor: "Schwer",
    "Orta sınıf roket": "Mittelschwere Rakete",
    "Ucuz ama taşıma kapasitesi sınırlı.": "Günstig, aber mit begrenzter Nutzlast.",
    "Ağır roket": "Schwerlastrakete",
    "Dengeli kapasite ve maliyet.": "Ausgewogene Kapazität und Kosten.",
    "Süper ağır roket": "Superschwerlastrakete",
    "Her şeyi taşır ama bütçeyi zorlar.": "Trägt alles, belastet aber das Budget.",
    "Hızlı transfer": "Schneller Transfer",
    "Daha çok yakıt (kütle) gerekir; mürettebat Mars'a erzakı dolu varır.":
      "Braucht mehr Treibstoff (Masse); die Crew erreicht den Mars mit vollen Vorräten.",
    "Ekonomik transfer": "Sparsamer Transfer",
    "Az yakıt gerekir ama yolculuk uzar: erzak ve oksijen eksik başlar.":
      "Braucht wenig Treibstoff, aber die Reise dauert länger: Vorräte und Sauerstoff sind zu Beginn knapper.",
    "Kısa görev: bütçe dostu, az erzak.": "Kurze Mission: budgetschonend, wenig Vorräte.",
    "Orta süre: ek erzak paketi.": "Mittlere Dauer: zusätzliches Vorratspaket.",
    "Uzun görev: bol erzak, yüksek maliyet.": "Lange Mission: viele Vorräte, hohe Kosten.",
    "Güç sistemi": "Energiesystem",
    "Tüm sistemler elektrik ister. Güneş panelleri fırtınada tozla kaplanır; radyoizotop jeneratör (RTG) hep aynı gücü verir ama ağır ve pahalıdır.":
      "Jedes System braucht Strom. Solarpaneele werden im Sturm mit Staub bedeckt; ein Radioisotopengenerator (RTG) liefert immer gleich viel Leistung, ist aber schwer und teuer.",
    "Hafif ve ucuz; fırtınada üretim düşer.": "Leicht und günstig; Leistung sinkt bei Sturm.",
    "Geniş güneş panelleri": "Große Solarpaneele",
    "Daha çok güç; fırtınada yine düşer.": "Mehr Leistung; sinkt bei Sturm trotzdem.",
    "Radyoizotop jeneratör (RTG)": "Radioisotopengenerator (RTG)",
    "Fırtınadan etkilenmez; ağır ve pahalı.": "Von Stürmen unbeeinflusst; schwer und teuer.",
    Batarya: "Batterie",
    "Batarya, güneş paneli üretimi düştüğünde (fırtına) sistemleri ayakta tutar.":
      "Die Batterie hält die Systeme am Laufen, wenn die Solarleistung sinkt (Sturm).",
    "Standart batarya": "Standardbatterie",
    "Fırtınada kısa süre idare eder.": "Reicht bei Sturm nur kurz.",
    "Büyük batarya": "Große Batterie",
    "Fırtınada güç kaybının yarısını karşılar.": "Deckt bei Sturm die Hälfte des Leistungsverlusts.",
    "Oksijen tüpünün kapasitesini ve kendini yenileme hızını belirler. Daha iyi sistem daha çok güç ve kütle ister.":
      "Bestimmt die Kapazität des Sauerstofftanks und wie schnell er sich wieder auffüllt. Ein besseres System braucht mehr Energie und Masse.",
    "Standart O₂ tüpü": "Standard-O₂-Tank",
    "Temel kapasite.": "Grundkapazität.",
    "Genişletilmiş tüp": "Erweiterter Tank",
    "%40 daha fazla oksijen.": "40 % mehr Sauerstoff.",
    "Kapalı döngü rejeneratör": "Regenerator mit geschlossenem Kreislauf",
    "Tüp neredeyse 2 kat hızlı dolar.": "Der Tank füllt sich fast doppelt so schnell.",
    "Yapı ve koruma": "Struktur und Schutz",
    "Gövde zırhı fırtınada motorun bozulma olasılığını azaltır. Zırh ağırdır; fırlatma aracının kapasitesini zorlar.":
      "Rumpfpanzerung senkt die Wahrscheinlichkeit eines Triebwerksausfalls im Sturm. Panzerung ist schwer und belastet die Kapazität der Trägerrakete.",
    "Hafif gövde": "Leichter Rumpf",
    "Fırtınada motor arıza riski %60.": "Triebwerksausfallrisiko bei Sturm: 60 %.",
    "Takviyeli gövde": "Verstärkter Rumpf",
    "Arıza riski %35 ile başlar.": "Ausfallrisiko beginnt bei 35 %.",
    "Ağır zırhlı gövde": "Schwer gepanzerter Rumpf",
    "Arıza riski %15 ile başlar.": "Ausfallrisiko beginnt bei 15 %.",
    "Anten, günde Dünya'ya gönderilebilecek veri miktarını (MB/sol) ve yanıt süresini belirler. Bilim aletlerinin ürettiği veri bu kapasiteyi aşarsa bilimin bir kısmı kaybolur.":
      "Die Antenne bestimmt, wie viele Daten pro Tag zur Erde gesendet werden können (MB/Sol) und wie schnell Antworten kommen. Erzeugen die Instrumente mehr Daten, geht ein Teil der Wissenschaft verloren.",
    "Düşük kazançlı anten": "Antenne mit geringem Gewinn",
    "Ucuz; az veri, yavaş yanıt.": "Günstig; wenig Daten, langsame Antworten.",
    "Yüksek kazançlı anten": "Richtantenne mit hohem Gewinn",
    "Dengeli seçim.": "Eine ausgewogene Wahl.",
    "Anten + Mars yörüngesinde röle uydusu": "Antenne + Relaissatellit im Marsorbit",
    "Çok veri, hızlı yanıt; fırtınada bile gönderim yapılır.":
      "Viele Daten, schnelle Antworten; Senden ist sogar bei Sturm möglich.",
    "Aviyonik ve yönelim kontrolü": "Avionik und Lageregelung",
    "Araç bilgisayarı ve yönelim kontrolü; gelişmiş sistem tarayıcının menzilini artırır.":
      "Bordcomputer und Lageregelung; das fortgeschrittene System erhöht die Reichweite des Scanners.",
    "Standart bilgisayar": "Standardcomputer",
    "Temel tarayıcı menzili.": "Grundreichweite des Scanners.",
    "Gelişmiş bilgisayar + yıldız izleyici": "Fortgeschrittener Computer + Sternsensor",
    "Tarayıcı menzili %35 artar.": "Scannerreichweite +35 %.",
    "Meteoroloji istasyonu": "Wetterstation",
    "Fırtına uyarısı 30 sn daha erken gelir.": "Sturmwarnungen kommen 30 s früher.",
    "Radyasyon dedektörü": "Strahlungsdetektor",
    "Radyasyon uyarısı 30 sn daha erken gelir.": "Strahlungswarnungen kommen 30 s früher.",
    "Kayaç spektrometresi": "Gesteinsspektrometer",
    "Numune raporlarının bilim değeri %50 artar.": "Probenberichte bringen 50 % mehr Wissenschaftswert.",
    "Zemin radarı": "Bodenradar",
    "Bilinmeyen taşları %80 daha uzaktan bulursun.":
      "Du findest unbekannte Gesteine aus 80 % größerer Entfernung.",
    "Sera modülü": "Gewächshausmodul",
    "Bitkiler %50 daha hızlı büyür.": "Pflanzen wachsen 50 % schneller.",
    "Panoramik kamera": "Panoramakamera",
    "Tüm raporların bilim değeri %15 artar; çok veri üretir.":
      "Alle Berichte bringen 15 % mehr Wissenschaftswert; erzeugt viele Daten.",
    "Görev hedefi": "Missionsziel",
    "Fırlatma ve yörünge": "Start und Flugbahn",
    "Uzay aracı": "Raumfahrzeug",
    "Bilim ve iletişim": "Wissenschaft und Kommunikation",
    "Simülasyon ve fırlatma": "Simulation und Start",
    Rekorlar: "Rekorde",
    "Kütle {0} t, fırlatma aracının kapasitesi {1} t. Daha güçlü bir roket seç ya da kütleyi azalt.":
      "Die Masse beträgt {0} t, die Trägerrakete trägt aber nur {1} t. Wähle eine stärkere Rakete oder verringere die Masse.",
    "Güç tüketimi {0} kW, üretim {1} kW. Güç sistemini büyüt ya da alet çıkar.":
      "Der Energiebedarf beträgt {0} kW, die Erzeugung {1} kW. Vergrößere das Energiesystem oder entferne ein Instrument.",
    "Maliyet {0} M$, bütçe {1} M$. Daha ucuz bileşenler seç.":
      "Die Kosten betragen {0} M$, das Budget {1} M$. Wähle günstigere Komponenten.",
    "Aletler günde {0} MB veri üretiyor, anten {1} MB gönderebiliyor. Bilimin yaklaşık %{2}'i kaybolacak.":
      "Die Instrumente erzeugen {0} MB Daten pro Tag, die Antenne kann {1} MB senden. Etwa {2} % der Wissenschaft gehen verloren.",
    "Hiç bilim aleti yok: görev bilim değeri düşük olur.":
      "Keine wissenschaftlichen Instrumente: Der Wissenschaftswert der Mission wird gering sein.",
    "Güç payı çok az: fırtınada güneş panelleri yetersiz kalabilir.":
      "Sehr wenig Energiereserve: Die Solarpaneele könnten bei Sturm nicht ausreichen.",
    "{0} simülasyonda fırlatma başarısız oldu: fırlatma aracının güvenilirliği bunu belirler.":
      "In {0} Simulationen schlug der Start fehl: Das hängt von der Zuverlässigkeit der Trägerrakete ab.",
    "{0} simülasyonda fırtına motoru onarılamaz şekilde bozdu: gövde zırhı bu riski düşürür.":
      "In {0} Simulationen beschädigte ein Sturm das Triebwerk irreparabel: Rumpfpanzerung senkt dieses Risiko.",
    "{0} simülasyonda oksijen yetmedi: yaşam desteği ve güç sistemi bunu etkiler.":
      "In {0} Simulationen reichte der Sauerstoff nicht: Lebenserhaltung und Energiesystem beeinflussen das.",
    "{0} simülasyonda erzak bitti: görev süresi, transfer yörüngesi ve sera modülü bunu etkiler.":
      "In {0} Simulationen gingen die Vorräte aus: Missionsdauer, Transferbahn und Gewächshausmodul beeinflussen das.",
    "Simülasyonların hiçbirinde ciddi bir arıza görülmedi.":
      "In keiner Simulation trat ein schwerer Ausfall auf.",
    "Mars'a ilk adım": "Erste Schritte auf dem Mars",
    "Mars'a yeni gelenler için. Kaynaklar daha yavaş tükenir, tehlikeler daha hafif vurur ve yaralar daha çabuk iyileşir. Keşfetmeye ve öğrenmeye odaklan.":
      "Für Neulinge auf dem Mars. Vorräte gehen langsamer zur Neige, Gefahren treffen schwächer und Wunden heilen schneller. Konzentriere dich aufs Erkunden und Lernen.",
    "Dengeli görev": "Ausgewogene Mission",
    "Oyunun tasarlandığı denge. Hayatta kalmak için yemeğini, suyunu ve oksijenini planlaman gerekir ama küçük hatalara yer vardır.":
      "Die Balance, für die das Spiel gemacht ist. Um zu überleben, musst du Nahrung, Wasser und Sauerstoff planen, aber kleine Fehler sind verzeihlich.",
    "Deneyimli komutan": "Erfahrener Kommandant",
    "Her kaynak değerlidir. Açlık, susuzluk ve oksijen daha hızlı düşer; fırtınalar, radyasyon ve meteorlar daha sert vurur, iyileşme yavaşlar.":
      "Jede Ressource zählt. Hunger, Durst und Sauerstoff sinken schneller; Stürme, Strahlung und Meteore treffen härter, und die Heilung ist langsamer.",
    "Açlık hızı": "Hungerrate",
    "Susuzluk hızı": "Durstrate",
    "Radyasyon hasarı": "Strahlungsschaden",
    "Fırtına etkisi": "Sturmwirkung",
    "Meteor hasarı": "Meteorschaden",
    "İyileşme hızı": "Heilungsrate",
    Standart: "Standard",
    "%{0} daha hızlı": "{0}% schneller",
    "%{0} daha yavaş": "{0}% langsamer",
    "%{0} daha fazla": "{0}% mehr",
    "%{0} daha az": "{0}% weniger",
    "%{0} daha güçlü": "{0}% stärker",
    "%{0} daha zayıf": "{0}% schwächer",
    "<h4>Görev özeti</h4><p>ARES-1 Mars'a doğru yola çıkıyor. İnişten sonra hayatta kal, keşfet ve bulgularını Dünya'ya raporla.</p>\n      <dl class=\"ng-dl\"><dt>Fırlatma aracı</dt><dd>{0}</dd><dt>Transfer</dt><dd>{1} · {2} gün</dd><dt>Güç</dt><dd>{3}</dd>\n      <dt>Yaşam desteği</dt><dd>{4}</dd><dt>Gövde</dt><dd>{5}</dd><dt>İletişim</dt><dd>{6}</dd>\n      <dt>Bilim aletleri</dt><dd>{7}</dd><dt>Görev süresi</dt><dd>{8} sol</dd></dl>":
      '<h4>Missionsübersicht</h4><p>ARES-1 ist auf dem Weg zum Mars. Überlebe nach der Landung, erkunde und melde deine Erkenntnisse an die Erde.</p>\n      <dl class="ng-dl"><dt>Trägerrakete</dt><dd>{0}</dd><dt>Transfer</dt><dd>{1} · {2} Tage</dd><dt>Energie</dt><dd>{3}</dd>\n      <dt>Lebenserhaltung</dt><dd>{4}</dd><dt>Rumpf</dt><dd>{5}</dd><dt>Kommunikation</dt><dd>{6}</dd>\n      <dt>Instrumente</dt><dd>{7}</dd><dt>Missionsdauer</dt><dd>{8} Sols</dd></dl>',
    '<div class="ng-left">\n      <label class="ng-lbl">Görev adı</label><input class="md-in ng-name" id="ngName" maxlength="24" placeholder="ARES-1" value="{0}">\n      <label class="ng-lbl">Zorluk</label>\n      <div class="ng-diffs">{1}</div>\n      <div class="ng-dbox" data-lv="{2}"><p id="ngDesc">{3}</p>\n        <div class="ng-rows">{4}</div>\n      </div>\n      <div class="ng-tg"><span><b>Açılış hikâyesi</b><small>Görev başlamadan önce ARES-1 sinemasını oynat.</small></span><div class="m2-tg {5}" id="ngIntro" role="switch"></div></div>\n    </div>\n    <div class="ng-right">{6}{7}</div>':
      '<div class="ng-left">\n      <label class="ng-lbl">Missionsname</label><input class="md-in ng-name" id="ngName" maxlength="24" placeholder="ARES-1" value="{0}">\n      <label class="ng-lbl">Schwierigkeit</label>\n      <div class="ng-diffs">{1}</div>\n      <div class="ng-dbox" data-lv="{2}"><p id="ngDesc">{3}</p>\n        <div class="ng-rows">{4}</div>\n      </div>\n      <div class="ng-tg"><span><b>Eröffnungsgeschichte</b><small>Vor Missionsbeginn die ARES-1-Filmsequenz abspielen.</small></span><div class="m2-tg {5}" id="ngIntro" role="switch"></div></div>\n    </div>\n    <div class="ng-right">{6}{7}</div>',
    "Aletlerin ürettiği veri anten kapasitesini aştı; bilimin %{0}'i Dünya'ya ulaşamadı.":
      "Die Daten der Instrumente überstiegen die Antennenkapazität; {0} % der Wissenschaft erreichten die Erde nie.",
    "Görev planlanan {0} solu {1} sol aştı: erzak ve bütçe zorlandı.":
      "Die Mission überschritt die geplanten {0} Sols um {1} Sols: Vorräte und Budget wurden knapp.",
    "{0} kez kritik yaşam değeri kaydedildi: oksijen, su veya yiyecek tükenmeye yaklaştı.":
      "{0}-mal wurde ein kritischer Lebenswert erfasst: Sauerstoff, Wasser oder Nahrung gingen fast aus.",
    "Bilim hedefinin yarısına ulaşılmadı: daha çok rapor göndermek ve hedefe uygun gözlem yapmak puanı artırır.":
      "Weniger als die Hälfte des Wissenschaftsziels wurde erreicht: Mehr Berichte und zum Ziel passende Beobachtungen erhöhen die Punktzahl.",
    "Görev başarısı": "Missionserfolg",
    "Bilim değeri": "Wissenschaftswert",
    "Kaynak verimliliği": "Ressourceneffizienz",
    "Zaman yönetimi": "Zeitmanagement",
    Atla: "Überspringen",
    Turkish: "Türkisch",
    İngilizce: "Englisch",
    Almanca: "Deutsch",
    İspanyolca: "Spanisch",
    Genel: "Allgemein",
    Ses: "Audio",
    Görüntü: "Grafik",
    Arayüz: "Oberfläche",
    Erişilebilirlik: "Barrierefreiheit",
    Kontroller: "Steuerung",
    Dil: "Sprache",
    Oynanış: "Spielablauf",
    Zorluk: "Schwierigkeit",
    "Açlık, susuzluk ve oksijen tüketimini; radyasyon, fırtına ve meteor hasarını ve iyileşme hızını belirler.":
      "Bestimmt Hunger-, Durst- und Sauerstoffverbrauch, Strahlungs-, Sturm- und Meteorschaden sowie die Heilungsrate.",
    "Etkileşim ipuçları": "Interaktionshinweise",
    "Ekranın altındaki “F: topla”, “E: kullan” gibi ipuçlarını göster.":
      "Hinweise wie „F: aufheben“ und „E: benutzen“ unten am Bildschirm anzeigen.",
    "Hasar ve kazanç sayıları": "Schadens- und Gewinnzahlen",
    "Oyuncunun üzerinde beliren +/− sayılarını göster.": "Die +/−-Zahlen über der Spielfigur anzeigen.",
    "Açılış hikâyesi": "Eröffnungsgeschichte",
    "Her yeni görevde ARES-1 açılış sinemasını oynat.":
      "Bei jeder neuen Mission die Eröffnungssequenz von ARES-1 abspielen.",
    "Otomatik kayıt": "Automatisches Speichern",
    "Görevi belirli aralıklarla kendiliğinden kaydet.":
      "Die Mission in regelmäßigen Abständen automatisch speichern.",
    Kapalı: "Aus",
    "Ses düzeyleri": "Lautstärke",
    "Genel ses": "Gesamtlautstärke",
    Müzik: "Musik",
    Efektler: "Effekte",
    "Çapa, toplama, meteor, telsiz ve arayüz sesleri.":
      "Hacke, Aufsammeln, Meteore, Funk und Oberflächengeräusche.",
    "Ortam sesi": "Umgebungsgeräusche",
    "Rüzgâr ve kum fırtınası uğultusu.": "Wind und Heulen des Sandsturms.",
    "Grafik kalitesi": "Grafikqualität",
    "Ultra grafik (WebGL)": "Ultra-Grafik (WebGL)",
    "Ana menü manzarası ve hikâyedeki gezegenler ekran kartıyla işlenir. Zayıf bilgisayarlarda kapatabilirsin.":
      "Die Landschaft im Hauptmenü und die Planeten in der Geschichte werden von der Grafikkarte berechnet. Auf schwächeren Computern kannst du das ausschalten.",
    "Parçacık yoğunluğu": "Partikeldichte",
    "Toz, duman, kıvılcım ve patlama parçacıkları.": "Staub-, Rauch-, Funken- und Explosionspartikel.",
    Düşük: "Niedrig",
    Orta: "Mittel",
    Yüksek: "Hoch",
    "Atmosfer efektleri": "Atmosphäreneffekte",
    "Ufuk pusu, süzülen toz perdeleri ve havadaki zerreler.":
      "Dunst am Horizont, ziehende Staubschleier und Schwebeteilchen in der Luft.",
    "Film greni": "Filmkorn",
    "Menü ve hikâyede sinematik gren dokusu.": "Kinoartige Körnung im Menü und in der Geschichte.",
    Ekran: "Bildschirm",
    "FPS sınırı": "FPS-Begrenzung",
    "Ekran yenilemesiyle eşitle.": "Mit der Bildwiederholrate synchronisieren.",
    "Tam ekran": "Vollbild",
    "Arayüz ölçeği": "Oberflächenskalierung",
    "Gün kartı, görev kartı, durum barları ve envanter boyutu.":
      "Größe von Tageskarte, Missionskarte, Statusleisten und Inventar.",
    Küçük: "Klein",
    Büyük: "Groß",
    "Harita boyutu": "Kartengröße",
    "Altyazı boyutu": "Untertitelgröße",
    "Açılış hikâyesindeki altyazılar.": "Untertitel in der Eröffnungsgeschichte.",
    "Hikâye anları": "Story-Momente",
    "İlk fırtına, radyasyon, nadir taş gibi anlarda kısa sahne ve iç ses. Kapalıyken yalnızca acil hedef gösterilir.":
      "Kurze Szenen und innere Stimme bei Schlüsselmomenten wie dem ersten Sturm, Strahlung oder einem seltenen Stein. Wenn aus, wird nur das dringende Ziel gezeigt.",
    "Ekran sarsıntısı": "Bildschirmwackeln",
    "Meteor, fırtına ve patlamalarda kamera sarsıntısının şiddeti.":
      "Stärke des Kamerawackelns bei Meteoriten, Stürmen und Explosionen.",
    "Parlamaları azalt": "Blitze reduzieren",
    "Meteor çarpması ve patlamalardaki beyaz ekran parlamalarını yumuşat.":
      "Die weißen Bildschirmblitze bei Meteoriteneinschlägen und Explosionen abschwächen.",
    "Yüksek kontrast": "Hoher Kontrast",
    "Arayüz metinlerini ve panelleri daha belirgin yap.":
      "Texte und Panels der Oberfläche deutlicher hervorheben.",
    Etkin: "Aktiviert",
    '<div class="m2-sec">Klavye</div><div class="m2-keys">':
      '<div class="m2-sec">Tastatur</div><div class="m2-keys">',
    Hareket: "Bewegung",
    Koş: "Rennen",
    "Etkileşim / rokete gir": "Interagieren / Rakete betreten",
    "Topla · ek · sula · hasat": "Aufheben · pflanzen · gießen · ernten",
    "Medikit kullan": "Medkit benutzen",
    "Rehber kitap": "Handbuch",
    "Çapayla kaz": "Mit der Hacke graben",
    "Sol tık": "Linksklick",
    "Eşyayı eline al": "Gegenstand in die Hand nehmen",
    Merdiven: "Leiter",
    Duraklat: "Pause",
    "Hikâyeyi geç": "Geschichte überspringen",
    "Space (basılı)": "Leertaste (halten)",
    Harita: "Karte",
    "sağ üst": "oben rechts",
    '</div>\n      <div class="m2-sec">Dokunmatik</div><div class="m2-keys"><div><span>Hareket</span><kbd>sol joystick</kbd></div><div><span>Eylemler</span><kbd>sağ düğmeler</kbd></div></div>':
      '</div>\n      <div class="m2-sec">Touch</div><div class="m2-keys"><div><span>Bewegung</span><kbd>linker Joystick</kbd></div><div><span>Aktionen</span><kbd>rechte Tasten</kbd></div></div>',
    "ROKET İÇİ": "IN DER RAKETE",
    '<h4>GÖREV DURUMU</h4>\n    <div class="m2-bars">{0}{1}{2}{3}</div>\n    <dl class="m2-kv"><dt>Görev</dt><dd>{4}</dd><dt>Kıyafet</dt><dd>{5}</dd>\n      <dt>Ana motor</dt><dd style="color:{6}">{7}</dd>\n      <dt>Fırtına kalkanı</dt><dd>{8}</dd><dt>Roket boyası</dt><dd>{9}</dd>\n      <dt>Kargo</dt><dd>{10} / {11}</dd><dt>Oynama süresi</dt><dd>{12}</dd></dl>\n    <h4>KAYNAKLAR</h4>\n    <div class="m2-res"><span><img src="{13}">{14}</span><span><img src="{15}">{16}</span><span><i class="ug-au"></i>{17}</span>{18}</div>':
      '<h4>MISSIONSSTATUS</h4>\n    <div class="m2-bars">{0}{1}{2}{3}</div>\n    <dl class="m2-kv"><dt>Mission</dt><dd>{4}</dd><dt>Anzug</dt><dd>{5}</dd>\n      <dt>Haupttriebwerk</dt><dd style="color:{6}">{7}</dd>\n      <dt>Sturmschild</dt><dd>{8}</dd><dt>Raketenlackierung</dt><dd>{9}</dd>\n      <dt>Fracht</dt><dd>{10} / {11}</dd><dt>Spielzeit</dt><dd>{12}</dd></dl>\n    <h4>RESSOURCEN</h4>\n    <div class="m2-res"><span><img src="{13}">{14}</span><span><img src="{15}">{16}</span><span><i class="ug-au"></i>{17}</span>{18}</div>',
    "Motoru onardın, numuneleri yükledin ve <b>Dünya'ya geri döndün!</b><br><br>":
      "Du hast das Triebwerk repariert, die Proben geladen und bist <b>zur Erde zurückgekehrt!</b><br><br>",
    "⏱ Süre: <b>": "⏱ Zeit: <b>",
    "🌍 Ziyaret edilen gezegen: <b>": "🌍 Besuchte Planeten: <b>",
    "📦 Getirilen numune: <b>": "📦 Mitgebrachte Proben: <b>",
    "</b><br>📅 Mars'ta geçen gün: <b>": "</b><br>📅 Tage auf dem Mars: <b>",
    "📋 Tamamlanan görev: <b>": "📋 Erledigte Missionen: <b>",
    '<h4 style="margin:6px 0;color:#fff;text-align:left">Görev sonrası analiz</h4><ul class="wr-why">{0}</ul>':
      '<h4 style="margin:6px 0;color:#fff;text-align:left">Analyse nach der Mission</h4><ul class="wr-why">{0}</ul>',
    "Hava kilidinden dışarı çık — <b>E</b>": "Durch die Luftschleuse hinaus — <b>E</b>",
    "Haritadaki ◆ işaretine yürü": "Gehe zu einer ◆-Markierung auf der Karte",
    "Numunenin yanında <b>F</b>'ye bas": "Drücke <b>F</b> neben der Probe",
    "Toplam <b>5</b> numune topla": "Insgesamt <b>5</b> Proben sammeln",
    "Merdivenden makine dairesine in — <b>S</b>": "Die Leiter hinunter in den Maschinenraum — <b>S</b>",
    "<b>ALET SANDIĞI</b> → <b>E</b> → Çapa: <b>Al</b>":
      "<b>WERKZEUGKISTE</b> → <b>E</b> → Hacke: <b>Nehmen</b>",
    "Alet sandığından <b>tohum</b> al": "Nimm <b>Saatgut</b> aus der Werkzeugkiste",
    "Dışarıda yere <b>sol tıkla</b> — çapayla kaz":
      "Draußen auf den Boden <b>linksklicken</b> — mit der Hacke graben",
    "Çukurun yanında <b>F</b> ile tohum ek": "Drücke <b>F</b> neben dem Loch, um zu säen",
    "Su şişesini eline al — alttaki numara tuşu": "Nimm die Wasserflasche — Zifferntaste unten",
    "<b>F</b> ile iç (ya da roketin mutfağında <b>İç</b>)":
      "Mit <b>F</b> trinken (oder <b>Trinken</b> in der Raketenküche)",
    "Rokete gir, komuta güvertesine çık": "Steig in die Rakete, klettere zum Kommandodeck",
    "Soldaki <b>İLETİŞİM</b> masasında <b>E</b>": "<b>E</b> am <b>KOMMUNIKATIONS</b>-Pult links",
    "<b>Rapor hazırla</b> → gözlem seç, not yaz → <b>Dünya'ya gönder</b>":
      "<b>Bericht erstellen</b> → Beobachtungen wählen, Notiz schreiben → <b>Zur Erde senden</b>",
    "Turuncu fırtına uyarısını bekle (Gün 2, ": "Warte auf die orange Sturmwarnung (Tag 2, ",
    "Uyarı çıkınca 45 sn içinde rokete gir": "Wenn sie erscheint, innerhalb von 45 s in die Rakete",
    "Fırtına bitene kadar içeride kal": "Bleib drinnen, bis der Sturm vorbei ist",
    "Fırtınanın motoru bozması — duman çıkar": "Der Sturm beschädigt das Triebwerk — es raucht",
    "4 onarım aşamasını tamamla": "Schließe die 4 Reparaturschritte ab",
    "Yeşil radyasyon uyarısını bekle (Gün 3)": "Warte auf die grüne Strahlungswarnung (Tag 3)",
    "Dalga geçene kadar içeride kal": "Bleib drinnen, bis die Welle vorbei ist",
    "Su şişesini eline al, parselin yanında <b>F</b> ile sula":
      "Nimm die Wasserflasche und gieße mit <b>F</b> am Beet",
    "Halka sarıya dönene kadar bekle": "Warte, bis der Ring gelb wird",
    "Dünya'nın yanıtını bekle (~½ sol)": "Warte auf die Antwort der Erde (~½ Sol)",
    "Komuta güvertesi → <b>İLETİŞİM</b> → <b>E</b>": "Kommandodeck → <b>KOMMUNIKATION</b> → <b>E</b>",
    "Gelen kutusu → <b>YANIT</b> etiketli mesajı aç": "Posteingang → Nachricht mit <b>ANTWORT</b> öffnen",
    "Çürük patates çantanda olsun (hasattan çıkar)":
      "Halte eine faule Kartoffel in der Tasche (aus der Ernte)",
    "Çürük patates → <b>Dünya'ya gönder</b>": "Faule Kartoffel → <b>Zur Erde senden</b>",
    "Laboratuvar inceliyor — kısa sürede yanıt gelir": "Das Labor untersucht sie — die Antwort kommt bald",
    "Gelen kutusu → <b>ANALİZ</b> mesajı: çürümenin nedeni":
      "Posteingang → <b>ANALYSE</b>-Nachricht: warum sie faulte",
    "Alet sandığından <b>radyasyon ölçeri</b> al":
      "Nimm das <b>Strahlungsmessgerät</b> aus der Werkzeugkiste",
    "Ölçeri eline al — numara tuşu": "Nimm das Messgerät in die Hand — Zifferntaste",
    "Toprağa <b>sol tıkla</b> — 3 farklı yer": "Auf den Boden <b>linksklicken</b> — 3 verschiedene Stellen",
    "Yeşil bayraklı yer bul (1,0 µSv/h altı)": "Finde eine Stelle mit grüner Fahne (unter 1,0 µSv/h)",
    "Sula, büyüt ve sağlıklı hasat al": "Gießen, wachsen lassen und gesund ernten",
    "Meteor düşmesini bekle — uğultu ve gölge": "Warte auf einen Meteor — Grollen und Schatten",
    "Kraterin çevresindeki sarı parçaları <b>F</b> ile topla (3)":
      "Sammle die gelben Stücke um den Krater mit <b>F</b> (3)",
    "Alet sandığından <b>jeolog kazmasını</b> al": "Nimm die <b>Geologenspitzhacke</b> aus der Werkzeugkiste",
    "Roketten uzaklaş, haritadaki <b>?</b> işaretine git":
      "Entferne dich von der Rakete, geh zur <b>?</b>-Markierung auf der Karte",
    "Taşın yanında <b>F</b> — kazmayla 3 vuruşta kır":
      "<b>F</b> neben dem Stein — mit 3 Schlägen zerschlagen",
    "Bilinmeyen taşı çapayla çıkar": "Grabe einen unbekannten Stein mit der Hacke aus",
    "Rokete gir → komuta güvertesi → <b>Kargo terminali</b>":
      "In die Rakete → Kommandodeck → <b>Frachtterminal</b>",
    "<b>ANALİZ İÇİN</b> satırında <b>Analize gönder</b>":
      "In der Zeile <b>ZUR ANALYSE</b>: <b>Zur Analyse senden</b>",
    "Malzeme topla: 8 metal, 1 ⭐, 2 olivin": "Material sammeln: 8 Metall, 1 ⭐, 2 Olivin",
    "Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b>":
      "Wohndeck → <b>FERTIGUNGSWERKSTATT</b> → <b>E</b>",
    "Kıyafet setleri → <b>Öncü Mk-II</b> → Üret ve giy":
      "Anzugsets → <b>Pionier Mk-II</b> → Herstellen und anziehen",
    "Malzeme topla: 10 altın, 3 titanyum": "Material sammeln: 10 Gold, 3 Titan",
    "Atölye → <b>Roket geliştirme</b> sekmesi": "Werkstatt → Reiter <b>Raketen-Upgrades</b>",
    "<b>Titanyum Plakalar</b> → <b>Kur</b>": "<b>Titanplatten</b> → <b>Installieren</b>",
    "Kıyafet setleri → <b>Kaşif Mk-I</b> → Üret ve giy":
      "Anzugsets → <b>Entdecker Mk-I</b> → Herstellen und anziehen",
    "Roketin yanında <b>F</b> ile kargoya yükle (10)":
      "Neben der Rakete mit <b>F</b> in den Frachtraum laden (10)",
    "Komuta güvertesi → <b>NAVİGASYON</b> → <b>E</b>": "Kommandodeck → <b>NAVIGATION</b> → <b>E</b>",
    "<b>EVE DÖN</b>'e bas": "Drücke <b>HEIMKEHR</b>",
    "UYKU KAPSÜLÜ": "SCHLAFKAPSEL",
    "Bu taşı kırmak için <b>jeolog kazması</b> gerekli — makine dairesindeki <b>alet sandığından</b> al":
      "Für diesen Stein brauchst du die <b>Geologenspitzhacke</b> — nimm sie aus der <b>Werkzeugkiste</b> im Maschinenraum",
    "JENERATÖR ARIZALI": "GENERATOR AUSGEFALLEN",
    "YAPAY YERÇEKİMİ": "KÜNSTLICHE SCHWERKRAFT",
    "⚠️ <b>Yapay yerçekimi jeneratörü durdu</b> — roketin içi de Mars yerçekiminde (0,38 g). Motoru onarınca geri gelir.":
      "⚠️ <b>Künstlicher Schwerkraftgenerator ausgefallen</b> — auch im Inneren der Rakete herrscht jetzt Marsschwerkraft (0,38 g). Nach der Triebwerksreparatur kommt sie zurück.",
    "✅ Yapay yerçekimi yeniden aktif (1 g)": "✅ Künstliche Schwerkraft wieder aktiv (1 g)",
    "🪐 <b>Mars yerçekimi: 0,38 g</b> — adımların seker, durması zordur. <b>Space</b> ile zıpla.":
      "🪐 <b>Marsschwerkraft: 0,38 g</b> — deine Schritte federn und Anhalten ist schwer. Mit <b>Leertaste</b> springen.",
    "Uff… Uzun bir uykuydu. ARES-1 yerde, ben de sağ salimim.":
      "Puh… Das war ein langer Schlaf. ARES-1 ist gelandet, und ich bin heil und gesund.",
    "Burada hayatta kalmalı, Mars'ı araştırmalı ve sonunda eve dönmeliyim.":
      "Ich muss hier überleben, den Mars erforschen und am Ende nach Hause zurückkehren.",
    "Önce makine dairesindeki alet sandığından ekipmanımı alayım. Sol üstteki görev kartı yolu gösterir.":
      "Zuerst hole ich meine Ausrüstung aus der Werkzeugkiste im Maschinenraum. Die Missionskarte oben links zeigt mir den Weg.",
    "Bu uğultu da ne?… Rüzgâr bir anda döndü!":
      "Was ist das für ein Heulen?… Der Wind hat plötzlich gedreht!",
    "Kum her yeri yutuyor, önümü göremiyorum… Bu hıza dayanamam.":
      "Der Sand verschluckt alles, ich sehe nichts mehr… Diesem Tempo halte ich nicht stand.",
    "Bir dahakine bu rüzgâra dayanmak için atölyede kıyafetimi ve roketimi güçlendirmeliyim.":
      "Damit ich diesem Wind nächstes Mal standhalte, muss ich in der Werkstatt meinen Anzug und die Rakete verstärken.",
    "Ama şimdi hemen rokete gitmeliyim!": "Aber jetzt muss ich sofort zur Rakete!",
    "Fırtınadan korun — rokete sığın": "Schutz vor dem Sturm — in die Rakete",
    "Kapağı son anda kapattım… Gövde zangır zangır titriyor.":
      "Die Luke im letzten Moment geschlossen… Der Rumpf bebt heftig.",
    "Dışarıda kalsam rüzgâr beni savururdu. Bir dahakine uyarı kartını görünce erkenden döneceğim.":
      "Draußen hätte mich der Wind umhergeschleudert. Nächstes Mal kehre ich zurück, sobald ich die Warnkarte sehe.",
    "Gövde zangır zangır titriyor… Dışarıda kum fırtınası kopmuş.":
      "Der Rumpf bebt heftig… Draußen tobt ein Sandsturm.",
    "İyi ki içerideyim. Fırtına bitene kadar buradan çıkmıyorum.":
      "Zum Glück bin ich drinnen. Bis der Sturm vorbei ist, gehe ich nicht raus.",
    "ARES-1, telemetride ana motor arızası görüyoruz!":
      "ARES-1, die Telemetrie zeigt einen Ausfall des Haupttriebwerks!",
    "Fırtına motoru vurmuş… Bu motor olmadan eve dönüş yok.":
      "Der Sturm hat das Triebwerk erwischt… Ohne es gibt es keinen Heimweg.",
    "Fırtına diner dinmez makine dairesine inip onarmalıyım.":
      "Sobald der Sturm nachlässt, muss ich in den Maschinenraum und es reparieren.",
    "Başım dönüyor… Canım neden bu kadar hızlı azalıyor?":
      "Mir ist schwindelig… Warum sinkt meine Gesundheit so schnell?",
    "Dozimetre çıldırmış — güneş patlaması! Bu radyasyon kıyafetimden geçiyor.":
      "Das Dosimeter spielt verrückt — eine Sonneneruption! Die Strahlung dringt durch meinen Anzug.",
    "Bir dahakine etkilenmemek için atölyede astronot kıyafetimi geliştirmeliyim.":
      "Damit mich das nächstes Mal nicht trifft, muss ich in der Werkstatt meinen Raumanzug verbessern.",
    "Şimdilik tek çare roketin kalın gövdesi. Hemen içeri!":
      "Für den Moment schützt nur der dicke Raketenrumpf. Sofort rein!",
    "Gövde zırhı radyasyonu kesiyor, değerler düşüyor.":
      "Die Rumpfpanzerung blockt die Strahlung, die Werte sinken.",
    "Dalga geçene kadar içerideyim. En iyisi uyku kabininde dinlenmek.":
      "Ich bleibe drinnen, bis die Welle vorbei ist. Am besten ruhe ich mich in der Schlafkabine aus.",
    "Dozimetre bir anda yükseldi… Dışarıda güneş patlaması var.":
      "Das Dosimeter ist plötzlich hochgeschnellt… Draußen gibt es eine Sonneneruption.",
    "Gövde zırhı beni koruyor. Dalga geçene kadar dışarı çıkmayacağım.":
      "Die Rumpfpanzerung schützt mich. Bis die Welle vorbei ist, gehe ich nicht raus.",
    "Motor yeniden çalışıyor… Ama bir sonraki fırtınada yine bozulabilir.":
      "Das Triebwerk läuft wieder… Aber der nächste Sturm könnte es wieder beschädigen.",
    "Atölyedeki roket geliştirmeden gövdeye titanyum zırh takmalıyım. Bunun için altın ve titanyum gerek.":
      "Ich sollte in der Werkstatt unter Raketen-Upgrades eine Titanpanzerung anbringen. Dafür brauche ich Gold und Titan.",
    "Canım çok hızlı eridi… Bu standart kıyafet radyasyonu durdurmuyor.":
      "Meine Gesundheit ist so schnell geschwunden… Dieser Standardanzug hält keine Strahlung ab.",
    "Atölyede radyasyon katmanlı bir kıyafet üretmeliyim. Bir sonraki dalgaya hazırlıklı olacağım.":
      "Ich muss in der Werkstatt einen strahlengeschützten Anzug herstellen. Auf die nächste Welle bin ich vorbereitet.",
    "Bu ne?… Patatesler kararmış, yumuşamış.": "Was ist das?… Die Kartoffeln sind dunkel und weich geworden.",
    "Suyu da verdim, ışığı da aldı. Sorun toprakta olmalı ama bunu burada çözemem.":
      "Ich habe gegossen, und sie hatten Licht. Es muss am Boden liegen, aber das kann ich hier nicht klären.",
    "Çürük patates çantamda. Rokete dönüp komuta güvertesindeki kargo terminalinden Dünya'ya göndereyim.":
      "Die faule Kartoffel ist in meiner Tasche. Ich gehe zur Rakete und schicke sie über das Frachtterminal auf dem Kommandodeck zur Erde.",
    "Laboratuvar inceleyip neden çürüdüğünü bana yazar.":
      "Das Labor untersucht sie und schreibt mir, warum sie gefault ist.",
    "Rokete dön": "Zurück zur Rakete",
    "Komuta güvertesine çık — merdivende W": "Zum Kommandodeck klettern — W an der Leiter",
    "Kargo terminalinde E'ye bas": "Am Frachtterminal E drücken",
    "Çürük patates → Dünya'ya gönder": "Faule Kartoffel → Zur Erde senden",
    "ARES-1, burası Dünya laboratuvarı. Patates numunen elimize ulaştı.":
      "ARES-1, hier ist das Erdlabor. Deine Kartoffelprobe ist angekommen.",
    "Çürümenin nedenini bulduk. Raporu gelen kutuna yolladık, hemen oku.":
      "Wir haben die Ursache gefunden. Der Bericht ist in deinem Posteingang — lies ihn sofort.",
    "Komuta güvertesi → İLETİŞİM masası → E": "Kommandodeck → Kommunikationspult → E",
    "Gelen kutusu → ANALİZ mesajını aç": "Posteingang → ANALYSE-Nachricht öffnen",
    "Demek sebep toprağın radyasyonuymuş… Mikrop değil.": "Es war also die Strahlung im Boden… keine Keime.",
    "Bundan sonra ekmeden önce radyasyon ölçerle toprağı ölçüp yeşil çıkan yere ekeceğim.":
      "Ab jetzt messe ich den Boden vor dem Pflanzen mit dem Strahlungsmessgerät und pflanze nur, wo es grün anzeigt.",
    "Aman Allah'ım… Bu taş kendi kendine ışık saçıyor!":
      "Oh mein Gott… Dieser Stein leuchtet ganz von selbst!",
    "Böyle bir mineral hiçbir kayıtta yok. İçinde ne var bunun?":
      "So ein Mineral ist nirgends verzeichnet. Was steckt da drin?",
    "Hemen rokete götürüp kargo terminalinden Dünya'ya analize göndermeliyim!":
      "Ich muss ihn zur Rakete bringen und über das Frachtterminal zur Analyse zur Erde schicken!",
    "Taşı rokete götür": "Bring den Stein zur Rakete",
    "Parlayan taş → Analize gönder": "Leuchtender Stein → Zur Analyse senden",
    "Vay… İçinden ışık sızan bir taş! Böylesini hiç görmedim.":
      "Wow… Ein Stein, aus dem Licht dringt! So etwas habe ich noch nie gesehen.",
    "Çok güzel… ama ne olduğunu bilmeden kullanmamalıyım.":
      "Wunderschön… aber ich sollte ihn nicht benutzen, ohne zu wissen, was er ist.",
    "Rokete götürüp kargo terminalinden Dünya'ya analize göndermeliyim. İnceleyip bana bildirsinler.":
      "Ich bringe ihn zur Rakete und schicke ihn über das Frachtterminal zur Analyse zur Erde. Sie sollen ihn untersuchen und mir Bescheid geben.",
    "Bilinmeyen taş → Analize gönder": "Unbekannter Stein → Zur Analyse senden",
    "ARES-1, numunen laboratuvara ulaştı. Ona bir ad verdik: ":
      "ARES-1, deine Probe ist im Labor angekommen. Wir haben ihr einen Namen gegeben: ",
    "Bileşimi, ne kadar tehlikeli olduğu ve ne işe yarayacağı raporda. Gelen kutuna yolladık.":
      "Zusammensetzung, Gefährlichkeit und Verwendung stehen im Bericht. Er ist in deinem Posteingang.",
    "… Demek adı buymuş. Artık bu taşı tanıyorum.": "… So heißt er also. Jetzt kenne ich diesen Stein.",
    "Haritada da adıyla görünüyor. Başka bilinmeyen taş bulursam onları da kırıp göndereceğim.":
      "Auf der Karte erscheint er jetzt auch mit Namen. Finde ich weitere unbekannte Steine, zerschlage und schicke ich sie auch.",
    "ARES-1, gönderdiğin parlayan taşın analizi bitti.":
      "ARES-1, die Analyse des leuchtenden Steins ist fertig.",
    "Ekip şaşkın — sonuçlar gelen kutunda. Okumadan o taşa dokunma!":
      "Das Team ist verblüfft — die Ergebnisse sind im Posteingang. Fass den Stein nicht an, bevor du sie gelesen hast!",
    "Gelen kutusu → Ares taşı analizini aç": "Posteingang → Analyse des Ares-Steins öffnen",
    "ARES-1, görevlerin tamam. Dünya'ya dönüş penceresi açıldı.":
      "ARES-1, deine Missionen sind erfüllt. Das Rückkehrfenster zur Erde ist offen.",
    "Eve dönme zamanı… Komuta güvertesinde navigasyonu açıp EVE DÖN'e basacağım.":
      "Zeit für die Heimkehr… Ich öffne die Navigation auf dem Kommandodeck und drücke HEIMKEHR.",
    "Navigasyondan EVE DÖN": "In der Navigation HEIMKEHR wählen",
    Devam: "Weiter",
    "GÖREV KONTROL · TELSİZ": "MISSIONSKONTROLLE · FUNK",
    "KOMUTAN · İÇ SES": "KOMMANDANT · INNERE STIMME",
    "ACİL HEDEF": "DRINGENDES ZIEL",
    "ACİL HEDEF · ": "DRINGENDES ZIEL · ",
    "⏸ GÖREV BEKLEMEDE · ÖNCE ACİL HEDEF": "⏸ MISSION PAUSIERT · ZUERST DRINGENDES ZIEL",
    "Bayrak kaldırıldı. Ölçtüğün yerleri istediğin zaman temizleyebilirsin.":
      "Fahne entfernt. Gemessene Stellen kannst du jederzeit räumen.",
    "🌅 Gün ": "🌅 Tag ",
    " başladı": " hat begonnen",
    "Bitkin düştün, revire taşındın.":
      "Du bist vor Erschöpfung zusammengebrochen und wurdest in die Krankenstation gebracht.",
    "🌲 Mahsul hazır! (F ile hasat)": "🌲 Ernte bereit! (mit F ernten)",
    "SİNYAL ZAYIF": "SCHWACHES SIGNAL",
    "HARİTA · ": "KARTE · ",
    "Ekim için uygun": "Zum Pflanzen geeignet",
    "Patates çürür": "Kartoffeln verfaulen",
    YÜKSEK: "HOCH",
    "Patatesler çürümüş!": "Die Kartoffeln sind verfault!",
    "Patatesler çürük çıktı, bir tanesi çantanda. Roketteki <b>kargo terminalinden</b> Dünya'ya gönder, incelesinler.":
      "Die Kartoffeln sind verfault; eine ist in deinem Gepäck. Schick sie über das <b>Frachtterminal</b> der Rakete zur Erde, damit sie untersucht wird.",
    "Bu toprak radyasyonlu, patatesler yine çürüdü. Ekmeden önce radyasyon ölçerle ölç":
      "Dieser Boden ist radioaktiv, die Kartoffeln sind wieder verfault. Miss vor dem Pflanzen mit dem Strahlungsmessgerät",
    "Patatesler yine çürüdü": "Die Kartoffeln sind wieder verfault",
    "Çok uzak — ölçmek istediğin yere biraz yaklaş": "Zu weit — geh etwas näher an die Messstelle",
    "İniş platformu metal — ölçümü toprak üzerinde yap":
      "Die Landeplattform ist aus Metall — miss auf dem Boden",
    "<b>Güvenli toprak</b> (": "<b>Sicherer Boden</b> (",
    " µSv/h) — buraya kazıp patates ekebilirsin. Yeşil bayrak yeri işaretliyor.":
      " µSv/h) — hier kannst du graben und Kartoffeln pflanzen. Die grüne Fahne markiert die Stelle.",
    "Bu toprakta patates çürür (": "In diesem Boden verfaulen Kartoffeln (",
    " µSv/h). <b>1,0 µSv/h altını</b> ara — biraz uzaklaşıp yeniden ölç.":
      " µSv/h). Suche <b>unter 1,0 µSv/h</b> — geh ein Stück weiter und miss erneut.",
    "Toprağı ölçmek için <b>radyasyon ölçeri</b> makine dairesindeki <b>alet sandığından</b> al.":
      "Um den Boden zu messen, nimm das <b>Strahlungsmessgerät</b> aus der <b>Werkzeugkiste</b> im Maschinenraum.",
    "Prob toprağa hizalanıyor…": "Sonde wird am Boden ausgerichtet…",
    "Ölçülüyor… <b>%{0}</b>": "Messung… <b>{0} %</b>",
    '<span class="rd-vd"><b>RADYASYON {0}</b><small>{1} µSv/h · {2}</small></span>':
      '<span class="rd-vd"><b>STRAHLUNG {0}</b><small>{1} µSv/h · {2}</small></span>',
    '<p>Komutan,</p>\n  <p>Gönderdiğin çürük patatesi inceledik. Mikrop ya da aşırı sulama izi yok. Neden <b>toprağın radyasyonu</b>: patatesin ekildiği yer yüksek radyasyonlu.</p>\n  <div class="ltr-dir"><b>NE YAPMALI?</b><ol>\n    <li>Roketteki alet sandığından <b>radyasyon ölçeri</b> al.</li>\n    <li>Ekmeden önce toprağı ölç: ölçeri eline al ve toprağa <b>sol tıkla</b>.</li>\n    <li>Ekranda <b>RADYASYON NORMAL</b> yazan yere ek. Yüksek çıkan yerde patates çürür.</li></ol></div>\n  <div class="ltr-scale"><span style="flex:1;background:#4ade80">0 – 1,0 NORMAL</span><span style="flex:1;background:#fbbf24">1,0 – 2,0 DİKKAT</span><span style="flex:1;background:#ff5d5d">2,0+ YÜKSEK</span></div>':
      '<p>Kommandant,</p>\n  <p>Wir haben die verfaulte Kartoffel untersucht. Keine Spur von Mikroben oder zu viel Wasser. Die Ursache ist die <b>Bodenstrahlung</b>: Die Stelle, an der die Kartoffel wuchs, strahlt stark.</p>\n  <div class="ltr-dir"><b>WAS TUN?</b><ol>\n    <li>Nimm das <b>Strahlungsmessgerät</b> aus der Werkzeugkiste der Rakete.</li>\n    <li>Miss den Boden vor dem Pflanzen: Messgerät in die Hand nehmen und <b>links</b> auf den Boden klicken.</li>\n    <li>Pflanze dort, wo <b>STRAHLUNG NORMAL</b> angezeigt wird. Wo sie hoch ist, verfaulen Kartoffeln.</li></ol></div>\n  <div class="ltr-scale"><span style="flex:1;background:#4ade80">0 – 1,0 NORMAL</span><span style="flex:1;background:#fbbf24">1,0 – 2,0 VORSICHT</span><span style="flex:1;background:#ff5d5d">2,0+ HOCH</span></div>',
    "Çürük patates analizi": "Analyse der verfaulten Kartoffel",
    "Önceki kargo hâlâ inceleniyor — Dünya'nın cevabını bekle":
      "Die vorherige Fracht wird noch untersucht — warte auf die Antwort der Erde",
    "Çantanda çürük patates yok": "Keine verfaulte Kartoffel im Gepäck",
    "Çürük patates kargoyla Dünya'ya gönderildi. Cevap birazdan gelen kutunda.":
      "Verfaulte Kartoffel per Fracht zur Erde geschickt. Die Antwort kommt bald in deinen Posteingang.",
    "Mars yüzey görevi": "Mission auf der Marsoberfläche",
    "Mars'ta hayatta kal · keşfet · Dünya'ya raporla":
      "Überlebe auf dem Mars · erkunde · berichte an die Erde",
    "Oyuna Başla": "Spiel starten",
    "Yeni görev · açılış hikâyesiyle": "Neue Mission · mit Eröffnungsgeschichte",
    "Devam Et": "Fortsetzen",
    Kaydedilenler: "Spielstände",
    "Görev kayıtlarını yükle ya da sil": "Missionsspielstände laden oder löschen",
    Ayarlar: "Einstellungen",
    "Ses, görüntü ve performans": "Audio, Grafik und Leistung",
    "hareket ·": "bewegen ·",
    koş: "rennen",
    "etkileşim / rokete gir": "interagieren / Rakete betreten",
    "topla · ek · sula · hasat": "aufheben · pflanzen · gießen · ernten",
    medikit: "Medkit",
    "çapayla kaz": "mit der Hacke graben",
    "eşyayı eline al": "Gegenstand in die Hand nehmen",
    "rehber kitap": "Handbuch",
    duraklat: "Pause",
    "Görev Kontrol bağlantısı: AKTİF": "Verbindung zur Missionskontrolle: AKTIV",
    Geç: "Überspringen",
    "basılı tut ·": "(gedrückt halten) ·",
    "ARES-1 · ARŞİV": "ARES-1 · ARCHIV",
    "ARES-1 · SİSTEM": "ARES-1 · SYSTEM",
    "Varsayılana döndür": "Standard wiederherstellen",
    "ARES-1 · GÖREV DURAKLATILDI": "ARES-1 · MISSION PAUSIERT",
    Duraklatıldı: "Pausiert",
    "Göreve geri dön · Esc": "Zurück zur Mission · Esc",
    Kaydet: "Speichern",
    "Görevin şu anki durumunu kaydet": "Den aktuellen Stand der Mission speichern",
    "Tehlikeler, sistemler ve ipuçları · R": "Gefahren, Systeme und Tipps · R",
    "Dil, zorluk, ses, görüntü, arayüz": "Sprache, Schwierigkeit, Audio, Grafik, Oberfläche",
    "Ana menüye dön": "Zurück zum Hauptmenü",
    "Kaydedilmemiş ilerleme kaybolur": "Nicht gespeicherter Fortschritt geht verloren",
    "ARES-1 · KAYIT": "ARES-1 · SPEICHERN",
    "Kaydı adlandır": "Spielstand benennen",
    Vazgeç: "Abbrechen",
    "ARES-1 · DİL": "ARES-1 · SPRACHE",
    "Dil değiştiriliyor": "Sprache wird geändert",
    "Dil değişikliğinin uygulanması için oyun yeniden başlatılacak. Görevin otomatik olarak kaydedilecek.":
      "Damit die Sprachänderung wirksam wird, startet das Spiel neu. Deine Mission wird automatisch gespeichert.",
    "Uygula ve yeniden başlat": "Übernehmen und neu starten",
    "Navigasyon Bilgisayarı": "Navigationscomputer",
    Rota: "Route",
    kapat: "schließen",
    "Tedarik & Ticaret": "Versorgung & Handel",
    "Erzak deposu": "Vorratslager",
    "📦 Kargo bölmesi · Dünya'ya götürülecek numuneler": "📦 Frachtraum · Proben für die Erde",
    "Numuneleri yükle": "Proben laden",
    "Uyku Kabini": "Schlafkabine",
    "Yataktan kalk": "Aufstehen",
    kalk: "aufstehen",
    "UYKUDA ZAMAN 2×": "IM SCHLAF ZEIT 2×",
    "Kapat (R)": "Schließen (R)",
    Kapsül: "Kapsel",
    İçerik: "Inhalt",
    "kapat · Al = çantaya · Koy =": "schließen · Nehmen = in die Tasche · Legen = in die",
    "Fabrikasyon Atölyesi": "Fertigungswerkstatt",
    "3B üretim ünitesi · EVA donanımı ve araç modifikasyonu":
      "3D-Fertigungseinheit · EVA-Ausrüstung und Fahrzeugmodifikation",
    "🧑‍🚀 Kıyafet setleri": "🧑‍🚀 Anzugsets",
    "🚀 Roket geliştirme": "🚀 Raketen-Upgrades",
    "kapat · kıyafet: metal + kristal + olivin · roket: altın + titanyum · en üst seviye: Ares taşı":
      "schließen · Anzug: Metall + Kristall + Olivin · Rakete: Gold + Titan · höchste Stufe: Aresstein",
    "ARES-1 · MODİFİKASYON": "ARES-1 · MODIFIKATION",
    "İletişim Terminali · Dünya": "Kommunikationsterminal · Erde",
    "Komuta güvertesi · yüksek kazançlı anten · yer istasyonu ağı":
      "Kommandodeck · Richtantenne · Bodenstationsnetz",
    "🛰️ Yer Birimi": "🛰️ Bodensegment",
    "📐 Görev Mimarisi": "📐 Missionsarchitektur",
    "kapat · yanıtlar ~½ sol (ACİL ~¼ sol) sonra gelir":
      "schließen · Antworten kommen nach ~½ Sol (DRINGEND ~¼ Sol)",
    "ARES-1 · GÖREV KONTROL HATTI": "ARES-1 · LEITUNG ZUR MISSIONSKONTROLLE",
    "Ana Motor · Onarım": "Haupttriebwerk · Reparatur",
    "Makine dairesi · ARES-1 itki çekirdeği": "Maschinenraum · Antriebskern von ARES-1",
    "AŞAMA 1/4": "STUFE 1/4",
    "çık · tamamlanan aşamalar kaydedilir": "verlassen · abgeschlossene Stufen werden gespeichert",
    "Yeni görev": "Neue Mission",
    İptal: "Abbrechen",
    "Görevi başlat": "Mission starten",
    "RADYASYON ÖLÇER": "STRAHLUNGSMESSER",
    "Dünyaya Hoş Geldin!": "Willkommen auf der Erde!",
    "Oyuna Devam Et": "Weiterspielen",
    "Ana Menüye Dön": "Zurück zum Hauptmenü",
    "GÖREV 1/8": "MISSION 1/8",
    Görev: "Mission",
    VÜCUT: "KÖRPER",
    NABIZ: "PULS",
    YERÇEKİMİ: "SCHWERKRAFT",
    RADYASYON: "STRAHLUNG",
    "MARS'A ULAŞILDI": "MARS ERREICHT",
    "MERIDIANI PLANUM · 1,95° G · 5,53° B": "MERIDIANI PLANUM · 1,95° S · 5,53° W",
    "ARES-1, iniş doğrulandı. Mars'a hoş geldin, Komutan.":
      "ARES-1, Landung bestätigt. Willkommen auf dem Mars, Kommandant.",
    "Kayıt adı": "Name des Spielstands",
    "Kapat (E)": "Schließen (E)",
    "Kalk (E)": "Aufstehen (E)",
    "Önceki (←)": "Zurück (←)",
    "Sonraki (→)": "Weiter (→)",
    "Çık (E)": "Verlassen (E)",
    '<h2><small>Bölüm 5</small>Tarım {0}</h2>\n    <ol><li>Alet sandığından {1} <b>çapayı</b> al. Çapayı eline al ve yere <b>sol tıkla</b>.</li>\n    <li>{2} <b>Tohumu</b> eline al, çukurun yanında <kbd>F</kbd>.</li>\n    <li>{3} <b>Suyu</b> eline al, <kbd>F</kbd> ile sula. Islak toprak bitkiyi 2,4 kat hızlı büyütür.</li>\n    <li>Halka <b>sarı</b> olunca <kbd>F</kbd> ile hasat et: 1–2 patates + 1 tohumluk patates. Çürük hasattan tohum çıkmaz.</li></ol>\n    <p>Büyümesi sulamadan yaklaşık 75 saniye sürer. Bitki aşamaları: filiz → fide → çiçekli bitki → hasat.</p>\n    <div class="warn">Kum fırtınasında bitkiler sallanır ama zarar görmez. Parselleri roketin yakınına aç ki fırtınada kaybolmayasın.</div>':
      '<h2><small>Kapitel 5</small>Landwirtschaft {0}</h2>\n    <ol><li>Nimm die {1} <b>Hacke</b> aus der Werkzeugkiste. Nimm die Hacke in die Hand und <b>klicke links</b> auf den Boden.</li>\n    <li>Nimm einen {2} <b>Samen</b> in die Hand und drücke neben dem Loch <kbd>F</kbd>.</li>\n    <li>Nimm {3} <b>Wasser</b> in die Hand und gieße mit <kbd>F</kbd>. Auf feuchtem Boden wächst die Pflanze 2,4-mal schneller.</li>\n    <li>Wenn der Ring <b>gelb</b> wird, ernte mit <kbd>F</kbd>: 1–2 Kartoffeln + 1 Saatkartoffel. Eine verfaulte Ernte liefert kein Saatgut.</li></ol>\n    <p>Ohne Gießen dauert das Wachstum etwa 75 Sekunden. Pflanzenstadien: Keim → Setzling → blühende Pflanze → Ernte.</p>\n    <div class="warn">Bei einem Sandsturm schwanken die Pflanzen, nehmen aber keinen Schaden. Lege deine Beete nahe der Rakete an, damit du dich im Sturm nicht verirrst.</div>',
  },
  es: {
    Donanım: "Equipamiento",
    "Roketteki alet sandığından <b>çapayı</b> al":
      "Coge la <b>azada</b> de la caja de herramientas del cohete",
    "Roketin yanında <b>E</b> ile gir → makine dairesi → <b>ALET SANDIĞI</b> → <b>E</b> → Çapa: <b>Al</b>.":
      "Junto al cohete pulsa <b>E</b> para entrar → sala de máquinas → <b>CAJA DE HERRAMIENTAS</b> → <b>E</b> → Azada: <b>Coger</b>.",
    Toplayıcı: "Recolector",
    "Etrafa saçılmış <b>5 metal numune</b> topla": "Recoge <b>5 muestras de metal</b> esparcidas",
    "Haritadaki ◆ işaretlerine yürü, numunenin yanında <b>F</b>'ye bas.":
      "Camina hasta los marcadores ◆ del mapa y pulsa <b>F</b> junto a una muestra.",
    Çiftçi: "Agricultor",
    "Toprağı kaz ve <b>tohum ek</b>": "Cava la tierra y <b>planta una semilla</b>",
    "Dışarıda yere <b>sol tıkla</b> (kaz), çukurun yanında <b>F</b> ile ek. Tohum alet sandığında.":
      "Fuera, haz <b>clic izquierdo</b> en el suelo (cavar) y planta con <b>F</b> junto al hoyo. Las semillas están en la caja de herramientas.",
    Susuzluk: "Sed",
    "Bir şişe <b>su iç</b>": "<b>Bebe</b> una botella de agua",
    "Su şişesini eline al (alttaki numara tuşu), sonra <b>F</b>'ye bas. Ya da roketteki <b>mutfakta</b> <b>İç</b>.":
      "Ten la botella de agua en la mano (tecla numérica de abajo) y pulsa <b>F</b>. O <b>Bebe</b> en la <b>cocina</b> del cohete.",
    "İlk Rapor": "Primer informe",
    "Dünya'ya <b>ilk raporunu gönder</b>": "<b>Envía tu primer informe</b> a la Tierra",
    "Komuta güvertesi → solda <b>İLETİŞİM</b> masası → <b>E</b> → <b>Rapor hazırla</b> → gözlem seç, not yaz → <b>Dünya'ya gönder</b>.":
      "Cubierta de mando → puesto de <b>COMUNICACIONES</b> a la izquierda → <b>E</b> → <b>Preparar informe</b> → selecciona observaciones, escribe una nota → <b>Enviar a la Tierra</b>.",
    Sığınak: "Resguardo",
    "Kum fırtınasını <b>roketin içinde atlat</b>": "<b>Resiste una tormenta de arena dentro del cohete</b>",
    "İlk fırtına <b>2. gün</b> gelir. Turuncu uyarı kartı çıkınca 45 sn içinde rokete gir ve fırtına bitene kadar içeride kal.":
      "La primera tormenta llega el <b>día 2</b>. Cuando aparezca la tarjeta de aviso naranja, entra en el cohete en menos de 45 s y quédate dentro hasta que termine.",
    Mühendis: "Ingeniero",
    "Kum fırtınasından sonra <b>ana motoru onar</b>":
      "<b>Repara el motor principal</b> tras la tormenta de arena",
    "2. gün gelen fırtına motoru bozar. Makine dairesi → <b>ANA MOTOR</b> → <b>E</b> → 4 aşamayı tamamla.":
      "La tormenta del día 2 avería el motor. Sala de máquinas → <b>MOTOR PRINCIPAL</b> → <b>E</b> → completa las 4 fases.",
    Kalkan: "Refugio",
    "Radyasyon dalgasını <b>roketin içinde atlat</b>":
      "<b>Resiste una ola de radiación dentro del cohete</b>",
    "İlk dalga <b>3. günün</b> başında gelir. Yeşil uyarı kartı çıkınca rokete gir; en kolayı uyku kabininde uyumak.":
      "La primera ola llega al comienzo del <b>día 3</b>. Cuando aparezca la tarjeta de aviso verde, entra en el cohete; lo más fácil es dormir en la cabina de descanso.",
    Hasatçı: "Cosechador",
    "Patatesi büyüt ve <b>hasat et</b>": "Cultiva una patata y <b>cosécha</b>",
    "Parseli <b>F</b> ile sula (hızlandırır). Halka sarı olunca <b>F</b> ile hasat et.":
      "Riega la parcela con <b>F</b> (acelera el crecimiento). Cuando el anillo se vuelva amarillo, cosecha con <b>F</b>.",
    Haberleşme: "Correspondencia",
    "Dünya'nın raporuna verdiği <b>resmî yanıtı oku</b>":
      "<b>Lee la respuesta oficial de la Tierra</b> a tu informe",
    "Yanıt raporundan ~½ sol sonra gelir (ACİL: ~¼ sol). İletişim terminali → <b>Gelen kutusu</b> → YANIT etiketli mesajı aç.":
      "La respuesta llega ~½ sol después de tu informe (URGENTE: ~¼ sol). Terminal de comunicaciones → <b>Bandeja de entrada</b> → abre el mensaje con la etiqueta RESPUESTA.",
    "Çürük Kargo": "Carga podrida",
    "Çürük patatesi <b>kargoyla Dünya'ya gönder</b>": "Envía la patata podrida <b>a la Tierra por carga</b>",
    "Radyasyonu yüksek toprağa ekilen patates çürük çıkar. Çürük patatesi rokete götür → komuta güvertesi → <b>Kargo terminali</b> → <b>Dünya'ya gönder</b>.":
      "Las patatas plantadas en suelo con mucha radiación salen podridas. Lleva la patata podrida al cohete → cubierta de mando → <b>Terminal de carga</b> → <b>Enviar a la Tierra</b>.",
    "Dünya'nın Cevabı": "Respuesta de la Tierra",
    "Dünya'dan gelen <b>analiz mesajını</b> oku": "Lee el <b>mensaje de análisis</b> de la Tierra",
    "Kargo ulaşınca Dünya kısa süre içinde cevap yazar. İletişim terminali → <b>Gelen kutusu</b> → ANALİZ etiketli mesaj.":
      "Cuando llega la carga, la Tierra responde enseguida. Terminal de comunicaciones → <b>Bandeja de entrada</b> → mensaje con la etiqueta ANÁLISIS.",
    Ölçüm: "Medición",
    "Radyasyon ölçerle <b>3 farklı yerde</b> toprağı ölç":
      "Mide el suelo en <b>3 lugares distintos</b> con el medidor de radiación",
    "Roketteki <b>alet sandığından</b> radyasyon ölçeri al. Dışarıda eline al (numara tuşu) ve toprağa <b>sol tıkla</b>. Her ölçüm yere renkli bir bayrak diker.":
      "Coge el medidor de radiación de la <b>caja de herramientas</b> del cohete. Fuera, sostenlo (tecla numérica) y haz <b>clic izquierdo</b> en el suelo. Cada medición clava una bandera de color.",
    "Temiz Toprak": "Suelo limpio",
    "Güvenli toprağa ek ve <b>sağlıklı hasat</b> al":
      "Planta en suelo seguro y consigue una <b>cosecha sana</b>",
    "<b>1,0 µSv/h</b> altında ölçülen (yeşil bayraklı) yere kaz, tohum ek, sula ve hasat et.":
      "Cava donde mediste menos de <b>1,0 µSv/h</b> (bandera verde), siembra, riega y cosecha.",
    "Altın Avcısı": "Buscador de oro",
    "Meteor kraterlerinden <b>3 altın parçası</b> topla":
      "Recoge <b>3 fragmentos de oro</b> de los cráteres de meteorito",
    "Meteor düştükten sonra kraterin çevresinde parlayan sarı parçaları ara, yanında <b>F</b>'ye bas.":
      "Después de que caiga un meteorito, busca los fragmentos amarillos brillantes alrededor del cráter y pulsa <b>F</b> junto a ellos.",
    Jeolog: "Geólogo",
    "Uzak bölgelerde <b>bilinmeyen bir taş</b> çıkar":
      "Extrae <b>una piedra desconocida</b> en una zona remota",
    "Alet sandığından <b>jeolog kazmasını</b> al. Tarayıcı bip sesi verince haritadaki <b>?</b> işaretine git ve taşı <b>F</b> ile kır.":
      "Coge el <b>pico de geólogo</b> de la caja de herramientas. Cuando el escáner pite, ve al marcador <b>?</b> del mapa y rompe la piedra con <b>F</b>.",
    "Numune Analizi": "Análisis de muestra",
    "Bilinmeyen taşı <b>analiz için Dünya'ya gönder</b>":
      "Envía la piedra desconocida <b>a la Tierra para analizarla</b>",
    "Komuta güvertesi → <b>Kargo terminali</b> → ANALİZ İÇİN satırında <b>Analize gönder</b>.":
      "Cubierta de mando → <b>Terminal de carga</b> → en la fila PARA ANÁLISIS, <b>Enviar a analizar</b>.",
    Terzi: "Sastre",
    "Fabrikasyon atölyesinde <b>yeni bir kıyafet</b> üret":
      "Fabrica <b>un traje nuevo</b> en el Taller de Fabricación",
    "Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b> → Kıyafet setleri → <b>Kaşif Mk-I</b> → Üret ve giy (4 metal).":
      "Cubierta habitable → <b>TALLER DE FABRICACIÓN</b> → <b>E</b> → Conjuntos de traje → <b>Explorador Mk-I</b> → Fabricar y ponerse (4 de metal).",
    "Radyasyon Zırhı": "Blindaje antirradiación",
    "Radyasyona dayanıklı <b>Öncü Mk-II</b> kıyafetini üret":
      "Fabrica el traje resistente a la radiación <b>Pionero Mk-II</b>",
    "Fabrikasyon atölyesi → Kıyafet setleri → <b>Öncü Mk-II</b> (radyasyon hasarı %40 azalır).":
      "Taller de fabricación → Trajes → <b>Pionero Mk-II</b> (daño por radiación −40 %).",
    "Zırh Ustası": "Maestro blindador",
    "Rokete <b>Titanyum Plakalar</b> zırhını tak":
      "Instala el blindaje de <b>placas de titanio</b> en el cohete",
    "Fabrikasyon atölyesi → <b>Roket geliştirme</b> → Titanyum Plakalar (fırtınada arıza olasılığı %60 → %35).":
      "Taller de fabricación → <b>Mejoras del cohete</b> → Placas de titanio (avería en tormenta 60 % → 35 %).",
    Kargo: "Carga",
    "Roketin kargosuna <b>10 numune</b> yükle": "Carga <b>10 muestras</b> en la bodega del cohete",
    "Metal = 1, ⭐ yıldız = 2 numune. Roketin yanında <b>F</b>'ye bas.":
      "Metal = 1, ⭐ estrella = 2 muestras. Pulsa <b>F</b> junto al cohete.",
    "Eve Dönüş": "Regreso a casa",
    "Roketle <b>Dünya'ya dön</b>": "<b>Vuelve a la Tierra</b> en el cohete",
    "Komuta güvertesi (en üst kat) → <b>NAVİGASYON</b> → <b>E</b> → <b>EVE DÖN</b>.":
      "Cubierta de mando (planta superior) → <b>NAVEGACIÓN</b> → <b>E</b> → <b>VOLVER A CASA</b>.",
    Dünya: "Tierra",
    Mars: "Marte",
    "Son kayıt: ": "Última partida: ",
    görev: "misión",
    " · Gün ": " · Día ",
    "Kayıtlı görev yok": "No hay misiones guardadas",
    '<div class="empty-note">Henüz kayıt yok.</div>':
      '<div class="empty-note">Aún no hay partidas guardadas.</div>',
    Yükle: "Cargar",
    Sil: "Borrar",
    "Kayıt yüklendi": "Partida cargada",
    "Kayıt ": "Partida ",
    "💾 Otomatik kaydedildi": "💾 Guardado automático",
    "💾 Kaydedildi": "💾 Guardado",
    "MAKİNE DAİRESİ": "SALA DE MÁQUINAS",
    "YAŞAM GÜVERTESİ": "CUBIERTA HABITABLE",
    "KOMUTA GÜVERTESİ": "CUBIERTA DE MANDO",
    "Hava kilidi": "Esclusa",
    "<b>E</b>: Dışarı çık": "<b>E</b>: Salir al exterior",
    "Alet sandığı": "Caja de herramientas",
    "<b>E</b>: Alet sandığını aç": "<b>E</b>: Abrir caja de herramientas",
    "O₂ tüpü": "Tanque de O₂",
    "<b>E</b>: Oksijen doldur": "<b>E</b>: Recargar oxígeno",
    "Ana motor": "Motor principal",
    "<b>E</b>: Ana motoru onar": "<b>E</b>: Reparar motor principal",
    "Tamir tezgâhı": "Banco de trabajo",
    "<b>E</b>: Motor onarımı": "<b>E</b>: Reparación del motor",
    "Uyku kapsülü": "Cápsula de sueño",
    "<b>E</b>: Yat / uyu (zaman 2×)": "<b>E</b>: Acostarse / dormir (tiempo 2×)",
    "Fabrikasyon atölyesi": "Taller de fabricación",
    "<b>E</b>: Atölye · kıyafet & roket geliştirme": "<b>E</b>: Taller · mejoras de traje y cohete",
    Mutfak: "Cocina",
    "<b>E</b>: Mutfağı aç · <b>F</b>: hızlı ye/iç": "<b>E</b>: Abrir cocina · <b>F</b>: comer/beber rápido",
    Revir: "Enfermería",
    "<b>E</b>: Revir dolabını aç": "<b>E</b>: Abrir botiquín de la enfermería",
    "Yemek kapsülü": "Cápsula de comida",
    "<b>E</b>: Yemek kapsülünü aç": "<b>E</b>: Abrir cápsula de comida",
    "İletişim terminali": "Terminal de comunicaciones",
    "<b>E</b>: Dünya iletişim terminali": "<b>E</b>: Terminal de comunicaciones con la Tierra",
    Navigasyon: "Navegación",
    "<b>E</b>: Navigasyon bilgisayarı": "<b>E</b>: Ordenador de navegación",
    "Kargo terminali": "Terminal de carga",
    "<b>E</b>: Kargo terminali": "<b>E</b>: Terminal de carga",
    "🚀 Roketin içindesin — <b>A/D</b> yürü · merdivende <b>W/S</b> · <b>E</b> kullan":
      "🚀 Estás dentro del cohete — <b>A/D</b> caminar · <b>W/S</b> en escaleras · <b>E</b> usar",
    "Hava kilidinden çıktın": "Has salido por la esclusa",
    "Yakında kullanılacak bir istasyon yok": "No hay ninguna estación cerca",
    "Numuneleri komuta güvertesindeki <b>stok terminalinden</b> kargoya yükle":
      "Carga las muestras en la bodega desde el <b>terminal de almacén</b> de la cubierta de mando",
    "Çantanda numune yok — dışarıda metal ve ⭐ topla":
      "No tienes muestras en la bolsa — recoge metal y ⭐ fuera",
    " numune kargoya yüklendi · kargo ": " muestras cargadas en la bodega · carga ",
    "🍽️ Yemek kapsülü stoku: 💧": "🍽️ Reservas de la cápsula de comida: 💧",
    "Şu an aç ya da susuz değilsin": "Ahora mismo no tienes hambre ni sed",
    "Yemek kapsülü boş — patates yetiştir, su geri dönüştürücüyü bekle":
      "La cápsula de comida está vacía — cultiva patatas y espera al reciclador de agua",
    "Çapa sırtında — dışarıda yere <b>sol tıkla</b>, toprağı kaz":
      "Azada a la espalda: fuera, haz <b>clic izquierdo</b> en el suelo para cavar",
    "Çapa alet sandığına bırakıldı": "Azada guardada en la caja de herramientas",
    "Açlık/susuzluktan uyandın — mutfağa git": "Te has despertado por hambre/sed — ve a la cocina",
    "🌅 Yeni güne uyandın": "🌅 Te has despertado en un nuevo día",
    "😴 Uyuyorsun…": "😴 Estás durmiendo…",
    "Gün ": "Día ",
    " · sabaha ": " · hasta la mañana ",
    " · zaman 2× hızlı": " · tiempo 2× más rápido",
    "E: uyan": "E: despertar",
    CAN: "SALUD",
    TOKLUK: "COMIDA",
    SU: "AGUA",
    "Uyuyorsun; oyun zamanı 2× hızlanıyor. Roket gövdesi radyasyonu keser.":
      "Estás durmiendo; el tiempo de juego pasa 2× más rápido. El casco del cohete bloquea la radiación.",
    "☢️ Dışarıda radyasyon var. Roket içindeyken güvendesin.":
      "☢️ Hay radiación fuera. Dentro del cohete estás a salvo.",
    "Uyumak zamanı 2× hızlandırır: mahsul daha çabuk büyür, can hızla yenilenir. Sabah olunca kendiliğinden uyanırsın.":
      "Dormir hace que el tiempo pase 2× más rápido: los cultivos crecen antes y la salud se regenera rápido. Te despiertas solo por la mañana.",
    "☀️ Uyan": "☀️ Despertar",
    "🛌 Uyu": "🛌 Dormir",
    Uyandın: "Te has despertado",
    "Uyku başladı — zaman 2× hızlanıyor": "Has empezado a dormir — el tiempo pasa 2× más rápido",
    "<b>E</b>: Oksijen doldur · giysi %": "<b>E</b>: Recargar oxígeno · traje %",
    " · tüp %": " · tanque %",
    " öğe": " objetos",
    "<b>E</b>: İletişim terminali": "<b>E</b>: Terminal de comunicaciones",
    " yeni mesaj": " mensajes nuevos",
    " gözlem": " observaciones",
    " · <b>F</b>: numuneleri yükle": " · <b>F</b>: cargar muestras",
    " — motor çalışıyor ✔": " — motor en marcha ✔",
    "<b>E</b>: Ana motoru onar · aşama ": "<b>E</b>: Reparar motor principal · fase ",
    " · medikit ": " · botiquines ",
    " · çanta ": " · bolsa ",
    " · <b>G</b>: hızlı kullan": " · <b>G</b>: uso rápido",
    " · metal ": " · metal ",
    " · altın ": " · oro ",
    "<b>W</b>/<b>S</b>: Merdivenle ": "<b>W</b>/<b>S</b>: Escalera: ",
    "yukarı çık": "subir",
    "aşağı in": "bajar",
    "PARAŞÜT / YÜK BÖLMESİ": "COMPARTIMENTO DE PARACAÍDAS / CARGA",
    "HAVA KİLİDİ": "ESCLUSA",
    "ANA MOTOR": "MOTOR PRINCIPAL",
    "MOTOR: ÇALIŞIYOR": "MOTOR: EN MARCHA",
    "ONARIM ": "REPARACIÓN ",
    "MOTOR: ONARIM": "MOTOR: REPARACIÓN",
    MUTFAK: "COCINA",
    "MEDİKİT ×": "BOTIQUÍN ×",
    REVİR: "ENFERMERÍA",
    "UPLINK ": "UPLINK ",
    " YENİ MESAJ": " MENSAJES NUEVOS",
    "AĞ · AKTİF": "RED · ACTIVA",
    İLETİŞİM: "COMUNICACIONES",
    MARS: "MARTE",
    DÜNYA: "TIERRA",
    "NAV v2.1 · SOL ": "NAV v2.1 · SOL ",
    " · KARGO ": " · CARGA ",
    "SİSTEM: HAZIR": "SISTEMA: LISTO",
    "KALKIŞ KİLİTLİ": "DESPEGUE BLOQUEADO",
    NAVİGASYON: "NAVEGACIÓN",
    "KARGO ": "CARGA ",
    STOK: "ALMACÉN",
    Kablolar: "Cables",
    Sigortalar: "Fusibles",
    Basınç: "Presión",
    Ateşleme: "Encendido",
    "✅ Ana motor çalışıyor — onarım gerekmiyor": "✅ El motor principal funciona — no necesita reparación",
    "AŞAMA ": "FASE ",
    "İLERLEME ": "PROGRESO ",
    TAMAMLANDI: "COMPLETADO",
    "İLERLEME 100%": "PROGRESO 100%",
    "Tüm sistemler <b>çevrimiçi</b>. Roket kalkışa hazır.":
      "Todos los sistemas <b>en línea</b>. El cohete está listo para despegar.",
    "MOTOR ÇEVRİMİÇİ": "MOTOR EN LÍNEA",
    "İTKİ ÇEKİRDEĞİ STABİL · KALKIŞ KİLİDİ AÇIK": "NÚCLEO DE EMPUJE ESTABLE · BLOQUEO DE DESPEGUE LIBERADO",
    "Harika — kapat": "Genial — cerrar",
    "🔧 Ana motor onarıldı — roket kalkışa hazır!":
      "🔧 Motor principal reparado — ¡el cohete está listo para despegar!",
    "Kopan <b>güç kablolarını</b> aynı renkteki motor soketlerine sürükle (ya da önce kabloya, sonra sokete tıkla).":
      "Arrastra los <b>cables de alimentación</b> rotos a los conectores del motor del mismo color (o haz clic en un cable y luego en un conector).",
    "GÜÇ ÜNİTESİ": "UNIDAD DE ENERGÍA",
    "⚠ DEVRE AÇIK": "⚠ CIRCUITO ABIERTO",
    "✔ DEVRE KAPALI": "✔ CIRCUITO CERRADO",
    "Kablolar bağlandı": "Cables conectados",
    "Kısa devre <b>sigortaları yaktı</b>. Kararmış olanlara tıklayıp değiştir, sonra <b>ana şalteri</b> kaldır. Sağlamlara dokunma!":
      "El cortocircuito <b>fundió los fusibles</b>. Haz clic en los ennegrecidos para cambiarlos y luego sube el <b>interruptor general</b>. ¡No toques los que están bien!",
    "SİGORTA PANOSU · 40A": "PANEL DE FUSIBLES · 40A",
    "YANIK: ": "FUNDIDOS: ",
    "ŞALTERİ KALDIR": "SUBE EL INTERRUPTOR",
    "ANA ŞALTER": "INTERRUPTOR GENERAL",
    "YANIK: 4": "FUNDIDOS: 4",
    "GÜÇ VAR": "HAY CORRIENTE",
    "Sigortalar değiştirildi": "Fusibles cambiados",
    "İbre <b>yeşil bölgedeyken</b> KİLİTLE'ye bas (ya da <b>Space</b>). 3 başarılı kilit gerekli; her kilitte bölge daralır.":
      "Pulsa BLOQUEAR cuando la aguja esté <b>en la zona verde</b> (o <b>Espacio</b>). Se necesitan 3 bloqueos correctos; la zona se estrecha cada vez.",
    "YAKIT HATTI BASINCI · kPa": "PRESIÓN DE LA LÍNEA DE COMBUSTIBLE · kPa",
    "KİLİT 0/3": "BLOQUEO 0/3",
    KİLİTLE: "BLOQUEAR",
    "KİLİT ": "BLOQUEO ",
    "Basınç kalibre edildi": "Presión calibrada",
    "Ateşleme dizisini <b>izle</b>, sonra düğmelere <b>aynı sırayla</b> bas.":
      "<b>Observa</b> la secuencia de encendido y luego pulsa los botones <b>en el mismo orden</b>.",
    "↻ TEKRAR İZLE": "↻ VER DE NUEVO",
    İZLE: "VER",
    "Dizi oynatılıyor…": "Reproduciendo secuencia…",
    "SIRA SENDE": "TU TURNO",
    HATA: "ERROR",
    "Dizi yeniden oynatılıyor": "Repitiendo la secuencia",
    ATEŞLEME: "ENCENDIDO",
    "İtki çekirdeği aktif": "Núcleo de empuje activo",
    "Ateşleme dizisi doğru": "Secuencia de encendido correcta",
    "🛡️ Fırtına kalkanı roketi korudu — motor sağlam":
      "🛡️ El escudo antitormentas protegió el cohete — el motor está intacto",
    "💥 Şiddetli bir esinti roketi savurdu — motordan duman yükseliyor!":
      "💥 Una ráfaga violenta sacudió el cohete — ¡sale humo del motor!",
    "Kum fırtınası yaklaşıyor": "Se acerca una tormenta de arena",
    "Roketin içindesin — güvendesin": "Estás dentro del cohete — estás a salvo",
    "Rüzgâr hızlanıyor · görüş azalacak": "El viento arrecia · la visibilidad bajará",
    "Roket içi güvenli": "A salvo dentro del cohete",
    "Dışarıda kum fırtınası · rüzgâr ": "Tormenta de arena en el exterior · viento ",
    "Kum fırtınası": "Tormenta de arena",
    "Rüzgâr ": "Viento ",
    " km/s · görüş çok düşük": " km/h · visibilidad muy baja",
    "Jeolog kazması": "Pico de geólogo",
    "Çürük patates": "Patata podrida",
    "DZ-7 radyasyon ölçer": "Medidor de radiación DZ-7",
    "Su şişesi": "Botella de agua",
    Patates: "Patata",
    "Patates tohumu": "Semilla de patata",
    Medikit: "Botiquín",
    Çapa: "Azada",
    "Metal numune": "Muestra de metal",
    "Yıldız kristali": "Cristal estelar",
    "🫁 Oksijen %30 — rokete dönüp tüpten doldur":
      "🫁 Oxígeno al 30 % — vuelve al cohete y recarga en el tanque",
    "⚠️ Oksijen kritik! Hemen rokete dön": "⚠️ ¡Oxígeno crítico! Vuelve al cohete ya",
    "🫁 Giysi oksijeni zaten dolu": "🫁 El oxígeno del traje ya está lleno",
    "O₂ tüpü boş — jeneratör dolduruyor, biraz bekle":
      "Tanque de O₂ vacío — el generador lo está rellenando, espera un poco",
    "🫁 Oksijen dolu · tüp %": "🫁 Oxígeno lleno · tanque %",
    "O₂ tüpü boşaldı — jeneratör dolduruyor": "Tanque de O₂ vacío — el generador lo está rellenando",
    OKSİJEN: "OXÍGENO",
    "Alet Sandığı": "Caja de herramientas",
    "Toprağı kazar ve parsel açar": "Cava la tierra y abre parcelas",
    "Yalnızca bilinmeyen (?) taşları kırar": "Solo rompe piedras desconocidas (?)",
    "Toprağın radyasyonunu ölçer · ekimden önce kullan":
      "Mide la radiación del suelo · úsalo antes de plantar",
    "Dışarıdaki parsele ekilir": "Se planta en la parcela exterior",
    "Yaşam güvertesi · tıbbi dolap ve sedye": "Cubierta habitable · botiquín y camilla",
    "Canı +": "Restaura salud +",
    " yeniler · yanında taşıyıp G ile kullan": " · llévalo contigo y úsalo con G",
    "Yaşam güvertesi · dolaplar, su sebili ve buzdolabı":
      "Cubierta habitable · armarios, dispensador de agua y nevera",
    "Şişe su · su sebilinden geri dönüştürülür": "Agua embotellada · reciclada por el dispensador",
    "Haşlanmış patates · açlığı giderir": "Patata cocida · quita el hambre",
    "Yemek Kapsülü": "Cápsula de comida",
    "Yaşam güvertesi · soğuk saklama + su geri dönüştürücü":
      "Cubierta habitable · almacenamiento en frío + reciclador de agua",
    "Susuzluğu giderir · geri dönüştürülür": "Quita la sed · se recicla",
    "Açlığı giderir · tarladan yetişir": "Quita el hambre · se cultiva en el campo",
    sandığa: "caja",
    kapsüle: "cápsula",
    SANDIK: "CAJA",
    KAPSÜL: "CÁPSULA",
    '<div class="cap-art"><img src="{0}" alt=""><span class="cap-n">×{1}</span></div>\n      <div class="cap-nm">{2}</div><div class="cap-ds">{3}</div>\n      <div class="cap-bar"><i style="width:{4}%"></i></div>\n      <div class="cap-meta"><span>{5} {6}/{7}</span><span>ÇANTA {8}</span></div>':
      '<div class="cap-art"><img src="{0}" alt=""><span class="cap-n">×{1}</span></div>\n      <div class="cap-nm">{2}</div><div class="cap-ds">{3}</div>\n      <div class="cap-bar"><i style="width:{4}%"></i></div>\n      <div class="cap-meta"><span>{5} {6}/{7}</span><span>BOLSA {8}</span></div>',
    Al: "Coger",
    Koy: "Guardar",
    Kullan: "Usar",
    "❤️ Revirde tedavi oldun · +": "❤️ Te han curado en la enfermería · +",
    " can": " de salud",
    İç: "Beber",
    Ye: "Comer",
    "CAN %": "SALUD %",
    "💧 +1 su / ": "💧 +1 agua / ",
    " dk": " min",
    "KİLİT: AÇIK": "CIERRE: ABIERTO",
    " ÖĞE": " OBJETOS",
    "YEMEK KAPSÜLÜ": "CÁPSULA DE COMIDA",
    "KİT KAPSÜLÜ": "CÁPSULA DE KIT",
    "ALET SANDIĞI": "CAJA DE HERRAMIENTAS",
    '<span class="ev rd">☢ Radyasyon · 00:00–01:30</span>':
      '<span class="ev rd">☢ Radiación · 00:00–01:30</span>',
    '<span class="ev st">🌪 Kum fırtınası · 01:30–04:00</span>':
      '<span class="ev st">🌪 Tormenta de arena · 01:30–04:00</span>',
    "<span class='ev ok'>Sakin</span>": "<span class='ev ok'>En calma</span>",
    '<tr class="{0}"><td>Gün {1}{2}</td><td>{3}</td></tr>':
      '<tr class="{0}"><td>Día {1}{2}</td><td>{3}</td></tr>',
    '<div class="pg-cover"><div class="emb"><span>ARES-1</span><i></i></div>\n    <h1>SAHA REHBERİ</h1><div class="sub">Mars Yüzey Operasyonları El Kitabı</div>\n    <p class="c">Bu kitap çantanda hep durur. <kbd>R</kbd> ile aç / kapat.</p>\n    <p class="c sm">Sayfa çevirmek için ◀ ▶ düğmeleri ya da klavyede <kbd>←</kbd> <kbd>→</kbd>.</p>\n    <p class="c sm">Kitap açıkken oyun zamanı durur.</p>\n    <div class="sig">— ARES-1 Görev Kontrol</div></div>':
      '<div class="pg-cover"><div class="emb"><span>ARES-1</span><i></i></div>\n    <h1>GUÍA DE CAMPO</h1><div class="sub">Manual de operaciones en la superficie de Marte</div>\n    <p class="c">Este libro siempre va en tu mochila. Ábrelo / ciérralo con <kbd>R</kbd>.</p>\n    <p class="c sm">Pasa las páginas con los botones ◀ ▶ o las teclas <kbd>←</kbd> <kbd>→</kbd>.</p>\n    <p class="c sm">El tiempo de juego se detiene mientras el libro está abierto.</p>\n    <div class="sig">— Control de Misión de ARES-1</div></div>',
    "İlk adımlar ve kontroller": "Primeros pasos y controles",
    Oksijen: "Oxígeno",
    "Yemek ve su": "Comida y agua",
    "Roketin içi": "Dentro del cohete",
    Tarım: "Cultivo",
    "Numuneler ve kargo": "Muestras y carga",
    "⚠ Kum fırtınası": "⚠ Tormenta de arena",
    "⚠ Radyasyon dalgası": "⚠ Ola de radiación",
    "⚠ Meteor yağmuru": "⚠ Lluvia de meteoritos",
    "Motor onarımı": "Reparación del motor",
    "Uyku ve zaman": "Sueño y tiempo",
    "Felaket takvimi": "Calendario de desastres",
    "Dünya ile iletişim": "Comunicación con la Tierra",
    "Kıyafet & roket geliştirme": "Mejoras de traje y cohete",
    "Acil durum listesi": "Lista de emergencia",
    "Görev mimarisi": "Arquitectura de la misión",
    '<h2>İçindekiler</h2><ol class="toc">{0}</ol>\n    <div class="note">İpucu: bir başlığa tıklarsan o sayfaya gidersin.</div>':
      '<h2>Índice</h2><ol class="toc">{0}</ol>\n    <div class="note">Consejo: haz clic en un título para ir a esa página.</div>',
    '<h2><small>Bölüm 1</small>İlk adımlar</h2>\n    <table class="keys"><tr><td><kbd>W A S D</kbd></td><td>Yürü · <kbd>Shift</kbd> koş</td></tr>\n    <tr><td><kbd>1</kbd>…<kbd>7</kbd></td><td>Eşyayı eline al · aynı tuşa tekrar bas = kullan</td></tr>\n    <tr><td><kbd>F</kbd></td><td>Topla · elindekiyle ek, sula, iç, ye</td></tr>\n    <tr><td><kbd>E</kbd></td><td>Rokete gir · istasyonu kullan</td></tr>\n    <tr><td><kbd>G</kbd></td><td>Medikit kullan</td></tr>\n    <tr><td>Sol tık</td><td>Çapa elindeyken yeri kaz</td></tr>\n    <tr><td><kbd>R</kbd></td><td>Bu rehberi aç</td></tr></table>\n    <div class="tip"><b>Altın kural:</b> sadece <u>elindeki</u> eşyayı kullanırsın. Çapa elindeyken su içemezsin; önce suyu eline al.</div>\n    <p>Sol üstte <b>gün ve saat</b>, altında <b>görev kartı</b> var. Görev kartındaki 💡 satırı ne yapacağını adım adım söyler.</p>':
      '<h2><small>Capítulo 1</small>Primeros pasos</h2>\n    <table class="keys"><tr><td><kbd>W A S D</kbd></td><td>Caminar · <kbd>Shift</kbd> correr</td></tr>\n    <tr><td><kbd>1</kbd>…<kbd>7</kbd></td><td>Sostener un objeto · pulsar de nuevo la misma tecla = usar</td></tr>\n    <tr><td><kbd>F</kbd></td><td>Recoger · plantar, regar, beber o comer con lo que sostienes</td></tr>\n    <tr><td><kbd>E</kbd></td><td>Entrar en el cohete · usar una estación</td></tr>\n    <tr><td><kbd>G</kbd></td><td>Usar un botiquín</td></tr>\n    <tr><td>Clic izquierdo</td><td>Cavar el suelo con la azada en la mano</td></tr>\n    <tr><td><kbd>R</kbd></td><td>Abrir esta guía</td></tr></table>\n    <div class="tip"><b>Regla de oro:</b> solo puedes usar el objeto que tienes <u>en la mano</u>. No puedes beber agua con la azada en la mano; coge primero el agua.</div>\n    <p>Arriba a la izquierda verás el <b>día y la hora</b> y, debajo, la <b>tarjeta de misión</b>. La línea 💡 de la tarjeta de misión te dice qué hacer, paso a paso.</p>',
    "<h2><small>Bölüm 2</small>Oksijen {0}</h2>\n    <p>Mars'ın havası solunamaz. Giysindeki oksijen dışarıda yaklaşık <b>3,5 dakikada</b> biter. Koşarken %35, fırtınada %25 daha hızlı azalır.</p>\n    <ul><li><b>%30</b>'da uyarı alırsın, <b>%10</b>'da alarm çalar.</li>\n    <li><b>%0</b>'da her saniye ~5 can kaybedersin, ekran kararır.</li>\n    <li>Roketin içinde oksijen azalmaz.</li></ul>\n    <div class=\"tip\"><b>Doldurma:</b> rokete gir → makine dairesi → <b>O₂ tüpleri</b> → <kbd>E</kbd>. Hortum sırt çantana bağlanır ve giysi dolar.</div>\n    <p>Tüplerin de bir kapasitesi var. Boşalırsa oksijen jeneratörü onları yavaşça yeniden doldurur; tüp göstergesini takip et.</p>":
      '<h2><small>Capítulo 2</small>Oxígeno {0}</h2>\n    <p>El aire de Marte no es respirable. El oxígeno de tu traje dura unos <b>3,5 minutos</b> en el exterior. Se agota un 35 % más rápido al correr y un 25 % más rápido durante una tormenta.</p>\n    <ul><li>Al <b>30 %</b> recibes un aviso y al <b>10 %</b>, una alarma.</li>\n    <li>Al <b>0 %</b> pierdes ~5 de salud por segundo y la pantalla se oscurece.</li>\n    <li>Dentro del cohete no se consume oxígeno.</li></ul>\n    <div class="tip"><b>Recarga:</b> entra en el cohete → sala de máquinas → <b>tanques de O₂</b> → <kbd>E</kbd>. La manguera se conecta a tu mochila y llena tu traje.</div>\n    <p>Los tanques también tienen una capacidad limitada. Cuando se vacían, el generador de oxígeno los rellena poco a poco; vigila el indicador del tanque.</p>',
    "<h2><small>Bölüm 3</small>Yemek ve su {0}</h2>\n    <p><b>Su</b> yaklaşık 4, <b>tokluk</b> yaklaşık 5,5 dakikada biter. Biri sıfırlanırsa saniyede 4 can gider.</p>\n    <ul><li>{1} <b>Su şişesi:</b> +35 su. Eline al ve <kbd>F</kbd>'ye bas.</li>\n    <li>{2} <b>Patates:</b> +35 tokluk. Eline al ve <kbd>F</kbd>'ye bas.</li></ul>\n    <div class=\"tip\"><b>Mutfak:</b> yaşam güvertesindeki mutfakta <kbd>E</kbd> → envanteri açılır. Oradan çantana alabilir ya da hemen içip yiyebilirsin.</div>\n    <p>Su stoku sınırlıdır ama <b>su geri dönüştürücü</b> her 2,5 dakikada 1 şişe üretir. Patatesi ise tarlada sen yetiştirirsin.</p>":
      '<h2><small>Capítulo 3</small>Comida y agua {0}</h2>\n    <p>El <b>agua</b> se acaba en unos 4 minutos y la <b>comida</b> en unos 5,5 minutos. Si cualquiera de las dos llega a cero, pierdes 4 de salud por segundo.</p>\n    <ul><li>{1} <b>Botella de agua:</b> +35 de agua. Sostenla y pulsa <kbd>F</kbd>.</li>\n    <li>{2} <b>Patata:</b> +35 de comida. Sostenla y pulsa <kbd>F</kbd>.</li></ul>\n    <div class="tip"><b>Cocina:</b> pulsa <kbd>E</kbd> en la cocina de la cubierta habitable → se abre su inventario. Puedes guardar objetos en tu mochila o comer y beber al momento.</div>\n    <p>La reserva de agua es limitada, pero el <b>reciclador de agua</b> produce 1 botella cada 2,5 minutos. Las patatas las cultivas tú mismo en el campo.</p>',
    '<h2><small>Bölüm 4</small>Roketin içi</h2>\n    <p>Roket 3 katlıdır. Merdivenin yanında <kbd>W</kbd>/<kbd>S</kbd> ile kat değiştirirsin.</p>\n    <div class="deck"><b>3 · Komuta güvertesi</b><span>Navigasyon (kalkış) · Kargo terminali</span></div>\n    <div class="deck"><b>2 · Yaşam güvertesi</b><span>Uyku kabini · Mutfak · Revir · Yemek kapsülü</span></div>\n    <div class="deck"><b>1 · Makine dairesi</b><span>Hava kilidi (çıkış) · Alet sandığı · O₂ tüpleri · Ana motor · Tamir tezgâhı</span></div>\n    <div class="tip">Roketin gövdesi seni <b>radyasyondan, fırtınadan ve meteorlardan</b> korur. Bir felaket yaklaşırken en güvenli yer burasıdır.</div>':
      '<h2><small>Capítulo 4</small>Dentro del cohete</h2>\n    <p>El cohete tiene 3 cubiertas. Junto a una escalera, cambia de cubierta con <kbd>W</kbd>/<kbd>S</kbd>.</p>\n    <div class="deck"><b>3 · Cubierta de mando</b><span>Navegación (despegue) · Terminal de carga</span></div>\n    <div class="deck"><b>2 · Cubierta habitable</b><span>Cabina de descanso · Cocina · Enfermería · Cápsula de comida</span></div>\n    <div class="deck"><b>1 · Sala de máquinas</b><span>Esclusa (salida) · Caja de herramientas · Tanques de O₂ · Motor principal · Banco de trabajo</span></div>\n    <div class="tip">El casco del cohete te protege de la <b>radiación, las tormentas y los meteoritos</b>. Cuando se acerca un desastre, este es el lugar más seguro.</div>',
    '<h2><small>Bölüm 5</small>Tarım {0}</h2>\n    <ol><li>Alet sandığından {1} <b>çapayı</b> al. Çapayı eline al ve yere <b>sol tıkla</b>.</li>\n    <li>{2} <b>Tohumu</b> eline al, çukurun yanında <kbd>F</kbd>.</li>\n    <li>{3} <b>Suyu</b> eline al, <kbd>F</kbd> ile sula. Islak toprak bitkiyi 2,4 kat hızlı büyütür.</li>\n    <li>Halka <b>sarı</b> olunca <kbd>F</kbd> ile hasat et: 1–2 patates + 1 tohum.</li></ol>\n    <p>Büyümesi sulamadan yaklaşık 75 saniye sürer. Bitki aşamaları: filiz → fide → çiçekli bitki → hasat.</p>\n    <div class="warn">Kum fırtınasında bitkiler sallanır ama zarar görmez. Parselleri roketin yakınına aç ki fırtınada kaybolmayasın.</div>':
      '<h2><small>Capítulo 5</small>Cultivo {0}</h2>\n    <ol><li>Coge la {1} <b>azada</b> de la caja de herramientas. Sostén la azada y haz <b>clic izquierdo</b> en el suelo.</li>\n    <li>Sostén una {2} <b>semilla</b> y pulsa <kbd>F</kbd> junto al hoyo.</li>\n    <li>Sostén el {3} <b>agua</b> y riega con <kbd>F</kbd>. En tierra húmeda la planta crece 2,4 veces más rápido.</li>\n    <li>Cuando el anillo se vuelva <b>amarillo</b>, cosecha con <kbd>F</kbd>: 1–2 patatas + 1 semilla.</li></ol>\n    <p>Sin riego tarda unos 75 segundos en crecer. Fases de la planta: brote → plántula → planta en flor → cosecha.</p>\n    <div class="warn">Durante una tormenta de arena las plantas se balancean, pero no sufren daños. Cava tus parcelas cerca del cohete para no perderte en una tormenta.</div>',
    '<h2><small>Bölüm 6</small>Numuneler ve kargo {0}</h2>\n    <p>Görevin bilimsel amacı Mars numunelerini Dünya\'ya götürmek.</p>\n    <ul><li>{1} <b>Metal numune</b> = 1 puan. Haritada ◆ olarak görünür.</li>\n    <li>{2} <b>Yıldız kristali</b> = 2 puan. Meteor çarpınca kraterde kalabilir.</li></ul>\n    <div class="tip">Roketin yanında <kbd>F</kbd> ya da komuta güvertesindeki <b>kargo terminali</b> ile kargoya yükle. Hedef: <b>10 numune</b>.</div>\n    <p>Çantana en fazla {3} metal numune sığar. Dolunca rokete dönüp boşalt.</p>':
      '<h2><small>Capítulo 6</small>Muestras y carga {0}</h2>\n    <p>El objetivo científico de la misión es llevar muestras de Marte a la Tierra.</p>\n    <ul><li>{1} <b>Muestra metálica</b> = 1 punto. Aparece como ◆ en el mapa.</li>\n    <li>{2} <b>Cristal estelar</b> = 2 puntos. Puede quedar en un cráter tras el impacto de un meteorito.</li></ul>\n    <div class="tip">Cárgalas en la bodega con <kbd>F</kbd> junto al cohete o en el <b>terminal de carga</b> de la cubierta de mando. Objetivo: <b>10 muestras</b>.</div>\n    <p>Tu mochila admite como máximo {3} muestras metálicas. Cuando esté llena, vuelve al cohete y descárgala.</p>',
    '<h2 class="danger"><small>Bölüm 7 · Felaket</small>🌪 Kum fırtınası (1/2)</h2>\n    <p><b>Ne zaman?</b> İlki <b>2. gün</b> gelir, sonra <b>her 5 günde bir</b> tekrarlar (7, 12, 17…). Günün 01:30\'unda başlar, <b>2,5 dakika</b> sürer.</p>\n    <p><b>Uyarı:</b> başlamadan <b>45 saniye</b> önce turuncu bir kart çıkar ve geri sayar.</p>\n    <p><b>Neler olur?</b></p>\n    <ul><li>Görüş birkaç metreye düşer, gökyüzü kararır.</li>\n    <li>Rüzgâr (130 km/s\'ye kadar) seni savurur, rüzgâra karşı yürümek zorlaşır.</li>\n    <li>Harita sinyali kaybolur: "SİNYAL ZAYIF".</li>\n    <li>Oksijen %25 daha hızlı tükenir.</li>\n    <li>Ani esintiler ekranı sarsar.</li></ul>':
      '<h2 class="danger"><small>Capítulo 7 · Desastre</small>🌪 Tormenta de arena (1/2)</h2>\n    <p><b>¿Cuándo?</b> La primera llega el <b>día 2</b> y luego se repite <b>cada 5 días</b> (7, 12, 17…). Empieza a las 01:30 y dura <b>2,5 minutos</b>.</p>\n    <p><b>Aviso:</b> <b>45 segundos</b> antes de que empiece aparece una tarjeta naranja con una cuenta atrás.</p>\n    <p><b>¿Qué ocurre?</b></p>\n    <ul><li>La visibilidad baja a unos pocos metros y el cielo se oscurece.</li>\n    <li>El viento (hasta 130 km/h) te empuja; caminar en su contra es difícil.</li>\n    <li>Se pierde la señal del mapa: «SEÑAL DÉBIL».</li>\n    <li>El oxígeno se agota un 25 % más rápido.</li>\n    <li>Las ráfagas repentinas hacen temblar la pantalla.</li></ul>',
    '<h2 class="danger"><small>Bölüm 7 · Felaket</small>🌪 Kum fırtınası (2/2)</h2>\n    <div class="warn"><b>İLK FIRTINA ROKETİ VURUR!</b> 2. gündeki fırtına zirvedeyken sert bir esinti roketi savurur ve <b>ana motor bozulur</b>. Motordan duman yükselir, kalkış kilitlenir.</div>\n    <p><b>Ne yapmalı?</b></p>\n    <ol><li>Uyarı kartını görünce işini bırak, <b>rokete dön</b>.</li>\n    <li>Fırtına bitene kadar içeride kal. Bu arada ye, iç, oksijen doldur.</li>\n    <li>Dışarıda yakalanırsan haritadaki roket okunu takip et.</li>\n    <li>Fırtına bitince motoru onar (Bölüm 10).</li></ol>\n    <p class="sm">Sonraki fırtınalarda motor <b>%60</b> olasılıkla yeniden bozulabilir; fırtına kalkanı bu riski azaltır (Bölüm 14).</p>':
      '<h2 class="danger"><small>Capítulo 7 · Desastre</small>🌪 Tormenta de arena (2/2)</h2>\n    <div class="warn"><b>¡LA PRIMERA TORMENTA GOLPEA EL COHETE!</b> En el momento álgido de la tormenta del día 2, una ráfaga violenta sacude el cohete y <b>el motor principal se avería</b>. Sale humo del motor y el despegue queda bloqueado.</div>\n    <p><b>¿Qué hacer?</b></p>\n    <ol><li>Cuando veas la tarjeta de aviso, deja lo que estés haciendo y <b>vuelve al cohete</b>.</li>\n    <li>Quédate dentro hasta que termine la tormenta. Mientras tanto, come, bebe y recarga oxígeno.</li>\n    <li>Si te sorprende fuera, sigue la flecha del cohete en el mapa.</li>\n    <li>Cuando pase la tormenta, repara el motor (capítulo 10).</li></ol>\n    <p class="sm">En tormentas posteriores el motor puede volver a averiarse con un <b>60 %</b> de probabilidad; el escudo antitormentas reduce este riesgo (capítulo 14).</p>',
    '<h2 class="danger"><small>Bölüm 8 · Felaket</small>☢ Radyasyon dalgası</h2>\n    <p><b>Ne zaman?</b> Güneş patlaması <b>3. günden itibaren her 3 günde bir</b> (3, 6, 9…), günün en başında (00:00) gelir ve <b>1,5 dakika</b> sürer.</p>\n    <p><b>Uyarı:</b> önceki günün bitmesine <b>40 saniye</b> kala yeşil kart çıkar.</p>\n    <ul><li>Dışarıdaysan ekran <b>yeşile</b> döner ve saniyede ~3 can kaybedersin — standart giysiyle 30 saniyede ölürsün! Kalkan Mk-III ve ARES Elite setleri hasarı büyük ölçüde azaltır.</li>\n    <li>Başının üstünde "☢" hasar yazıları belirir.</li>\n    <li>Dalganın tamamını dışarıda geçirmek kesin ölümdür!</li></ul>\n    <div class="tip"><b>Korunma:</b> rokete gir. Gövde zırhı radyasyonu tamamen keser, içeride can kaybetmezsin. En iyi taktik: dalga gecesinde roketin <b>uyku kabininde</b> uyumak.</div>':
      '<h2 class="danger"><small>Capítulo 8 · Desastre</small>☢ Ola de radiación</h2>\n    <p><b>¿Cuándo?</b> <b>A partir del día 3, cada 3 días</b> (3, 6, 9…), llega una erupción solar justo al comienzo del día (00:00) y dura <b>1,5 minutos</b>.</p>\n    <p><b>Aviso:</b> aparece una tarjeta verde <b>40 segundos</b> antes de que termine el día anterior.</p>\n    <ul><li>Si estás fuera, la pantalla se vuelve <b>verde</b> y pierdes ~3 de salud por segundo: ¡con el traje estándar mueres en menos de 30 segundos! Los conjuntos Escudo Mk-III y ARES Elite reducen mucho el daño.</li>\n    <li>Sobre tu cabeza aparecen números de daño «☢».</li>\n    <li>¡Pasar toda la ola fuera significa una muerte segura!</li></ul>\n    <div class="tip"><b>Protección:</b> entra en el cohete. El blindaje del casco bloquea la radiación por completo; dentro no pierdes salud. La mejor táctica: duerme en la <b>cabina de descanso</b> del cohete la noche de la ola.</div>',
    '<h2 class="danger"><small>Bölüm 9 · Felaket</small>☄ Meteor yağmuru</h2>\n    <p>Meteorlar <b>uyarı vermeden</b>, rastgele zamanlarda 1–3 tane düşer. Kum fırtınası sırasında düşmez.</p>\n    <p><b>Belirtiler:</b> önce yükselen bir uğultu duyulur. Gökyüzünde iz bırakan bir ateş topu belirir ve yerde <b>büyüyen bir gölge</b> oluşur. Gölge çarpma noktasıdır!</p>\n    <ul><li>Çarpma yarıçapı ~9 m, hasar <b>26 can</b>.</li>\n    <li>Çarpma kalıcı bir krater bırakır. Krater bir süre sıcak kalır ve tüter.</li></ul>\n    <div class="tip"><b>Fırsat:</b> kraterlerde sık sık {0} <b>yıldız kristali</b> ya da metal numune kalır. Gölgeden uzaklaş, çarpmadan sonra topla.</div>':
      '<h2 class="danger"><small>Capítulo 9 · Desastre</small>☄ Lluvia de meteoritos</h2>\n    <p>Los meteoritos caen <b>sin previo aviso</b>, de 1 a 3 a la vez, en momentos aleatorios. No caen durante una tormenta de arena.</p>\n    <p><b>Señales:</b> primero oyes un estruendo creciente. En el cielo aparece una bola de fuego con estela y en el suelo se forma una <b>sombra que crece</b>. ¡La sombra es el punto de impacto!</p>\n    <ul><li>Radio de impacto ~9 m, daño de <b>26 de salud</b>.</li>\n    <li>El impacto deja un cráter permanente. El cráter permanece caliente y humeante durante un rato.</li></ul>\n    <div class="tip"><b>Oportunidad:</b> en los cráteres suele haber un {0} <b>cristal estelar</b> o una muestra metálica. Aléjate de la sombra y recoge después del impacto.</div>',
    '<h2><small>Bölüm 10</small>Motor onarımı 🔧</h2>\n    <p>Makine dairesinde <b>ANA MOTOR</b> → <kbd>E</kbd>. Onarım 4 aşamadır; tamamladığın aşamalar kaydedilir.</p>\n    <ol><li><b>Kablolar:</b> renkli kabloları aynı renkteki sokete sürükle.</li>\n    <li><b>Sigortalar:</b> kararmış sigortalara tıkla, sonra ana şalteri kaldır. Sağlamlara dokunma!</li>\n    <li><b>Basınç:</b> ibre yeşil bölgedeyken KİLİTLE ya da <kbd>Space</kbd>. 3 kez başarman gerekir.</li>\n    <li><b>Ateşleme:</b> ışık dizisini izle, aynı sırayla bas.</li></ol>\n    <div class="tip">Onarım bitince kalkış kilidi açılır ve görevler seni Dünya\'ya yönlendirir.</div>':
      '<h2><small>Capítulo 10</small>Reparación del motor 🔧</h2>\n    <p>En la sala de máquinas: <b>MOTOR PRINCIPAL</b> → <kbd>E</kbd>. La reparación tiene 4 fases; las fases completadas se guardan.</p>\n    <ol><li><b>Cables:</b> arrastra los cables de colores hasta el conector del mismo color.</li>\n    <li><b>Fusibles:</b> haz clic en los fusibles ennegrecidos y luego sube el interruptor general. ¡No toques los que están bien!</li>\n    <li><b>Presión:</b> pulsa BLOQUEAR o <kbd>Espacio</kbd> mientras la aguja esté en la zona verde. Tienes que acertar 3 veces.</li>\n    <li><b>Encendido:</b> observa la secuencia de luces y púlsalas en el mismo orden.</li></ol>\n    <div class="tip">Una vez terminada la reparación, se libera el bloqueo de despegue y las misiones te guían de vuelta a la Tierra.</div>',
    '<h2><small>Bölüm 11</small>Uyku ve zaman</h2>\n    <p>Mars\'ta <b>1 gün = 6 dakika</b>. Sol üstteki çubuk günün ilerleyişini, turuncu çizgiler olayları gösterir.</p>\n    <ul><li>Uyku kabininde uyursan <b>zaman 2 kat hızlanır</b>, can hızla yenilenir.</li>\n    <li>Sabah olunca kendiliğinden uyanırsın. Aç ya da susuz kalırsan erken uyanırsın.</li>\n    <li>Uyurken mahsul de 2 kat hızlı büyür.</li></ul>\n    <div class="tip">Radyasyon gecesinde ya da uzun bir fırtınada uyumak, tehlikeyi güvenle atlatmanın en kolay yolu.</div>':
      '<h2><small>Capítulo 11</small>Sueño y tiempo</h2>\n    <p>En Marte <b>1 día = 6 minutos</b>. La barra de arriba a la izquierda muestra el avance del día; las marcas naranjas indican eventos.</p>\n    <ul><li>Si duermes en la cabina de descanso, <b>el tiempo pasa 2× más rápido</b> y la salud se regenera deprisa.</li>\n    <li>Te despiertas automáticamente por la mañana. Si te entra hambre o sed, te despiertas antes.</li>\n    <li>Los cultivos también crecen 2× más rápido mientras duermes.</li></ul>\n    <div class="tip">Dormir durante una noche de radiación o una tormenta larga es la forma más sencilla de superar el peligro sin riesgos.</div>',
    '<h2><small>Bölüm 12</small>Felaket takvimi</h2>\n    <p class="sm">Bugün: <b>Gün {0}</b> · gün bitimine <b>{1}</b> · sonraki fırtına <b>Gün {2}</b></p>\n    <table class="cal">{3}</table>\n    <p class="sm">Meteorlar takvime girmez: her an düşebilir.</p>':
      '<h2><small>Capítulo 12</small>Calendario de desastres</h2>\n    <p class="sm">Hoy: <b>Día {0}</b> · hasta el final del día <b>{1}</b> · próxima tormenta <b>Día {2}</b></p>\n    <table class="cal">{3}</table>\n    <p class="sm">Los meteoritos no figuran en el calendario: pueden caer en cualquier momento.</p>',
    "<h2><small>Bölüm 13</small>Dünya ile iletişim 📡</h2>\n    <p>Görevin asıl amacı: Mars'ta yaşadıklarını ve topladığın bilgileri <b>Dünya'ya aktarmak</b>. Komuta güvertesinin solundaki <b>İLETİŞİM</b> masasına <kbd>E</kbd>.</p>\n    <ul><li><b>Saha günlüğü</b> fırtına, radyasyon, meteor, arıza, numune, tarım ve kritik değerleri <b>otomatik</b> kaydeder.</li>\n    <li>Kayıtları seç, kendi notunu yaz (sorunlarını, sorularını), öncelik belirle ve gönder.</li>\n    <li>Görev Kontrol <b>~½ sol</b> sonra (ACİL: ~¼ sol) resmî bir yanıt yollar: analiz, talimatlar ve 5 sollük tahmin.</li>\n    <li>Kum fırtınası sırasında anten tozla kapanır, <b>gönderim yapılamaz</b>.</li>\n    <li><b>🛰️ Yer Birimi</b> sekmesi, raporlarını alan yer istasyonlarını ve görev kontrol merkezlerini gösterir.</li></ul>\n    <div class=\"tip\">Görev Kontrol bazen kendiliğinden yazar: hava bültenleri, telemetri uyarıları, rapor talepleri. Sağ üstteki rozet yeni mesajı gösterir.</div>":
      '<h2><small>Capítulo 13</small>Comunicación con la Tierra 📡</h2>\n    <p>El verdadero objetivo de la misión: <b>transmitir a la Tierra</b> lo que vives en Marte y los datos que recoges. Pulsa <kbd>E</kbd> en el puesto de <b>COMUNICACIONES</b> a la izquierda de la cubierta de mando.</p>\n    <ul><li>El <b>registro de campo</b> anota <b>automáticamente</b> tormentas, radiación, meteoritos, averías, muestras, cultivos y valores críticos.</li>\n    <li>Selecciona entradas, escribe tu propia nota (tus problemas, tus preguntas), elige una prioridad y envía.</li>\n    <li>Control de Misión envía una respuesta oficial al cabo de <b>~½ sol</b> (URGENTE: ~¼ sol): análisis, instrucciones y un pronóstico de 5 soles.</li>\n    <li>Durante una tormenta de arena la antena se obstruye con polvo y <b>no se puede enviar nada</b>.</li>\n    <li>La pestaña <b>🛰️ Segmento terrestre</b> muestra las estaciones terrestres y los centros de control de misión que reciben tus informes.</li></ul>\n    <div class="tip">Control de Misión a veces escribe por iniciativa propia: boletines meteorológicos, alertas de telemetría, solicitudes de informe. La insignia de arriba a la derecha muestra los mensajes nuevos.</div>',
    '<h2><small>Bölüm 14</small>Kıyafet & roket geliştirme 🧬</h2>\n    <p>Yaşam güvertesindeki <b>Fabrikasyon Atölyesi</b> <kbd>E</kbd> ile açılır.</p>\n    <ul><li><b>Kıyafet setleri</b> (Kaşif → Öncü → Kalkan → ARES Elite) metal numune, yıldız kristali ve nadir taşlarla sırayla üretilir. Her set oksijen tüketimini, yürüme hızını, radyasyon ve fırtına korumasını artırır.</li>\n    <li><b>Roket geliştirme</b> meteor kraterlerinin çevresine saçılan <b>altın parçaları</b> ve titanyum cevheriyle yapılır. Fırtına kalkanı 3 seviyedir; son seviyede fırtına motoru bozamaz.</li>\n    <li>İlk fırtınadan sonraki her fırtınada motor <b>%60</b> olasılıkla bozulur — kalkan bunu azaltır.</li>\n    <li>Altınla rokete yeni boyalar da alabilirsin.</li></ul>\n    <div class="tip">Meteor düştükten sonra krater çevresini tara: parıldayan sarı parçalar altındır. Uzak bölgelerde tarayıcının bip sesini takip et: <b>bilinmeyen taşlar</b> (titanyum, olivin, Ares taşı) üst seviye geliştirmeler için şart — çıkarmak için saha kiti gerekir.</div>':
      '<h2><small>Capítulo 14</small>Mejoras de traje y cohete 🧬</h2>\n    <p>El <b>Taller de Fabricación</b> de la cubierta habitable se abre con <kbd>E</kbd>.</p>\n    <ul><li>Los <b>conjuntos de traje</b> (Explorador → Pionero → Escudo → ARES Elite) se fabrican en orden con muestras metálicas, cristales estelares y piedras raras. Cada conjunto mejora el consumo de oxígeno, la velocidad al caminar y la protección contra la radiación y las tormentas.</li>\n    <li>Las <b>mejoras del cohete</b> se hacen con los <b>fragmentos de oro</b> esparcidos alrededor de los cráteres de meteorito y con mineral de titanio. El escudo antitormentas tiene 3 niveles; en el último, las tormentas ya no pueden averiar el motor.</li>\n    <li>En cada tormenta posterior a la primera, el motor se avería con un <b>60 %</b> de probabilidad; el escudo lo reduce.</li>\n    <li>Con oro también puedes comprar nuevas pinturas para el cohete.</li></ul>\n    <div class="tip">Después de que caiga un meteorito, busca alrededor del cráter: los fragmentos amarillos brillantes son oro. En zonas remotas sigue el pitido del escáner: las <b>piedras desconocidas</b> (titanio, olivino, piedra de Ares) son necesarias para las mejoras de nivel superior; para extraerlas necesitas el kit de campo.</div>',
    '<h2><small>Bölüm 15</small>Acil durum listesi</h2>\n    <table class="emg"><tr><td>🫁 Oksijen &lt; %30</td><td>Rokete dön → O₂ tüpleri</td></tr>\n    <tr><td>❤ Can düşük</td><td>Medikit (<kbd>G</kbd>), revir ya da uyku</td></tr>\n    <tr><td>💧 / 🍽 bitti</td><td>Mutfak ya da yemek kapsülü</td></tr>\n    <tr><td>🌪 Turuncu kart</td><td>45 sn içinde rokete gir</td></tr>\n    <tr><td>☢ Yeşil kart</td><td>Rokete gir, mümkünse uyu</td></tr>\n    <tr><td>☄ Uğultu + gölge</td><td>Gölgeden uzaklaş</td></tr>\n    <tr><td>💨 Motordan duman</td><td>Ana motoru onar</td></tr></table>\n    <h3>Eve dönüş</h3><p>Sol üstteki görev kartını takip et: numune → kit → tarım → ilk rapor → fırtına → motor onarımı → radyasyon → hasat → Dünya\'nın yanıtı → altın → nadir taş → yeni kıyafet → kargo (10). Sonra komuta güvertesinde <b>NAVİGASYON</b> → <b>EVE DÖN</b>.</p>':
      '<h2><small>Capítulo 15</small>Lista de emergencia</h2>\n    <table class="emg"><tr><td>🫁 Oxígeno &lt; 30 %</td><td>Vuelve al cohete → tanques de O₂</td></tr>\n    <tr><td>❤ Salud baja</td><td>Botiquín (<kbd>G</kbd>), enfermería o dormir</td></tr>\n    <tr><td>💧 / 🍽 vacío</td><td>Cocina o cápsula de comida</td></tr>\n    <tr><td>🌪 Tarjeta naranja</td><td>Entra en el cohete en menos de 45 s</td></tr>\n    <tr><td>☢ Tarjeta verde</td><td>Entra en el cohete y duerme si puedes</td></tr>\n    <tr><td>☄ Estruendo + sombra</td><td>Aléjate de la sombra</td></tr>\n    <tr><td>💨 Humo del motor</td><td>Repara el motor principal</td></tr></table>\n    <h3>Volver a casa</h3><p>Sigue la tarjeta de misión de arriba a la izquierda: muestras → kit → cultivo → primer informe → tormenta → reparación del motor → radiación → cosecha → respuesta de la Tierra → oro → piedra rara → traje nuevo → carga (10). Después, en la cubierta de mando: <b>NAVEGACIÓN</b> → <b>VOLVER A CASA</b>.</p>',
    '<h2><small>Bölüm 16</small>Görev mimarisi 📐</h2>\n    <p>ARES-1 bir uzay görevinin tüm parçalarıyla tasarlandı. İletişim terminalindeki <b>📐 Görev Mimarisi</b> sekmesi bunları canlı gösterir.</p>\n    <ul><li><b>Görev segmentleri:</b> fırlatma, uzay, yer ve kullanıcı segmentleri birlikte çalışır.</li>\n    <li><b>Kavram olgunluğu:</b> görev bir fikirle başlar; fizibilite analizi ve ödünleşim çalışmalarından geçerek nokta tasarıma ulaşır.</li>\n    <li><b>Alt sistemler:</b> itki, yaşam desteği, ısıl koruma, yapı ve iletişim ayrı ayrı izlenir.</li></ul>\n    <div class="tip">ARES-1 kurgusal bir görevdir; oyundaki sayılar oyun için basitleştirilmiştir.</div>':
      '<h2><small>Capítulo 16</small>Arquitectura de la misión 📐</h2>\n    <p>ARES-1 se diseñó con todas las partes de una misión espacial. La pestaña <b>📐 Arquitectura de la misión</b> del terminal de comunicaciones las muestra en directo.</p>\n    <ul><li><b>Segmentos de la misión:</b> los segmentos de lanzamiento, espacial, terrestre y de usuario trabajan juntos.</li>\n    <li><b>Madurez del concepto:</b> una misión empieza como una idea y llega a un diseño puntual mediante el análisis de viabilidad y los estudios de compensación.</li>\n    <li><b>Subsistemas:</b> la propulsión, el soporte vital, la protección térmica, la estructura y las comunicaciones se supervisan por separado.</li></ul>\n    <div class="tip">ARES-1 es una misión ficticia; las cifras del juego están simplificadas.</div>',
    "Uçuş Direktörü": "Director de vuelo",
    "Mürettebat İletişim Sorumlusu": "Responsable de comunicaciones con la tripulación",
    "İtki Sistemleri Şefi": "Jefe de sistemas de propulsión",
    "Uzay Hava Durumu Birimi": "Unidad de meteorología espacial",
    "Gezegen Bilimi Ekibi Lideri": "Jefe del equipo de ciencia planetaria",
    "Biyorejeneratif Yaşam Destek": "Soporte vital biorregenerativo",
    "Uçuş Cerrahı": "Médico de vuelo",
    "Davranış Sağlığı Uzmanı": "Especialista en salud conductual",
    "Lojistik ve Kargo Planlama": "Logística y planificación de carga",
    "Görev Destek Yapay Zekâsı": "IA de Apoyo a la Misión",
    "Uzay hava durumu": "Meteorología espacial",
    "Ana motor arızası": "Avería del motor principal",
    "Araç sistemleri": "Sistemas del vehículo",
    "Radyasyon dalgası": "Ola de radiación",
    "Meteor düşüşü": "Caída de meteoritos",
    "Gezegen bilimi": "Ciencia planetaria",
    "Jeolojik numune": "Muestra geológica",
    "Tarım deneyi": "Experimento de cultivo",
    "Yaşam bilimi": "Ciencias de la vida",
    "Kargo yüklemesi": "Carga de muestras",
    Lojistik: "Logística",
    "Yaşam destek uyarısı": "Alerta de soporte vital",
    "Mürettebat sağlığı": "Salud de la tripulación",
    "Nadir mineral": "Mineral raro",
    "Çürüyen hasat": "Cosecha podrida",
    KRİTİK: "CRÍTICO",
    ÖNEMLİ: "IMPORTANTE",
    OLUMLU: "POSITIVO",
    RUTİN: "RUTINA",
    Su: "Agua",
    Tokluk: "Comida",
    Can: "Salud",
    Erzak: "Suministros",
    " sa ": " h ",
    "{0}. solda ~{1} süren yerel toz fırtınası. Görüş sıfıra yakın, gövde sarsıntısı yüksek. ":
      "Tormenta de polvo local en el sol {0} con una duración de ~{1}. Visibilidad casi nula, fuertes sacudidas del casco. ",
    "Fırtına sırasında araç dışında {0} geçirildi. ": "{0} fuera del vehículo durante la tormenta. ",
    "Mürettebat fırtına boyunca araç içinde kaldı. ":
      "La tripulación permaneció dentro del vehículo durante toda la tormenta. ",
    "Fırtına ana motoru devre dışı bıraktı.": "La tormenta inutilizó el motor principal.",
    "Araçta yeni hasar gözlenmedi.": "No se observan daños nuevos en el vehículo.",
    "{0}. solda fırtına esnasında itki çekirdeğinde arıza. Makine dairesinde yoğun duman, kalkış kilitli.":
      "Avería en el núcleo de empuje durante la tormenta del sol {0}. Humo denso en la sala de máquinas, despegue bloqueado.",
    "Ana motor 4 aşamalı prosedürle onarıldı (kablolar, sigortalar, basınç, ateşleme). Sistem çevrimiçi.":
      "Motor principal reparado con el procedimiento de 4 fases (cables, fusibles, presión, encendido). Sistema en línea.",
    "Güneş kaynaklı parçacık dalgası (~{0}). ": "Ola de partículas solares (~{0}). ",
    "Dışarıda {0} maruz kalındı, ~{1} can kaybı.": "{0} de exposición en el exterior, ~{1} de salud perdida.",
    "Mürettebat zırhlı gövdede korundu, doz alınmadı.":
      "La tripulación estuvo protegida por el casco blindado; no recibió dosis.",
    "{0} meteor çarpması gözlendi": "{0} impactos de meteoritos observados",
    ", en yakını ~{0} m mesafede.": ", el más cercano a ~{0} m.",
    " Taze kraterler oluştu.": " Se han formado cráteres recientes.",
    " ve {0} yıldız kristali": " y {0} cristal(es) estelar(es)",
    "{0} metal{1} numunesi toplandı.": "{0} muestras metálicas{1} recogidas.",
    " parsele tohum ekildi": " parcelas sembradas",
    " hasat alındı": " cosechas recogidas",
    "Kargo bölmesine {0} birim numune yüklendi (toplam {1}/{2}).":
      "{0} unidades de muestras cargadas en la bodega (total {1}/{2}).",
    " çıkarıldı ve analiz edildi.": " extraído y analizado.",
    "{0} parselden alınan patates yumruları kararmış ve yumuşamış halde çıktı. Yapraklar hasattan önce solmuştu. Nedeni bilinmiyor.":
      "Los tubérculos de {0} parcela(s) salieron ennegrecidos y blandos. Las hojas se habían marchitado antes de la cosecha. Se desconoce la causa.",
    "Kritik değerler: ": "Valores críticos: ",
    "erzak tükendi": "suministros agotados",
    "📝 Saha günlüğüne eklendi: <b>": "📝 Añadido al registro de campo: <b>",
    "</b> — komuta güvertesindeki <b>iletişim terminalinden</b> Dünya'ya raporla":
      "</b> — infórmalo a la Tierra desde el <b>terminal de comunicaciones</b> de la cubierta de mando",
    "📨 <b>Dünya'dan resmî mesaj:</b> ": "📨 <b>Mensaje oficial de la Tierra:</b> ",
    " — iletişim terminalinden oku": " — léelo en el terminal de comunicaciones",
    "ACİL · ": "URGENTE · ",
    '<div class="ltr-cc"><b>Bilgi:</b> {0}</div>': '<div class="ltr-cc"><b>Copia a:</b> {0}</div>',
    '<div class="ltr">\n  <div class="ltr-hd"><div class="ltr-seal"><b>ARES</b><span>GK</span></div>\n    <div class="ltr-org"><b>ARES-1 GÖREV KONTROL MERKEZİ</b><span>Yer istasyonu ağı üzerinden</span></div>\n    <div class="ltr-cls {0}">{1}RESMİ<br><small>MÜRETTEBATA ÖZEL</small></div></div>\n  <table class="ltr-meta">\n    <tr><td>Belge No</td><td>{2}</td><td>Tarih</td><td>{3} (Mars yerel)</td></tr>\n    <tr><td>Kime</td><td>ARES-1 Komutanı</td><td>İlgi</td><td>{4}</td></tr>\n    <tr><td>Konu</td><td colspan="3"><b>{5}</b></td></tr></table>\n  <div class="ltr-body">{6}</div>\n  {7}\n  <div class="ltr-sign">{8}</div>\n  {9}\n  <div class="ltr-ft">Bu ileti {10} dk ışık gecikmesiyle iletilmiştir · Şifreli kanal AES-256 · {11}</div>\n</div>':
      '<div class="ltr">\n  <div class="ltr-hd"><div class="ltr-seal"><b>ARES</b><span>MC</span></div>\n    <div class="ltr-org"><b>CENTRO DE CONTROL DE LA MISIÓN ARES-1</b><span>A través de la red de estaciones terrestres</span></div>\n    <div class="ltr-cls {0}">{1}OFICIAL<br><small>SOLO TRIPULACIÓN</small></div></div>\n  <table class="ltr-meta">\n    <tr><td>N.º de documento</td><td>{2}</td><td>Fecha</td><td>{3} (hora local de Marte)</td></tr>\n    <tr><td>Para</td><td>Comandante de ARES-1</td><td>Ref.</td><td>{4}</td></tr>\n    <tr><td>Asunto</td><td colspan="3"><b>{5}</b></td></tr></table>\n  <div class="ltr-body">{6}</div>\n  {7}\n  <div class="ltr-sign">{8}</div>\n  {9}\n  <div class="ltr-ft">Este mensaje se transmitió con un retardo de luz de {10} min · Canal cifrado AES-256 · {11}</div>\n</div>',
    '<span class="fx rd">☢ Radyasyon · {0}–{1}</span>': '<span class="fx rd">☢ Radiación · {0}–{1}</span>',
    '<span class="fx st">🌪 Kum fırtınası · {0}–{1}</span>':
      '<span class="fx st">🌪 Tormenta de arena · {0}–{1}</span>',
    '<span class="fx ok">Açık · dış görev uygun</span>':
      '<span class="fx ok">Despejado · apto para EVA</span>',
    "EK-A · Uzay hava durumu tahmini": "ANEXO A · Pronóstico de meteorología espacial",
    '<div class="ltr-annex"><div class="ah">{0}</div><table>{1}</table><div class="an">Meteor düşüşleri öngörülemez; tahmine dahil değildir.</div></div>':
      '<div class="ltr-annex"><div class="ah">{0}</div><table>{1}</table><div class="an">La caída de meteoritos no se puede predecir y no se incluye en el pronóstico.</div></div>',
    "<p>Sayın Komutan,</p>\n  <p>ARES-1 aracının Mars yüzeyine başarılı inişini tebrik ederiz. Tüm Görev Kontrol ekibi şu an sizi izliyor ve iniş telemetrisini eksiksiz aldık.</p>\n  <p>Görevinizin temel amacı, yüzeyde <b>bilimsel veri toplamak</b> ve yaşadığınız her olayı — özellikle tehlikeli olanları — Dünya'ya <b>raporlamaktır</b>. Burada hiçbir insanın daha önce yaşamadığı koşulları yaşayacaksınız; gözlemleriniz gelecekteki mürettebatların hayatını kurtaracak.</p>\n  <ol><li>Fırtına, radyasyon, meteor, arıza, numune ve tarım olayları aracın <b>saha günlüğüne</b> otomatik kaydedilir.</li>\n  <li>Komuta güvertesindeki <b>İletişim Terminali</b>nden bu kayıtları seçip kendi notunuzu ekleyerek rapor gönderin.</li>\n  <li>Raporlar ekiplerimiz tarafından incelenir; resmî yanıtımız yaklaşık <b>½ sol</b> içinde ulaşır. Hayati durumlarda raporu <b>ACİL</b> işaretleyin; yanıt süresi ~¼ sole iner.</li></ol>\n  <p>Uydu verilerimiz bölgenizde gelişmekte olan bir toz sistemi gösteriyor. Yoğunluğu hakkında henüz kesin bilgimiz yok; lütfen aracın çevresinden çok uzaklaşmayın.</p>\n  <p>Size güveniyoruz. Dünya'dan selamlar.</p>":
      "<p>Estimado comandante:</p>\n  <p>Enhorabuena por el aterrizaje con éxito de ARES-1 en la superficie de Marte. Todo el equipo de Control de Misión le está siguiendo en este momento y hemos recibido íntegra la telemetría del aterrizaje.</p>\n  <p>El objetivo principal de su misión es <b>recoger datos científicos</b> en la superficie e <b>informar</b> a la Tierra de cada suceso que viva, especialmente de los peligrosos. Se enfrentará a condiciones que ningún ser humano ha experimentado; sus observaciones salvarán la vida de futuras tripulaciones.</p>\n  <ol><li>Las tormentas, la radiación, los meteoritos, las averías, las muestras y los eventos de cultivo se registran automáticamente en el <b>registro de campo</b> del vehículo.</li>\n  <li>Envíe informes desde el <b>Terminal de Comunicaciones</b> de la cubierta de mando seleccionando esas entradas y añadiendo su propia nota.</li>\n  <li>Nuestros equipos revisan los informes; nuestra respuesta oficial llega en unos <b>½ sol</b>. En situaciones críticas marque el informe como <b>URGENTE</b>; el tiempo de respuesta baja a ~¼ sol.</li></ol>\n  <p>Nuestros datos de satélite muestran un sistema de polvo que se está formando en su zona. Aún desconocemos su intensidad; por favor, no se aleje demasiado del vehículo.</p>\n  <p>Confiamos en usted. Saludos desde la Tierra.</p>",
    "Görev başlangıç brifingi": "Sesión informativa de inicio de misión",
    "Yörünge görüntüleri bölgenize doğru ilerleyen bir toz cephesi gösteriyor.":
      "Las imágenes orbitales muestran un frente de polvo que avanza hacia su zona.",
    "Basınç modellerimiz yerel bir toz fırtınasının oluşacağını öngörüyor.":
      "Nuestros modelos de presión predicen la formación de una tormenta de polvo local.",
    "Hellas havzasından yükselen bir toz sistemi konumunuza yaklaşıyor.":
      "Un sistema de polvo procedente de la cuenca de Hellas se acerca a su posición.",
    "<li><b>Sol {0} · Kum fırtınası:</b> {1} Beklenen başlangıç <b>{2}</b>, süre yaklaşık <b>{3}</b>. Rüzgâr hızı {4} km/sa'e ulaşabilir.</li>":
      "<li><b>Sol {0} · Tormenta de arena:</b> {1} Inicio previsto <b>{2}</b>, duración aproximada <b>{3}</b>. El viento puede alcanzar {4} km/h.</li>",
    "Güneş yüzeyinde X sınıfı bir patlama kaydedildi.":
      "Se ha registrado una fulguración de clase X en la superficie del Sol.",
    "SOHO gözlemleri yüksek enerjili bir koronal kütle atımı gösteriyor.":
      "Las observaciones del SOHO muestran una eyección de masa coronal de alta energía.",
    "Güneş rüzgârı parçacık akısında ani artış bekleniyor.":
      "Se espera un aumento repentino del flujo de partículas del viento solar.",
    "<li><b>Sol {0} · Radyasyon dalgası:</b> {1} Parçacık akısı <b>{2}–{3}</b> arasında zirve yapacak. Bu sürede <b>araç dışına çıkmayın</b>.</li>":
      "<li><b>Sol {0} · Ola de radiación:</b> {1} El flujo de partículas alcanzará su máximo entre <b>{2}–{3}</b>. <b>No salga del vehículo</b> durante ese tiempo.</li>",
    "Uzay hava durumu biriminin günlük değerlendirmesi aşağıdadır.":
      "A continuación figura la evaluación diaria de la unidad de meteorología espacial.",
    "Önümüzdeki iki sol için risk değerlendirmemiz ekte sunulmuştur.":
      "Adjuntamos nuestra evaluación de riesgos para los próximos dos soles.",
    "Rutin uzay hava durumu bülteni bilgilerinize sunulur.":
      "Le enviamos para su información el boletín rutinario de meteorología espacial.",
    "Dış görevlerinizi bu pencerelerin dışına planlamanızı öneriyoruz.":
      "Le recomendamos programar sus EVA fuera de estas franjas.",
    "Numunelerinizi olay öncesinde kargoya yüklemenizi öneriyoruz.":
      "Le recomendamos cargar sus muestras en la bodega antes del evento.",
    "Olay sırasındaki gözlemlerinizi raporlamanız modellerimizi iyileştirecektir.":
      "Informar de sus observaciones durante el evento mejorará nuestros modelos.",
    '<p>ARES-1 mürettebatına,</p><p>{0}</p>\n  <ul class="ltr-ul">{1}</ul>\n  <p>{2}</p>':
      '<p>A la tripulación de ARES-1:</p><p>{0}</p>\n  <ul class="ltr-ul">{1}</ul>\n  <p>{2}</p>',
    "Uzay hava durumu bülteni · Sol ": "Boletín de meteorología espacial · Sol ",
    "Uzay hava durumu bülteni": "Boletín de meteorología espacial",
    '<p>Sayın Komutan,</p>\n  <p>Araç telemetrisinde <b>itki sisteminde anomali</b> tespit ettik: ana motor kontrol kartından veri alınamıyor, yakıt hattında basınç dalgalanması görülüyor. Bu tablo, son fırtınada ciddi bir hasar oluştuğuna işaret ediyor.</p>\n  <p>Henüz sizden bu konuda bir rapor almadık. Lütfen <b>en kısa sürede durum raporu gönderin</b> ve makine dairesindeki tamir tezgâhından onarım prosedürünü başlatın.</p>\n  <div class="ltr-dir"><b>TALİMATLAR</b><ol><li>Makine dairesine inin, ana motora <kbd>E</kbd> ile erişin.</li><li>Prosedürü sırayla uygulayın: kablolar → sigortalar → basınç → ateşleme.</li><li>Duman yoğunsa oksijen seviyenizi kontrol edin.</li></ol></div>':
      '<p>Estimado comandante:</p>\n  <p>Hemos detectado una <b>anomalía en el sistema de propulsión</b> en la telemetría del vehículo: no llegan datos de la placa de control del motor principal y se observan fluctuaciones de presión en la línea de combustible. Este cuadro indica que se produjo un daño grave en la última tormenta.</p>\n  <p>Aún no hemos recibido ningún informe suyo al respecto. Por favor, <b>envíe un informe de situación lo antes posible</b> e inicie el procedimiento de reparación desde el banco de trabajo de la sala de máquinas.</p>\n  <div class="ltr-dir"><b>INSTRUCCIONES</b><ol><li>Baje a la sala de máquinas y acceda al motor principal con <kbd>E</kbd>.</li><li>Siga el procedimiento en orden: cables → fusibles → presión → encendido.</li><li>Si hay mucho humo, compruebe su nivel de oxígeno.</li></ol></div>',
    "Telemetri anomalisi · itki sistemi": "Anomalía de telemetría · sistema de propulsión",
    "<p>Komutan,</p><p>Son <b>{0} soldur</b> sizden rapor alamadık. Telemetri aracın çalıştığını gösteriyor, ancak saha günlüğünüzde <b>{1} gönderilmemiş kayıt</b> birikmiş durumda.</p>\n  <p>Bilim ekibimiz ve mürettebat sağlığı birimimiz verilerinizi bekliyor. Kısa da olsa bir durum raporu göndermenizi rica ederiz. Nasıl hissettiğinizi bir iki cümleyle yazmanız da bizim için değerlidir.</p>":
      "<p>Comandante:</p><p>No hemos recibido ningún informe suyo en los últimos <b>{0} soles</b>. La telemetría muestra que el vehículo funciona, pero en su registro de campo se han acumulado <b>{1} entradas sin enviar</b>.</p>\n  <p>Nuestro equipo científico y la unidad de salud de la tripulación esperan sus datos. Le rogamos que envíe un informe de situación, aunque sea breve. Que nos escriba una o dos frases sobre cómo se siente también es valioso para nosotros.</p>",
    "Rapor talebi": "Solicitud de informe",
    "<p>Sayın Komutan,</p><p>Telemetri ana motorun çevrimiçi olduğunu ve kargo bölmesinin <b>{0}/{1}</b> dolduğunu doğruluyor. <b>Dünya'ya dönüş penceresi açılmıştır.</b></p>\n  <p>Komuta güvertesindeki navigasyon bilgisayarından dönüş rotasını onaylayabilirsiniz. Kalkıştan önce yaşadıklarınızı içeren son bir rapor göndermeniz, görev arşivi için çok değerli olacaktır.</p><p>Eve hoş geleceksiniz.</p>":
      "<p>Estimado comandante:</p><p>La telemetría confirma que el motor principal está en línea y que la bodega de carga está llena al <b>{0}/{1}</b>. <b>La ventana de regreso a la Tierra está abierta.</b></p>\n  <p>Puede confirmar la ruta de regreso desde el ordenador de navegación de la cubierta de mando. Enviar un último informe con sus vivencias antes del despegue sería muy valioso para el archivo de la misión.</p><p>Bienvenido a casa de antemano.</p>",
    "Dönüş penceresi açıldı": "Ventana de regreso abierta",
    "Çürüyen patatesleri biyoloji ekibi inceleyecek. Çürük patatesi kargo terminalinden bize gönderin.":
      "El equipo de biología examinará las patatas podridas. Enviadnos una patata podrida desde el terminal de carga.",
    "Fırtınalar konusundaki endişenizi anlıyoruz. Fırtınalar her 5 solda bir, sabah saatlerinde başlıyor; uyarı kartı göründüğünde 45 saniyeniz var.":
      "Entendemos su preocupación por las tormentas. Empiezan cada 5 soles por la mañana; cuando aparece la tarjeta de aviso dispone de 45 segundos.",
    "Toz fırtınası sırasında aracın gövdesi tasarım sınırları içinde kalıyor; içeride güvendesiniz. Sarsıntı normaldir.":
      "Durante una tormenta de polvo el casco del vehículo se mantiene dentro de sus límites de diseño; dentro está a salvo. Las sacudidas son normales.",
    "Motor konusunda yazdıklarınızı itki ekibine ilettik. Duman, kontrol kartındaki yanık sigortalardan ve kopan güç kablolarından kaynaklanıyor; onarım prosedürü bu sırayı izliyor.":
      "Hemos transmitido al equipo de propulsión lo que escribió sobre el motor. El humo procede de fusibles quemados en la placa de control y de cables de alimentación arrancados; el procedimiento de reparación sigue este orden.",
    "İtki ekibi, onarım sırasında aşamaları atlamamanızı rica ediyor: önce kablolar, sonra sigortalar ve ana şalter, ardından basınç kalibrasyonu ve son olarak ateşleme dizisi.":
      "El equipo de propulsión le pide que no se salte fases durante la reparación: primero los cables, luego los fusibles y el interruptor general, después la calibración de presión y, por último, la secuencia de encendido.",
    "Oksijen yönetimi hayati önemde: giysi oksijeni %30'un altına indiğinde dış görevi bitirin. Makine dairesindeki O₂ tüpleri kendini yavaşça yeniliyor; tüp seviyesini de takip edin.":
      "La gestión del oxígeno es vital: termine la EVA cuando el oxígeno del traje baje del 30 %. Los tanques de O₂ de la sala de máquinas se rellenan solos poco a poco; vigile también su nivel.",
    "Su geri dönüştürücü düzenli çalışıyor; stok yavaş da olsa kendiliğinden yenileniyor. Mutfaktan şişe alıp çantanızda taşıyabilirsiniz.":
      "El reciclador de agua funciona con normalidad; la reserva se repone sola, aunque despacio. Puede coger botellas de la cocina y llevarlas en su mochila.",
    "Erzak durumunuzu yakından izliyoruz. Patates yetiştirmek uzun vadeli tek gıda kaynağınız; her hasat ek tohum da veriyor. Mutfak ve yemek kapsülündeki stoku dengeli kullanın.":
      "Seguimos de cerca su situación de víveres. Cultivar patatas es su única fuente de alimento a largo plazo; cada cosecha también da semillas adicionales. Use con moderación las reservas de la cocina y de la cápsula de comida.",
    "Radyasyon dalgaları her 3 solda bir, günün ilk saatlerinde geliyor. Aracın gövde zırhı sizi tamamen koruyor; dalga boyunca içeride kalmanız ya da uyumanız yeterli.":
      "Las olas de radiación llegan cada 3 soles en las primeras horas del día. El blindaje del casco del vehículo le protege por completo; basta con quedarse dentro o dormir durante la ola.",
    "Meteorlar öngörülemez, ancak düşmeden önce bir uğultu ve yerde büyüyen bir gölge oluşuyor. Gölgeden uzaklaşın; çarpmadan sonra kraterlerde değerli numuneler bulabilirsiniz.":
      "Los meteoritos son impredecibles, pero antes de caer se oye un estruendo y aparece en el suelo una sombra que crece. Aléjese de la sombra; tras el impacto puede encontrar muestras valiosas en los cráteres.",
    "Yazdıklarınızı dikkatle okudum. Bu duyguların izole ve yüksek riskli bir ortamda çok doğal olduğunu bilmenizi isterim; zayıflık değil, insan olmanın bir parçası.":
      "He leído con atención lo que nos escribió. Quiero que sepa que estos sentimientos son totalmente naturales en un entorno aislado y de alto riesgo; no son debilidad, sino parte de ser humano.",
    "Günlük bir rutin kurmanızı öneriyorum: düzenli uyku, öğünler ve her sol kısa da olsa bir rapor. Bize yazmak da bir bağ kurmaktır; her mesajınızı okuyoruz. Aileniz iyi ve size selamlarını iletiyorlar.":
      "Le sugiero establecer una rutina diaria: sueño regular, comidas y un informe cada sol, aunque sea breve. Escribirnos también es una forma de mantener el vínculo; leemos todos sus mensajes. Su familia está bien y le envía saludos.",
    "Sağlık durumunuzu kayda aldık. Can değeriniz düştüğünde revirdeki medikitleri kullanın; uyku da iyileşmeyi belirgin şekilde hızlandırıyor.":
      "Hemos registrado su estado de salud. Use los botiquines de la enfermería cuando baje su salud; dormir también acelera notablemente la recuperación.",
    "Tarım denemeniz biyoloji ekibinin en çok takip ettiği konu. Parsellerinizi sulamayı unutmayın; ıslak toprakta büyüme belirgin şekilde hızlanıyor.":
      "Su experimento de cultivo es el tema que el equipo de biología sigue más de cerca. No olvide regar sus parcelas; en tierra húmeda el crecimiento se acelera notablemente.",
    "Dönüş için iki koşul gerekiyor: ana motorun çalışır olması ve kargo bölmesinin {0} birim numuneyle dolması. Bu sağlandığında navigasyon bilgisayarı dönüş rotasını açacak.":
      "Para el regreso se necesitan dos condiciones: que el motor principal funcione y que la bodega de carga se llene con {0} unidades de muestras. Cuando se cumplan, el ordenador de navegación desbloqueará la ruta de regreso.",
    "Asıl biz teşekkür ederiz. Kontrol odasında her raporunuz okunurken herkes ekranın başına toplanıyor.":
      "Somos nosotros quienes debemos darle las gracias. Cada vez que se lee uno de sus informes, todos en la sala de control se reúnen frente a la pantalla.",
    "Numune toplama çalışmanız bilim ekibinin önceliği. Yıldız kristalleri metal numunelerin iki katı değerinde; kargoya yüklerken bunu göz önünde bulundurun.":
      "Su recogida de muestras es la prioridad del equipo científico. Los cristales estelares valen el doble que las muestras metálicas; téngalo en cuenta al cargar la bodega.",
    "Patatesler, ekildikleri toprağın radyasyonu <b>1,0 µSv/h</b> ve üzerindeyse hasatta çürük çıkar. Roketteki <b>alet sandığından</b> radyasyon ölçeri alın ve ekmeden önce toprağı ölçün; ekranda <b>RADYASYON NORMAL</b> görünen yere ekin. Bugüne kadar {0} ölçüm yaptınız, bunların {1} tanesi normal çıktı.":
      "Las patatas salen podridas en la cosecha si el suelo donde se plantaron marca <b>1,0 µSv/h</b> o más. Coge el medidor de radiación de la <b>caja de herramientas</b> del cohete y mide el suelo antes de plantar; planta donde la pantalla muestre <b>RADIACIÓN NORMAL</b>. Hasta ahora has hecho {0} mediciones, {1} de ellas normales.",
    "Giysi oksijeniniz şu anda <b>%{0}</b>, roketteki O₂ tüpü <b>%{1}</b> dolu. Giysi oksijeni %30'un altına düştüğünde rokete dönün ve makine dairesindeki O₂ istasyonundan doldurun. Koşmak tüketimi artırır.":
      "El oxígeno de tu traje está al <b>{0} %</b> y el tanque de O₂ del cohete al <b>{1} %</b>. Cuando el oxígeno del traje baje del 30 %, vuelve al cohete y recarga en la estación de O₂ de la sala de máquinas. Correr aumenta el consumo.",
    "Çantanızda <b>{0}</b>, depoda <b>{1}</b> şişe su var; susuzluk göstergeniz %{2}. Su geri dönüştürücü yaklaşık her {3} dakikada bir şişe üretir. Şişeleri kargo terminalinden ya da mutfaktan alabilirsiniz.":
      "Tienes <b>{0}</b> botellas de agua en la mochila y <b>{1}</b> en el almacén; tu indicador de sed está al {2} %. El reciclador de agua produce una botella cada {3} minutos aproximadamente. Puedes cogerlas en el terminal de carga o en la cocina.",
    "Tokluğunuz %{0}. Çantanızda <b>{1}</b>, depoda <b>{2}</b> patates ve toplam <b>{3}</b> tohum var. Erzak azalıyorsa radyasyonu normal toprağa patates ekin; düzenli sulama büyümeyi hızlandırır.":
      "Tu saciedad está al {0} %. Tienes <b>{1}</b> patatas en la mochila, <b>{2}</b> en el almacén y <b>{3}</b> semillas en total. Si escasean las provisiones, planta patatas en suelo con radiación normal; regar a menudo acelera el crecimiento.",
    "Bir sonraki toz fırtınası <b>Sol {0}</b> için öngörülüyor. Fırtına sırasında anten kapanabilir ve dışarıdaki ana motor arızalanabilir. Uyarı gelince rokete girin ve fırtına geçene kadar dışarı çıkmayın.":
      "La próxima tormenta de polvo está prevista para el <b>Sol {0}</b>. Durante la tormenta la antena puede quedar bloqueada y el motor principal puede averiarse. Cuando llegue el aviso, entra en el cohete y quédate dentro hasta que pase.",
    "Bir sonraki güneş kaynaklı radyasyon dalgası <b>Sol {0}</b> için öngörülüyor. Dalga sırasında dışarıda kalmak can kaybettirir; roketin gövdesi koruma sağlar. Şu anki ortam radyasyonu <b>{1} µSv/h</b>.":
      "La próxima ola de radiación solar está prevista para el <b>Sol {0}</b>. Quedarse fuera durante la ola resta salud; el casco del cohete te protege. La radiación ambiental actual es de <b>{1} µSv/h</b>.",
    "Ana motor şu anda <b>çevrimiçi</b>. Fırtınalarda arızalanabileceği için fırtına uyarısında rokete girmeniz yeterlidir.":
      "El motor principal está <b>en línea</b>. Puede averiarse con las tormentas, así que basta con entrar en el cohete cuando llegue el aviso.",
    "Ana motor şu anda <b>devre dışı</b>; onarım {0}/4 aşamada. Makine dairesindeki onarım istasyonuna gidip adımları sırasıyla tamamlayın.":
      "El motor principal está <b>fuera de servicio</b>; la reparación va por la fase {0}/4. Ve a la estación de reparación de la sala de máquinas y completa los pasos en orden.",
    çevrimiçi: "en línea",
    "devre dışı": "fuera de servicio",
    "Dünya'ya dönüş için iki koşul gerekiyor: ana motorun çevrimiçi olması (şu an: <b>{0}</b>) ve kargoda en az <b>{1}</b> numune bulunması (şu an: <b>{2}/{3}</b>).":
      "Para volver a la Tierra hacen falta dos cosas: el motor principal en línea (ahora: <b>{0}</b>) y al menos <b>{1}</b> muestras en la bodega (ahora: <b>{2}/{3}</b>).",
    "Kargo bölmesinde <b>{0}/{1}</b> numune var. Metal numune 1, yıldız kırıntısı 2 puan sayılır; numuneleri roketin yanında <b>F</b> ile ya da kargo terminalinden yükleyin.":
      "La bodega tiene <b>{0}/{1}</b> muestras. Una muestra metálica cuenta 1 y un fragmento de estrella 2; carga las muestras junto al cohete con <b>F</b> o desde el terminal de carga.",
    "Canınız <b>%{0}</b>. Toplam <b>{1}</b> medikitiniz var; revirden alıp kullanabilirsiniz. Uyumak da canı yavaşça yeniler.":
      "Tu salud está al <b>{0} %</b>. Tienes <b>{1}</b> botiquines en total; cógelos en la enfermería. Dormir también recupera salud poco a poco.",
    "Yatakhanedeki ranzada uyuyabilirsiniz. Uyurken zaman hızlanır, can yenilenir; oksijen ve erzak tüketimi devam eder, bu yüzden uyumadan önce stoklarınızı kontrol edin.":
      "Puedes dormir en la litera del dormitorio. Mientras duermes el tiempo pasa más rápido y recuperas salud; el oxígeno y la comida se siguen consumiendo, así que revisa tus provisiones antes de dormir.",
    "Şu an <b>Sol {0}</b>, Mars yerel saati <b>{1}</b>. Bir Mars günü (sol) yaklaşık 24 saat 40 dakika sürer.":
      "Ahora es el <b>Sol {0}</b>, hora local de Marte <b>{1}</b>. Un día marciano (sol) dura unas 24 horas y 40 minutos.",
    "Dış sıcaklık şu anda yaklaşık <b>{0} °C</b>. Giysinizin ısıl kontrolü vücut sıcaklığınızı <b>{1} °C</b> civarında tutuyor; gece sıcaklık −75 °C'ye kadar düşebilir.":
      "La temperatura exterior es de unos <b>{0} °C</b>. El control térmico del traje mantiene tu temperatura corporal en torno a <b>{1} °C</b>; de noche puede bajar a −75 °C.",
    "Mesajlarınız Mars ile Dünya arasında tek yönde yaklaşık <b>{0} dakikada</b> iletiliyor. Şu an sizi <b>{1}</b> derin uzay anteni izliyor; istasyonlar Dünya döndükçe sırayla devralır.":
      "Tus mensajes tardan unos <b>{0} minutos</b> en un sentido entre Marte y la Tierra. Ahora te sigue la antena de espacio profundo <b>{1}</b>; las estaciones se relevan a medida que gira la Tierra.",
    "Meteorlar önceden kesin olarak bilinemez. Düşmeden önce bir uğultu duyulur ve yerde büyüyen bir gölge oluşur; gölgeyi görünce hemen uzaklaşın.":
      "Los meteoritos no se pueden predecir con exactitud. Antes del impacto se oye un retumbo y aparece una sombra creciente en el suelo; aléjate en cuanto la veas.",
    "Şu anda <b>{0}</b> altınınız var. Roketteki geliştirme istasyonunda altınla roketinizi ve ekipmanınızı güçlendirebilirsiniz.":
      "Tienes <b>{0}</b> de oro. Úsalo en la estación de mejoras del cohete para mejorar el cohete y el equipo.",
    "Tüm görevleri tamamladınız. Dönüş penceresi açıksa rokete binip Dünya'ya dönebilirsiniz.":
      "Has completado todas las misiones. Si la ventana de regreso está abierta, sube al cohete y vuelve a la Tierra.",
    "Şu anki göreviniz: <b>{0}</b> — {1}. Önerimiz: {2}":
      "Tu tarea actual: <b>{0}</b> — {1}. Nuestro consejo: {2}",
    "Duygularınızı paylaştığınız için teşekkür ederiz. Uzun görevlerde bu çok doğal. Davranış sağlığı ekibimiz sizi takip ediyor; düzenli uyku, kısa molalar ve hedeflerinizi küçük adımlara bölmek yardımcı olur. Yalnız değilsiniz, her mesajınız burada okunuyor.":
      "Gracias por compartir cómo te sientes. En misiones largas es muy normal. Nuestro equipo de salud conductual te acompaña; dormir con regularidad, hacer pausas cortas y dividir los objetivos en pasos pequeños ayuda. No estás solo: aquí se lee cada mensaje.",
    "Ben <b>GDY-1</b>, ARES Görev Kontrol Merkezi'nin görev destek yapay zekâsıyım. Raporlarınızdaki soruları canlı görev verileriyle eşleştirip resmî yanıt hazırlıyorum; ayrıntılı değerlendirmeler uzman ekiplerden ayrıca gelir.":
      "Soy <b>GDY-1</b>, la IA de apoyo a la misión del Control de Misión ARES. Relaciono las preguntas de tus informes con datos de misión en directo y preparo respuestas oficiales; las evaluaciones detalladas llegan aparte de los equipos expertos.",
    "Merhaba Komutan. Mesajınız alındı; sinyal kalitesi iyi. Sormak istediğiniz her şeyi raporunuza yazabilirsiniz.":
      "Hola, comandante. Hemos recibido tu mensaje y la calidad de la señal es buena. Puedes escribir en tu informe todo lo que quieras preguntar.",
    "Rica ederiz Komutan. Görev Kontrol her an hattadır.":
      "De nada, comandante. Control de Misión está siempre en línea.",
    "Sorunuzu kayda aldım; görev veritabanında doğrudan eşleşen bir konu bulamadım ve uzman ekiplere ilettim.":
      "He registrado tu pregunta; no encontré una coincidencia directa en la base de datos de la misión y la he enviado a los equipos expertos.",
    "Sorunuzu kayda aldım; görev veritabanında doğrudan eşleşen bir konu bulamadım ve uzman ekiplere ilettim. Bu arada şu anki göreviniz: <b>{0}</b> — {1}.":
      "He registrado tu pregunta; no encontré una coincidencia directa en la base de datos de la misión y la he enviado a los equipos expertos. Mientras tanto, tu tarea actual: <b>{0}</b> — {1}.",
    '<div class="ai-qa"><div class="ai-q"><span>SORU {0}</span>«{1}»</div><div class="ai-a"><span>YANIT</span><p>{2}</p></div></div>':
      '<div class="ai-qa"><div class="ai-q"><span>PREGUNTA {0}</span>«{1}»</div><div class="ai-a"><span>RESPUESTA</span><p>{2}</p></div></div>',
    '<p>Sayın Komutan,</p>\n  <p><b>{0}</b> numaralı raporunuzdaki not, {1} anteni üzerinden alınarak <b>GDY-1 Görev Destek Yapay Zekâsı</b> tarafından canlı görev verileriyle (Sol {2} · {3}) değerlendirilmiştir. Yanıtlar aşağıdadır.</p>\n  {4}\n  <p class="ai-ft">Bu yanıt otomatik olarak hazırlanmış ve Görev Kontrol adına resmî bilgilendirme niteliğindedir. Uzman ekiplerin ayrıntılı değerlendirmesi rapor yanıtıyla ayrıca iletilecektir.</p>':
      '<p>Estimado comandante:</p>\n  <p>La nota de tu informe <b>{0}</b> se recibió a través de la antena {1} y la evaluó con datos de misión en directo (Sol {2} · {3}) <b>GDY-1, la IA de Apoyo a la Misión</b>. Las respuestas están a continuación.</p>\n  {4}\n  <p class="ai-ft">Esta respuesta se generó automáticamente y es un aviso oficial en nombre de Control de Misión. La evaluación detallada de los equipos expertos llegará con la respuesta al informe.</p>',
    "Sorunuza yanıt · ": "Respuesta a tu pregunta · ",
    '<div class="ltr-dir"><b>TALİMATLAR</b><ol>{0}</ol></div>':
      '<div class="ltr-dir"><b>INSTRUCCIONES</b><ol>{0}</ol></div>',
    "Sol {0} fırtınasına ait verileriniz Uzay Hava Durumu Birimi tarafından incelendi. Yörünge görüntüleriyle karşılaştırıldığında bölgenizdeki toz yoğunluğunun optik derinlik <b>τ≈{1}</b> seviyesine ulaştığı anlaşılıyor.":
      "La Unidad de Meteorología Espacial ha analizado sus datos de la tormenta del sol {0}. Al compararlos con las imágenes orbitales, se deduce que la densidad de polvo en su zona alcanzó una profundidad óptica de <b>τ≈{1}</b>.",
    "Gönderdiğiniz fırtına gözlemleri, bu enlemde kaydedilen en yoğun yerel toz olaylarından biriyle uyumlu. Rüzgâr hızının anlık olarak <b>{0} km/sa</b>'e çıktığını tahmin ediyoruz.":
      "Sus observaciones de la tormenta coinciden con uno de los eventos de polvo locales más intensos registrados en esta latitud. Calculamos que la velocidad del viento llegó a <b>{0} km/h</b> en algunos momentos.",
    "Fırtına süresince toplanan basınç ve görüş verileri modelimizi doğrulamamızı sağladı; tahmin hatamız bu veriyle <b>%{0}</b> azaldı.":
      "Los datos de presión y visibilidad recogidos durante la tormenta nos permitieron validar nuestro modelo; con ellos, nuestro error de pronóstico se redujo un <b>{0} %</b>.",
    "Kayıtlar fırtına sırasında araç dışında yaklaşık <b>{0}</b> geçirdiğinizi gösteriyor. Bu, EVA güvenlik kuralının (GK-EVA-7) açıkça ihlalidir; lütfen bir daha tekrarlamayın.":
      "Los registros muestran que pasó aproximadamente <b>{0}</b> fuera del vehículo durante la tormenta. Esto es una clara infracción de la norma de seguridad de EVA (GK-EVA-7); por favor, no lo repita.",
    "Fırtına boyunca araç içinde kalmanız prosedüre tam uygundur; teşekkür ederiz.":
      "Permanecer dentro del vehículo durante toda la tormenta se ajusta plenamente al procedimiento; gracias.",
    "Mürettebatın fırtınayı araç içinde geçirmesi doğru karardı.":
      "La decisión de la tripulación de pasar la tormenta dentro del vehículo fue la correcta.",
    " Fırtınanın ana motora verdiği hasar ayrıca itki ekibine iletilmiştir.":
      " Los daños que la tormenta causó al motor principal también se han comunicado al equipo de propulsión.",
    "Fırtına uyarı kartı göründüğünde <b>45 saniye</b> içinde hava kilidine dönün.":
      "Cuando aparezca la tarjeta de aviso de tormenta, vuelva a la esclusa en menos de <b>45 segundos</b>.",
    "Sonraki fırtına <b>Sol {0}</b>, {1} için öngörülüyor; o sol dış görevleri fırtına öncesine planlayın.":
      "La próxima tormenta está prevista para el <b>sol {0}</b>, {1}; planifique las EVA de ese sol antes de la tormenta.",
    "Fırtına öncesi çantanızdaki numuneleri kargoya yükleyin.":
      "Cargue en la bodega las muestras de su mochila antes de la tormenta.",
    "Fırtına sırasında komuta güvertesindeki ön camdan görüş gözlemi yapıp raporlayın.":
      "Durante la tormenta, observe la visibilidad a través del parabrisas de la cubierta de mando e infórmenos.",
    "Fırtına sonrası oksijen tüpü seviyesini kontrol edin; filtreler tozla yüklenmiş olabilir.":
      "Después de la tormenta, compruebe el nivel de los tanques de oxígeno; los filtros pueden estar cargados de polvo.",
    "İtki ekibimiz bildirdiğiniz arızayı telemetriyle eşleştirdi. Toz girişinin yakıt hattı vanasında basınç dalgalanmasına, ardından kontrol kartında aşırı akıma yol açtığı değerlendiriliyor.":
      "Nuestro equipo de propulsión ha cotejado la avería que comunicó con la telemetría. Se cree que la entrada de polvo provocó fluctuaciones de presión en la válvula de la línea de combustible y, a continuación, una sobrecorriente en la placa de control.",
    "Arıza raporunuz itki ekibinde öncelikli olarak ele alındı. Ön analiz: fırtına esnasındaki titreşim güç kablolarını soketlerinden kopardı, oluşan kısa devre sigortaları yaktı.":
      "El equipo de propulsión atendió su informe de avería con prioridad. Análisis preliminar: la vibración durante la tormenta arrancó los cables de alimentación de sus conectores y el cortocircuito resultante quemó los fusibles.",
    "Bildirdiğiniz motor arızası, test tesisimizdeki yedek motorda simüle edildi. Aynı belirtileri (duman, kalkış kilidi, kontrol kartı sessizliği) elde ettik; arıza tipi doğrulandı.":
      "La avería del motor que comunicó se simuló en el motor de reserva de nuestras instalaciones de pruebas. Obtuvimos los mismos síntomas (humo, bloqueo del despegue, placa de control sin señal); el tipo de avería está confirmado.",
    "<b>Bu yanıt hazırlanırken alınan telemetri motorun yeniden çevrimiçi olduğunu gösteriyor — tebrikler.</b>":
      "<b>La telemetría recibida mientras se preparaba esta respuesta muestra que el motor vuelve a estar en línea: enhorabuena.</b>",
    "<b>Güncel telemetri motorun hâlâ devre dışı olduğunu gösteriyor</b> (tamamlanan aşama: {0}/4). Onarım bitmeden dönüş penceresi açılmayacaktır.":
      "<b>La telemetría actual muestra que el motor sigue fuera de servicio</b> (fases completadas: {0}/4). La ventana de regreso no se abrirá hasta que termine la reparación.",
    "Motor çalışırken makine dairesinde olağandışı ses ya da duman görürseniz derhal raporlayın.":
      "Si nota ruidos o humo inusuales en la sala de máquinas con el motor en marcha, infórmenos de inmediato.",
    "Makine dairesinde ana motora ya da tamir tezgâhına <kbd>E</kbd> ile erişin.":
      "En la sala de máquinas, acceda al motor principal o al banco de trabajo con <kbd>E</kbd>.",
    "Prosedür sırası: <b>kablolar → sigortalar + ana şalter → basınç kalibrasyonu → ateşleme</b>. Tamamlanan aşamalar kaydedilir.":
      "Orden del procedimiento: <b>cables → fusibles + interruptor general → calibración de presión → encendido</b>. Las fases completadas se guardan.",
    "Basınç aşamasında ibre yeşil bölgedeyken kilitleyin; acele etmeyin.":
      "En la fase de presión, bloquee mientras la aguja esté en la zona verde; no se precipite.",
    "Duman yoğunken uzun süre makine dairesinde kalmayın.":
      "No permanezca mucho tiempo en la sala de máquinas mientras haya mucho humo.",
    "Onarım kayıtlarınızı inceledik: tüm aşamalar nominal değerlerde tamamlanmış. Bu, Mars yüzeyinde mürettebat tarafından yapılan ilk tam itki onarımıdır; tebrikler.":
      "Hemos revisado sus registros de reparación: todas las fases se completaron con valores nominales. Es la primera reparación completa de propulsión realizada por una tripulación en la superficie de Marte; enhorabuena.",
    "Motorun yeniden çevrimiçi olması tüm kontrol odasında alkışla karşılandı. Onarım verileriniz üretici firmaya iletildi; sonraki araç tasarımında toz filtresi revize edilecek.":
      "La vuelta del motor a la línea se recibió con aplausos en toda la sala de control. Sus datos de reparación se han enviado al fabricante; el filtro de polvo se revisará en el próximo diseño del vehículo.",
    "Sonraki fırtınada motor bölmesinin sızdırmazlığını gözlemleyin.":
      "En la próxima tormenta, observe la estanqueidad del compartimento del motor.",
    "Onarım sırasında fark ettiğiniz her şeyi notunuza ekleyin; mühendislerimiz için çok değerli.":
      "Añada a su nota todo lo que haya notado durante la reparación; es muy valioso para nuestros ingenieros.",
    "Dozimetre verileriniz Uzay Hava Durumu Birimi ve Uçuş Cerrahı tarafından birlikte değerlendirildi.":
      "La Unidad de Meteorología Espacial y el médico de vuelo evaluaron conjuntamente sus datos de dosímetro.",
    "Parçacık dalgasına ait sensör verileriniz başarıyla işlendi; olay, Güneş'teki bir koronal kütle atımıyla eşleştirildi.":
      "Sus datos de sensores sobre la ola de partículas se procesaron correctamente; el evento se asoció a una eyección de masa coronal en el Sol.",
    " Kayıtlara göre dalga sırasında araç dışında <b>{0}</b> kaldınız; tahmini alınan doz <b>~{1} mSv</b>. Bu değer yıllık limitinizin önemli bir kısmıdır. Sağlık kaydınıza işlendi.":
      " Según los registros, durante la ola estuvo <b>{0}</b> fuera del vehículo; la dosis estimada recibida es de <b>~{1} mSv</b>. Es una parte importante de su límite anual. Se ha anotado en su historial médico.",
    " Dalga boyunca zırhlı gövde içinde kalmanız sayesinde aldığınız doz ihmal edilebilir düzeyde (<b>&lt;1 mSv</b>). Mükemmel.":
      " Gracias a que permaneció dentro del casco blindado durante la ola, la dosis recibida es insignificante (<b>&lt;1 mSv</b>). Excelente.",
    "Sonraki radyasyon dalgası <b>Sol {0}</b>, {1}–{2} arasında bekleniyor.":
      "La próxima ola de radiación se espera el <b>sol {0}</b>, entre {1}–{2}.",
    "Dalga sırasında araç içinde kalın; uyumak zamanı güvenle geçirmenin en iyi yolu.":
      "Permanezca dentro del vehículo durante la ola; dormir es la mejor forma de pasar el tiempo con seguridad.",
    "Doz aldıysanız revirdeki medikiti kullanın.":
      "Si ha recibido una dosis, use el botiquín de la enfermería.",
    "Ekran yeşile döndüğünde ve kenarlarda ışıma başladığında derhal rokete dönün.":
      "Cuando la pantalla se vuelva verde y los bordes empiecen a brillar, vuelva de inmediato al cohete.",
    "Bildirdiğiniz <b>{0}</b> meteor çarpması bilim ekibinde büyük heyecan yarattı. Taze kraterler, Mars yüzeyinin yaşı ve iç yapısı hakkında eşsiz bilgi sağlıyor.":
      "Los <b>{0}</b> impactos de meteoritos que comunicó causaron gran entusiasmo en el equipo científico. Los cráteres recientes aportan información única sobre la edad y la estructura interna de la superficie de Marte.",
    "Gezegen Bilimi Ekibi, raporunuzdaki {0} çarpmayı yörünge sismik verileriyle eşleştirdi. Çarpışma enerjilerinin her biri için birkaç ton TNT eşdeğeri olduğu hesaplanıyor.":
      "El Equipo de Ciencia Planetaria cotejó los {0} impactos de su informe con datos sísmicos orbitales. Se calcula que la energía de cada impacto equivale a varias toneladas de TNT.",
    " Ancak en yakın çarpmanın yalnızca <b>~{0} m</b> mesafede olması ciddi bir risk; uçuş cerrahımız endişeli.":
      " Sin embargo, que el impacto más cercano estuviera a solo <b>~{0} m</b> supone un riesgo grave; nuestro médico de vuelo está preocupado.",
    " En yakın çarpma ~{0} m mesafede; güvenli sınırlar içinde.":
      " El impacto más cercano estuvo a ~{0} m; dentro de los límites de seguridad.",
    "Uğultu duyduğunuzda yerdeki <b>büyüyen gölgeyi</b> arayın ve ondan uzaklaşın.":
      "Cuando oiga un estruendo, busque la <b>sombra que crece</b> en el suelo y aléjese de ella.",
    "Taze kraterler bir süre sıcak kalır; tütmesi bitince numune arayın.":
      "Los cráteres recientes permanecen calientes un tiempo; busque muestras cuando dejen de humear.",
    "Kraterlerde bulduğunuz yıldız kristallerini öncelikle kargoya yükleyin.":
      "Cargue primero en la bodega los cristales estelares que encuentre en los cráteres.",
    "Bildirdiğiniz <b>{0}</b> bulguları bilim ekibinde olağanüstü bir heyecan yarattı. Bu mineraller yörünge spektrometreleriyle yalnızca dolaylı olarak tespit edilmişti; yerinde analiz ilk kez yapıldı.":
      "Los hallazgos de <b>{0}</b> que comunicó causaron un entusiasmo extraordinario en el equipo científico. Hasta ahora estos minerales solo se habían detectado de forma indirecta con espectrómetros orbitales; es el primer análisis in situ.",
    "Gezegen Bilimi Ekibi raporladığınız {0} örneklerini inceledi. Kristal yapısı, bölgede geçmişte hidrotermal etkinlik olduğuna işaret ediyor.":
      "El Equipo de Ciencia Planetaria examinó las muestras de {0} que comunicó. La estructura cristalina indica que en la zona hubo actividad hidrotermal en el pasado.",
    "Uzak bölgelerde tarayıcı sinyallerini takip etmeye devam edin; ancak oksijen seviyenizi dönüş için yeterli tutun.":
      "Siga las señales del escáner en zonas remotas, pero conserve oxígeno suficiente para el regreso.",
    "Titanyum cevherini roket zırhı için, olivin kristallerini EVA giysisi için ayırın.":
      "Reserve el mineral de titanio para el blindaje del cohete y los cristales de olivino para el traje de EVA.",
    "Ares taşı son derece nadir; bulduğunuz her parça bilimsel olarak paha biçilemez.":
      "La piedra de Ares es extremadamente rara; cada fragmento que encuentre tiene un valor científico incalculable.",
    "Gönderdiğiniz {0} metal{1} numunesinin spektral ön verisi, yüksek demir-nikel oranına işaret ediyor.":
      "Los datos espectrales preliminares de las {0} muestras metálicas{1} que envió indican una alta proporción de hierro y níquel.",
    ", {0} kristal": ", {0} cristales",
    "Numune verileriniz ({0} metal{1}) laboratuvarımızdaki Mars göktaşı koleksiyonuyla karşılaştırılıyor; ilk sonuçlar umut verici.":
      "Sus datos de muestras ({0} metálicas{1}) se están comparando con la colección de meteoritos marcianos de nuestro laboratorio; los primeros resultados son prometedores.",
    "Yıldız kristallerinin kökeni ekibimizde tartışma yarattı; hidratlı mineral olasılığı, geçmişte sıvı su bulunduğuna işaret edebilir.":
      "El origen de los cristales estelares ha generado debate en nuestro equipo; la posibilidad de que sean minerales hidratados podría indicar que en el pasado hubo agua líquida.",
    "Kristallerin parlaklık spektrumu bilinen hiçbir Mars mineraliyle tam eşleşmiyor. Lütfen toplamaya devam edin.":
      "El espectro de brillo de los cristales no coincide del todo con ningún mineral marciano conocido. Por favor, siga recogiéndolos.",
    "Kargo hedefi: <b>{0}</b> birim · güncel durum <b>{1}/{2}</b>. Numuneleri komuta güvertesindeki stok terminalinden yükleyin.":
      "Objetivo de carga: <b>{0}</b> unidades · estado actual <b>{1}/{2}</b>. Cargue las muestras desde el terminal de existencias de la cubierta de mando.",
    "Çürümenin nedeni toprağın yüksek radyasyonu. Ekimden önce radyasyon ölçerle toprağı ölçün.":
      "La podredumbre se debe a la alta radiación del suelo. Medid el suelo con el medidor de radiación antes de plantar.",
    "Çürüyen hasat bildiriminiz biyoloji ekibine iletildi. Çürük patatesi kargo terminalinden bize gönderin, inceleyip sonucu bildirelim.":
      "Vuestro aviso de cosecha podrida ha llegado al equipo de biología. Enviadnos una patata podrida desde el terminal de carga y os daremos el resultado.",
    "Ekimden önce toprağı ölç: <b>1,0 µSv/h</b> altı güvenli.":
      "Mide el suelo antes de plantar: por debajo de <b>1,0 µSv/h</b> es seguro.",
    "Çürük patates örneğini çantanızda tutun.": "Guardad una patata podrida como muestra en la mochila.",
    "Aynı parsele yeniden ekim yapmayın.": "No volváis a plantar en la misma parcela.",
    "Tarım verileriniz ({0} ekim, {1} hasat) Biyorejeneratif Yaşam Destek ekibinin en çok beklediği veriler arasında. Mars regolitinde patates yetiştirmek, uzun süreli görevlerin anahtarı.":
      "Sus datos de cultivo ({0} siembras, {1} cosechas) están entre los que más esperaba el equipo de Soporte Vital Biorregenerativo. Cultivar patatas en el regolito marciano es la clave de las misiones de larga duración.",
    "Biyoloji ekibi raporunuzdaki ekim/hasat oranını ({0}/{1}) Dünya'daki kontrol deneyiyle karşılaştırıyor. Regolitteki perkloratlara rağmen büyümenin sürmesi çok önemli bir bulgu.":
      "El equipo de biología está comparando la proporción de siembra/cosecha de su informe ({0}/{1}) con el experimento de control en la Tierra. Que el crecimiento continúe pese a los percloratos del regolito es un hallazgo muy importante.",
    "Parselleri düzenli sulayın; ıslak toprakta büyüme hızlanır.":
      "Riegue las parcelas con regularidad; en tierra húmeda el crecimiento se acelera.",
    "Her hasattan gelen tohumu yeniden ekerek döngüyü sürdürün.":
      "Mantenga el ciclo resembrando la semilla de cada cosecha.",
    "Uyurken mahsul de 2 kat hızlı büyür; gece ekim yapmayı düşünün.":
      "Mientras duerme, los cultivos también crecen 2× más rápido; considere sembrar por la noche.",
    "Fırtınadan sonra parselleri kontrol edin.": "Revise las parcelas después de la tormenta.",
    "Lojistik kayıtları güncellendi. Güncel kargo durumu <b>{0}/{1}</b>. ":
      "Registros logísticos actualizados. Estado actual de la carga: <b>{0}/{1}</b>. ",
    "Kargo hedefi tamamlandı; dönüş için yalnızca araç sistemlerinin hazır olması gerekiyor.":
      "Se ha cumplido el objetivo de carga; para el regreso solo falta que los sistemas del vehículo estén listos.",
    "Hedefe ulaşmak için numune toplamaya devam edin.": "Siga recogiendo muestras para alcanzar el objetivo.",
    "Mürettebat sağlığı birimi raporunuzdaki kritik değerleri ciddiyetle inceledi.":
      "La unidad de salud de la tripulación examinó con seriedad los valores críticos de su informe.",
    "Yaşam destek uyarılarınız Uçuş Cerrahı'na öncelikli olarak iletildi.":
      "Sus alertas de soporte vital se enviaron con prioridad al médico de vuelo.",
    " Kayda geçen değerler: ": " Valores registrados: ",
    "<b>erzak tükenmesi</b>": "<b>suministros agotados</b>",
    "Giysi oksijeni %30'un altına inince dış görevi sonlandırın; O₂ tüpleri makine dairesinde.":
      "Termine la EVA cuando el oxígeno del traje baje del 30 %; los tanques de O₂ están en la sala de máquinas.",
    "Su seviyeniz için mutfaktan şişe alın ve çantanızda yedek taşıyın.":
      "Para su nivel de agua, coja botellas de la cocina y lleve repuestos en la mochila.",
    "Tokluk düştüğünde mutfakta ya da yemek kapsülünde patates tüketin.":
      "Cuando baje su nivel de saciedad, coma patatas en la cocina o en la cápsula de comida.",
    "Can değeriniz düşükken revirde medikit kullanın ve dinlenin.":
      "Cuando su salud esté baja, use un botiquín en la enfermería y descanse.",
    "Erzak tükendi: önceliğiniz tarım olmalı. Su geri dönüştürücü stoku yavaşça yeniliyor.":
      "Los suministros se han agotado: el cultivo debe ser su prioridad. El reciclador de agua repone la reserva poco a poco.",
    "Notunuz ilgili birimlere dağıtıldı. Konuyu daha ayrıntılı açıklarsanız uzman ekiplerimiz size daha net yanıt verebilir.":
      "Su nota se ha distribuido a las unidades correspondientes. Si explica el asunto con más detalle, nuestros equipos especializados podrán darle una respuesta más clara.",
    "Notunuzu kayda aldık ve görev günlüğüne işledik. Ekip toplantımızda ele alınacak.":
      "Hemos registrado su nota y la hemos anotado en el diario de la misión. Se tratará en nuestra reunión de equipo.",
    "Sorularınızın tümüne yanıt vermeye çalıştık; eksik kalan bir nokta olursa bir sonraki raporunuzda tekrar sorun.":
      "Hemos intentado responder a todas sus preguntas; si quedó algo pendiente, vuelva a preguntarlo en su próximo informe.",
    "Sorunuzu dikkate aldık. Daha fazla ayrıntı için bir sonraki raporunuzda bize koşullarınızı anlatın.":
      "Hemos tomado nota de su pregunta. Para más detalles, descríbanos sus condiciones en su próximo informe.",
    "<h4>{0}. ✍ Mürettebat notunuz</h4>{1}": "<h4>{0}. ✍ Su nota de tripulación</h4>{1}",
    '<span class="ok">ÇEVRİMİÇİ</span>': '<span class="ok">EN LÍNEA</span>',
    '<span class="bad">DEVRE DIŞI</span> · onarım ':
      '<span class="bad">FUERA DE SERVICIO</span> · reparación ',
    "<li>Ana motor: {0}</li>": "<li>Motor principal: {0}</li>",
    '<span class="bad">· KRİTİK</span>': '<span class="bad">· CRÍTICO</span>',
    "<li>Erzak: su {0}, patates {1} {2}</li>": "<li>Suministros: agua {0}, patatas {1} {2}</li>",
    "<li>O₂ tüpü: %{0} · kargo: {1}/{2}</li>": "<li>Tanque de O₂: {0} % · carga: {1}/{2}</li>",
    "ACİL önceliğiyle işaretlenen raporunuz alınır alınmaz görev ekibi toplandı ve tüm birimler raporunuzu öncelikli olarak inceledi.":
      "En cuanto llegó su informe marcado como URGENTE, el equipo de la misión se reunió y todas las unidades lo revisaron con prioridad.",
    "ACİL raporunuz üzerine kontrol odasında olağanüstü vardiya başlatıldı.":
      "En respuesta a su informe URGENTE se ha abierto un turno extraordinario en la sala de control.",
    "Raporunuz ilgili ekiplerimiz tarafından ayrıntılı olarak incelenmiştir.":
      "Los equipos correspondientes han revisado su informe en detalle.",
    "Raporunuz tüm birimlere dağıtılmış ve değerlendirilmiştir.":
      "Su informe se ha distribuido a todas las unidades y ha sido evaluado.",
    "Gönderdiğiniz veriler kontrol odasında ekiplerimiz tarafından tek tek ele alındı.":
      "Nuestros equipos de la sala de control analizaron uno por uno los datos que envió.",
    "Sayın Komutan,": "Estimado comandante:",
    "ARES-1 Komutanına,": "Al comandante de ARES-1:",
    "Değerli Komutanımız,": "Apreciado comandante:",
    "Çalışmalarınız için tüm ekip adına teşekkür ederiz. Güvende kalın.":
      "En nombre de todo el equipo, gracias por su trabajo. Manténgase a salvo.",
    "Dünya'da hepimiz sizinle gurur duyuyoruz. Bir sonraki raporunuzu bekliyoruz.":
      "Todos en la Tierra estamos orgullosos de usted. Esperamos su próximo informe.",
    "Unutmayın: yalnız değilsiniz, her adımınızı izliyoruz. Bir sonraki raporunuzu bekliyoruz.":
      "Recuerde: no está solo, seguimos cada uno de sus pasos. Esperamos su próximo informe.",
    '<p>{0}</p>\n  <p><b>Sol {1}</b> tarihli <b>{2}</b> numaralı raporunuz {3} üzerinden <b>{4} MB</b> olarak eksiksiz alınmıştır. {5}</p>\n  {6}\n  <h4>{7}. 📊 Görev durumu değerlendirmesi</h4><ul class="ltr-ul">{8}</ul>\n  <p>Bilim ekibi bu paketi <b>{9} bilim puanı</b> olarak değerlendirdi. Görev bilim hedefinin <b>%{10}</b>\'i tamamlandı.</p>\n  <div class="ltr-sci"><i style="width:{11}%"></i></div>\n  <p>{12}</p>':
      '<p>{0}</p>\n  <p>Su informe n.º <b>{2}</b> del <b>sol {1}</b> se recibió íntegro a través de {3} con un tamaño de <b>{4} MB</b>. {5}</p>\n  {6}\n  <h4>{7}. 📊 Evaluación del estado de la misión</h4><ul class="ltr-ul">{8}</ul>\n  <p>El equipo científico ha valorado este paquete en <b>{9} puntos de ciencia</b>. Se ha completado el <b>{10} %</b> del objetivo científico de la misión.</p>\n  <div class="ltr-sci"><i style="width:{11}%"></i></div>\n  <p>{12}</p>',
    "Yanıt: ": "Re: ",
    "Mürettebat notu": "Nota de tripulación",
    " (Sol ": " (Sol ",
    "EK-A · Önümüzdeki 5 sol tahmini": "ANEXO A · Pronóstico para los próximos 5 soles",
    Avustralya: "Australia",
    "Batı Avustralya · Perth'in 140 km kuzeyi": "Australia Occidental · 140 km al norte de Perth",
    İspanya: "España",
    "Ávila · Madrid'in 77 km batısı": "Ávila · 77 km al oeste de Madrid",
    "Malargüe (DSA 3)": "Malargüe (DSA 3)",
    Arjantin: "Argentina",
    "Mendoza · Malargüe'nin 30 km güneyi": "Mendoza · 30 km al sur de Malargüe",
    "ARES Görev Kontrol Merkezi": "Centro de Control de la Misión ARES",
    "GÖREV YÖNETİMİ": "GESTIÓN DE LA MISIÓN",
    "Uçuş direktörü ve iletişim sorumlusuyla görev takibi":
      "Seguimiento de la misión con el director de vuelo y el responsable de comunicaciones",
    "Raporları inceler, resmî yanıtları ve talimatları yazar":
      "Revisa los informes y redacta respuestas oficiales e instrucciones",
    "Mürettebat sağlığı ve uzay hava durumu değerlendirmesi":
      "Evaluación de la salud de la tripulación y de la meteorología espacial",
    "Derin Uzay Anten Ağı": "Red de Antenas de Espacio Profundo",
    "Avustralya · İspanya · Arjantin": "Australia · España · Argentina",
    "Üç 35 m anteni sırayla Mars'a yönlendirir": "Apunta las tres antenas de 35 m hacia Marte por turnos",
    "Her ~8 Mars saatinde bir istasyon devri": "Un relevo de estación cada ~8 horas marcianas",
    "Delta-DOR ile hassas konum ve sinyal kalitesi takibi":
      "Posicionamiento preciso y control de la calidad de señal con Delta-DOR",
    "Kullanıcı segmenti": "Segmento de usuario",
    "VERİ ALIMI": "RECEPCIÓN DE DATOS",
    "Gelen telemetri ve bilim paketlerinin işlenmesi":
      "Procesamiento de la telemetría y los paquetes científicos recibidos",
    "Numune, hava ve radyasyon verilerinin arşivlenmesi":
      "Archivo de los datos de muestras, meteorología y radiación",
    "Verilerin bilim ekiplerine dağıtılması": "Distribución de los datos a los equipos científicos",
    '<div class="np-crew"><div class="gs-mk sm">ARES</div><div><b>Komutan · ARES-1</b><small>ARES-1/CDR · Mars yüzey görevi</small></div></div>':
      '<div class="np-crew"><div class="gs-mk sm">ARES</div><div><b>Comandante · ARES-1</b><small>ARES-1/CDR · Misión en la superficie de Marte</small></div></div>',
    "⚖️ Kütle": "⚖️ Masa",
    "⚡ Güç": "⚡ Potencia",
    "Fırtına: panel üretimi düştü": "Tormenta: ha bajado la producción de los paneles",
    "Güneş panelleri": "Paneles solares",
    "RTG · sabit güç": "RTG · potencia constante",
    "💰 Bütçe": "💰 Presupuesto",
    "💾 Veri": "💾 Datos",
    "Kapasite aşılıyor: bilimin %": "Capacidad superada: se pierde el %",
    "'i kayıp": " de la ciencia",
    "📡 İletişim": "📡 Comunicaciones",
    "Gönderilen: ": "Enviado: ",
    " gün transfer": " días de tránsito",
    '<div class="gs-sec">Tasarım kaynakları · canlı</div>\n    <div class="ar-kv">{0}\n      {1}\n      {2}\n      {3}\n      {4}\n      {5}</div>':
      '<div class="gs-sec">Recursos del diseño · en directo</div>\n    <div class="ar-kv">{0}\n      {1}\n      {2}\n      {3}\n      {4}\n      {5}</div>',
    "Fırlatma segmenti": "Segmento de lanzamiento",
    "Görevi uzaya taşıyan fırlatma aracı ve fırlatma hizmetleri.":
      "El vehículo y los servicios de lanzamiento que sitúan la misión en el espacio.",
    Araç: "Vehículo",
    "ARES-1 iniş ve dönüş roketi": "Cohete de aterrizaje y regreso ARES-1",
    Transfer: "Transferencia",
    "≈ 214 gün · 225 milyon km": "≈ 214 días · 225 millones de km",
    Varış: "Llegada",
    "Mars · ekvator ovası": "Marte · llanura ecuatorial",
    "Uzay segmenti": "Segmento espacial",
    "Görevi yürüten araç, alet ve ekipman: roket, kıyafet ve numune sistemleri.":
      "El vehículo, los instrumentos y el equipo que llevan a cabo la misión: cohete, traje y sistemas de muestras.",
    NOMİNAL: "NOMINAL",
    ARIZA: "AVERÍA",
    Çalışıyor: "Operativo",
    "Arızalı · ": "Averiado · ",
    Kıyafet: "Traje",
    "Yer segmenti": "Segmento terrestre",
    "İletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları ve görev kontrol merkezleri.":
      "Estaciones terrestres y centros de control de misión responsables de las comunicaciones, la recepción de datos y la gestión de la misión.",
    BAĞLI: "CONECTADO",
    KESİK: "CAÍDO",
    "Görev kontrol": "Control de misión",
    "Işık gecikmesi": "Retardo de luz",
    "Görev verilerini analiz eden ve kullanan bilim insanları ve diğer kullanıcılar.":
      "Científicos y otros usuarios que analizan y aplican los datos de la misión.",
    "Gönderilen rapor": "Informes enviados",
    "Gönderilen veri": "Datos enviados",
    "Bilim hedefi": "Objetivo científico",
    "İlk görev fikri": "Idea inicial de la misión",
    "Bilim sorusu: Mars'ta insan yaşamı mümkün mü?":
      "Pregunta científica: ¿es posible la vida humana en Marte?",
    "Tek kişilik mürettebat ve tek araçla görev mümkün mü?":
      "¿Es posible la misión con una tripulación de una persona y un solo vehículo?",
    "Ödünleşim çalışmaları": "Estudios de compensación",
    "Güç, kütle, iletişim ve koruma seçeneklerinin karşılaştırılması":
      "Comparación de opciones de potencia, masa, comunicaciones y protección",
    "Nokta tasarım": "Diseño puntual",
    "ARES-1 görev mimarisi": "Arquitectura de la misión ARES-1",
    '<div class="ar-cml now"><em>FAZ E</em><b>Operasyon</b><small>Mars yüzey operasyonları · Sol {0}</small></div>':
      '<div class="ar-cml now"><em>FASE E</em><b>Operaciones</b><small>Operaciones en la superficie de Marte · Sol {0}</small></div>',
    Kavram: "Concepto",
    Fırlatma: "Lanzamiento",
    "214 gün": "214 días",
    "Giriş · İniş": "Entrada · Aterrizaje",
    Yüzey: "Superficie",
    Dönüş: "Regreso",
    "Rota açık": "Ruta abierta",
    Kilitli: "Bloqueada",
    İtki: "Propulsión",
    "Ana motor çalışıyor": "Motor principal en marcha",
    "Ana motor arızalı": "Motor principal averiado",
    "Yaşam desteği": "Soporte vital",
    "O₂ tüpü %": "Tanque de O₂ %",
    " · su ": " · agua ",
    " · patates ": " · patatas ",
    "Isıl ve radyasyon koruması": "Protección térmica y antirradiación",
    " · radyasyon hasarı %": " · daño por radiación %",
    Yapı: "Estructura",
    "Fırtına kalkanı ": "Escudo antitormentas ",
    "Seviye ": "Nivel ",
    Yok: "Ninguno",
    " · arıza riski %": " · riesgo de avería %",
    İletişim: "Comunicaciones",
    " · bağlı": " · conectado",
    "Bağlantı kesik": "Enlace caído",
    "Görev operasyonları": "Operaciones de la misión",
    "Görev ": "Misión ",
    Risk: "Riesgo",
    "Sonraki fırtına Sol ": "Próxima tormenta Sol ",
    " · radyasyon Sol ": " · radiación Sol ",
    '<div class="gs ar">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>ARES-1 GÖREV MİMARİSİ</b>\n      <p>ARES-1; fırlatma, uzay, yer ve kullanıcı segmentlerinden oluşur. Kavram, olgunluk seviyeleri boyunca fikirden nokta tasarıma geliştirildi. Alt sistemler mühendislik disiplinlerine göre ayrı ayrı izlenir.</p></div></div>\n    <div class="gs-sec">Görev segmentleri</div>\n    <div class="ar-segs">{0}</div>\n    {1}\n    <div class="gs-sec">Görev zaman çizelgesi</div>\n    <div class="ar-tls">{2}</div>\n    <div class="gs-sec">Kavram olgunluğu</div>\n    <div class="ar-cmls">{3}</div>\n    <div class="gs-sec">Alt sistem durumu</div>\n    <div class="ar-subs">{4}</div>\n  </div>':
      '<div class="gs ar">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>ARQUITECTURA DE LA MISIÓN ARES-1</b>\n      <p>ARES-1 consta de los segmentos de lanzamiento, espacial, terrestre y de usuario. El concepto se desarrolló desde una idea hasta un diseño puntual a través de varios niveles de madurez. Los subsistemas se supervisan por separado según su disciplina de ingeniería.</p></div></div>\n    <div class="gs-sec">Segmentos de la misión</div>\n    <div class="ar-segs">{0}</div>\n    {1}\n    <div class="gs-sec">Cronología de la misión</div>\n    <div class="ar-tls">{2}</div>\n    <div class="gs-sec">Madurez del concepto</div>\n    <div class="ar-cmls">{3}</div>\n    <div class="gs-sec">Estado de los subsistemas</div>\n    <div class="ar-subs">{4}</div>\n  </div>',
    '<b class="sat-on">GÖRÜŞ ALANINDA</b>': '<b class="sat-on">A LA VISTA</b>',
    '<b class="sat-off">UFUK ALTINDA</b>': '<b class="sat-off">BAJO EL HORIZONTE</b>',
    "Geçiş sürüyor · {0} kaldı": "Pase en curso · quedan {0}",
    "{0} sonra · {1} sürecek": "dentro de {0} · dura {1}",
    "ufkun altında (": "bajo el horizonte (",
    '<div class="sat">\n    <div class="sat-map">\n      <svg viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">\n        <defs><linearGradient id="satBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a2a1c"/><stop offset=".5" stop-color="#8a3f26"/><stop offset="1" stop-color="#4a2216"/></linearGradient>\n          <radialGradient id="satGl"><stop offset="0" stop-color="#7fe7ff" stop-opacity=".9"/><stop offset="1" stop-color="#7fe7ff" stop-opacity="0"/></radialGradient></defs>\n        <rect width="360" height="180" fill="url(#satBg)"/>\n        <g class="sat-grid">{0}</g>\n        <line x1="0" y1="90" x2="360" y2="90" class="sat-eq"/>\n        <ellipse cx="{1}" cy="{2}" rx="{3}" ry="{4}" class="sat-cov {5}"/>\n        {6}\n        {7}\n        {8}\n        <circle cx="{9}" cy="{10}" r="11" fill="url(#satGl)"/><g transform="translate({11},{12})" class="sat-ic"><rect x="-2.6" y="-2.6" width="5.2" height="5.2" rx="1"/><rect x="-9" y="-1.3" width="5" height="2.6"/><rect x="4" y="-1.3" width="5" height="2.6"/></g>\n      </svg>\n      <div class="sat-legend"><span><i class="lg-site"></i>ARES-1 · {13}</span><span><i class="lg-sat"></i>{14}</span><span><i class="lg-fut"></i>Sonraki tur</span><span><i class="lg-cov"></i>Görüş alanı</span></div>\n    </div>\n    <div class="sat-side">\n      <div class="sat-hd"><div><small>RÖLE UYDUSU</small><b>{15}</b></div>{16}</div>\n      <dl class="sat-dl">\n        <dt>Anlık konum</dt><dd>{17} · {18}</dd>\n        <dt>ARES-1\'e uzaklık</dt><dd>{19} km</dd>\n        <dt>Yükseliş açısı</dt><dd>{20}</dd>\n        <dt>Sonraki geçiş</dt><dd>{21}</dd>\n        <dt>Yörünge</dt><dd>Dairesel · {22} km · eğim {23}°</dd>\n        <dt>Periyot · hız</dt><dd>{24} dk · {25} km/s</dd>\n        <dt>Bağlantılar</dt><dd>UHF 401 MHz (yüzey) · X-bant (Dünya)</dd>\n        <dt>Mars–Dünya</dt><dd>{26} milyon km · {27} dk</dd>\n      </dl>\n    </div>\n  </div>':
      '<div class="sat">\n    <div class="sat-map">\n      <svg viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">\n        <defs><linearGradient id="satBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a2a1c"/><stop offset=".5" stop-color="#8a3f26"/><stop offset="1" stop-color="#4a2216"/></linearGradient>\n          <radialGradient id="satGl"><stop offset="0" stop-color="#7fe7ff" stop-opacity=".9"/><stop offset="1" stop-color="#7fe7ff" stop-opacity="0"/></radialGradient></defs>\n        <rect width="360" height="180" fill="url(#satBg)"/>\n        <g class="sat-grid">{0}</g>\n        <line x1="0" y1="90" x2="360" y2="90" class="sat-eq"/>\n        <ellipse cx="{1}" cy="{2}" rx="{3}" ry="{4}" class="sat-cov {5}"/>\n        {6}\n        {7}\n        {8}\n        <circle cx="{9}" cy="{10}" r="11" fill="url(#satGl)"/><g transform="translate({11},{12})" class="sat-ic"><rect x="-2.6" y="-2.6" width="5.2" height="5.2" rx="1"/><rect x="-9" y="-1.3" width="5" height="2.6"/><rect x="4" y="-1.3" width="5" height="2.6"/></g>\n      </svg>\n      <div class="sat-legend"><span><i class="lg-site"></i>ARES-1 · {13}</span><span><i class="lg-sat"></i>{14}</span><span><i class="lg-fut"></i>Próxima órbita</span><span><i class="lg-cov"></i>Visibilidad</span></div>\n    </div>\n    <div class="sat-side">\n      <div class="sat-hd"><div><small>SATÉLITE DE RETRANSMISIÓN</small><b>{15}</b></div>{16}</div>\n      <dl class="sat-dl">\n        <dt>Posición</dt><dd>{17} · {18}</dd>\n        <dt>Distancia a ARES-1</dt><dd>{19} km</dd>\n        <dt>Elevación</dt><dd>{20}</dd>\n        <dt>Próximo pase</dt><dd>{21}</dd>\n        <dt>Órbita</dt><dd>Circular · {22} km · incl. {23}°</dd>\n        <dt>Periodo · velocidad</dt><dd>{24} min · {25} km/s</dd>\n        <dt>Enlaces</dt><dd>UHF 401 MHz (superficie) · banda X (Tierra)</dd>\n        <dt>Marte–Tierra</dt><dd>{26} millones de km · {27} min</dd>\n      </dl>\n    </div>\n  </div>',
    '<span class="st on">● MARS\'I İZLİYOR</span>': '<span class="st on">● SIGUIENDO A MARTE</span>',
    '<span class="st err">● SİNYAL YOK</span>': '<span class="st err">● SIN SEÑAL</span>',
    '<span class="st">BEKLEMEDE</span>': '<span class="st">EN ESPERA</span>',
    "<dt>Mars yükseliş açısı</dt><dd>{0}°</dd><dt>Veri hızı</dt><dd>{1}</dd>":
      "<dt>Elevación de Marte</dt><dd>{0}°</dd><dt>Tasa de datos</dt><dd>{1}</dd>",
    '<div class="gs-card gs-st {0}">{1}<h5>{2}</h5><div class="loc">📍 {3} · {4}</div>\n      <dl class="gs-dl"><dt>Enlem</dt><dd>{5}</dd><dt>Boylam</dt><dd>{6}</dd><dt>Rakım</dt><dd>{7}</dd><dt>Çanak anten</dt><dd>{8} · ışın kılavuzlu</dd>\n      <dt>Gönderme</dt><dd>{9} bant</dd><dt>Alma</dt><dd>{10} bant</dd><dt>Hizmete giriş</dt><dd>{11}</dd>\n      {12}</dl></div>':
      '<div class="gs-card gs-st {0}">{1}<h5>{2}</h5><div class="loc">📍 {3} · {4}</div>\n      <dl class="gs-dl"><dt>Latitud</dt><dd>{5}</dd><dt>Longitud</dt><dd>{6}</dd><dt>Altitud</dt><dd>{7}</dd><dt>Antena</dt><dd>{8} · guía de ondas</dd>\n      <dt>Enlace ascendente</dt><dd>{9} banda</dd><dt>Enlace descendente</dt><dd>{10} banda</dd><dt>En servicio desde</dt><dd>{11}</dd>\n      {12}</dl></div>',
    "Mars yüzeyi · yüksek kazançlı anten": "Superficie de Marte · antena de alta ganancia",
    "X-bant": "Banda X",
    "İstasyon ağı": "Red de estaciones",
    "İletişim operasyonu": "Operaciones de comunicaciones",
    "Görev Kontrol": "Control de Misión",
    "Görev yönetimi": "Gestión de la misión",
    "Bilim ekipleri": "Equipos científicos",
    AKTİF: "ACTIVA",
    '<div class="gs">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>YER BİRİMİ · ARES-1</b>\n      <p>Yer birimi; iletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları ve görev kontrol merkezlerinden oluşur. ARES-1, boylamda yaklaşık 120° aralıklı üç gerçek 35 m derin uzay anteniyle (New Norcia, Cebreros, Malargüe) Dünya döndükçe kesintisiz izlenir.</p></div></div>\n    <div class="gs-sec">Veri yolu</div>\n    <div class="gs-path">\n      {0}{1}\n      {2}{3}\n      {4}{5}\n      {6}{7}\n      {8}\n    </div>\n    <div class="gs-sec">Röle uydusu · konum ve yörünge</div>\n    {9}\n    <div class="gs-kv">\n      <div><span>Bağlantı</span><b style="color:{10}">{11}</b></div>\n      <div><span>Işık gecikmesi</span><b>{12} dk</b></div>\n      <div><span>Gönderilen veri</span><b>{13} MB</b></div>\n      <div><span>Alınan mesaj</span><b>{14}</b></div></div>\n    <div class="gs-sec">Yer istasyonları</div>\n    <div class="gs-grid">{15}</div>\n    <div class="gs-kv" style="grid-template-columns:repeat(3,1fr)">\n      <div><span>Aktif istasyon</span><b>{16}</b></div>\n      <div><span>Sonraki devir</span><b>{17} · {18}</b></div>\n      <div><span>Veri kapasitesi</span><b>{19} MB/sol</b></div></div>\n    <div class="gs-sec">Görev kontrol merkezleri</div>\n    <div class="gs-grid">{20}</div>\n  </div>':
      '<div class="gs">\n    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>SEGMENTO TERRESTRE · ARES-1</b>\n      <p>El segmento terrestre está formado por las estaciones terrestres y los centros de control de misión responsables de las comunicaciones, la recepción de datos y la gestión de la misión. ARES-1 se sigue sin interrupción mientras la Tierra gira gracias a tres antenas reales de espacio profundo de 35 m separadas unos 120° en longitud (New Norcia, Cebreros, Malargüe).</p></div></div>\n    <div class="gs-sec">Ruta de datos</div>\n    <div class="gs-path">\n      {0}{1}\n      {2}{3}\n      {4}{5}\n      {6}{7}\n      {8}\n    </div>\n    <div class="gs-sec">Satélite de retransmisión · posición y órbita</div>\n    {9}\n    <div class="gs-kv">\n      <div><span>Enlace</span><b style="color:{10}">{11}</b></div>\n      <div><span>Retardo de luz</span><b>{12} min</b></div>\n      <div><span>Datos enviados</span><b>{13} MB</b></div>\n      <div><span>Mensajes recibidos</span><b>{14}</b></div></div>\n    <div class="gs-sec">Estaciones terrestres</div>\n    <div class="gs-grid">{15}</div>\n    <div class="gs-kv" style="grid-template-columns:repeat(3,1fr)">\n      <div><span>Estación activa</span><b>{16}</b></div>\n      <div><span>Próximo relevo</span><b>{17} · {18}</b></div>\n      <div><span>Capacidad de datos</span><b>{19} MB/sol</b></div></div>\n    <div class="gs-sec">Centros de control de misión</div>\n    <div class="gs-grid">{20}</div>\n  </div>',
    "YEREL AĞ": "RED LOCAL",
    "RÖLE UYDUSU": "SATÉLITE DE RETRANSMISIÓN",
    "ANTEN TOZLA KAPALI": "ANTENA BLOQUEADA POR EL POLVO",
    "PARAZİT · ": "INTERFERENCIA · ",
    "Gönderilecek bir şey yok — gözlem seç ya da not yaz":
      "No hay nada que enviar: selecciona una observación o escribe una nota",
    "📡 Toz fırtınası yüksek kazançlı anteni kör ediyor — fırtına geçince gönder":
      "📡 La tormenta de polvo ciega la antena de alta ganancia: envía cuando haya pasado",
    "Notun GDY-1'e iletildi — yanıt ~": "Tu nota se envió a GDY-1: la respuesta llegará a tu bandeja en ~",
    " içinde gelen kutunda": " ",
    "</b> Dünya'ya iletildi · yanıt beklenen: <b>": "</b> enviado a la Tierra · respuesta prevista: <b>",
    "📥 Gelen kutusu": "📥 Bandeja de entrada",
    "📝 Rapor hazırla": "📝 Preparar informe",
    "📤 Gönderilenler": "📤 Enviados",
    "📡 Dünya'ya gönder": "📡 Enviar a la Tierra",
    "📡 Anten kapalı — fırtına bekleniyor": "📡 Antena bloqueada: esperando a que pase la tormenta",
    '<span class="mut">Raporda henüz içerik yok.</span>':
      '<span class="mut">El informe aún no tiene contenido.</span>',
    " + not": " + nota",
    "<div><span>İçerik</span><b>{0} gözlem{1}</b></div>\n    <div><span>Paket</span><b>{2} MB</b></div>\n    <div><span>Işık gecikmesi</span><b>~{3} dk</b></div>\n    <div><span>Tahmini yanıt</span><b>Sol {4} civarı</b></div>":
      "<div><span>Contenido</span><b>{0} observaciones{1}</b></div>\n    <div><span>Paquete</span><b>{2} MB</b></div>\n    <div><span>Retardo de luz</span><b>~{3} min</b></div>\n    <div><span>Respuesta prevista</span><b>hacia el sol {4}</b></div>",
    "Yüksek kazançlı anten Dünya'ya hizalanıyor…": "Alineando la antena de alta ganancia con la Tierra…",
    "Paket sıkıştırılıyor ve AES-256 ile şifreleniyor…": "Comprimiendo el paquete y cifrándolo con AES-256…",
    " gözlem kaydı + ": " entradas de observación + ",
    "mürettebat notu": "nota de tripulación",
    "not yok": "sin nota",
    " paketlendi": " empaquetado",
    "X-bandı iletim · ": "Transmisión en banda X · ",
    "İletim tamamlandı · ışık gecikmesi ~": "Transmisión completada · retardo de luz ~",
    '<div class="cm-empty">📭 Saha günlüğünde gönderilmemiş kayıt yok.<br><small>Fırtına, radyasyon, meteor, arıza, numune toplama, tarım ve kritik yaşam değerleri burada otomatik kaydedilir.</small></div>':
      '<div class="cm-empty">📭 No hay entradas sin enviar en el registro de campo.<br><small>Las tormentas, la radiación, los meteoritos, las averías, la recogida de muestras, el cultivo y los valores vitales críticos se registran aquí automáticamente.</small></div>',
    "Patatesler çürüdü, neden olabilir?": "Las patatas se han podrido, ¿cuál puede ser la causa?",
    "Motordan duman geliyor, ne yapmalıyım?": "Sale humo del motor, ¿qué debo hacer?",
    "Erzak azalıyor": "Se están acabando los suministros",
    "Fırtınada roket çok sarsıldı": "El cohete se sacudió mucho en la tormenta",
    "Radyasyon sırasında dışarıda kaldım": "Me quedé fuera durante la radiación",
    "Kendimi yalnız hissediyorum": "Me siento solo",
    "Ne zaman Dünya'ya dönebilirim?": "¿Cuándo podré volver a la Tierra?",
    '<div class="cm-cols">\n      <div class="cm-col"><div class="con-sec">Saha günlüğü · {0} kayıt</div><div class="cm-obs">{1}</div></div>\n      <div class="cm-col"><div class="con-sec">Mürettebat notu</div>\n        <textarea id="cmNote" maxlength="500" placeholder="Yaşadığın sorunları, gözlemlerini ya da sorularını yaz…">{2}</textarea>\n        <div class="cm-quick">{3}</div>\n        <div class="con-sec">Öncelik</div>\n        <div class="cm-prio"><button data-p="rutin" class="{4}">RUTİN<small>yanıt ≈ ½ sol</small></button><button data-p="acil" class="acil {5}">ACİL<small>yanıt ≈ ¼ sol</small></button></div>\n        <div class="cm-sum" id="cmSum"></div>\n        <button class="cbtn pri wide" id="cmSend">📡 Dünya\'ya gönder</button></div></div>':
      '<div class="cm-cols">\n      <div class="cm-col"><div class="con-sec">Registro de campo · {0} entradas</div><div class="cm-obs">{1}</div></div>\n      <div class="cm-col"><div class="con-sec">Nota de tripulación</div>\n        <textarea id="cmNote" maxlength="500" placeholder="Escribe los problemas que has tenido, tus observaciones o tus preguntas…">{2}</textarea>\n        <div class="cm-quick">{3}</div>\n        <div class="con-sec">Prioridad</div>\n        <div class="cm-prio"><button data-p="rutin" class="{4}">RUTINA<small>respuesta ≈ ½ sol</small></button><button data-p="acil" class="acil {5}">URGENTE<small>respuesta ≈ ¼ sol</small></button></div>\n        <div class="cm-sum" id="cmSum"></div>\n        <button class="cbtn pri wide" id="cmSend">📡 Enviar a la Tierra</button></div></div>',
    YANIT: "RESPUESTA",
    BÜLTEN: "BOLETÍN",
    UYARI: "ALERTA",
    BRİFİNG: "SESIÓN INFORMATIVA",
    TALEP: "SOLICITUD",
    ANALİZ: "ANÁLISIS",
    "YZ YANITI": "RESPUESTA IA",
    MESAJ: "MENSAJE",
    ACİL: "URGENTE",
    '<div class="cm-empty">📭 Gelen kutusu boş.<br><small>Görev Kontrol\'ün brifingleri, bültenleri ve raporlarına verdiği yanıtlar burada görünür.</small></div>':
      '<div class="cm-empty">📭 La bandeja de entrada está vacía.<br><small>Aquí aparecen las sesiones informativas, los boletines y las respuestas de Control de Misión a tus informes.</small></div>',
    Gönderildi: "Enviado",
    "Dünya'ya ulaştı": "Llegó a la Tierra",
    İnceleniyor: "En revisión",
    "Yanıt geldi": "Respuesta recibida",
    '<span class="badge err">ACİL</span>': '<span class="badge err">URGENTE</span>',
    '<span class="badge mute">RUTİN</span>': '<span class="badge mute">RUTINA</span>',
    "📨 Yanıt gelen kutunda": "📨 La respuesta está en tu bandeja de entrada",
    "⏳ Yanıt bekleniyor · <b>{0}</b> civarı · kalan ~{1} (oyun saati)":
      "⏳ Esperando respuesta · hacia <b>{0}</b> · faltan ~{1} (tiempo de juego)",
    '<div class="cm-empty">📤 Henüz rapor göndermedin.<br><small>“Rapor hazırla” sekmesinden saha günlüğünü ve notunu Dünya\'ya ilet.</small></div>':
      '<div class="cm-empty">📤 Aún no has enviado ningún informe.<br><small>Envía tu registro de campo y tu nota a la Tierra desde la pestaña «Preparar informe».</small></div>',
    '<span class="ci">📨</span><div><b>Dünya\'dan {0} yeni mesaj</b><small>Komuta güvertesi · iletişim terminali</small></div>':
      '<span class="ci">📨</span><div><b>{0} mensaje(s) nuevo(s) de la Tierra</b><small>Cubierta de mando · terminal de comunicaciones</small></div>',
    '<span class="ci">📡</span><div><b>Yanıt bekleniyor</b><small>{0} civarı</small></div>':
      '<span class="ci">📡</span><div><b>Esperando respuesta</b><small>hacia {0}</small></div>',
    '<span class="ci">📝</span><div><b>{0} gözlem rapor bekliyor</b><small>İletişim terminalinden gönder</small></div>':
      '<span class="ci">📝</span><div><b>{0} observación(es) a la espera de informe</b><small>Envía desde el terminal de comunicaciones</small></div>',
    "İnsanlık binlerce yıldır gece gökyüzündeki o kızıl noktaya baktı.":
      "Durante miles de años, la humanidad ha contemplado ese punto rojo del cielo nocturno.",
    "Şimdi, ilk kez bir insan oraya gidiyor.": "Ahora, por primera vez, un ser humano va hacia allí.",
    "Tek başına.": "Solo.",
    "UÇUŞ DİREKTÖRÜ · GÖREV KONTROL": "DIRECTOR DE VUELO · CONTROL DE MISIÓN",
    "ARES-1 görevi onaylandı. Mürettebat: tek kişi. Komutan sensin.":
      "La misión ARES-1 ha sido aprobada. Tripulación: una persona. Tú eres el comandante.",
    "Görevin: Mars'a in, oradaki yaşam koşullarını incele ve her bulguyu Dünya'ya aktar.":
      "Tu misión: aterrizar en Marte, estudiar sus condiciones de vida y enviar cada hallazgo a la Tierra.",
    "Orada yalnız olacaksın. Ama biz seni her an dinliyor olacağız.":
      "Allí estarás solo. Pero te escucharemos en todo momento.",
    "YER İSTASYONU AĞI": "RED DE ESTACIONES TERRESTRES",
    "A, B ve C istasyonları hazır. Yolculuk boyunca üç istasyon seni sırayla izleyecek.":
      "Las estaciones A, B y C están listas. Durante el viaje, las tres estaciones te seguirán por turnos.",
    "KALKIŞ KONTROL": "CONTROL DE LANZAMIENTO",
    "Tüm sistemler hazır. Geri sayım başladı.": "Todos los sistemas listos. Ha comenzado la cuenta atrás.",
    "GÖREV KONTROL": "CONTROL DE MISIÓN",
    "Kalkış! ARES-1 kuleden ayrıldı.": "¡Despegue! ARES-1 ha dejado atrás la torre.",
    "Yörüngeye giriş nominal. Mars yolu açık. İyi yolculuklar, Komutan.":
      "Inserción en órbita nominal. El camino a Marte está abierto. Buen viaje, comandante.",
    "KOMUTANIN GÜNLÜĞÜ": "DIARIO DEL COMANDANTE",
    "Gün 12 — Dünya artık başparmağımın arkasına sığıyor.":
      "Día 12 — Ahora la Tierra cabe detrás de mi pulgar.",
    "Gün 97 — Buradaki tek ses, Görev Kontrol'den gelen cızırtılı mesajlar.":
      "Día 97 — El único sonido aquí son los mensajes entrecortados de Control de Misión.",
    "Gün 211 — Kızıl gezegen pencereyi dolduruyor. Neredeyse geldim.":
      "Día 211 — El planeta rojo llena la ventana. Ya casi he llegado.",
    "ARES-1, atmosfere girişe hazırlan. Isı kalkanı devrede.":
      "ARES-1, prepárate para la entrada atmosférica. Escudo térmico activado.",
    "Isı kalkanı 1.600 °C… sinyal… kesil—": "Escudo térmico a 1600 °C… señal… se cort—",
    "Retro motorlar ateşlendi… 40 metre… 20… 10…": "Retrocohetes encendidos… 40 metros… 20… 10…",
    "ARES-1, burası Görev Kontrol. A istasyonu sinyalini aldı, inişini doğruluyoruz. Mars'a hoş geldin, Komutan.":
      "ARES-1, aquí Control de Misión. La estación A ha recibido tu señal, confirmamos tu aterrizaje. Bienvenido a Marte, comandante.",
    "GÖREV DOSYASI": "EXPEDIENTE DE LA MISIÓN",
    KALKIŞ: "LANZAMIENTO",
    "YOLCULUK · 214 GÜN": "VIAJE · 214 DÍAS",
    "ARES-1, Dünya'ya dönüş penceresi açık. Kalkış için onay verildi.":
      "ARES-1, la ventana de regreso a la Tierra está abierta. Autorizado para despegar.",
    "Motorlar ateşlendi… Mars, her şey için teşekkürler.": "Motores encendidos… Marte, gracias por todo.",
    "Kalkış başarılı. Hoşça kal, Kızıl Gezegen.": "Despegue con éxito. Adiós, Planeta Rojo.",
    "ARES-R1 · RÖLE UYDUSU": "ARES-R1 · SATÉLITE DE RETRANSMISIÓN",
    "Son bağlantı: yüzey verilerinin tamamı aktarıldı. İyi yolculuklar, ARES-1.":
      "Último contacto: todos los datos de superficie se han transferido. Buen viaje, ARES-1.",
    "Dünya'ya transfer ateşlemesi tamamlandı. Yeni rota: ev.":
      "Encendido de transferencia a la Tierra completado. Nuevo rumbo: casa.",
    "Dönüş günü {0} — Mars arkamda küçülüyor. Kargo bölmesinde {1} numune var.":
      "Día de regreso {0} — Marte se encoge a mi espalda. Hay {1} muestras en la bodega.",
    "Dönüş günü {0} — Ekip her mesajımda Mars'ta öğrendiklerimizi soruyor.":
      "Día de regreso {0} — En cada mensaje el equipo pregunta lo que aprendimos en Marte.",
    "Dönüş günü {0} — Pencerede mavi bir nokta büyüyor. Evim.":
      "Día de regreso {0} — Un punto azul crece en la ventana. Mi hogar.",
    "ARES-1, Ay'ın yörüngesini geçtin. Kapsül ayrılmasına hazırlan.":
      "ARES-1, has cruzado la órbita de la Luna. Prepárate para la separación de la cápsula.",
    "Kapsül ayrıldı. Isı kalkanı Dünya'ya dönük.": "Cápsula separada. Escudo térmico orientado a la Tierra.",
    "Atmosfere giriş. Hız saniyede 11 kilometre. İletişim kesintisi bekleniyor.":
      "Entrada atmosférica. Velocidad de 11 kilómetros por segundo. Se espera un apagón de comunicaciones.",
    "Pencerenin dışı alev alev… dayan…": "Fuera de la ventana todo es fuego… aguanta…",
    "KURTARMA EKİBİ": "EQUIPO DE RESCATE",
    "Sinyal geri geldi! Paraşütler açıldı, üçü de sağlam.":
      "¡Señal recuperada! Paracaídas desplegados, los tres en buen estado.",
    "Kapsülü görüyoruz. Okyanusa iniş için hazırlan.":
      "Tenemos la cápsula a la vista. Prepárate para el amerizaje.",
    "ARES-1, suya iniş doğrulandı. Kurtarma gemisi yolda.":
      "ARES-1, amerizaje confirmado. El buque de rescate va en camino.",
    "Mars'ta {0} sol geçirdin. Dünya'ya hoş geldin, Komutan.":
      "Pasaste {0} soles en Marte. Bienvenido a la Tierra, comandante.",
    "MARS · KALKIŞ": "MARTE · DESPEGUE",
    "MARS YÖRÜNGESİ": "ÓRBITA DE MARTE",
    "EVE DÖNÜŞ · {0} GÜN": "REGRESO · {0} DÍAS",
    "ATMOSFERE GİRİŞ": "ENTRADA ATMOSFÉRICA",
    "OKYANUSA İNİŞ": "AMERIZAJE",
    EVRE: "FASE",
    "GERİ SAYIM": "CUENTA ATRÁS",
    "MARS KALKIŞI": "DESPEGUE DE MARTE",
    İRTİFA: "ALTITUD",
    İTKİ: "EMPUJE",
    "DÜNYA'YA TRANSFER ATEŞLEMESİ": "ENCENDIDO HACIA LA TIERRA",
    "TRANSFER YÖRÜNGESİ": "ÓRBITA DE TRANSFERENCIA",
    HIZ: "VELOCIDAD",
    "DÖNÜŞ GÜNÜ": "DÍA DE REGRESO",
    "DÜNYA'YA UZAKLIK": "DISTANCIA A LA TIERRA",
    " milyon km": " millones de km",
    "SİNYAL GECİKMESİ": "RETARDO DE SEÑAL",
    KARGO: "CARGA",
    " numune": " muestras",
    "YER İSTASYONU": "ESTACIÓN TERRESTRE",
    "KAPSÜL AYRILDI": "CÁPSULA SEPARADA",
    "DÜNYA YAKLAŞMASI": "APROXIMACIÓN A LA TIERRA",
    "ISI KALKANI": "ESCUDO TÉRMICO",
    SİNYAL: "SEÑAL",
    YOK: "NINGUNA",
    "PARAŞÜTLER AÇIK": "PARACAÍDAS ABIERTOS",
    "İNİŞ HIZI": "VELOCIDAD DE DESCENSO",
    "SUYA İNİŞ": "AMERIZAJE",
    KONUM: "UBICACIÓN",
    "Pasifik Okyanusu": "Océano Pacífico",
    KURTARMA: "RESCATE",
    YOLDA: "EN CAMINO",
    "KAPSÜLE YAKLAŞIYOR": "ACERCÁNDOSE A LA CÁPSULA",
    "GÖREV TAMAMLANDI": "MISIÓN COMPLETADA",
    "Mars'ta {0} sol · {1} numune · bilim hedefi %{2}":
      "{0} soles en Marte · {1} muestras · objetivo científico {2} %",
    "225 milyon km": "225 millones de km",
    "ARES PROGRAMI": "PROGRAMA ARES",
    "ARES-1 · GÖREV PROFİLİ": "ARES-1 · PERFIL DE LA MISIÓN",
    "TRANSFER YÖRÜNGESİ · 214 GÜN": "ÓRBITA DE TRANSFERENCIA · 214 DÍAS",
    "MÜRETTEBAT: 1": "TRIPULACIÓN: 1",
    "● GÖREV ONAYLANDI": "● MISIÓN APROBADA",
    "ARES PROGRAMI — GÖREV DOSYASI": "PROGRAMA ARES — EXPEDIENTE DE LA MISIÓN",
    "GİZLİLİK: ÜST DÜZEY": "CLASIFICACIÓN: MÁXIMO NIVEL",
    "KOMUTAN — SEN": "COMANDANTE — TÚ",
    "KİMLİK ARES-1/CDR": "ID ARES-1/CDR",
    GÖREV: "MISIÓN",
    "ARES-1 · Mars yüzey keşfi": "ARES-1 · Exploración de la superficie de Marte",
    MÜRETTEBAT: "TRIPULACIÓN",
    "1 kişi — Komutan (sen)": "1 persona — Comandante (tú)",
    ARAÇ: "VEHÍCULO",
    "ARES-1 iniş ve dönüş roketi · 3 güverte": "Cohete de aterrizaje y regreso ARES-1 · 3 cubiertas",
    YOLCULUK: "VIAJE",
    HEDEF: "DESTINO",
    "YER BİRİMİ": "SEGMENTO TERRESTRE",
    "Görev Kontrol · 3 yer istasyonu": "Control de Misión · 3 estaciones terrestres",
    "Atmosferi, toprağı ve radyasyonu ölç, verileri topla":
      "Medir la atmósfera, el suelo y la radiación, y recoger los datos",
    "Su, oksijen ve tarımla yaşam koşullarını test et":
      "Probar las condiciones de vida con agua, oxígeno y cultivos",
    "Fırtına, radyasyon ve meteor gibi tehlikeleri raporla":
      "Informar de peligros como tormentas, radiación y meteoritos",
    "Tüm bulguları iletişim terminalinden Dünya'ya aktar":
      "Transmitir todos los hallazgos a la Tierra desde el terminal de comunicaciones",
    "GÖREV AMAÇLARI": "OBJETIVOS DE LA MISIÓN",
    ONAYLANDI: "APROBADA",
    KALKIŞA: "PARA EL DESPEGUE",
    YAKIT: "COMBUSTIBLE",
    RÜZGÂR: "VIENTO",
    "6 km/sa": "6 km/h",
    DURUM: "ESTADO",
    HAZIR: "LISTO",
    YÜKSELİŞ: "ASCENSO",
    "KADEME AYRILMASI": "SEPARACIÓN DE ETAPA",
    YÖRÜNGE: "ÓRBITA",
    "GÖREV GÜNÜ": "DÍA DE MISIÓN",
    "GÜÇLÜ İNİŞ": "DESCENSO PROPULSADO",
    "DİKEY HIZ": "VELOCIDAD VERTICAL",
    TEMAS: "CONTACTO",
    İNİŞ: "ATERRIZAJE",
    BAŞARILI: "CON ÉXITO",
    "İSTASYON A · ALINDI": "ESTACIÓN A · RECIBIDA",
    '<span><i class="dot"></i>CANLI</span><span>MARS YEREL <b>{0}:{1}</b></span><span>SICAKLIK <b>{2} °C</b></span><span>RÜZGÂR <b>{3} km/sa</b></span><span>BASINÇ <b>6,1 mbar</b></span><span>IŞIK GECİKMESİ <b>{4} dk</b></span>':
      '<span><i class="dot"></i>EN DIRECTO</span><span>HORA LOCAL DE MARTE <b>{0}:{1}</b></span><span>TEMPERATURA <b>{2} °C</b></span><span>VIENTO <b>{3} km/h</b></span><span>PRESIÓN <b>6,1 mbar</b></span><span>RETARDO DE LUZ <b>{4} min</b></span>',
    "Görev başlıyor: Mars'ı incele, hayatta kal ve her şeyi Dünya'ya aktar.":
      "Comienza la misión: estudia Marte, sobrevive y envíalo todo a la Tierra.",
    "ARES Standart": "ARES Estándar",
    BAŞLANGIÇ: "INICIAL",
    Dengeli: "Equilibrado",
    "Görevin standart EVA giysisi. Beyaz çok katmanlı kumaş, temel yaşam desteği. Kısa dış görevler için yeterli, uzun maruziyette yetersiz.":
      "El traje de EVA estándar de la misión. Tejido blanco multicapa, soporte vital básico. Suficiente para EVA cortas, insuficiente para exposiciones largas.",
    "Kaşif Mk-I": "Explorador Mk-I",
    "Hafif · Çevik": "Ligero · Ágil",
    "Kum rengi hafif kompozit dış katman ve geliştirilmiş CO₂ geri dönüştürücü. Uzun yürüyüşlerde daha az oksijen harcar, daha çevik hareket eder.":
      "Capa exterior ligera de material compuesto color arena y reciclador de CO₂ mejorado. Consume menos oxígeno en las caminatas largas y se mueve con más agilidad.",
    "Ağırlıklı botlar": "Botas lastradas",
    "Öncü Mk-II": "Pionero Mk-II",
    "Karbon · Işık şeritli": "Carbono · Franjas luminosas",
    "Karbon-grafit gövde, ışık şeritli eklemler ve toz contalı bağlantılar. Fırtınada rüzgâra karşı daha sağlam, radyasyona karşı ara katmanlı.":
      "Cuerpo de carbono-grafito, articulaciones con franjas luminosas y uniones selladas contra el polvo. Más firme contra el viento en las tormentas, con una capa intermedia contra la radiación.",
    "Manyetik botlar": "Botas magnéticas",
    "Kalkan Mk-III": "Escudo Mk-III",
    "Zırhlı · Radyasyon kalkanı": "Blindado · Escudo antirradiación",
    "Kurşun katkılı zırh plakaları, manyetik radyasyon kalkanı ve güçlendirilmiş motor destekli eklemler. Radyasyon dalgasında çok daha uzun dayanır.":
      "Placas de blindaje con plomo, escudo magnético antirradiación y articulaciones reforzadas con asistencia motorizada. Resiste mucho más tiempo en una ola de radiación.",
    "Jiroskop dengeleyici": "Estabilizador giroscópico",
    "Prototip · Altın vizör": "Prototipo · Visor dorado",
    "Görev Kontrol'ün gizli prototipi. Altın kaplı vizör, plazma çekirdekli yaşam desteği, tam fırtına zırhı ve güçlendirilmiş dış iskelet.":
      "El prototipo secreto de Control de Misión. Visor bañado en oro, soporte vital con núcleo de plasma, blindaje completo contra tormentas y exoesqueleto reforzado.",
    "Aktif yerçekimi dengeleyici": "Estabilizador de gravedad activo",
    "Klasik ARES": "ARES Clásico",
    "Beyaz gövde, turuncu burun — görevin orijinal boyası.":
      "Fuselaje blanco, morro naranja: la pintura original de la misión.",
    "Kutup Mavisi": "Azul Polar",
    "Buz beyazı gövde, lacivert burun, camgöbeği kanatlar ve ince hız şeritleri.":
      "Fuselaje blanco hielo, morro azul marino, aletas cian y finas franjas de carreras.",
    "Mars Kamuflajı": "Camuflaje Marciano",
    "Pas ve kum tonlarında desen, zeytin yeşili kanatlar. Mars'ta neredeyse görünmez.":
      "Patrón en tonos óxido y arena, aletas verde oliva. Casi invisible en Marte.",
    "Gece Kuzgunu": "Cuervo Nocturno",
    "Mat siyah gövde, kızıl burun ve kanatlar, parlayan kırmızı çizgiler.":
      "Fuselaje negro mate, morro y aletas carmesí, líneas rojas brillantes.",
    "Altın Çağ": "Edad de Oro",
    "Krom-altın kaplama, siyah burun ve şeritler, güneşte parıldayan yansımalar.":
      "Revestimiento cromo-dorado, morro y franjas negros, reflejos que brillan al sol.",
    "Titanyum Plakalar": "Placas de titanio",
    "Alt gövdeye perçinli titanyum plakalar. Fırtınada motor arızası olasılığı %60 → %35.":
      "Placas de titanio remachadas en la parte inferior del fuselaje. Probabilidad de avería del motor en una tormenta: 60 % → 35 %.",
    "Kanat & Burun Zırhı": "Blindaje de aletas y morro",
    "Kanat kenar koruyucuları ve güçlendirilmiş burun başlığı. Arıza olasılığı %15'e iner, gövde daha az sarsılır.":
      "Protectores para el borde de las aletas y una punta de morro reforzada. La probabilidad de avería baja al 15 % y el fuselaje se sacude menos.",
    "Deflektör Kalkanı": "Escudo deflector",
    "Manyetik toz deflektörü roketi enerji kalkanıyla sarar. Fırtına artık motoru bozamaz.":
      "Un deflector magnético de polvo envuelve el cohete en un escudo de energía. Las tormentas ya no pueden averiar el motor.",
    ATÖLYE: "TALLER",
    "Oksijen tüketimi": "Consumo de oxígeno",
    " daha az": " menos",
    "Yürüme hızı": "Velocidad al caminar",
    "Radyasyon koruması": "Protección antirradiación",
    " daha az hasar": " menos daño",
    "Fırtına direnci": "Resistencia a tormentas",
    " daha az etki": " menos efecto",
    "Yerçekimi dengesi": "Equilibrio gravitatorio",
    " daha az sekme": " menos rebote",
    standart: "estándar",
    '<span class="ug-cost ok">Ücretsiz</span>': '<span class="ug-cost ok">Gratis</span>',
    '<span><img src="{0}">Metal <b>{1}</b></span><span><img src="{2}">Kristal <b>{3}</b></span><span><i class="ug-au"></i>Altın <b>{4}</b></span>':
      '<span><img src="{0}">Metal <b>{1}</b></span><span><img src="{2}">Cristal <b>{3}</b></span><span><i class="ug-au"></i>Oro <b>{4}</b></span>',
    GİYİLİ: "PUESTO",
    SAHİP: "EN PROPIEDAD",
    KİLİTLİ: "BLOQUEADO",
    '<div class="ug-feat">⚙ {0} · dışarıda yerçekiminden daha az etkilenirsin</div>':
      '<div class="ug-feat">⚙ {0} · fuera, la baja gravedad te afecta menos</div>',
    "✓ Şu an giyili": "✓ Puesto actualmente",
    Giy: "Ponerse",
    "Önce ": "Requiere ",
    "Üret ve giy": "Fabricar y ponerse",
    "Önce bir önceki seti üretmelisin": "Primero debes fabricar el conjunto anterior",
    "Malzeme yetersiz — metal, yıldız kristali ve uzak bölgelerdeki nadir taşları topla":
      "Materiales insuficientes: recoge metal, cristales estelares y piedras raras de zonas remotas",
    "</b> giyildi — ": "</b> equipado — ",
    '<button class="cbtn pri" data-armor="{0}">Kur</button>':
      '<button class="cbtn pri" data-armor="{0}">Instalar</button>',
    '<span class="ug-badge on">KURULU</span>': '<span class="ug-badge on">INSTALADO</span>',
    '<span class="ug-badge">KİLİTLİ</span>': '<span class="ug-badge">BLOQUEADO</span>',
    "✓ Uygulandı": "✓ Aplicada",
    "Boyayı uygula": "Aplicar pintura",
    "Satın al ve uygula": "Comprar y aplicar",
    '<div class="ug-rk">\n      <div class="ug-rkstage" style="--g:#5ad1ff"><div class="ug-ring"></div><img class="ug-hero rk" src="{0}"><div class="ug-floor"></div>\n        <div class="ug-rkcap"><small>BOYA</small><b>{1}</b><p>{2}</p></div></div>\n      <div class="ug-rkside">\n        <div class="ug-sec">🛡️ FIRTINA KALKANI <span>Arıza olasılığı: <b>%{3}</b></span></div>\n        <div class="ug-armor">{4}</div>\n        <div class="ug-sec">🎨 GÖRÜNÜM <span>Altın parçalarıyla boya</span></div>\n        <div class="ug-skins">{5}</div>\n        <div class="ug-buy">{6}\n          <button class="cbtn pri wide" id="ugSk" {7}>{8}</button></div>\n      </div></div>':
      '<div class="ug-rk">\n      <div class="ug-rkstage" style="--g:#5ad1ff"><div class="ug-ring"></div><img class="ug-hero rk" src="{0}"><div class="ug-floor"></div>\n        <div class="ug-rkcap"><small>PINTURA</small><b>{1}</b><p>{2}</p></div></div>\n      <div class="ug-rkside">\n        <div class="ug-sec">🛡️ ESCUDO ANTITORMENTAS <span>Probabilidad de avería: <b>{3} %</b></span></div>\n        <div class="ug-armor">{4}</div>\n        <div class="ug-sec">🎨 ASPECTO <span>Pintura con fragmentos de oro</span></div>\n        <div class="ug-skins">{5}</div>\n        <div class="ug-buy">{6}\n          <button class="cbtn pri wide" id="ugSk" {7}>{8}</button></div>\n      </div></div>',
    "Malzeme yetersiz — altın (meteor kraterleri) ve titanyum cevheri (uzak bölgeler) topla":
      "Materiales insuficientes: recoge oro (cráteres de meteorito) y mineral de titanio (zonas remotas)",
    "</b> kuruldu — fırtınada arıza olasılığı %": "</b> instalado — probabilidad de avería en tormenta: %",
    "Yeterli altın yok — meteor kraterlerinden altın parçası topla":
      "No tienes suficiente oro: recoge fragmentos de oro de los cráteres de meteorito",
    "🎨 Roket boyandı: <b>": "🎨 Cohete pintado: <b>",
    "Titanyum cevheri": "Mineral de titanio",
    "Roket zırhı · fırtına kalkanı": "Blindaje del cohete · escudo antitormentas",
    "Olivin kristali": "Cristal de olivino",
    "Kıyafet setleri · Öncü, Kalkan, Elite": "Conjuntos de traje · Pionero, Escudo, Elite",
    "Ares taşı": "Piedra de Ares",
    "En üst seviye · ARES Elite + Deflektör kalkanı": "Nivel máximo · ARES Elite + escudo deflector",
    "Hematit küreleri": "Esférulas de hematita",
    "Bilim numunesi · geçmişte su izi": "Muestra científica · huella de agua pasada",
    "Jips kristali": "Cristal de yeso",
    "Bilim numunesi · kristal suyu içerir": "Muestra científica · contiene agua de cristalización",
    "Perklorat tuzu": "Sal de perclorato",
    "Bilim numunesi · zehirli, dikkatle taşı": "Muestra científica · tóxica, manipular con cuidado",
    "Demir-nikel meteorit": "Meteorito de hierro-níquel",
    "Bilim numunesi · uzaydan gelen göktaşı": "Muestra científica · un meteorito llegado del espacio",
    "Oksit minerali · ilmenit": "Mineral óxido · ilmenita",
    "Doğal radyoaktivite yok": "Sin radiactividad natural",
    "Tehlikesiz. Kesip öğütürken çıkan tozu solumayın.":
      "Inofensivo. No inhales el polvo al cortarlo o molerlo.",
    "Mars bazaltlarında yaygın titanyum kaynağıdır. Titanyum hafif ve çok dayanıklı olduğu için roket zırhı ve ısıl kalkan için en değerli yerel malzemelerden biridir.":
      "Una fuente habitual de titanio en los basaltos marcianos. El titanio es ligero y muy resistente, por lo que es uno de los materiales locales más valiosos para el blindaje y los escudos térmicos.",
    "Silikat minerali · forsterit–fayalit serisi": "Mineral silicato · serie forsterita–fayalita",
    Diğer: "Otros",
    "Olivin suyla temas edince kolayca ayrışır. Bu kadar taze olivin bulunması, bölgenin çok uzun süredir kuru kaldığını gösteriyor. Sert ve ısıya dayanıklı yapısıyla kıyafet katmanlarında kullanılabilir.":
      "El olivino se descompone fácilmente en contacto con el agua. Encontrarlo tan fresco indica que la zona lleva muchísimo tiempo seca. Por su dureza y resistencia al calor puede usarse en las capas del traje.",
    "Tanımlanamayan kristal yapı (Mars'a özgü)": "Estructura cristalina no identificada (exclusiva de Marte)",
    "Si–Fe–O + nadir toprak elementleri": "Si–Fe–O + tierras raras",
    "Zayıf radyoaktivite (doğal arka planın ~3 katı)": "Radiactividad débil (~3 veces el fondo natural)",
    "Dikkat. Uzun süre çıplak elle tutmayın ve yatakhanede saklamayın. Kargo bölmesinde korumalı taşınabilir.":
      "Precaución. No la sostengas mucho tiempo sin guantes ni la guardes en el dormitorio. Puede transportarse blindada en la bodega.",
    "Dünya'da eşi bilinmeyen bir kristal örgü. Nadir toprak elementleri ve çok yüksek sertlik, onu kalkan sistemleri için eşsiz kılıyor. Ekiplerimiz kökenini araştırmayı sürdürüyor.":
      "Una red cristalina sin equivalente conocido en la Tierra. Sus tierras raras y su enorme dureza la hacen única para sistemas de escudo. Nuestros equipos siguen investigando su origen.",
    "Demir oksit · küresel konkresyon": "Óxido de hierro · concreción esférica",
    "Tehlikesiz.": "Inofensivo.",
    "Bu küçük demir oksit küreleri, kayaçların içinden geçen yeraltı suyunda yavaş yavaş oluşur. Yani bu bölgede çok uzun zaman önce sıvı su vardı. Meridiani Planum'da bulunan ünlü kürelerle aynı türden.":
      "Estas pequeñas esferas de óxido de hierro se forman lentamente en el agua subterránea que atraviesa las rocas. Es decir, aquí hubo agua líquida hace muchísimo tiempo. Son del mismo tipo que las famosas esférulas de Meridiani Planum.",
    "Sülfat minerali · kalsiyum sülfat dihidrat": "Mineral sulfato · sulfato de calcio dihidratado",
    "H₂O (kristal suyu)": "H₂O (agua de cristalización)",
    "Tehlikesiz. Çok yumuşaktır, kolay kırılır.": "Inofensivo. Es muy blando y se rompe con facilidad.",
    "Jips, su buharlaşırken oluşan bir mineraldir ve yapısında %21 oranında su tutar. Isıtıldığında bu suyu bırakır; ileride Mars'ta su elde etmek için önemli bir kaynak olabilir.":
      "El yeso se forma al evaporarse el agua y retiene un 21 % de agua en su estructura. Al calentarlo la libera, así que podría ser una fuente de agua importante en Marte.",
    "Klor tuzu · magnezyum/kalsiyum perklorat": "Sal de cloro · perclorato de magnesio/calcio",
    "ClO₄⁻ (perklorat)": "ClO₄⁻ (perclorato)",
    "Toprak + su": "Suelo + agua",
    "TEHLİKELİ. Perklorat insan için zehirlidir; tiroid bezinin çalışmasını bozar. Çıplak elle dokunmayın, tozunu solumayın, kabine sokmayın. Giysiyi kabine girmeden önce temizleyin.":
      "PELIGROSO. El perclorato es tóxico para las personas y altera la glándula tiroides. No lo toques sin guantes, no inhales su polvo ni lo metas en la cabina. Limpia el traje antes de entrar.",
    "Perkloratlar Mars toprağında yaygındır (yaklaşık %0,5–1). Zehirli olsalar da parçalandıklarında oksijen açığa çıkardıkları için gelecekte oksijen üretiminde kullanılabilirler.":
      "Los percloratos son comunes en el suelo marciano (alrededor del 0,5–1 %). Aunque son tóxicos, liberan oxígeno al descomponerse, por lo que podrían servir para producir oxígeno en el futuro.",
    "Demir meteorit · kamasit–tenit": "Meteorito metálico · kamacita–taenita",
    "Fe–Ni alaşımı": "Aleación Fe–Ni",
    "Kozmik ışınla oluşmuş izotop izleri (zararsız)": "Trazas de isótopos cosmogénicos (inofensivas)",
    "Tehlikesiz. Çok ağırdır; taşırken dikkat edin.": "Inofensivo. Es muy pesado; cuidado al transportarlo.",
    "Bu taş Mars'a uzaydan düşmüş bir göktaşı. Kesilip parlatıldığında çok yavaş soğumanın izi olan çapraz desenler görülür. Mars yüzeyinde bulunan demir meteoritler, atmosferin geçmişteki kalınlığı hakkında ipucu verir.":
      "Esta roca es un meteorito caído sobre Marte desde el espacio. Cortado y pulido muestra patrones cruzados fruto de un enfriamiento muy lento. Los meteoritos metálicos de la superficie marciana dan pistas sobre el grosor que tuvo la atmósfera.",
    "Bilinmeyen taş": "Piedra desconocida",
    "BİLİNMEYEN TAŞ": "PIEDRA DESCONOCIDA",
    "📡 Tarayıcı: yakında ": "📡 Escáner: señal de ",
    "<b>bilinmeyen bir mineral</b>": "<b>un mineral desconocido</b>",
    " sinyali — haritadaki işarete git": " cerca — ve a la marca del mapa",
    "<b>Bilinmeyen taş</b> çantana alındı. Ne olduğunu ve tehlikeli olup olmadığını öğrenmek için roketteki <b>kargo terminalinden</b> analize gönder.":
      "<b>Roca desconocida</b> guardada en la mochila. Para saber qué es y si es peligrosa, envíala a analizar desde el <b>terminal de carga</b> del cohete.",
    "</b> (toplam ": "</b> (total ",
    "Bu taş zaten analizde": "Esta roca ya se está analizando",
    "Taş numunesi <b>analiz için</b> Dünya'ya gönderildi. Laboratuvar sonucu birazdan gelen kutunda.":
      "Muestra de roca enviada a la Tierra <b>para su análisis</b>. El resultado llegará pronto a tu bandeja.",
    GÜVENLİ: "SEGURO",
    DİKKAT: "PRECAUCIÓN",
    TEHLİKELİ: "PELIGROSO",
    '<p>Sayın Komutan,</p>\n  <p><b>Analiz için</b> gönderdiğiniz bilinmeyen taş numunesi laboratuvarımızda incelendi. Taşın adı ve özellikleri aşağıdadır.</p>\n  <div class="ltr-annex"><div class="ah">NUMUNE ANALİZ RAPORU · {0}</div>\n  <table class="mn-tbl">\n    <tr><td>Tanım</td><td><b>{1}</b></td></tr>\n    <tr><td>Mineral sınıfı</td><td>{2}</td></tr>\n    <tr><td>Kimyasal formül</td><td><b>{3}</b></td></tr>\n    <tr><td>Sertlik (Mohs)</td><td>{4}</td></tr>\n    <tr><td>Yoğunluk</td><td>{5}</td></tr>\n    <tr><td>Radyoaktivite</td><td>{6}</td></tr></table>\n  <b style="font-size:12px">Bileşim (ağırlıkça)</b>{7}\n  <div class="an">Yöntem: X-ışını kırınımı (XRD) · X-ışını floresansı (XRF) · gama spektrometrisi</div></div>\n  <div class="mn-hz {8}"><b>{9}</b><span>{10}</span></div>\n  <h4>Bilimsel değerlendirme</h4><p>{11}</p>\n  <p><b>Oyundaki kullanımı:</b> {12}.</p>':
      '<p>Estimado comandante:</p>\n  <p>La muestra de roca desconocida que enviaste <b>para su análisis</b> se ha examinado en nuestro laboratorio. Su nombre y propiedades figuran a continuación.</p>\n  <div class="ltr-annex"><div class="ah">INFORME DE ANÁLISIS DE MUESTRA · {0}</div>\n  <table class="mn-tbl">\n    <tr><td>Identificación</td><td><b>{1}</b></td></tr>\n    <tr><td>Clase mineral</td><td>{2}</td></tr>\n    <tr><td>Fórmula química</td><td><b>{3}</b></td></tr>\n    <tr><td>Dureza (Mohs)</td><td>{4}</td></tr>\n    <tr><td>Densidad</td><td>{5}</td></tr>\n    <tr><td>Radiactividad</td><td>{6}</td></tr></table>\n  <b style="font-size:12px">Composición (en peso)</b>{7}\n  <div class="an">Método: difracción de rayos X (XRD) · fluorescencia de rayos X (XRF) · espectrometría gamma</div></div>\n  <div class="mn-hz {8}"><b>{9}</b><span>{10}</span></div>\n  <h4>Evaluación científica</h4><p>{11}</p>\n  <p><b>Uso en el juego:</b> {12}.</p>',
    "Numune analizi · ": "Análisis de muestra · ",
    "🌀 Toz şeytanına yakalandın — uzaklaş!": "🌀 Te ha atrapado un remolino de polvo: ¡aléjate!",
    "'e varıldı": ": has llegado",
    '<span class="st on">🌪 FIRTINA</span>': '<span class="st on">🌪 TORMENTA</span>',
    '<span class="st" title="Sonraki kum fırtınası">🌪 Gün ':
      '<span class="st" title="Próxima tormenta de arena">🌪 Día ',
    '<span class="rd on">☢ AKTİF</span>': '<span class="rd on">☢ ACTIVA</span>',
    '<span class="rd" title="Sonraki radyasyon dalgası">☢ Gün ':
      '<span class="rd" title="Próxima ola de radiación">☢ Día ',
    '<div class="hd-top"><span class="hd-planet" style="{0}"></span>\n      <div class="hd-tt"><b>{1}</b><span>GÜN {2}</span></div>\n      <div class="hd-clock">{3} {4}</div></div>\n    <div class="hd-bar">{5}<em style="left:{6}%"></em></div>\n    <div class="hd-foot"><span>⏳ {7}</span><span class="hd-ev">{8}</span></div>':
      '<div class="hd-top"><span class="hd-planet" style="{0}"></span>\n      <div class="hd-tt"><b>{1}</b><span>DÍA {2}</span></div>\n      <div class="hd-clock">{3} {4}</div></div>\n    <div class="hd-bar">{5}<em style="left:{6}%"></em></div>\n    <div class="hd-foot"><span>⏳ {7}</span><span class="hd-ev">{8}</span></div>',
    DIŞARI: "FUERA",
    KABİN: "CABINA",
    "💧 Su": "💧 Agua",
    "🥔 Patates": "🥔 Patata",
    "💊 Medikit": "💊 Botiquín",
    "🌱 Tohum": "🌱 Semilla",
    "🔩 Metal numune": "🔩 Muestra metálica",
    "⭐ Yıldız kırıntısı (2 numune)": "⭐ Fragmento estelar (2 muestras)",
    "Çürük patates (numune)": "Patata podrida (muestra)",
    "Bu numarada henüz eşya yok — önce topla": "Aún no hay ningún objeto en esta ranura: recoge uno primero",
    "Çapa elinde — yakındaki yere <b>sol tıkla</b>, toprağı kaz":
      "Azada en la mano: haz <b>clic izquierdo</b> en el suelo cercano para cavar",
    "Bu slot boş — (": "Esta ranura está vacía — (",
    "Susuzluğun zaten dolu": "No tienes sed",
    "Su içildi (+": "Has bebido agua (+",
    " susuzluk)": " de agua)",
    "Açlığın zaten dolu": "No tienes hambre",
    "Patates yendi (+": "Has comido una patata (+",
    " açlık)": " de comida)",
    "Radyasyon ölçer dışarıda, toprak üzerinde kullanılır":
      "El medidor de radiación se usa fuera, sobre el suelo",
    "Çürük patates yenmez — roketteki kargo terminalinden Dünya'ya gönder":
      "Las patatas podridas no se comen: envíala a la Tierra desde el terminal de carga del cohete",
    "Tarla parselinin yakınına git": "Acércate a una parcela de cultivo",
    "Parsel dolu — önce hasat et (F)": "La parcela está ocupada: cosecha primero (F)",
    "🌱 Ekildi": "🌱 Plantado",
    "Numuneler roketin kargo bölmesine yüklenir — rokete götür (F)":
      "Las muestras se cargan en la bodega del cohete: llévalas al cohete (F)",
    "Slot ": "Ranura ",
    "🔓 Dünya rotası açıldı! Komuta güvertesindeki navigasyondan eve dön":
      "🔓 ¡Ruta a la Tierra desbloqueada! Vuelve a casa desde la navegación de la cubierta de mando",
    '<div class="qd-n">Sıradaki görev: <b>{0} {1}</b></div>':
      '<div class="qd-n">Siguiente misión: <b>{0} {1}</b></div>',
    '<div class="qd-n"><b>Tüm görevler bitti!</b></div>':
      '<div class="qd-n"><b>¡Todas las misiones completadas!</b></div>',
    '<div class="qd-ck">✓</div><div class="qd-k">GÖREV TAMAMLANDI</div><div class="qd-t">{0} {1}</div>\n{2}':
      '<div class="qd-ck">✓</div><div class="qd-k">MISIÓN COMPLETADA</div><div class="qd-t">{0} {1}</div>\n{2}',
    "GÖREV ": "MISIÓN ",
    "⏳ Fırtına bekleniyor: <b>Gün 2</b>, saat {0} civarı. O zamana kadar numune topla, tarım yap.":
      "⏳ Tormenta prevista: <b>día 2</b>, hacia las {0}. Hasta entonces, recoge muestras y cultiva.",
    " yüzeyi · sol ": " · superficie · sol ",
    '<div class="ai">⚠️</div><div><b>Ana motor hasarlı — kalkış kilitli.</b><br>Makine dairesindeki ana motoru onar · aşama {0}/4</div>':
      '<div class="ai">⚠️</div><div><b>Motor principal dañado: despegue bloqueado.</b><br>Repara el motor principal en la sala de máquinas · fase {0}/4</div>',
    "Şu an buradasın": "Estás aquí",
    '<span class="badge ok">BURADASIN</span>': '<span class="badge ok">ESTÁS AQUÍ</span>',
    "Görevleri tamamla (": "Completa las misiones (",
    '<span class="badge mute">🔒 KİLİTLİ</span>': '<span class="badge mute">🔒 BLOQUEADO</span>',
    "Eve dönüş rotası hazır": "Ruta de regreso lista",
    "Daha önce ziyaret edildi": "Visitado anteriormente",
    "Yeni rota": "Nueva ruta",
    "🌍 EVE DÖN": "🌍 VOLVER A CASA",
    "🚀 KALKIŞ": "🚀 DESPEGAR",
    "Ana motor hasarlı": "Motor principal dañado",
    "Ana motor arızalı — makine dairesinde motoru onar":
      "Motor principal averiado: repara el motor en la sala de máquinas",
    "Roket yolculuğu sürüyor…": "Viaje en cohete en curso…",
    "Kargo Terminali": "Terminal de carga",
    "Numuneleri kargo bölmesine yükle · erzak kapsüllerde":
      "Carga las muestras en la bodega · los suministros están en las cápsulas",
    "Dışarıdaki parsele ek": "Se planta en una parcela exterior",
    "Canı yeniler": "Restaura la salud",
    '<div class="ri">{0}</div><div><div class="rn">{1}</div><div class="rd">{2}</div></div>\n      <div class="rp"><span>DEPO {3}</span><span class="rp-sub">ÇANTA {4}</span></div>':
      '<div class="ri">{0}</div><div><div class="rn">{1}</div><div class="rd">{2}</div></div>\n      <div class="rp"><span>ALMACÉN {3}</span><span class="rp-sub">MOCHILA {4}</span></div>',
    Bırak: "Dejar",
    '<span class="chip">🔩 Metal <b>×{0}</b> <i>+{1}</i></span>':
      '<span class="chip">🔩 Metal <b>×{0}</b> <i>+{1}</i></span>',
    '<span class="chip">⭐ Yıldız <b>×{0}</b> <i>+{1}</i></span>':
      '<span class="chip">⭐ Estrella <b>×{0}</b> <i>+{1}</i></span>',
    '<div class="con-note">Çantanda numune yok — dışarıda metal ve ⭐ topla, burada kargoya yükle.</div>':
      '<div class="con-note">No llevas muestras en la mochila: recoge metal y ⭐ fuera y cárgalos aquí en la bodega.</div>',
    "Dünya'ya gönderildi · laboratuvar inceliyor": "Enviada a la Tierra · el laboratorio la examina",
    "Ne olduğunu ve tehlikeli olup olmadığını öğrenmek için gönder":
      "Envíala para saber qué es y si es peligrosa",
    '<div class="ri"><img src="{0}" alt="" style="width:32px;height:32px;filter:{1}"></div><div><div class="rn">Bilinmeyen taş · {2}. tür<span class="ana-tag">ANALİZ İÇİN</span></div><div class="rd">{3}</div></div><div class="rp"><span>ÇANTA {4}</span></div>':
      '<div class="ri"><img src="{0}" alt="" style="width:32px;height:32px;filter:{1}"></div><div><div class="rn">Roca desconocida · tipo {2}<span class="ana-tag">PARA ANÁLISIS</span></div><div class="rd">{3}</div></div><div class="rp"><span>BOLSA {4}</span></div>',
    "Analizde…": "Analizando…",
    "Analize gönder": "Enviar a analizar",
    "Dünya'ya gönderildi · analiz bekleniyor": "Enviada a la Tierra · esperando análisis",
    "Kargoyla Dünya'ya gönder · neden çürüdüğünü incelesinler":
      "Envíala a la Tierra por carga · que averigüen por qué se pudrió",
    '<div class="ri"><img src="{0}" alt="" style="width:30px;height:30px"></div><div><div class="rn">Çürük patates<span class="ana-tag">ANALİZ İÇİN</span></div><div class="rd">{1}</div></div><div class="rp"><span>ÇANTA {2}</span></div>':
      '<div class="ri"><img src="{0}" alt="" style="width:30px;height:30px"></div><div><div class="rn">Patata podrida<span class="ana-tag">PARA ANÁLISIS</span></div><div class="rd">{1}</div></div><div class="rp"><span>BOLSA {2}</span></div>',
    "Dünya'ya gönder": "Enviar a la Tierra",
    "📦 Numuneleri kargoya yükle · +": "📦 Cargar muestras en la bodega · +",
    "Yüklenecek numune yok": "No hay muestras para cargar",
    " altın": " de oro",
    "🪙 <b>Altın parçası</b> — roketteki geliştirme istasyonunda roketini güçlendirmek için kullan":
      "🪙 <b>Fragmento de oro</b>: úsalo en la estación de mejoras del cohete para reforzarlo",
    "Envanter dolu! (": "¡Inventario lleno! (",
    "🌱 Tohumu eline aldın — ekmek için tekrar <b>F</b>":
      "🌱 Tienes la semilla en la mano: pulsa <b>F</b> otra vez para plantar",
    "Tohum yok — roketteki alet sandığından al":
      "No hay semillas: coge de la caja de herramientas del cohete",
    "💧 Sulandı": "💧 Regado",
    "💧 Su şişesini eline aldın — sulamak için tekrar <b>F</b>":
      "💧 Tienes la botella de agua en la mano: pulsa <b>F</b> otra vez para regar",
    "Sulamak için su yok · büyüyor %": "No hay agua para regar · creciendo %",
    " su)": " de agua)",
    "Tok durumdasın": "No tienes hambre",
    " tokluk)": " de comida)",
    "Çapa elinde — su içmek için önce suyu eline al (numara tuşu)":
      "Azada en la mano: para beber, coge primero el agua (tecla numérica)",
    "Yapılacak bir şey yok (F)": "Aquí no hay nada que hacer (F)",
    "Canın zaten dolu": "Tu salud ya está al máximo",
    "☢️ Radyasyon dalgası başladı — canın azalıyor, rokete gir!":
      "☢️ Ha empezado una ola de radiación: estás perdiendo salud, ¡entra en el cohete!",
    "☢️ Radyasyon dalgası geçti": "☢️ La ola de radiación ha pasado",
    "Radyasyon dalgası · gövde zırhı koruyor": "Ola de radiación · el blindaje del casco te protege",
    "Dışarıda can azalıyor — rokete sığın!": "Fuera estás perdiendo salud: ¡refúgiate en el cohete!",
    "Radyasyon dalgası yaklaşıyor": "Se acerca una ola de radiación",
    "Güneş patlaması · rokete yaklaş": "Erupción solar · acércate al cohete",
    "<b>F</b>: Altın parçası topla · roket geliştirme":
      "<b>F</b>: Recoger fragmento de oro · mejora del cohete",
    " — kazmayla kır": " — rómpela con el pico",
    "Bilinmeyen taşı kazmayla kır": "Rompe la piedra desconocida con el pico",
    " · <b style='color:#ff8a8a'>jeolog kazması gerekli</b>":
      " · <b style='color:#ff8a8a'>necesitas el pico de geólogo</b>",
    "Çanta dolu (": "Mochila llena (",
    ") — rokete yükle": "): cárgala en el cohete",
    "<b>F</b>: Metal numune topla": "<b>F</b>: Recoger muestra metálica",
    "<b>F</b>: Yıldız kırıntısı topla (⭐ = 2 numune)":
      "<b>F</b>: Recoger fragmento estelar (⭐ = 2 muestras)",
    "Taş kırılıyor…": "Rompiendo la piedra…",
    "Sol tık: ölçümü kapat": "Clic izquierdo: cerrar medición",
    "Ölçülüyor… hareket etme": "Midiendo… no te muevas",
    "<b>F</b>: Ölçüm bayrağını kaldır (": "<b>F</b>: Quitar bandera de medición (",
    "<b>E</b>: Rokete gir": "<b>E</b>: Entrar en el cohete",
    "  ·  <b>F</b>: Numuneleri kargoya yükle": "  ·  <b>F</b>: Cargar muestras en la bodega",
    "  ·  çürük patatesi kargo terminalinden gönder":
      "  ·  envía la patata podrida desde el terminal de carga",
    "<b>Sol tık</b>: toprağın radyasyonunu ölç  ·  <b>F</b>: önündeki toprağı ölç":
      "<b>Clic izquierdo</b>: medir la radiación del suelo  ·  <b>F</b>: medir el suelo de delante",
    "<b>Sol tık</b>: yakındaki yere kaz — ilk parseli aç":
      "<b>Clic izquierdo</b>: cava el suelo cercano y abre la primera parcela",
    "Çapayı eline al (numara tuşu) ya da yere tıkla": "Coge la azada (tecla numérica) o haz clic en el suelo",
    "Çapa roketteki alet sandığında (makine dairesi) — rokete gir: <b>E</b>":
      "La azada está en la caja de herramientas del cohete (sala de máquinas): entra en el cohete: <b>E</b>",
    "<b>F</b>: Tohum ek": "<b>F</b>: Plantar semilla",
    "<b>F</b>: Tohumu eline al": "<b>F</b>: Coger la semilla",
    "<b>F</b>: Hasat et — yapraklar solmuş, bir terslik var":
      "<b>F</b>: Cosechar — las hojas están marchitas, algo va mal",
    "<b>F</b>: Hasat et 🥔": "<b>F</b>: Cosechar 🥔",
    "<b>F</b>: Sula (hızlandırır)": "<b>F</b>: Regar (acelera el crecimiento)",
    "<b>F</b>: Suyu eline al (sulamak için)": "<b>F</b>: Coger el agua (para regar)",
    "Büyüyor %": "Creciendo %",
    "<b>G</b>: Medikit kullan (": "<b>G</b>: Usar botiquín (",
    "Dikkat: canın düşük! Roketin revirinde iyileş":
      "¡Atención: tu salud está baja! Cúrate en la enfermería del cohete",
    "Elinde: ": "En la mano: ",
    "Çok uzak — tıkladığın yere daha yaklaş": "Demasiado lejos: acércate al lugar donde hiciste clic",
    "Azami parsel sayısına ulaştın (": "Has alcanzado el número máximo de parcelas (",
    "Buraya çok yakın — biraz aralık bırak": "Demasiado cerca de otra parcela: deja algo de espacio",
    "İniş platformunu kazamazsın": "No puedes cavar en la plataforma de aterrizaje",
    "Dünyanın kenarını kazamazsın": "No puedes cavar en el borde del mundo",
    "Tohumu ekmek için açtığın bir parsele tıkla":
      "Haz clic en una parcela que hayas cavado para plantar la semilla",
    "Sulamak için ekili bir parsele tıkla": "Haz clic en una parcela sembrada para regarla",
    "Bu parsel boş — önce tohum ek": "Esta parcela está vacía: siembra primero",
    "Mahsul hazır — hasat için yanına git ve <b>F</b>": "Cosecha lista: acércate y pulsa <b>F</b>",
    Sulandı: "Regado",
    "Yeni parsel: boş": "Nueva parcela: vacía",
    "Yeni parsel hazır: <b>boş</b> — tohum ek (F)":
      "Nueva parcela lista: <b>vacía</b>; planta una semilla (F)",
    "Jeolog kazması yalnızca <b>bilinmeyen (?) taşları</b> kırar — kazmak için çapayı eline al":
      "El pico de geólogo solo rompe <b>piedras desconocidas (?)</b>: para cavar, coge la azada",
    "Elinde başka bir eşya var — kazmak için çapayı eline al (numara tuşu)":
      "Llevas otra cosa en la mano: coge la azada para cavar (tecla numérica)",
    "Çapa rokette — makine dairesindeki alet sandığından al":
      "La azada está en el cohete: cógela de la caja de herramientas de la sala de máquinas",
    "Çapayı eline aldın — kazmak için tekrar tıkla": "Azada en la mano: haz clic otra vez para cavar",
    "Yaşanabilirlik araştırması": "Estudio de habitabilidad",
    "Mars'ta bir insanın hayatta kalıp kalamayacağını ölç. Fırtına, radyasyon ve yaşam desteği raporları daha değerli.":
      "Mide si un ser humano puede sobrevivir en Marte. Los informes de tormentas, radiación y soporte vital valen más.",
    "Jeoloji ve nadir mineraller": "Geología y minerales raros",
    "Kayaçları ve bilinmeyen mineralleri incele. Numune ve nadir taş raporları daha değerli.":
      "Estudia las rocas y los minerales desconocidos. Los informes de muestras y piedras raras valen más.",
    "Uzun süreli yaşam testi": "Prueba de vida de larga duración",
    "Mars toprağında besin üretimini dene. Tarım ve yaşam desteği raporları daha değerli.":
      "Prueba a producir alimentos en el suelo marciano. Los informes de cultivo y soporte vital valen más.",
    Kolay: "Fácil",
    Normal: "Normal",
    Zor: "Difícil",
    "Orta sınıf roket": "Cohete de carga media",
    "Ucuz ama taşıma kapasitesi sınırlı.": "Barato, pero con capacidad de carga limitada.",
    "Ağır roket": "Cohete pesado",
    "Dengeli kapasite ve maliyet.": "Capacidad y coste equilibrados.",
    "Süper ağır roket": "Cohete superpesado",
    "Her şeyi taşır ama bütçeyi zorlar.": "Lo lleva todo, pero aprieta el presupuesto.",
    "Hızlı transfer": "Transferencia rápida",
    "Daha çok yakıt (kütle) gerekir; mürettebat Mars'a erzakı dolu varır.":
      "Necesita más combustible (masa); la tripulación llega a Marte con los suministros completos.",
    "Ekonomik transfer": "Transferencia económica",
    "Az yakıt gerekir ama yolculuk uzar: erzak ve oksijen eksik başlar.":
      "Necesita poco combustible, pero el viaje es más largo: los suministros y el oxígeno empiezan más bajos.",
    "Kısa görev: bütçe dostu, az erzak.": "Misión corta: barata, pocos suministros.",
    "Orta süre: ek erzak paketi.": "Duración media: paquete extra de suministros.",
    "Uzun görev: bol erzak, yüksek maliyet.": "Misión larga: muchos suministros, coste elevado.",
    "Güç sistemi": "Sistema de energía",
    "Tüm sistemler elektrik ister. Güneş panelleri fırtınada tozla kaplanır; radyoizotop jeneratör (RTG) hep aynı gücü verir ama ağır ve pahalıdır.":
      "Todos los sistemas necesitan electricidad. Los paneles solares se cubren de polvo en las tormentas; un generador de radioisótopos (RTG) da siempre la misma potencia, pero es pesado y caro.",
    "Hafif ve ucuz; fırtınada üretim düşer.": "Ligeros y baratos; la producción baja en las tormentas.",
    "Geniş güneş panelleri": "Paneles solares grandes",
    "Daha çok güç; fırtınada yine düşer.": "Más potencia; sigue bajando en las tormentas.",
    "Radyoizotop jeneratör (RTG)": "Generador de radioisótopos (RTG)",
    "Fırtınadan etkilenmez; ağır ve pahalı.": "No le afectan las tormentas; pesado y caro.",
    Batarya: "Batería",
    "Batarya, güneş paneli üretimi düştüğünde (fırtına) sistemleri ayakta tutar.":
      "La batería mantiene los sistemas en marcha cuando baja la producción de los paneles (tormentas).",
    "Standart batarya": "Batería estándar",
    "Fırtınada kısa süre idare eder.": "Aguanta poco tiempo en una tormenta.",
    "Büyük batarya": "Batería grande",
    "Fırtınada güç kaybının yarısını karşılar.": "Cubre la mitad de la pérdida de potencia en una tormenta.",
    "Oksijen tüpünün kapasitesini ve kendini yenileme hızını belirler. Daha iyi sistem daha çok güç ve kütle ister.":
      "Determina la capacidad del tanque de oxígeno y la rapidez con que se rellena. Un sistema mejor necesita más potencia y masa.",
    "Standart O₂ tüpü": "Tanque de O₂ estándar",
    "Temel kapasite.": "Capacidad básica.",
    "Genişletilmiş tüp": "Tanque ampliado",
    "%40 daha fazla oksijen.": "Un 40 % más de oxígeno.",
    "Kapalı döngü rejeneratör": "Regenerador de circuito cerrado",
    "Tüp neredeyse 2 kat hızlı dolar.": "El tanque se rellena casi el doble de rápido.",
    "Yapı ve koruma": "Estructura y protección",
    "Gövde zırhı fırtınada motorun bozulma olasılığını azaltır. Zırh ağırdır; fırlatma aracının kapasitesini zorlar.":
      "El blindaje del casco reduce la probabilidad de que el motor se averíe en una tormenta. Es pesado y aprieta la capacidad del vehículo de lanzamiento.",
    "Hafif gövde": "Casco ligero",
    "Fırtınada motor arıza riski %60.": "Riesgo de avería del motor en tormentas: 60 %.",
    "Takviyeli gövde": "Casco reforzado",
    "Arıza riski %35 ile başlar.": "El riesgo de avería empieza en el 35 %.",
    "Ağır zırhlı gövde": "Casco con blindaje pesado",
    "Arıza riski %15 ile başlar.": "El riesgo de avería empieza en el 15 %.",
    "Anten, günde Dünya'ya gönderilebilecek veri miktarını (MB/sol) ve yanıt süresini belirler. Bilim aletlerinin ürettiği veri bu kapasiteyi aşarsa bilimin bir kısmı kaybolur.":
      "La antena determina cuántos datos se pueden enviar a la Tierra al día (MB/sol) y lo rápido que llegan las respuestas. Si los instrumentos generan más datos, se pierde parte de la ciencia.",
    "Düşük kazançlı anten": "Antena de baja ganancia",
    "Ucuz; az veri, yavaş yanıt.": "Barata; pocos datos, respuestas lentas.",
    "Yüksek kazançlı anten": "Antena de alta ganancia",
    "Dengeli seçim.": "Una opción equilibrada.",
    "Anten + Mars yörüngesinde röle uydusu": "Antena + satélite de retransmisión en órbita de Marte",
    "Çok veri, hızlı yanıt; fırtınada bile gönderim yapılır.":
      "Muchos datos, respuestas rápidas; puedes transmitir incluso durante las tormentas.",
    "Aviyonik ve yönelim kontrolü": "Aviónica y control de actitud",
    "Araç bilgisayarı ve yönelim kontrolü; gelişmiş sistem tarayıcının menzilini artırır.":
      "El ordenador del vehículo y el control de actitud; el sistema avanzado aumenta el alcance del escáner.",
    "Standart bilgisayar": "Ordenador estándar",
    "Temel tarayıcı menzili.": "Alcance básico del escáner.",
    "Gelişmiş bilgisayar + yıldız izleyici": "Ordenador avanzado + rastreador estelar",
    "Tarayıcı menzili %35 artar.": "Alcance del escáner +35 %.",
    "Meteoroloji istasyonu": "Estación meteorológica",
    "Fırtına uyarısı 30 sn daha erken gelir.": "Los avisos de tormenta llegan 30 s antes.",
    "Radyasyon dedektörü": "Detector de radiación",
    "Radyasyon uyarısı 30 sn daha erken gelir.": "Los avisos de radiación llegan 30 s antes.",
    "Kayaç spektrometresi": "Espectrómetro de rocas",
    "Numune raporlarının bilim değeri %50 artar.": "Los informes de muestras valen un 50 % más de ciencia.",
    "Zemin radarı": "Radar de penetración terrestre",
    "Bilinmeyen taşları %80 daha uzaktan bulursun.":
      "Encuentras piedras desconocidas desde un 80 % más lejos.",
    "Sera modülü": "Módulo de invernadero",
    "Bitkiler %50 daha hızlı büyür.": "Las plantas crecen un 50 % más rápido.",
    "Panoramik kamera": "Cámara panorámica",
    "Tüm raporların bilim değeri %15 artar; çok veri üretir.":
      "Todos los informes valen un 15 % más de ciencia; genera muchos datos.",
    "Görev hedefi": "Objetivo de la misión",
    "Fırlatma ve yörünge": "Lanzamiento y trayectoria",
    "Uzay aracı": "Nave espacial",
    "Bilim ve iletişim": "Ciencia y comunicaciones",
    "Simülasyon ve fırlatma": "Simulación y lanzamiento",
    Rekorlar: "Récords",
    "Kütle {0} t, fırlatma aracının kapasitesi {1} t. Daha güçlü bir roket seç ya da kütleyi azalt.":
      "La masa es de {0} t, pero el vehículo de lanzamiento lleva {1} t. Elige un cohete más potente o reduce la masa.",
    "Güç tüketimi {0} kW, üretim {1} kW. Güç sistemini büyüt ya da alet çıkar.":
      "El consumo es de {0} kW y la producción de {1} kW. Amplía el sistema de energía o quita un instrumento.",
    "Maliyet {0} M$, bütçe {1} M$. Daha ucuz bileşenler seç.":
      "El coste es de {0} M$ y el presupuesto de {1} M$. Elige componentes más baratos.",
    "Aletler günde {0} MB veri üretiyor, anten {1} MB gönderebiliyor. Bilimin yaklaşık %{2}'i kaybolacak.":
      "Los instrumentos generan {0} MB de datos al día y la antena puede enviar {1} MB. Se perderá aproximadamente el {2} % de la ciencia.",
    "Hiç bilim aleti yok: görev bilim değeri düşük olur.":
      "Sin instrumentos científicos: el valor científico de la misión será bajo.",
    "Güç payı çok az: fırtınada güneş panelleri yetersiz kalabilir.":
      "Muy poco margen de potencia: los paneles solares pueden quedarse cortos en las tormentas.",
    "{0} simülasyonda fırlatma başarısız oldu: fırlatma aracının güvenilirliği bunu belirler.":
      "El lanzamiento falló en {0} simulaciones: lo determina la fiabilidad del vehículo de lanzamiento.",
    "{0} simülasyonda fırtına motoru onarılamaz şekilde bozdu: gövde zırhı bu riski düşürür.":
      "En {0} simulaciones una tormenta dañó el motor sin reparación posible: el blindaje del casco reduce este riesgo.",
    "{0} simülasyonda oksijen yetmedi: yaşam desteği ve güç sistemi bunu etkiler.":
      "En {0} simulaciones se acabó el oxígeno: influyen el soporte vital y el sistema de energía.",
    "{0} simülasyonda erzak bitti: görev süresi, transfer yörüngesi ve sera modülü bunu etkiler.":
      "En {0} simulaciones se acabaron los suministros: influyen la duración de la misión, la trayectoria y el módulo de invernadero.",
    "Simülasyonların hiçbirinde ciddi bir arıza görülmedi.":
      "No hubo ninguna avería grave en ninguna simulación.",
    "Mars'a ilk adım": "Primeros pasos en Marte",
    "Mars'a yeni gelenler için. Kaynaklar daha yavaş tükenir, tehlikeler daha hafif vurur ve yaralar daha çabuk iyileşir. Keşfetmeye ve öğrenmeye odaklan.":
      "Para recién llegados a Marte. Los recursos se agotan más despacio, los peligros golpean con menos fuerza y las heridas sanan antes. Céntrate en explorar y aprender.",
    "Dengeli görev": "Misión equilibrada",
    "Oyunun tasarlandığı denge. Hayatta kalmak için yemeğini, suyunu ve oksijenini planlaman gerekir ama küçük hatalara yer vardır.":
      "El equilibrio para el que se diseñó el juego. Para sobrevivir debes planificar tu comida, agua y oxígeno, pero hay margen para pequeños errores.",
    "Deneyimli komutan": "Comandante veterano",
    "Her kaynak değerlidir. Açlık, susuzluk ve oksijen daha hızlı düşer; fırtınalar, radyasyon ve meteorlar daha sert vurur, iyileşme yavaşlar.":
      "Cada recurso cuenta. El hambre, la sed y el oxígeno bajan más rápido; las tormentas, la radiación y los meteoritos golpean más fuerte y la curación es más lenta.",
    "Açlık hızı": "Ritmo del hambre",
    "Susuzluk hızı": "Ritmo de la sed",
    "Radyasyon hasarı": "Daño por radiación",
    "Fırtına etkisi": "Efecto de las tormentas",
    "Meteor hasarı": "Daño por meteoritos",
    "İyileşme hızı": "Velocidad de curación",
    Standart: "Estándar",
    "%{0} daha hızlı": "{0}% más rápido",
    "%{0} daha yavaş": "{0}% más lento",
    "%{0} daha fazla": "{0}% más",
    "%{0} daha az": "{0}% menos",
    "%{0} daha güçlü": "{0}% más fuerte",
    "%{0} daha zayıf": "{0}% más débil",
    "<h4>Görev özeti</h4><p>ARES-1 Mars'a doğru yola çıkıyor. İnişten sonra hayatta kal, keşfet ve bulgularını Dünya'ya raporla.</p>\n      <dl class=\"ng-dl\"><dt>Fırlatma aracı</dt><dd>{0}</dd><dt>Transfer</dt><dd>{1} · {2} gün</dd><dt>Güç</dt><dd>{3}</dd>\n      <dt>Yaşam desteği</dt><dd>{4}</dd><dt>Gövde</dt><dd>{5}</dd><dt>İletişim</dt><dd>{6}</dd>\n      <dt>Bilim aletleri</dt><dd>{7}</dd><dt>Görev süresi</dt><dd>{8} sol</dd></dl>":
      '<h4>Resumen de la misión</h4><p>ARES-1 va rumbo a Marte. Tras aterrizar, sobrevive, explora e informa de tus hallazgos a la Tierra.</p>\n      <dl class="ng-dl"><dt>Vehículo de lanzamiento</dt><dd>{0}</dd><dt>Transferencia</dt><dd>{1} · {2} días</dd><dt>Energía</dt><dd>{3}</dd>\n      <dt>Soporte vital</dt><dd>{4}</dd><dt>Casco</dt><dd>{5}</dd><dt>Comunicaciones</dt><dd>{6}</dd>\n      <dt>Instrumentos científicos</dt><dd>{7}</dd><dt>Duración de la misión</dt><dd>{8} soles</dd></dl>',
    '<div class="ng-left">\n      <label class="ng-lbl">Görev adı</label><input class="md-in ng-name" id="ngName" maxlength="24" placeholder="ARES-1" value="{0}">\n      <label class="ng-lbl">Zorluk</label>\n      <div class="ng-diffs">{1}</div>\n      <div class="ng-dbox" data-lv="{2}"><p id="ngDesc">{3}</p>\n        <div class="ng-rows">{4}</div>\n      </div>\n      <div class="ng-tg"><span><b>Açılış hikâyesi</b><small>Görev başlamadan önce ARES-1 sinemasını oynat.</small></span><div class="m2-tg {5}" id="ngIntro" role="switch"></div></div>\n    </div>\n    <div class="ng-right">{6}{7}</div>':
      '<div class="ng-left">\n      <label class="ng-lbl">Nombre de la misión</label><input class="md-in ng-name" id="ngName" maxlength="24" placeholder="ARES-1" value="{0}">\n      <label class="ng-lbl">Dificultad</label>\n      <div class="ng-diffs">{1}</div>\n      <div class="ng-dbox" data-lv="{2}"><p id="ngDesc">{3}</p>\n        <div class="ng-rows">{4}</div>\n      </div>\n      <div class="ng-tg"><span><b>Historia de introducción</b><small>Reproducir la cinemática de ARES-1 antes de empezar la misión.</small></span><div class="m2-tg {5}" id="ngIntro" role="switch"></div></div>\n    </div>\n    <div class="ng-right">{6}{7}</div>',
    "Aletlerin ürettiği veri anten kapasitesini aştı; bilimin %{0}'i Dünya'ya ulaşamadı.":
      "Los datos de los instrumentos superaron la capacidad de la antena; el {0} % de la ciencia nunca llegó a la Tierra.",
    "Görev planlanan {0} solu {1} sol aştı: erzak ve bütçe zorlandı.":
      "La misión superó en {1} soles los {0} soles previstos: los suministros y el presupuesto se resintieron.",
    "{0} kez kritik yaşam değeri kaydedildi: oksijen, su veya yiyecek tükenmeye yaklaştı.":
      "Se registró {0} veces un valor vital crítico: el oxígeno, el agua o la comida estuvieron a punto de agotarse.",
    "Bilim hedefinin yarısına ulaşılmadı: daha çok rapor göndermek ve hedefe uygun gözlem yapmak puanı artırır.":
      "No se alcanzó la mitad del objetivo científico: enviar más informes y hacer observaciones acordes con el objetivo sube la puntuación.",
    "Görev başarısı": "Éxito de la misión",
    "Bilim değeri": "Valor científico",
    "Kaynak verimliliği": "Eficiencia de recursos",
    "Zaman yönetimi": "Gestión del tiempo",
    Atla: "Saltar",
    Turkish: "Turco",
    İngilizce: "Inglés",
    Almanca: "Alemán",
    İspanyolca: "Español",
    Genel: "General",
    Ses: "Sonido",
    Görüntü: "Gráficos",
    Arayüz: "Interfaz",
    Erişilebilirlik: "Accesibilidad",
    Kontroller: "Controles",
    Dil: "Idioma",
    Oynanış: "Jugabilidad",
    Zorluk: "Dificultad",
    "Açlık, susuzluk ve oksijen tüketimini; radyasyon, fırtına ve meteor hasarını ve iyileşme hızını belirler.":
      "Determina el consumo de hambre, sed y oxígeno; el daño por radiación, tormentas y meteoritos; y la velocidad de curación.",
    "Etkileşim ipuçları": "Pistas de interacción",
    "Ekranın altındaki “F: topla”, “E: kullan” gibi ipuçlarını göster.":
      "Mostrar pistas como «F: recoger» y «E: usar» en la parte inferior de la pantalla.",
    "Hasar ve kazanç sayıları": "Números de daño y ganancia",
    "Oyuncunun üzerinde beliren +/− sayılarını göster.":
      "Mostrar los números +/− que aparecen sobre el jugador.",
    "Açılış hikâyesi": "Historia de introducción",
    "Her yeni görevde ARES-1 açılış sinemasını oynat.":
      "Reproducir la cinemática de introducción de ARES-1 en cada misión nueva.",
    "Otomatik kayıt": "Guardado automático",
    "Görevi belirli aralıklarla kendiliğinden kaydet.":
      "Guardar la misión automáticamente cada cierto tiempo.",
    Kapalı: "Desactivado",
    "Ses düzeyleri": "Niveles de volumen",
    "Genel ses": "Volumen general",
    Müzik: "Música",
    Efektler: "Efectos",
    "Çapa, toplama, meteor, telsiz ve arayüz sesleri.":
      "Sonidos de azada, recogida, meteoritos, radio e interfaz.",
    "Ortam sesi": "Sonido ambiente",
    "Rüzgâr ve kum fırtınası uğultusu.": "Viento y aullido de la tormenta de arena.",
    "Grafik kalitesi": "Calidad gráfica",
    "Ultra grafik (WebGL)": "Gráficos ultra (WebGL)",
    "Ana menü manzarası ve hikâyedeki gezegenler ekran kartıyla işlenir. Zayıf bilgisayarlarda kapatabilirsin.":
      "El paisaje del menú principal y los planetas de la historia los procesa la tarjeta gráfica. En ordenadores poco potentes puedes desactivarlo.",
    "Parçacık yoğunluğu": "Densidad de partículas",
    "Toz, duman, kıvılcım ve patlama parçacıkları.": "Partículas de polvo, humo, chispas y explosiones.",
    Düşük: "Baja",
    Orta: "Media",
    Yüksek: "Alta",
    "Atmosfer efektleri": "Efectos atmosféricos",
    "Ufuk pusu, süzülen toz perdeleri ve havadaki zerreler.":
      "Bruma en el horizonte, velos de polvo a la deriva y partículas en el aire.",
    "Film greni": "Grano de película",
    "Menü ve hikâyede sinematik gren dokusu.":
      "Textura de grano cinematográfico en el menú y en la historia.",
    Ekran: "Pantalla",
    "FPS sınırı": "Límite de FPS",
    "Ekran yenilemesiyle eşitle.": "Sincronizar con la frecuencia de actualización de la pantalla.",
    "Tam ekran": "Pantalla completa",
    "Arayüz ölçeği": "Escala de la interfaz",
    "Gün kartı, görev kartı, durum barları ve envanter boyutu.":
      "Tamaño de la tarjeta del día, la tarjeta de misión, las barras de estado y el inventario.",
    Küçük: "Pequeña",
    Büyük: "Grande",
    "Harita boyutu": "Tamaño del mapa",
    "Altyazı boyutu": "Tamaño de los subtítulos",
    "Açılış hikâyesindeki altyazılar.": "Subtítulos de la historia de introducción.",
    "Hikâye anları": "Momentos de historia",
    "İlk fırtına, radyasyon, nadir taş gibi anlarda kısa sahne ve iç ses. Kapalıyken yalnızca acil hedef gösterilir.":
      "Escenas cortas y voz interior en momentos clave como la primera tormenta, la radiación o una piedra rara. Desactivado, solo se muestra el objetivo urgente.",
    "Ekran sarsıntısı": "Vibración de pantalla",
    "Meteor, fırtına ve patlamalarda kamera sarsıntısının şiddeti.":
      "Intensidad de la sacudida de cámara con meteoritos, tormentas y explosiones.",
    "Parlamaları azalt": "Reducir destellos",
    "Meteor çarpması ve patlamalardaki beyaz ekran parlamalarını yumuşat.":
      "Suavizar los destellos blancos de pantalla por impactos de meteoritos y explosiones.",
    "Yüksek kontrast": "Alto contraste",
    "Arayüz metinlerini ve panelleri daha belirgin yap.":
      "Hacer más visibles los textos y paneles de la interfaz.",
    Etkin: "Activado",
    '<div class="m2-sec">Klavye</div><div class="m2-keys">':
      '<div class="m2-sec">Teclado</div><div class="m2-keys">',
    Hareket: "Movimiento",
    Koş: "Correr",
    "Etkileşim / rokete gir": "Interactuar / entrar en el cohete",
    "Topla · ek · sula · hasat": "Recoger · plantar · regar · cosechar",
    "Medikit kullan": "Usar botiquín",
    "Rehber kitap": "Guía de campo",
    "Çapayla kaz": "Cavar con la azada",
    "Sol tık": "Clic izquierdo",
    "Eşyayı eline al": "Coger objeto",
    Merdiven: "Escalera",
    Duraklat: "Pausa",
    "Hikâyeyi geç": "Saltar la historia",
    "Space (basılı)": "Espacio (mantener)",
    Harita: "Mapa",
    "sağ üst": "arriba a la derecha",
    '</div>\n      <div class="m2-sec">Dokunmatik</div><div class="m2-keys"><div><span>Hareket</span><kbd>sol joystick</kbd></div><div><span>Eylemler</span><kbd>sağ düğmeler</kbd></div></div>':
      '</div>\n      <div class="m2-sec">Táctil</div><div class="m2-keys"><div><span>Movimiento</span><kbd>joystick izquierdo</kbd></div><div><span>Acciones</span><kbd>botones derechos</kbd></div></div>',
    "ROKET İÇİ": "DENTRO DEL COHETE",
    '<h4>GÖREV DURUMU</h4>\n    <div class="m2-bars">{0}{1}{2}{3}</div>\n    <dl class="m2-kv"><dt>Görev</dt><dd>{4}</dd><dt>Kıyafet</dt><dd>{5}</dd>\n      <dt>Ana motor</dt><dd style="color:{6}">{7}</dd>\n      <dt>Fırtına kalkanı</dt><dd>{8}</dd><dt>Roket boyası</dt><dd>{9}</dd>\n      <dt>Kargo</dt><dd>{10} / {11}</dd><dt>Oynama süresi</dt><dd>{12}</dd></dl>\n    <h4>KAYNAKLAR</h4>\n    <div class="m2-res"><span><img src="{13}">{14}</span><span><img src="{15}">{16}</span><span><i class="ug-au"></i>{17}</span>{18}</div>':
      '<h4>ESTADO DE LA MISIÓN</h4>\n    <div class="m2-bars">{0}{1}{2}{3}</div>\n    <dl class="m2-kv"><dt>Misión</dt><dd>{4}</dd><dt>Traje</dt><dd>{5}</dd>\n      <dt>Motor principal</dt><dd style="color:{6}">{7}</dd>\n      <dt>Escudo antitormentas</dt><dd>{8}</dd><dt>Pintura del cohete</dt><dd>{9}</dd>\n      <dt>Carga</dt><dd>{10} / {11}</dd><dt>Tiempo de juego</dt><dd>{12}</dd></dl>\n    <h4>RECURSOS</h4>\n    <div class="m2-res"><span><img src="{13}">{14}</span><span><img src="{15}">{16}</span><span><i class="ug-au"></i>{17}</span>{18}</div>',
    "Motoru onardın, numuneleri yükledin ve <b>Dünya'ya geri döndün!</b><br><br>":
      "¡Reparaste el motor, cargaste las muestras y <b>volviste a la Tierra!</b><br><br>",
    "⏱ Süre: <b>": "⏱ Tiempo: <b>",
    "🌍 Ziyaret edilen gezegen: <b>": "🌍 Planetas visitados: <b>",
    "📦 Getirilen numune: <b>": "📦 Muestras traídas: <b>",
    "</b><br>📅 Mars'ta geçen gün: <b>": "</b><br>📅 Días en Marte: <b>",
    "📋 Tamamlanan görev: <b>": "📋 Misiones completadas: <b>",
    '<h4 style="margin:6px 0;color:#fff;text-align:left">Görev sonrası analiz</h4><ul class="wr-why">{0}</ul>':
      '<h4 style="margin:6px 0;color:#fff;text-align:left">Análisis posterior a la misión</h4><ul class="wr-why">{0}</ul>',
    "Hava kilidinden dışarı çık — <b>E</b>": "Sal por la esclusa — <b>E</b>",
    "Haritadaki ◆ işaretine yürü": "Camina hasta un marcador ◆ del mapa",
    "Numunenin yanında <b>F</b>'ye bas": "Pulsa <b>F</b> junto a la muestra",
    "Toplam <b>5</b> numune topla": "Recoge <b>5</b> muestras en total",
    "Merdivenden makine dairesine in — <b>S</b>": "Baja a la sala de máquinas — <b>S</b>",
    "<b>ALET SANDIĞI</b> → <b>E</b> → Çapa: <b>Al</b>":
      "<b>CAJA DE HERRAMIENTAS</b> → <b>E</b> → Azada: <b>Coger</b>",
    "Alet sandığından <b>tohum</b> al": "Coge <b>semillas</b> de la caja de herramientas",
    "Dışarıda yere <b>sol tıkla</b> — çapayla kaz":
      "Fuera, haz <b>clic izquierdo</b> en el suelo — cava con la azada",
    "Çukurun yanında <b>F</b> ile tohum ek": "Pulsa <b>F</b> junto al hoyo para sembrar",
    "Su şişesini eline al — alttaki numara tuşu": "Coge la botella de agua — tecla numérica de abajo",
    "<b>F</b> ile iç (ya da roketin mutfağında <b>İç</b>)":
      "Bebe con <b>F</b> (o <b>Beber</b> en la cocina del cohete)",
    "Rokete gir, komuta güvertesine çık": "Entra en el cohete y sube a la cubierta de mando",
    "Soldaki <b>İLETİŞİM</b> masasında <b>E</b>":
      "<b>E</b> en la mesa de <b>COMUNICACIONES</b> de la izquierda",
    "<b>Rapor hazırla</b> → gözlem seç, not yaz → <b>Dünya'ya gönder</b>":
      "<b>Preparar informe</b> → elige observaciones, escribe una nota → <b>Enviar a la Tierra</b>",
    "Turuncu fırtına uyarısını bekle (Gün 2, ": "Espera el aviso naranja de tormenta (Día 2, ",
    "Uyarı çıkınca 45 sn içinde rokete gir": "Cuando aparezca, entra en el cohete en 45 s",
    "Fırtına bitene kadar içeride kal": "Quédate dentro hasta que pase la tormenta",
    "Fırtınanın motoru bozması — duman çıkar": "La tormenta daña el motor — sale humo",
    "4 onarım aşamasını tamamla": "Completa las 4 fases de reparación",
    "Yeşil radyasyon uyarısını bekle (Gün 3)": "Espera el aviso verde de radiación (Día 3)",
    "Dalga geçene kadar içeride kal": "Quédate dentro hasta que pase la ola",
    "Su şişesini eline al, parselin yanında <b>F</b> ile sula":
      "Coge la botella de agua y riega con <b>F</b> junto a la parcela",
    "Halka sarıya dönene kadar bekle": "Espera a que el anillo se vuelva amarillo",
    "Dünya'nın yanıtını bekle (~½ sol)": "Espera la respuesta de la Tierra (~½ sol)",
    "Komuta güvertesi → <b>İLETİŞİM</b> → <b>E</b>": "Cubierta de mando → <b>COMUNICACIONES</b> → <b>E</b>",
    "Gelen kutusu → <b>YANIT</b> etiketli mesajı aç":
      "Bandeja de entrada → abre el mensaje con <b>RESPUESTA</b>",
    "Çürük patates çantanda olsun (hasattan çıkar)": "Ten una patata podrida en la bolsa (de la cosecha)",
    "Çürük patates → <b>Dünya'ya gönder</b>": "Patata podrida → <b>Enviar a la Tierra</b>",
    "Laboratuvar inceliyor — kısa sürede yanıt gelir":
      "El laboratorio la examina — la respuesta llega pronto",
    "Gelen kutusu → <b>ANALİZ</b> mesajı: çürümenin nedeni":
      "Bandeja → mensaje de <b>ANÁLISIS</b>: por qué se pudrió",
    "Alet sandığından <b>radyasyon ölçeri</b> al":
      "Coge el <b>medidor de radiación</b> de la caja de herramientas",
    "Ölçeri eline al — numara tuşu": "Coge el medidor — tecla numérica",
    "Toprağa <b>sol tıkla</b> — 3 farklı yer": "Haz <b>clic izquierdo</b> en el suelo — 3 lugares distintos",
    "Yeşil bayraklı yer bul (1,0 µSv/h altı)": "Busca un sitio con bandera verde (menos de 1,0 µSv/h)",
    "Sula, büyüt ve sağlıklı hasat al": "Riega, deja crecer y obtén una cosecha sana",
    "Meteor düşmesini bekle — uğultu ve gölge": "Espera un meteorito — estruendo y sombra",
    "Kraterin çevresindeki sarı parçaları <b>F</b> ile topla (3)":
      "Recoge con <b>F</b> los trozos amarillos alrededor del cráter (3)",
    "Alet sandığından <b>jeolog kazmasını</b> al":
      "Coge el <b>pico de geólogo</b> de la caja de herramientas",
    "Roketten uzaklaş, haritadaki <b>?</b> işaretine git":
      "Aléjate del cohete y ve al marcador <b>?</b> del mapa",
    "Taşın yanında <b>F</b> — kazmayla 3 vuruşta kır": "<b>F</b> junto a la piedra: rómpela en 3 golpes",
    "Bilinmeyen taşı çapayla çıkar": "Extrae una piedra desconocida con la azada",
    "Rokete gir → komuta güvertesi → <b>Kargo terminali</b>":
      "Entra en el cohete → cubierta de mando → <b>Terminal de carga</b>",
    "<b>ANALİZ İÇİN</b> satırında <b>Analize gönder</b>":
      "En la fila <b>PARA ANÁLISIS</b>, <b>Enviar a analizar</b>",
    "Malzeme topla: 8 metal, 1 ⭐, 2 olivin": "Reúne material: 8 metal, 1 ⭐, 2 olivino",
    "Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b>":
      "Cubierta habitable → <b>TALLER DE FABRICACIÓN</b> → <b>E</b>",
    "Kıyafet setleri → <b>Öncü Mk-II</b> → Üret ve giy": "Trajes → <b>Pionero Mk-II</b> → Fabricar y poner",
    "Malzeme topla: 10 altın, 3 titanyum": "Reúne material: 10 de oro, 3 de titanio",
    "Atölye → <b>Roket geliştirme</b> sekmesi": "Taller → pestaña <b>Mejoras del cohete</b>",
    "<b>Titanyum Plakalar</b> → <b>Kur</b>": "<b>Placas de titanio</b> → <b>Instalar</b>",
    "Kıyafet setleri → <b>Kaşif Mk-I</b> → Üret ve giy": "Trajes → <b>Explorador Mk-I</b> → Fabricar y poner",
    "Roketin yanında <b>F</b> ile kargoya yükle (10)": "Carga en la bodega con <b>F</b> junto al cohete (10)",
    "Komuta güvertesi → <b>NAVİGASYON</b> → <b>E</b>": "Cubierta de mando → <b>NAVEGACIÓN</b> → <b>E</b>",
    "<b>EVE DÖN</b>'e bas": "Pulsa <b>VOLVER A CASA</b>",
    "UYKU KAPSÜLÜ": "CÁPSULA DE SUEÑO",
    "Bu taşı kırmak için <b>jeolog kazması</b> gerekli — makine dairesindeki <b>alet sandığından</b> al":
      "Necesitas el <b>pico de geólogo</b> para romper esta piedra: cógelo de la <b>caja de herramientas</b> de la sala de máquinas",
    "JENERATÖR ARIZALI": "GENERADOR AVERIADO",
    "YAPAY YERÇEKİMİ": "GRAVEDAD ARTIFICIAL",
    "⚠️ <b>Yapay yerçekimi jeneratörü durdu</b> — roketin içi de Mars yerçekiminde (0,38 g). Motoru onarınca geri gelir.":
      "⚠️ <b>Se ha detenido el generador de gravedad artificial</b>: dentro del cohete también hay gravedad marciana (0,38 g). Vuelve al reparar el motor.",
    "✅ Yapay yerçekimi yeniden aktif (1 g)": "✅ Gravedad artificial activa de nuevo (1 g)",
    "🪐 <b>Mars yerçekimi: 0,38 g</b> — adımların seker, durması zordur. <b>Space</b> ile zıpla.":
      "🪐 <b>Gravedad de Marte: 0,38 g</b>: tus pasos rebotan y cuesta frenar. Salta con <b>Espacio</b>.",
    "Uff… Uzun bir uykuydu. ARES-1 yerde, ben de sağ salimim.":
      "Uf… Ha sido un sueño largo. ARES-1 está en tierra y yo estoy sano y salvo.",
    "Burada hayatta kalmalı, Mars'ı araştırmalı ve sonunda eve dönmeliyim.":
      "Tengo que sobrevivir aquí, explorar Marte y, al final, volver a casa.",
    "Önce makine dairesindeki alet sandığından ekipmanımı alayım. Sol üstteki görev kartı yolu gösterir.":
      "Primero cogeré mi equipo de la caja de herramientas de la sala de máquinas. La tarjeta de misión de arriba a la izquierda me guiará.",
    "Bu uğultu da ne?… Rüzgâr bir anda döndü!": "¿Qué es ese rugido?… ¡El viento ha cambiado de golpe!",
    "Kum her yeri yutuyor, önümü göremiyorum… Bu hıza dayanamam.":
      "La arena se lo traga todo, no veo nada… No aguantaré este viento.",
    "Bir dahakine bu rüzgâra dayanmak için atölyede kıyafetimi ve roketimi güçlendirmeliyim.":
      "La próxima vez, para aguantar este viento, debo mejorar mi traje y el cohete en el taller.",
    "Ama şimdi hemen rokete gitmeliyim!": "¡Pero ahora tengo que ir al cohete ya!",
    "Fırtınadan korun — rokete sığın": "Protégete de la tormenta — refúgiate en el cohete",
    "Kapağı son anda kapattım… Gövde zangır zangır titriyor.":
      "Cerré la escotilla en el último segundo… El casco tiembla sin parar.",
    "Dışarıda kalsam rüzgâr beni savururdu. Bir dahakine uyarı kartını görünce erkenden döneceğim.":
      "Fuera, el viento me habría arrastrado. La próxima vez volveré en cuanto vea la tarjeta de aviso.",
    "Gövde zangır zangır titriyor… Dışarıda kum fırtınası kopmuş.":
      "El casco tiembla sin parar… Fuera se ha desatado una tormenta de arena.",
    "İyi ki içerideyim. Fırtına bitene kadar buradan çıkmıyorum.":
      "Menos mal que estoy dentro. No salgo hasta que pase la tormenta.",
    "ARES-1, telemetride ana motor arızası görüyoruz!":
      "¡ARES-1, la telemetría muestra una avería del motor principal!",
    "Fırtına motoru vurmuş… Bu motor olmadan eve dönüş yok.":
      "La tormenta dañó el motor… Sin él no hay regreso a casa.",
    "Fırtına diner dinmez makine dairesine inip onarmalıyım.":
      "En cuanto amaine la tormenta, tengo que bajar a la sala de máquinas y repararlo.",
    "Başım dönüyor… Canım neden bu kadar hızlı azalıyor?":
      "Estoy mareado… ¿Por qué baja tan rápido mi salud?",
    "Dozimetre çıldırmış — güneş patlaması! Bu radyasyon kıyafetimden geçiyor.":
      "¡El dosímetro se ha vuelto loco — una erupción solar! Esta radiación atraviesa mi traje.",
    "Bir dahakine etkilenmemek için atölyede astronot kıyafetimi geliştirmeliyim.":
      "Para que no me afecte la próxima vez, debo mejorar mi traje espacial en el taller.",
    "Şimdilik tek çare roketin kalın gövdesi. Hemen içeri!":
      "Por ahora el único refugio es el grueso casco del cohete. ¡Adentro, ya!",
    "Gövde zırhı radyasyonu kesiyor, değerler düşüyor.":
      "El blindaje del casco frena la radiación, los valores bajan.",
    "Dalga geçene kadar içerideyim. En iyisi uyku kabininde dinlenmek.":
      "Me quedo dentro hasta que pase la ola. Lo mejor es descansar en la cabina de sueño.",
    "Dozimetre bir anda yükseldi… Dışarıda güneş patlaması var.":
      "El dosímetro se disparó de repente… Fuera hay una erupción solar.",
    "Gövde zırhı beni koruyor. Dalga geçene kadar dışarı çıkmayacağım.":
      "El blindaje del casco me protege. No saldré hasta que pase la ola.",
    "Motor yeniden çalışıyor… Ama bir sonraki fırtınada yine bozulabilir.":
      "El motor vuelve a funcionar… Pero la próxima tormenta podría romperlo otra vez.",
    "Atölyedeki roket geliştirmeden gövdeye titanyum zırh takmalıyım. Bunun için altın ve titanyum gerek.":
      "Debo instalar blindaje de titanio en el casco desde las mejoras del cohete del taller. Necesito oro y titanio.",
    "Canım çok hızlı eridi… Bu standart kıyafet radyasyonu durdurmuyor.":
      "Mi salud se esfumó muy rápido… Este traje estándar no frena la radiación.",
    "Atölyede radyasyon katmanlı bir kıyafet üretmeliyim. Bir sonraki dalgaya hazırlıklı olacağım.":
      "Tengo que fabricar un traje con blindaje antirradiación en el taller. Estaré preparado para la próxima ola.",
    "Bu ne?… Patatesler kararmış, yumuşamış.": "¿Qué es esto?… Las patatas se han puesto negras y blandas.",
    "Suyu da verdim, ışığı da aldı. Sorun toprakta olmalı ama bunu burada çözemem.":
      "Les di agua y recibieron luz. Debe ser la tierra, pero aquí no puedo averiguarlo.",
    "Çürük patates çantamda. Rokete dönüp komuta güvertesindeki kargo terminalinden Dünya'ya göndereyim.":
      "La patata podrida está en mi bolsa. Volveré al cohete y la enviaré a la Tierra desde la terminal de carga de la cubierta de mando.",
    "Laboratuvar inceleyip neden çürüdüğünü bana yazar.":
      "El laboratorio la examinará y me dirá por qué se pudrió.",
    "Rokete dön": "Vuelve al cohete",
    "Komuta güvertesine çık — merdivende W": "Sube a la cubierta de mando — W en la escalera",
    "Kargo terminalinde E'ye bas": "Pulsa E en la terminal de carga",
    "Çürük patates → Dünya'ya gönder": "Patata podrida → Enviar a la Tierra",
    "ARES-1, burası Dünya laboratuvarı. Patates numunen elimize ulaştı.":
      "ARES-1, aquí el laboratorio de la Tierra. Tu muestra de patata ha llegado.",
    "Çürümenin nedenini bulduk. Raporu gelen kutuna yolladık, hemen oku.":
      "Hemos encontrado la causa. El informe está en tu bandeja de entrada: léelo ya.",
    "Komuta güvertesi → İLETİŞİM masası → E": "Cubierta de mando → mesa de COMUNICACIONES → E",
    "Gelen kutusu → ANALİZ mesajını aç": "Bandeja → abre el mensaje de ANÁLISIS",
    "Demek sebep toprağın radyasyonuymuş… Mikrop değil.":
      "Así que era la radiación de la tierra… no gérmenes.",
    "Bundan sonra ekmeden önce radyasyon ölçerle toprağı ölçüp yeşil çıkan yere ekeceğim.":
      "A partir de ahora mediré la tierra con el medidor antes de sembrar y solo plantaré donde salga verde.",
    "Aman Allah'ım… Bu taş kendi kendine ışık saçıyor!": "Dios mío… ¡Esta piedra brilla por sí sola!",
    "Böyle bir mineral hiçbir kayıtta yok. İçinde ne var bunun?":
      "No hay ningún mineral así en los registros. ¿Qué tendrá dentro?",
    "Hemen rokete götürüp kargo terminalinden Dünya'ya analize göndermeliyim!":
      "¡Tengo que llevarla al cohete y enviarla a analizar a la Tierra desde la terminal de carga!",
    "Taşı rokete götür": "Lleva la piedra al cohete",
    "Parlayan taş → Analize gönder": "Piedra brillante → Enviar a analizar",
    "Vay… İçinden ışık sızan bir taş! Böylesini hiç görmedim.":
      "Vaya… ¡Una piedra que deja escapar luz! Nunca he visto nada igual.",
    "Çok güzel… ama ne olduğunu bilmeden kullanmamalıyım.":
      "Es preciosa… pero no debería usarla sin saber qué es.",
    "Rokete götürüp kargo terminalinden Dünya'ya analize göndermeliyim. İnceleyip bana bildirsinler.":
      "La llevaré al cohete y la enviaré a analizar a la Tierra desde la terminal de carga. Que la examinen y me lo digan.",
    "Bilinmeyen taş → Analize gönder": "Piedra desconocida → Enviar a analizar",
    "ARES-1, numunen laboratuvara ulaştı. Ona bir ad verdik: ":
      "ARES-1, tu muestra ha llegado al laboratorio. Le hemos puesto nombre: ",
    "Bileşimi, ne kadar tehlikeli olduğu ve ne işe yarayacağı raporda. Gelen kutuna yolladık.":
      "Su composición, lo peligrosa que es y para qué sirve están en el informe. Está en tu bandeja de entrada.",
    "… Demek adı buymuş. Artık bu taşı tanıyorum.": "… Así que se llama así. Ahora conozco esta piedra.",
    "Haritada da adıyla görünüyor. Başka bilinmeyen taş bulursam onları da kırıp göndereceğim.":
      "Ahora también aparece con su nombre en el mapa. Si encuentro más piedras desconocidas, también las romperé y enviaré.",
    "ARES-1, gönderdiğin parlayan taşın analizi bitti.":
      "ARES-1, el análisis de la piedra brillante que enviaste ha terminado.",
    "Ekip şaşkın — sonuçlar gelen kutunda. Okumadan o taşa dokunma!":
      "El equipo está asombrado: los resultados están en tu bandeja. ¡No toques esa piedra sin leerlos!",
    "Gelen kutusu → Ares taşı analizini aç": "Bandeja → abre el análisis de la piedra Ares",
    "ARES-1, görevlerin tamam. Dünya'ya dönüş penceresi açıldı.":
      "ARES-1, tus misiones están completas. La ventana de regreso a la Tierra está abierta.",
    "Eve dönme zamanı… Komuta güvertesinde navigasyonu açıp EVE DÖN'e basacağım.":
      "Hora de volver a casa… Abriré la navegación en la cubierta de mando y pulsaré VOLVER A CASA.",
    "Navigasyondan EVE DÖN": "Pulsa VOLVER A CASA en navegación",
    Devam: "Continuar",
    "GÖREV KONTROL · TELSİZ": "CONTROL DE MISIÓN · RADIO",
    "KOMUTAN · İÇ SES": "COMANDANTE · VOZ INTERIOR",
    "ACİL HEDEF": "OBJETIVO URGENTE",
    "ACİL HEDEF · ": "OBJETIVO URGENTE · ",
    "⏸ GÖREV BEKLEMEDE · ÖNCE ACİL HEDEF": "⏸ MISIÓN EN ESPERA · PRIMERO EL OBJETIVO URGENTE",
    "Bayrak kaldırıldı. Ölçtüğün yerleri istediğin zaman temizleyebilirsin.":
      "Bandera quitada. Puedes limpiar los puntos medidos cuando quieras.",
    "🌅 Gün ": "🌅 Día ",
    " başladı": " ha comenzado",
    "Bitkin düştün, revire taşındın.": "Te desplomaste de agotamiento y te llevaron a la enfermería.",
    "🌲 Mahsul hazır! (F ile hasat)": "🌲 ¡Cosecha lista! (cosecha con F)",
    "SİNYAL ZAYIF": "SEÑAL DÉBIL",
    "HARİTA · ": "MAPA · ",
    "Ekim için uygun": "Apto para plantar",
    "Patates çürür": "Las patatas se pudren",
    YÜKSEK: "ALTO",
    "Patatesler çürümüş!": "¡Las patatas se han podrido!",
    "Patatesler çürük çıktı, bir tanesi çantanda. Roketteki <b>kargo terminalinden</b> Dünya'ya gönder, incelesinler.":
      "Las patatas han salido podridas; tienes una en la mochila. Envíala a la Tierra desde el <b>terminal de carga</b> del cohete para que la examinen.",
    "Bu toprak radyasyonlu, patatesler yine çürüdü. Ekmeden önce radyasyon ölçerle ölç":
      "Este suelo es radiactivo y las patatas se han vuelto a pudrir. Mide con el medidor de radiación antes de plantar",
    "Patatesler yine çürüdü": "Las patatas se han vuelto a pudrir",
    "Çok uzak — ölçmek istediğin yere biraz yaklaş":
      "Demasiado lejos: acércate un poco al punto que quieres medir",
    "İniş platformu metal — ölçümü toprak üzerinde yap":
      "La plataforma de aterrizaje es metálica: mide sobre el suelo",
    "<b>Güvenli toprak</b> (": "<b>Suelo seguro</b> (",
    " µSv/h) — buraya kazıp patates ekebilirsin. Yeşil bayrak yeri işaretliyor.":
      " µSv/h): puedes cavar aquí y plantar patatas. La bandera verde marca el lugar.",
    "Bu toprakta patates çürür (": "En este suelo las patatas se pudren (",
    " µSv/h). <b>1,0 µSv/h altını</b> ara — biraz uzaklaşıp yeniden ölç.":
      " µSv/h). Busca <b>menos de 1,0 µSv/h</b>: aléjate un poco y vuelve a medir.",
    "Toprağı ölçmek için <b>radyasyon ölçeri</b> makine dairesindeki <b>alet sandığından</b> al.":
      "Para medir el suelo, coge el <b>medidor de radiación</b> de la <b>caja de herramientas</b> de la sala de máquinas.",
    "Prob toprağa hizalanıyor…": "Alineando la sonda con el suelo…",
    "Ölçülüyor… <b>%{0}</b>": "Midiendo… <b>{0} %</b>",
    '<span class="rd-vd"><b>RADYASYON {0}</b><small>{1} µSv/h · {2}</small></span>':
      '<span class="rd-vd"><b>RADIACIÓN {0}</b><small>{1} µSv/h · {2}</small></span>',
    '<p>Komutan,</p>\n  <p>Gönderdiğin çürük patatesi inceledik. Mikrop ya da aşırı sulama izi yok. Neden <b>toprağın radyasyonu</b>: patatesin ekildiği yer yüksek radyasyonlu.</p>\n  <div class="ltr-dir"><b>NE YAPMALI?</b><ol>\n    <li>Roketteki alet sandığından <b>radyasyon ölçeri</b> al.</li>\n    <li>Ekmeden önce toprağı ölç: ölçeri eline al ve toprağa <b>sol tıkla</b>.</li>\n    <li>Ekranda <b>RADYASYON NORMAL</b> yazan yere ek. Yüksek çıkan yerde patates çürür.</li></ol></div>\n  <div class="ltr-scale"><span style="flex:1;background:#4ade80">0 – 1,0 NORMAL</span><span style="flex:1;background:#fbbf24">1,0 – 2,0 DİKKAT</span><span style="flex:1;background:#ff5d5d">2,0+ YÜKSEK</span></div>':
      '<p>Comandante:</p>\n  <p>Hemos examinado la patata podrida que enviaste. No hay rastro de microbios ni de exceso de riego. La causa es la <b>radiación del suelo</b>: el lugar donde se plantó tiene mucha radiación.</p>\n  <div class="ltr-dir"><b>¿QUÉ HACER?</b><ol>\n    <li>Coge el <b>medidor de radiación</b> de la caja de herramientas del cohete.</li>\n    <li>Mide el suelo antes de plantar: sostén el medidor y haz <b>clic izquierdo</b> en el suelo.</li>\n    <li>Planta donde la pantalla muestre <b>RADIACIÓN NORMAL</b>. Donde sea alta, las patatas se pudren.</li></ol></div>\n  <div class="ltr-scale"><span style="flex:1;background:#4ade80">0 – 1,0 NORMAL</span><span style="flex:1;background:#fbbf24">1,0 – 2,0 PRECAUCIÓN</span><span style="flex:1;background:#ff5d5d">2,0+ ALTO</span></div>',
    "Çürük patates analizi": "Análisis de la patata podrida",
    "Önceki kargo hâlâ inceleniyor — Dünya'nın cevabını bekle":
      "La carga anterior aún se está examinando: espera la respuesta de la Tierra",
    "Çantanda çürük patates yok": "No tienes ninguna patata podrida",
    "Çürük patates kargoyla Dünya'ya gönderildi. Cevap birazdan gelen kutunda.":
      "Patata podrida enviada a la Tierra por carga. La respuesta llegará pronto a tu bandeja.",
    "Mars yüzey görevi": "Misión en la superficie de Marte",
    "Mars'ta hayatta kal · keşfet · Dünya'ya raporla": "Sobrevive en Marte · explora · informa a la Tierra",
    "Oyuna Başla": "Empezar partida",
    "Yeni görev · açılış hikâyesiyle": "Nueva misión · con la historia de introducción",
    "Devam Et": "Continuar",
    Kaydedilenler: "Partidas guardadas",
    "Görev kayıtlarını yükle ya da sil": "Cargar o borrar partidas guardadas",
    Ayarlar: "Ajustes",
    "Ses, görüntü ve performans": "Sonido, gráficos y rendimiento",
    "hareket ·": "moverse ·",
    koş: "correr",
    "etkileşim / rokete gir": "interactuar / entrar en el cohete",
    "topla · ek · sula · hasat": "recoger · plantar · regar · cosechar",
    medikit: "botiquín",
    "çapayla kaz": "cavar con la azada",
    "eşyayı eline al": "coger objeto",
    "rehber kitap": "guía de campo",
    duraklat: "pausa",
    "Görev Kontrol bağlantısı: AKTİF": "Enlace con Control de Misión: ACTIVO",
    Geç: "Saltar",
    "basılı tut ·": "(mantener) ·",
    "ARES-1 · ARŞİV": "ARES-1 · ARCHIVO",
    "ARES-1 · SİSTEM": "ARES-1 · SISTEMA",
    "Varsayılana döndür": "Restablecer valores predeterminados",
    "ARES-1 · GÖREV DURAKLATILDI": "ARES-1 · MISIÓN EN PAUSA",
    Duraklatıldı: "En pausa",
    "Göreve geri dön · Esc": "Volver a la misión · Esc",
    Kaydet: "Guardar",
    "Görevin şu anki durumunu kaydet": "Guardar el estado actual de la misión",
    "Tehlikeler, sistemler ve ipuçları · R": "Peligros, sistemas y consejos · R",
    "Dil, zorluk, ses, görüntü, arayüz": "Idioma, dificultad, sonido, gráficos, interfaz",
    "Ana menüye dön": "Volver al menú principal",
    "Kaydedilmemiş ilerleme kaybolur": "Se perderá el progreso no guardado",
    "ARES-1 · KAYIT": "ARES-1 · GUARDADO",
    "Kaydı adlandır": "Nombra tu partida",
    Vazgeç: "Cancelar",
    "ARES-1 · DİL": "ARES-1 · IDIOMA",
    "Dil değiştiriliyor": "Cambiando el idioma",
    "Dil değişikliğinin uygulanması için oyun yeniden başlatılacak. Görevin otomatik olarak kaydedilecek.":
      "El juego se reiniciará para aplicar el cambio de idioma. Tu misión se guardará automáticamente.",
    "Uygula ve yeniden başlat": "Aplicar y reiniciar",
    "Navigasyon Bilgisayarı": "Ordenador de navegación",
    Rota: "Ruta",
    kapat: "cerrar",
    "Tedarik & Ticaret": "Suministros y comercio",
    "Erzak deposu": "Almacén de suministros",
    "📦 Kargo bölmesi · Dünya'ya götürülecek numuneler":
      "📦 Bodega de carga · muestras para llevar a la Tierra",
    "Numuneleri yükle": "Cargar muestras",
    "Uyku Kabini": "Cabina de descanso",
    "Yataktan kalk": "Levantarse de la cama",
    kalk: "levantarse",
    "UYKUDA ZAMAN 2×": "TIEMPO 2× AL DORMIR",
    "Kapat (R)": "Cerrar (R)",
    Kapsül: "Cápsula",
    İçerik: "Contenido",
    "kapat · Al = çantaya · Koy =": "cerrar · Coger = a la bolsa · Dejar = a la",
    "Fabrikasyon Atölyesi": "Taller de Fabricación",
    "3B üretim ünitesi · EVA donanımı ve araç modifikasyonu":
      "Unidad de fabricación 3D · equipo de EVA y modificación del vehículo",
    "🧑‍🚀 Kıyafet setleri": "🧑‍🚀 Conjuntos de traje",
    "🚀 Roket geliştirme": "🚀 Mejoras del cohete",
    "kapat · kıyafet: metal + kristal + olivin · roket: altın + titanyum · en üst seviye: Ares taşı":
      "cerrar · traje: metal + cristal + olivino · cohete: oro + titanio · nivel máximo: piedra de Ares",
    "ARES-1 · MODİFİKASYON": "ARES-1 · MODIFICACIÓN",
    "İletişim Terminali · Dünya": "Terminal de comunicaciones · Tierra",
    "Komuta güvertesi · yüksek kazançlı anten · yer istasyonu ağı":
      "Cubierta de mando · antena de alta ganancia · red de estaciones terrestres",
    "🛰️ Yer Birimi": "🛰️ Segmento terrestre",
    "📐 Görev Mimarisi": "📐 Arquitectura de la misión",
    "kapat · yanıtlar ~½ sol (ACİL ~¼ sol) sonra gelir":
      "cerrar · las respuestas llegan tras ~½ sol (URGENTE ~¼ sol)",
    "ARES-1 · GÖREV KONTROL HATTI": "ARES-1 · LÍNEA CON CONTROL DE MISIÓN",
    "Ana Motor · Onarım": "Motor principal · Reparación",
    "Makine dairesi · ARES-1 itki çekirdeği": "Sala de máquinas · núcleo de propulsión de ARES-1",
    "AŞAMA 1/4": "FASE 1/4",
    "çık · tamamlanan aşamalar kaydedilir": "salir · las fases completadas se guardan",
    "Yeni görev": "Nueva misión",
    İptal: "Cancelar",
    "Görevi başlat": "Empezar misión",
    "RADYASYON ÖLÇER": "MEDIDOR DE RADIACIÓN",
    "Dünyaya Hoş Geldin!": "¡Bienvenido a la Tierra!",
    "Oyuna Devam Et": "Seguir jugando",
    "Ana Menüye Dön": "Volver al menú principal",
    "GÖREV 1/8": "MISIÓN 1/8",
    Görev: "Misión",
    VÜCUT: "CUERPO",
    NABIZ: "PULSO",
    YERÇEKİMİ: "GRAVEDAD",
    RADYASYON: "RADIACIÓN",
    "MARS'A ULAŞILDI": "MARTE ALCANZADO",
    "MERIDIANI PLANUM · 1,95° G · 5,53° B": "MERIDIANI PLANUM · 1,95° S · 5,53° O",
    "ARES-1, iniş doğrulandı. Mars'a hoş geldin, Komutan.":
      "ARES-1, aterrizaje confirmado. Bienvenido a Marte, comandante.",
    "Kayıt adı": "Nombre de la partida",
    "Kapat (E)": "Cerrar (E)",
    "Kalk (E)": "Levantarse (E)",
    "Önceki (←)": "Anterior (←)",
    "Sonraki (→)": "Siguiente (→)",
    "Çık (E)": "Salir (E)",
    '<h2><small>Bölüm 5</small>Tarım {0}</h2>\n    <ol><li>Alet sandığından {1} <b>çapayı</b> al. Çapayı eline al ve yere <b>sol tıkla</b>.</li>\n    <li>{2} <b>Tohumu</b> eline al, çukurun yanında <kbd>F</kbd>.</li>\n    <li>{3} <b>Suyu</b> eline al, <kbd>F</kbd> ile sula. Islak toprak bitkiyi 2,4 kat hızlı büyütür.</li>\n    <li>Halka <b>sarı</b> olunca <kbd>F</kbd> ile hasat et: 1–2 patates + 1 tohumluk patates. Çürük hasattan tohum çıkmaz.</li></ol>\n    <p>Büyümesi sulamadan yaklaşık 75 saniye sürer. Bitki aşamaları: filiz → fide → çiçekli bitki → hasat.</p>\n    <div class="warn">Kum fırtınasında bitkiler sallanır ama zarar görmez. Parselleri roketin yakınına aç ki fırtınada kaybolmayasın.</div>':
      '<h2><small>Capítulo 5</small>Cultivo {0}</h2>\n    <ol><li>Coge la {1} <b>azada</b> de la caja de herramientas. Sostén la azada y haz <b>clic izquierdo</b> en el suelo.</li>\n    <li>Sostén una {2} <b>semilla</b> y pulsa <kbd>F</kbd> junto al hoyo.</li>\n    <li>Sostén el {3} <b>agua</b> y riega con <kbd>F</kbd>. En tierra húmeda la planta crece 2,4 veces más rápido.</li>\n    <li>Cuando el anillo se vuelva <b>amarillo</b>, cosecha con <kbd>F</kbd>: 1–2 patatas + 1 patata de siembra. Una cosecha podrida no da semilla.</li></ol>\n    <p>Sin riego tarda unos 75 segundos en crecer. Fases de la planta: brote → plántula → planta en flor → cosecha.</p>\n    <div class="warn">Durante una tormenta de arena las plantas se balancean, pero no sufren daños. Cava tus parcelas cerca del cohete para no perderte en una tormenta.</div>',
  },
};
(function () {
  const X = {
    en: {
      "KENDİNE GELDİN": "YOU CAME TO",
      "UYKU KAPSÜLÜ · YAŞAM GÜVERTESİ": "SLEEP POD · HABITATION DECK",
      "ARES-1, yaşam değerlerin kritik seviyeye düştü. Kapsülde kendine geldin. Önce yemek, su ve oksijeni toparla.":
        "ARES-1, your vital signs dropped to a critical level. You came to in the pod. Restore food, water and oxygen first.",
      "😵 Bilincini kaybettin, uyku kapsülünde kendine geldin. Kendine dikkat et!":
        "😵 You passed out and came to in the sleep pod. Take care of yourself!",
      "Ekili parselin üstüne kapatılır · radyasyon dalgasından korur":
        "Placed over a planted plot · protects from radiation waves",
      "Seramik kalkan": "Ceramic shield",
      "🛡️ Seramik kalkan": "🛡️ Ceramic shield",
      "Seramik kalkan ekili parsele takılır — önce tohum ek":
        "The ceramic shield goes on a planted plot — plant a seed first",
      "Bu parsel zaten seramik kalkanla korunuyor": "This plot is already protected by a ceramic shield",
      "Seramik kalkan yok — roketteki alet sandığından al":
        "No ceramic shield — take one from the rocket's tool chest",
      "🛡️ Kalkan takıldı": "🛡️ Shield fitted",
      "🛡️ Seramik kalkan radyasyon dalgasını keser. Hasatta kalkan çantana geri döner.":
        "🛡️ The ceramic shield blocks radiation waves. At harvest the shield returns to your bag.",
      "+1 🛡️ kalkan geri alındı": "+1 🛡️ shield recovered",
      "Kalkanı takmak için ekili bir parsele tıkla": "Click a planted plot to fit the shield",
      "Seramik kalkan dışarıda, ekili parselin üstüne takılır":
        "The ceramic shield is fitted outside, over a planted plot",
      "Ekili bir parselin yakınına git": "Go near a planted plot",
      "<b>F</b>: Seramik kalkanı tak · radyasyondan korur":
        "<b>F</b>: Fit ceramic shield · protects from radiation",
      "☢️ Bitki radyasyondan zarar görüyor — seramik kalkanı eline al ve <b>F</b>":
        "☢️ The plant is taking radiation damage — hold the ceramic shield and press <b>F</b>",
      "🌱 {0} parsel açıkta — seramik kalkanı olmayan bitkiler radyasyondan zarar görüyor":
        "🌱 {0} plot(s) exposed — plants without a ceramic shield take radiation damage",
      '<div class="warn"><b>Seramik kalkan:</b> Radyasyon dalgasında açıkta kalan bitkiler büyümesini kaybeder. Alet sandığındaki seramik kalkanı eline al ve ekili parselin yanında <kbd>F</kbd>\'ye bas. Hasatta kalkan çantana geri döner.</div>':
        '<div class="warn"><b>Ceramic shield:</b> During a radiation wave, exposed plants lose their growth. Hold the ceramic shield from the tool chest and press <kbd>F</kbd> next to a planted plot. At harvest the shield returns to your bag.</div>',
      "  ·  <b>Q</b>: kalkanı kapat": "  ·  <b>Q</b>: close shield",
      "  ·  <b>Q</b>: kalkanı kapat  ·  <b>Shift+Q</b>: sök":
        "  ·  <b>Q</b>: close shield  ·  <b>Shift+Q</b>: remove",
      " · <b>Q</b>: aç": " · <b>Q</b>: open",
      "+1 🛡️ kalkan söküldü": "+1 🛡️ shield removed",
      "<b>F</b> ile hasat et": "Harvest with <b>F</b>",
      "<b>F</b>: Seramik kalkanı kur · <b>Q</b> ile açılıp kapanır":
        "<b>F</b>: Install ceramic shield · opens and closes with <b>Q</b>",
      "<b>Q</b> ile kalkanı aç": "Open the shield with <b>Q</b>",
      "<b>Q</b> ile yeniden kapat": "Close it again with <b>Q</b>",
      '<div class="warn"><b>Seramik kalkan:</b> Radyasyon dalgasında açıkta kalan bitkiler büyümesini kaybeder. Alet sandığındaki kalkanı eline al, parselin yanında <kbd>F</kbd> ile kur. <kbd>Q</kbd> kanatları açar/kapatır: kapalıyken bitki korunur ama sulayamaz, hasat edemezsin. Kalkan parselde kalır; boş parselden <kbd>Shift+Q</kbd> ile sökülür.</div>':
        '<div class="warn"><b>Ceramic shield:</b> During a radiation wave, exposed plants lose their growth. Hold the shield from the tool chest and install it next to a plot with <kbd>F</kbd>. <kbd>Q</kbd> opens/closes the panels: closed, the plant is protected but you cannot water or harvest. The shield stays on the plot; remove it from an empty plot with <kbd>Shift+Q</kbd>.</div>',
      "ARES-1, burası uzay hava durumu birimi. Güneşte büyük bir patlama gördük!":
        "ARES-1, this is the space weather unit. We just saw a major solar flare!",
      "Alet sandığında seramik kalkanlar vardı. Parselin üstüne kurup kapatırsam bitki korunur.":
        "There were ceramic shields in the tool chest. If I install one over the plot and close it, the plant will be safe.",
      "Alet sandığından <b>seramik kalkanı</b> al. Dışarıda eline al, ekili parselin yanında <b>F</b>. Kalkan kurulunca kendiliğinden kapanır.":
        "Take the <b>ceramic shield</b> from the tool chest. Outside, hold it and press <b>F</b> next to the planted plot. Once installed, the shield closes by itself.",
      "Ama burada güneş patlamaları var. Radyasyon dalgası gelince bu filiz kavrulur.":
        "But there are solar flares here. When a radiation wave hits, this sprout will be scorched.",
      "Ama radyasyon gelirken mutlaka kapalı olmalı. Bunu unutmamalıyım.":
        "But when radiation comes it must be closed. I must not forget that.",
      "Anlaşıldı. Önce kalkanlar, sonra ben.": "Copy that. Shields first, then me.",
      "Açıkta kalan bitki kavrulmuş, büyümesi geriye gitti.":
        "The exposed plant got scorched; its growth went backwards.",
      "Bir dahakine dalga gelmeden kalkanı Q ile kapatmalıyım.":
        "Next time I must close the shield with Q before the wave arrives.",
      "Bir parselin yakınına git": "Go near a plot",
      "Bitkin kalkanın altında olsun, kalkan kapalı": "Keep your plant under the shield, shield closed",
      "Bitkin radyasyon dalgasını <b>kapalı kalkanın altında</b> atlatsın":
        "Let your plant survive a radiation wave <b>under a closed shield</b>",
      "Boş parseldeki kalkanı sök": "Remove shield from empty plot",
      "Bu parselde zaten seramik kalkan var · <b>Q</b> ile aç/kapat":
        "This plot already has a ceramic shield · open/close with <b>Q</b>",
      "Dalga boyunca kalkanı kapalı tut — sen de rokete sığın":
        "Keep the shield closed during the wave — and take shelter in the rocket",
      "Dalga gelmeden kalkanı <b>Q</b> ile kapat. Kapalı kalkan dalgayı keser; açık kalan bitki büyümesini kaybeder.":
        "Close the shield with <b>Q</b> before the wave. A closed shield blocks it; an exposed plant loses its growth.",
      "Dalga geçti… Kalkanın altındaki bitki sapasağlam!":
        "The wave has passed… The plant under the shield is perfectly fine!",
      "Dışarıda kalkanı eline al — numara tuşu": "Outside, hold the shield — number key",
      "Ekili parselin yanında <b>F</b> — kalkan kurulur ve kapanır":
        "<b>F</b> next to the planted plot — the shield installs and closes",
      "Ektiğin tohumun üstüne <b>seramik kalkan</b> kur":
        "Install a <b>ceramic shield</b> over your planted seed",
      "Halka sarı olunca kalkanı <b>Q</b> ile aç, <b>F</b> ile hasat et. Kalkan parselde kalır: yeniden ek ve <b>Q</b> ile kapat.":
        "When the ring turns yellow, open the shield with <b>Q</b> and harvest with <b>F</b>. The shield stays on the plot: replant and close with <b>Q</b>.",
      "Halka sarıya dönene kadar bekle (sulamak hızlandırır)":
        "Wait until the ring turns yellow (watering speeds it up)",
      "Kalkan Kontrolü": "Shield Control",
      "Kalkan yalnızca boş parselden sökülür — önce hasat et":
        "A shield can only be removed from an empty plot — harvest first",
      "Kalkan yerine oturdu. Servolar çalışıyor, kanatlar kendiliğinden kapandı.":
        "The shield is in place. The servos are running and the panels closed on their own.",
      "Kalkanlı parselin yanına git": "Go to the shielded plot",
      "Kalkanlı parselin yanında <b>Q</b>: kanatlar açılır. Açıkken sulayıp hasat edebilirsin ama bitki korunmaz. Tekrar <b>Q</b> ile kapat.":
        "Next to the shielded plot press <b>Q</b>: the panels open. While open you can water and harvest, but the plant is unprotected. Close again with <b>Q</b>.",
      "Kalkanı <b>Q</b> ile aç": "Open the shield with <b>Q</b>",
      "Kalkanı <b>Q</b> ile aç ve yeniden kapat": "Open the shield with <b>Q</b> and close it again",
      "Kalkanı kurmak için bir parselin yanına git": "Go next to a plot to install the shield",
      "Kapalıyken içeri elim yetişmez. Sulamak ya da hasat için Q ile açmam gerek.":
        "When it is closed I cannot reach inside. To water or harvest I have to open it with Q.",
      "Koruma Altında": "Under Protection",
      "Parsele kurulur · Q ile açılıp kapanır · kapalıyken radyasyondan korur":
        "Installed on a plot · opens and closes with Q · protects from radiation when closed",
      "Patatesi büyüt, kalkanı aç ve <b>hasat et</b>": "Grow the potato, open the shield and <b>harvest</b>",
      "Patatesler olgunlaşmış ama kalkan kapalı, içeri uzanamıyorum.":
        "The potatoes are ripe but the shield is closed; I cannot reach inside.",
      "Q ile kalkanı açıp hasat edeyim. Sonra yeniden ekip kapatırım.":
        "I will open the shield with Q and harvest. Then I will replant and close it.",
      "Radyasyon dalgası birazdan yüzeye ulaşacak. Seramik kalkanlarını kapat, sonra hemen rokete gir.":
        "The radiation wave will reach the surface soon. Close your ceramic shields, then get into the rocket immediately.",
      "Rokete gir → makine dairesi → <b>ALET SANDIĞI</b>":
        "Enter the rocket → engine room → <b>TOOL CHEST</b>",
      "Seramik Kalkan": "Ceramic Shield",
      "Seramik kalkan: <b>Al</b>": "Ceramic shield: <b>Take</b>",
      "Seramik kalkanı aç / kapat": "Open / close ceramic shield",
      "seramik kalkanı aç/kapat": "open/close ceramic shield",
      "Seramik radyasyonu kesiyor. Dünya'daki mühendislere teşekkür borçluyum.":
        "The ceramic blocks the radiation. I owe the engineers on Earth a thank-you.",
      "Yakında seramik kalkan yok — kalkanlı bir parselin yanına git":
        "No ceramic shield nearby — go next to a shielded plot",
      "Yeşil radyasyon uyarısını bekle (her 3 günde bir)":
        "Wait for the green radiation warning (every 3 days)",
      "İlk tohum toprakta… Mars'ta filiz görmek tuhaf olacak.":
        "The first seed is in the ground… Seeing a sprout on Mars will be strange.",
      "☢️ Dikkat! Radyasyon dalgası sürüyor — açık kalkan bitkiyi korumaz":
        "☢️ Careful! The radiation wave is still on — an open shield does not protect the plant",
      "☢️ Radyasyon! Bitki zarar görüyor — <b>Q</b> ile kalkanı kapat":
        "☢️ Radiation! The plant is taking damage — close the shield with <b>Q</b>",
      "🌱 Ekildi — şimdi <b>Q</b> ile kalkanı kapat": "🌱 Planted — now close the shield with <b>Q</b>",
      "🌲 Mahsul hazır! Kalkan kapalı — <b>Q</b> ile aç, <b>F</b> ile hasat":
        "🌲 Crop ready! Shield closed — open with <b>Q</b>, harvest with <b>F</b>",
      "📡 Görev Kontrol: radyasyon dalgası yaklaşıyor — seramik kalkanlarını kapat!":
        "📡 Mission Control: radiation wave incoming — close your ceramic shields!",
      "🔒 Kalkan kapalı · <b>Q</b>: aç ve tohum ek": "🔒 Shield closed · <b>Q</b>: open and plant",
      "🔒 Kalkan kapalı — patatese ulaşmak için <b>Q</b> ile aç":
        "🔒 Shield closed — open with <b>Q</b> to reach the potatoes",
      "🔒 Kalkan kapalı — sulamak için <b>Q</b> ile aç": "🔒 Shield closed — open with <b>Q</b> to water",
      "🔒 Kalkan kapalı — tohum ekmek için önce <b>Q</b> ile aç":
        "🔒 Shield closed — open with <b>Q</b> first to plant",
      "🔒 Kalkan kapalı — önce <b>Q</b> ile aç": "🔒 Shield closed — open with <b>Q</b> first",
      "🔒 Kalkan kapanıyor": "🔒 Shield closing",
      "🔒 Patatesler hazır ama kalkan kapalı · <b>Q</b>: aç":
        "🔒 Potatoes ready but shield closed · <b>Q</b>: open",
      "🔓 Kalkan açıkken sulayıp hasat edebilirsin. Radyasyon gelmeden <b>Q</b> ile kapatmayı unutma.":
        "🔓 With the shield open you can water and harvest. Remember to close it with <b>Q</b> before radiation comes.",
      "🔓 Kalkan açılıyor": "🔓 Shield opening",
      "🛡️ Kalkan açılıyor…": "🛡️ Shield opening…",
      "🛡️ Kalkan kapalı · korunuyor · büyüyor %": "🛡️ Shield closed · protected · growing %",
      "🛡️ Kalkan kapanıyor — içerideki bitki artık radyasyondan korunuyor":
        "🛡️ Shield closing — the plant inside is now protected from radiation",
      "🛡️ Kalkan kapanıyor…": "🛡️ Shield closing…",
      "🛡️ Kalkan kuruldu": "🛡️ Shield installed",
      "🛡️ Kalkan kuruldu. Tohumu ek, sonra <b>Q</b> ile kapat.":
        "🛡️ Shield installed. Plant the seed, then close it with <b>Q</b>.",
      "Tohumluk patates": "Seed potato",
      "🥔 Tohumluk patates": "🥔 Seed potato",
      tohumluk: "seed potato",
      "🥔 Tohumluk patatesi eline aldın — ekmek için tekrar <b>F</b>":
        "🥔 You picked up the seed potato — press <b>F</b> again to plant",
      "Tohum yok — roketteki alet sandığından al ya da sağlıklı hasat yap":
        "No seeds — take some from the rocket's tool chest or get a healthy harvest",
      "🥔 Hasattan <b>1 tohumluk patates</b> çıktı — filizli gözleriyle yeniden ekilebilir":
        "🥔 The harvest gave <b>1 seed potato</b> — its sprouting eyes can be planted again",
      "🥀 Çürük yumrudan tohum çıkmaz — tohumu kaybettin":
        "🥀 A rotten tuber gives no seed — you lost the seed",
      "Seramik kalkan da burada işe yaramaz: yalnızca gökten gelen dalgayı keser, topraktaki radyasyonu değil.":
        "The ceramic shield won't help here either: it only blocks the wave from the sky, not the radiation in the soil.",
    },
    de: {
      "KENDİNE GELDİN": "DU BIST WIEDER BEI BEWUSSTSEIN",
      "UYKU KAPSÜLÜ · YAŞAM GÜVERTESİ": "SCHLAFKAPSEL · WOHNDECK",
      "ARES-1, yaşam değerlerin kritik seviyeye düştü. Kapsülde kendine geldin. Önce yemek, su ve oksijeni toparla.":
        "ARES-1, deine Vitalwerte sind kritisch gefallen. Du bist in der Kapsel aufgewacht. Kümmere dich zuerst um Nahrung, Wasser und Sauerstoff.",
      "😵 Bilincini kaybettin, uyku kapsülünde kendine geldin. Kendine dikkat et!":
        "😵 Du bist ohnmächtig geworden und in der Schlafkapsel aufgewacht. Pass auf dich auf!",
      "Ekili parselin üstüne kapatılır · radyasyon dalgasından korur":
        "Wird über ein bepflanztes Beet gesetzt · schützt vor Strahlungswellen",
      "Seramik kalkan": "Keramikschild",
      "🛡️ Seramik kalkan": "🛡️ Keramikschild",
      "Seramik kalkan ekili parsele takılır — önce tohum ek":
        "Der Keramikschild kommt auf ein bepflanztes Beet — säe zuerst",
      "Bu parsel zaten seramik kalkanla korunuyor":
        "Dieses Beet ist bereits durch einen Keramikschild geschützt",
      "Seramik kalkan yok — roketteki alet sandığından al":
        "Kein Keramikschild — nimm einen aus der Werkzeugkiste der Rakete",
      "🛡️ Kalkan takıldı": "🛡️ Schild angebracht",
      "🛡️ Seramik kalkan radyasyon dalgasını keser. Hasatta kalkan çantana geri döner.":
        "🛡️ Der Keramikschild blockt Strahlungswellen. Bei der Ernte kommt der Schild zurück in deine Tasche.",
      "+1 🛡️ kalkan geri alındı": "+1 🛡️ Schild zurück",
      "Kalkanı takmak için ekili bir parsele tıkla":
        "Klicke auf ein bepflanztes Beet, um den Schild anzubringen",
      "Seramik kalkan dışarıda, ekili parselin üstüne takılır":
        "Der Keramikschild wird draußen über ein bepflanztes Beet gesetzt",
      "Ekili bir parselin yakınına git": "Geh zu einem bepflanzten Beet",
      "<b>F</b>: Seramik kalkanı tak · radyasyondan korur":
        "<b>F</b>: Keramikschild anbringen · schützt vor Strahlung",
      "☢️ Bitki radyasyondan zarar görüyor — seramik kalkanı eline al ve <b>F</b>":
        "☢️ Die Pflanze nimmt Strahlenschaden — nimm den Keramikschild und drücke <b>F</b>",
      "🌱 {0} parsel açıkta — seramik kalkanı olmayan bitkiler radyasyondan zarar görüyor":
        "🌱 {0} Beet(e) ungeschützt — Pflanzen ohne Keramikschild nehmen Strahlenschaden",
      '<div class="warn"><b>Seramik kalkan:</b> Radyasyon dalgasında açıkta kalan bitkiler büyümesini kaybeder. Alet sandığındaki seramik kalkanı eline al ve ekili parselin yanında <kbd>F</kbd>\'ye bas. Hasatta kalkan çantana geri döner.</div>':
        '<div class="warn"><b>Keramikschild:</b> Während einer Strahlungswelle verlieren ungeschützte Pflanzen ihr Wachstum. Nimm den Keramikschild aus der Werkzeugkiste und drücke <kbd>F</kbd> neben einem bepflanzten Beet. Bei der Ernte kommt der Schild zurück in deine Tasche.</div>',
      "  ·  <b>Q</b>: kalkanı kapat": "  ·  <b>Q</b>: Schild schließen",
      "  ·  <b>Q</b>: kalkanı kapat  ·  <b>Shift+Q</b>: sök":
        "  ·  <b>Q</b>: Schild schließen  ·  <b>Shift+Q</b>: abbauen",
      " · <b>Q</b>: aç": " · <b>Q</b>: öffnen",
      "+1 🛡️ kalkan söküldü": "+1 🛡️ Schild abgebaut",
      "<b>F</b> ile hasat et": "Mit <b>F</b> ernten",
      "<b>F</b>: Seramik kalkanı kur · <b>Q</b> ile açılıp kapanır":
        "<b>F</b>: Keramikschild aufbauen · mit <b>Q</b> öffnen/schließen",
      "<b>Q</b> ile kalkanı aç": "Öffne den Schild mit <b>Q</b>",
      "<b>Q</b> ile yeniden kapat": "Mit <b>Q</b> wieder schließen",
      '<div class="warn"><b>Seramik kalkan:</b> Radyasyon dalgasında açıkta kalan bitkiler büyümesini kaybeder. Alet sandığındaki kalkanı eline al, parselin yanında <kbd>F</kbd> ile kur. <kbd>Q</kbd> kanatları açar/kapatır: kapalıyken bitki korunur ama sulayamaz, hasat edemezsin. Kalkan parselde kalır; boş parselden <kbd>Shift+Q</kbd> ile sökülür.</div>':
        '<div class="warn"><b>Keramikschild:</b> Während einer Strahlungswelle verlieren ungeschützte Pflanzen ihr Wachstum. Nimm den Schild aus der Werkzeugkiste und baue ihn neben einem Beet mit <kbd>F</kbd> auf. <kbd>Q</kbd> öffnet/schließt die Flügel: Geschlossen ist die Pflanze geschützt, aber du kannst weder gießen noch ernten. Der Schild bleibt am Beet; von einem leeren Beet baust du ihn mit <kbd>Shift+Q</kbd> ab.</div>',
      "ARES-1, burası uzay hava durumu birimi. Güneşte büyük bir patlama gördük!":
        "ARES-1, hier ist die Weltraumwetter-Einheit. Wir haben eine große Sonneneruption gesehen!",
      "Alet sandığında seramik kalkanlar vardı. Parselin üstüne kurup kapatırsam bitki korunur.":
        "In der Werkzeugkiste waren Keramikschilde. Wenn ich einen über dem Beet aufbaue und schließe, ist die Pflanze geschützt.",
      "Alet sandığından <b>seramik kalkanı</b> al. Dışarıda eline al, ekili parselin yanında <b>F</b>. Kalkan kurulunca kendiliğinden kapanır.":
        "Nimm den <b>Keramikschild</b> aus der Werkzeugkiste. Halte ihn draußen und drücke <b>F</b> neben dem bepflanzten Beet. Nach dem Aufbau schließt er sich von selbst.",
      "Ama burada güneş patlamaları var. Radyasyon dalgası gelince bu filiz kavrulur.":
        "Aber hier gibt es Sonneneruptionen. Kommt eine Strahlungswelle, verbrennt dieser Keim.",
      "Ama radyasyon gelirken mutlaka kapalı olmalı. Bunu unutmamalıyım.":
        "Aber wenn Strahlung kommt, muss er geschlossen sein. Das darf ich nicht vergessen.",
      "Anlaşıldı. Önce kalkanlar, sonra ben.": "Verstanden. Erst die Schilde, dann ich.",
      "Açıkta kalan bitki kavrulmuş, büyümesi geriye gitti.":
        "Die ungeschützte Pflanze ist verbrannt, ihr Wachstum ging zurück.",
      "Bir dahakine dalga gelmeden kalkanı Q ile kapatmalıyım.":
        "Nächstes Mal muss ich den Schild vor der Welle mit Q schließen.",
      "Bir parselin yakınına git": "Geh zu einem Beet",
      "Bitkin kalkanın altında olsun, kalkan kapalı": "Deine Pflanze unter dem Schild, Schild geschlossen",
      "Bitkin radyasyon dalgasını <b>kapalı kalkanın altında</b> atlatsın":
        "Lass deine Pflanze eine Strahlungswelle <b>unter geschlossenem Schild</b> überstehen",
      "Boş parseldeki kalkanı sök": "Schild von leerem Beet abbauen",
      "Bu parselde zaten seramik kalkan var · <b>Q</b> ile aç/kapat":
        "Dieses Beet hat bereits einen Keramikschild · mit <b>Q</b> öffnen/schließen",
      "Dalga boyunca kalkanı kapalı tut — sen de rokete sığın":
        "Halte den Schild während der Welle geschlossen — und flüchte in die Rakete",
      "Dalga gelmeden kalkanı <b>Q</b> ile kapat. Kapalı kalkan dalgayı keser; açık kalan bitki büyümesini kaybeder.":
        "Schließe den Schild vor der Welle mit <b>Q</b>. Ein geschlossener Schild blockt sie; eine ungeschützte Pflanze verliert Wachstum.",
      "Dalga geçti… Kalkanın altındaki bitki sapasağlam!":
        "Die Welle ist vorbei… Die Pflanze unter dem Schild ist kerngesund!",
      "Dışarıda kalkanı eline al — numara tuşu": "Draußen den Schild in die Hand nehmen — Zifferntaste",
      "Ekili parselin yanında <b>F</b> — kalkan kurulur ve kapanır":
        "<b>F</b> neben dem bepflanzten Beet — der Schild wird aufgebaut und schließt sich",
      "Ektiğin tohumun üstüne <b>seramik kalkan</b> kur":
        "Baue einen <b>Keramikschild</b> über deinem Saatgut auf",
      "Halka sarı olunca kalkanı <b>Q</b> ile aç, <b>F</b> ile hasat et. Kalkan parselde kalır: yeniden ek ve <b>Q</b> ile kapat.":
        "Wenn der Ring gelb wird, öffne den Schild mit <b>Q</b> und ernte mit <b>F</b>. Der Schild bleibt am Beet: neu säen und mit <b>Q</b> schließen.",
      "Halka sarıya dönene kadar bekle (sulamak hızlandırır)":
        "Warte, bis der Ring gelb wird (Gießen beschleunigt)",
      "Kalkan Kontrolü": "Schildsteuerung",
      "Kalkan yalnızca boş parselden sökülür — önce hasat et":
        "Der Schild lässt sich nur von einem leeren Beet abbauen — erst ernten",
      "Kalkan yerine oturdu. Servolar çalışıyor, kanatlar kendiliğinden kapandı.":
        "Der Schild sitzt. Die Servos laufen, die Flügel haben sich von selbst geschlossen.",
      "Kalkanlı parselin yanına git": "Geh zum Beet mit Schild",
      "Kalkanlı parselin yanında <b>Q</b>: kanatlar açılır. Açıkken sulayıp hasat edebilirsin ama bitki korunmaz. Tekrar <b>Q</b> ile kapat.":
        "Neben dem Beet mit Schild <b>Q</b>: Die Flügel öffnen sich. Offen kannst du gießen und ernten, aber die Pflanze ist ungeschützt. Mit <b>Q</b> wieder schließen.",
      "Kalkanı <b>Q</b> ile aç": "Öffne den Schild mit <b>Q</b>",
      "Kalkanı <b>Q</b> ile aç ve yeniden kapat": "Öffne den Schild mit <b>Q</b> und schließe ihn wieder",
      "Kalkanı kurmak için bir parselin yanına git": "Geh zu einem Beet, um den Schild aufzubauen",
      "Kapalıyken içeri elim yetişmez. Sulamak ya da hasat için Q ile açmam gerek.":
        "Geschlossen komme ich nicht hinein. Zum Gießen oder Ernten muss ich ihn mit Q öffnen.",
      "Koruma Altında": "Unter Schutz",
      "Parsele kurulur · Q ile açılıp kapanır · kapalıyken radyasyondan korur":
        "Wird auf einem Beet aufgebaut · mit Q öffnen/schließen · schützt geschlossen vor Strahlung",
      "Patatesi büyüt, kalkanı aç ve <b>hasat et</b>":
        "Lass die Kartoffel wachsen, öffne den Schild und <b>ernte</b>",
      "Patatesler olgunlaşmış ama kalkan kapalı, içeri uzanamıyorum.":
        "Die Kartoffeln sind reif, aber der Schild ist zu; ich komme nicht hinein.",
      "Q ile kalkanı açıp hasat edeyim. Sonra yeniden ekip kapatırım.":
        "Ich öffne den Schild mit Q und ernte. Dann säe ich neu und schließe ihn.",
      "Radyasyon dalgası birazdan yüzeye ulaşacak. Seramik kalkanlarını kapat, sonra hemen rokete gir.":
        "Die Strahlungswelle erreicht gleich die Oberfläche. Schließe deine Keramikschilde und geh sofort in die Rakete.",
      "Rokete gir → makine dairesi → <b>ALET SANDIĞI</b>":
        "Betritt die Rakete → Maschinenraum → <b>WERKZEUGKISTE</b>",
      "Seramik Kalkan": "Keramikschild",
      "Seramik kalkan: <b>Al</b>": "Keramikschild: <b>Nehmen</b>",
      "Seramik kalkanı aç / kapat": "Keramikschild öffnen / schließen",
      "seramik kalkanı aç/kapat": "Keramikschild öffnen/schließen",
      "Seramik radyasyonu kesiyor. Dünya'daki mühendislere teşekkür borçluyum.":
        "Die Keramik blockt die Strahlung. Ich schulde den Ingenieuren auf der Erde Dank.",
      "Yakında seramik kalkan yok — kalkanlı bir parselin yanına git":
        "Kein Keramikschild in der Nähe — geh zu einem Beet mit Schild",
      "Yeşil radyasyon uyarısını bekle (her 3 günde bir)":
        "Warte auf die grüne Strahlungswarnung (alle 3 Tage)",
      "İlk tohum toprakta… Mars'ta filiz görmek tuhaf olacak.":
        "Der erste Samen ist in der Erde… Einen Keim auf dem Mars zu sehen, wird seltsam sein.",
      "☢️ Dikkat! Radyasyon dalgası sürüyor — açık kalkan bitkiyi korumaz":
        "☢️ Achtung! Die Strahlungswelle läuft noch — ein offener Schild schützt die Pflanze nicht",
      "☢️ Radyasyon! Bitki zarar görüyor — <b>Q</b> ile kalkanı kapat":
        "☢️ Strahlung! Die Pflanze nimmt Schaden — schließe den Schild mit <b>Q</b>",
      "🌱 Ekildi — şimdi <b>Q</b> ile kalkanı kapat": "🌱 Gesät — schließe jetzt den Schild mit <b>Q</b>",
      "🌲 Mahsul hazır! Kalkan kapalı — <b>Q</b> ile aç, <b>F</b> ile hasat":
        "🌲 Ernte bereit! Schild geschlossen — mit <b>Q</b> öffnen, mit <b>F</b> ernten",
      "📡 Görev Kontrol: radyasyon dalgası yaklaşıyor — seramik kalkanlarını kapat!":
        "📡 Missionskontrolle: Strahlungswelle naht — schließe deine Keramikschilde!",
      "🔒 Kalkan kapalı · <b>Q</b>: aç ve tohum ek": "🔒 Schild geschlossen · <b>Q</b>: öffnen und säen",
      "🔒 Kalkan kapalı — patatese ulaşmak için <b>Q</b> ile aç":
        "🔒 Schild geschlossen — mit <b>Q</b> öffnen, um an die Kartoffeln zu kommen",
      "🔒 Kalkan kapalı — sulamak için <b>Q</b> ile aç":
        "🔒 Schild geschlossen — zum Gießen mit <b>Q</b> öffnen",
      "🔒 Kalkan kapalı — tohum ekmek için önce <b>Q</b> ile aç":
        "🔒 Schild geschlossen — zum Säen erst mit <b>Q</b> öffnen",
      "🔒 Kalkan kapalı — önce <b>Q</b> ile aç": "🔒 Schild geschlossen — erst mit <b>Q</b> öffnen",
      "🔒 Kalkan kapanıyor": "🔒 Schild schließt",
      "🔒 Patatesler hazır ama kalkan kapalı · <b>Q</b>: aç":
        "🔒 Kartoffeln reif, aber Schild zu · <b>Q</b>: öffnen",
      "🔓 Kalkan açıkken sulayıp hasat edebilirsin. Radyasyon gelmeden <b>Q</b> ile kapatmayı unutma.":
        "🔓 Bei offenem Schild kannst du gießen und ernten. Vergiss nicht, ihn vor der Strahlung mit <b>Q</b> zu schließen.",
      "🔓 Kalkan açılıyor": "🔓 Schild öffnet",
      "🛡️ Kalkan açılıyor…": "🛡️ Schild öffnet…",
      "🛡️ Kalkan kapalı · korunuyor · büyüyor %": "🛡️ Schild zu · geschützt · wächst %",
      "🛡️ Kalkan kapanıyor — içerideki bitki artık radyasyondan korunuyor":
        "🛡️ Schild schließt — die Pflanze darin ist jetzt vor Strahlung geschützt",
      "🛡️ Kalkan kapanıyor…": "🛡️ Schild schließt…",
      "🛡️ Kalkan kuruldu": "🛡️ Schild aufgebaut",
      "🛡️ Kalkan kuruldu. Tohumu ek, sonra <b>Q</b> ile kapat.":
        "🛡️ Schild aufgebaut. Säe, dann mit <b>Q</b> schließen.",
      "Tohumluk patates": "Saatkartoffel",
      "🥔 Tohumluk patates": "🥔 Saatkartoffel",
      tohumluk: "Saatkartoffel",
      "🥔 Tohumluk patatesi eline aldın — ekmek için tekrar <b>F</b>":
        "🥔 Du hältst die Saatkartoffel — drücke erneut <b>F</b> zum Pflanzen",
      "Tohum yok — roketteki alet sandığından al ya da sağlıklı hasat yap":
        "Kein Saatgut — nimm welches aus der Werkzeugkiste der Rakete oder ernte gesund",
      "🥔 Hasattan <b>1 tohumluk patates</b> çıktı — filizli gözleriyle yeniden ekilebilir":
        "🥔 Die Ernte brachte <b>1 Saatkartoffel</b> — mit ihren Keimaugen kann sie neu gepflanzt werden",
      "🥀 Çürük yumrudan tohum çıkmaz — tohumu kaybettin":
        "🥀 Aus einer faulen Knolle gibt es kein Saatgut — der Samen ist verloren",
      "Seramik kalkan da burada işe yaramaz: yalnızca gökten gelen dalgayı keser, topraktaki radyasyonu değil.":
        "Der Keramikschild hilft hier auch nicht: Er blockt nur die Welle von oben, nicht die Strahlung im Boden.",
    },
    es: {
      "KENDİNE GELDİN": "HAS RECUPERADO EL SENTIDO",
      "UYKU KAPSÜLÜ · YAŞAM GÜVERTESİ": "CÁPSULA DE SUEÑO · CUBIERTA HABITABLE",
      "ARES-1, yaşam değerlerin kritik seviyeye düştü. Kapsülde kendine geldin. Önce yemek, su ve oksijeni toparla.":
        "ARES-1, tus constantes vitales cayeron a un nivel crítico. Has despertado en la cápsula. Recupera primero comida, agua y oxígeno.",
      "😵 Bilincini kaybettin, uyku kapsülünde kendine geldin. Kendine dikkat et!":
        "😵 Te desmayaste y despertaste en la cápsula de sueño. ¡Cuídate!",
      "Ekili parselin üstüne kapatılır · radyasyon dalgasından korur":
        "Se coloca sobre una parcela sembrada · protege de las ondas de radiación",
      "Seramik kalkan": "Escudo cerámico",
      "🛡️ Seramik kalkan": "🛡️ Escudo cerámico",
      "Seramik kalkan ekili parsele takılır — önce tohum ek":
        "El escudo cerámico va sobre una parcela sembrada — siembra primero",
      "Bu parsel zaten seramik kalkanla korunuyor": "Esta parcela ya está protegida por un escudo cerámico",
      "Seramik kalkan yok — roketteki alet sandığından al":
        "No tienes escudo cerámico — cógelo del cofre de herramientas del cohete",
      "🛡️ Kalkan takıldı": "🛡️ Escudo colocado",
      "🛡️ Seramik kalkan radyasyon dalgasını keser. Hasatta kalkan çantana geri döner.":
        "🛡️ El escudo cerámico bloquea las ondas de radiación. Al cosechar, el escudo vuelve a tu mochila.",
      "+1 🛡️ kalkan geri alındı": "+1 🛡️ escudo recuperado",
      "Kalkanı takmak için ekili bir parsele tıkla":
        "Haz clic en una parcela sembrada para colocar el escudo",
      "Seramik kalkan dışarıda, ekili parselin üstüne takılır":
        "El escudo cerámico se coloca fuera, sobre una parcela sembrada",
      "Ekili bir parselin yakınına git": "Acércate a una parcela sembrada",
      "<b>F</b>: Seramik kalkanı tak · radyasyondan korur":
        "<b>F</b>: Colocar escudo cerámico · protege de la radiación",
      "☢️ Bitki radyasyondan zarar görüyor — seramik kalkanı eline al ve <b>F</b>":
        "☢️ La planta sufre daño por radiación — toma el escudo cerámico y pulsa <b>F</b>",
      "🌱 {0} parsel açıkta — seramik kalkanı olmayan bitkiler radyasyondan zarar görüyor":
        "🌱 {0} parcela(s) expuesta(s) — las plantas sin escudo cerámico sufren daño por radiación",
      '<div class="warn"><b>Seramik kalkan:</b> Radyasyon dalgasında açıkta kalan bitkiler büyümesini kaybeder. Alet sandığındaki seramik kalkanı eline al ve ekili parselin yanında <kbd>F</kbd>\'ye bas. Hasatta kalkan çantana geri döner.</div>':
        '<div class="warn"><b>Escudo cerámico:</b> Durante una onda de radiación, las plantas expuestas pierden su crecimiento. Toma el escudo cerámico del cofre de herramientas y pulsa <kbd>F</kbd> junto a una parcela sembrada. Al cosechar, el escudo vuelve a tu mochila.</div>',
      "  ·  <b>Q</b>: kalkanı kapat": "  ·  <b>Q</b>: cerrar escudo",
      "  ·  <b>Q</b>: kalkanı kapat  ·  <b>Shift+Q</b>: sök":
        "  ·  <b>Q</b>: cerrar escudo  ·  <b>Shift+Q</b>: quitar",
      " · <b>Q</b>: aç": " · <b>Q</b>: abrir",
      "+1 🛡️ kalkan söküldü": "+1 🛡️ escudo retirado",
      "<b>F</b> ile hasat et": "Cosecha con <b>F</b>",
      "<b>F</b>: Seramik kalkanı kur · <b>Q</b> ile açılıp kapanır":
        "<b>F</b>: Instalar escudo cerámico · se abre y cierra con <b>Q</b>",
      "<b>Q</b> ile kalkanı aç": "Abre el escudo con <b>Q</b>",
      "<b>Q</b> ile yeniden kapat": "Ciérralo de nuevo con <b>Q</b>",
      '<div class="warn"><b>Seramik kalkan:</b> Radyasyon dalgasında açıkta kalan bitkiler büyümesini kaybeder. Alet sandığındaki kalkanı eline al, parselin yanında <kbd>F</kbd> ile kur. <kbd>Q</kbd> kanatları açar/kapatır: kapalıyken bitki korunur ama sulayamaz, hasat edemezsin. Kalkan parselde kalır; boş parselden <kbd>Shift+Q</kbd> ile sökülür.</div>':
        '<div class="warn"><b>Escudo cerámico:</b> Durante una onda de radiación, las plantas expuestas pierden su crecimiento. Toma el escudo del cofre de herramientas e instálalo junto a una parcela con <kbd>F</kbd>. <kbd>Q</kbd> abre/cierra las alas: cerrado, la planta está protegida pero no puedes regar ni cosechar. El escudo se queda en la parcela; se quita de una parcela vacía con <kbd>Shift+Q</kbd>.</div>',
      "ARES-1, burası uzay hava durumu birimi. Güneşte büyük bir patlama gördük!":
        "ARES-1, aquí la unidad de meteorología espacial. ¡Hemos visto una gran erupción solar!",
      "Alet sandığında seramik kalkanlar vardı. Parselin üstüne kurup kapatırsam bitki korunur.":
        "En el cofre de herramientas había escudos cerámicos. Si instalo uno sobre la parcela y lo cierro, la planta estará a salvo.",
      "Alet sandığından <b>seramik kalkanı</b> al. Dışarıda eline al, ekili parselin yanında <b>F</b>. Kalkan kurulunca kendiliğinden kapanır.":
        "Toma el <b>escudo cerámico</b> del cofre de herramientas. Fuera, sostenlo y pulsa <b>F</b> junto a la parcela sembrada. Una vez instalado, se cierra solo.",
      "Ama burada güneş patlamaları var. Radyasyon dalgası gelince bu filiz kavrulur.":
        "Pero aquí hay erupciones solares. Cuando llegue una onda de radiación, este brote se quemará.",
      "Ama radyasyon gelirken mutlaka kapalı olmalı. Bunu unutmamalıyım.":
        "Pero cuando llegue la radiación debe estar cerrado. No debo olvidarlo.",
      "Anlaşıldı. Önce kalkanlar, sonra ben.": "Entendido. Primero los escudos, luego yo.",
      "Açıkta kalan bitki kavrulmuş, büyümesi geriye gitti.":
        "La planta expuesta se ha quemado; su crecimiento ha retrocedido.",
      "Bir dahakine dalga gelmeden kalkanı Q ile kapatmalıyım.":
        "La próxima vez debo cerrar el escudo con Q antes de que llegue la onda.",
      "Bir parselin yakınına git": "Acércate a una parcela",
      "Bitkin kalkanın altında olsun, kalkan kapalı": "Ten tu planta bajo el escudo, escudo cerrado",
      "Bitkin radyasyon dalgasını <b>kapalı kalkanın altında</b> atlatsın":
        "Que tu planta supere una onda de radiación <b>bajo un escudo cerrado</b>",
      "Boş parseldeki kalkanı sök": "Quitar escudo de una parcela vacía",
      "Bu parselde zaten seramik kalkan var · <b>Q</b> ile aç/kapat":
        "Esta parcela ya tiene escudo cerámico · ábrelo/ciérralo con <b>Q</b>",
      "Dalga boyunca kalkanı kapalı tut — sen de rokete sığın":
        "Mantén el escudo cerrado durante la onda — y refúgiate en el cohete",
      "Dalga gelmeden kalkanı <b>Q</b> ile kapat. Kapalı kalkan dalgayı keser; açık kalan bitki büyümesini kaybeder.":
        "Cierra el escudo con <b>Q</b> antes de la onda. Un escudo cerrado la bloquea; una planta expuesta pierde crecimiento.",
      "Dalga geçti… Kalkanın altındaki bitki sapasağlam!":
        "La onda ha pasado… ¡La planta bajo el escudo está intacta!",
      "Dışarıda kalkanı eline al — numara tuşu": "Fuera, sostén el escudo — tecla numérica",
      "Ekili parselin yanında <b>F</b> — kalkan kurulur ve kapanır":
        "<b>F</b> junto a la parcela sembrada — el escudo se instala y se cierra",
      "Ektiğin tohumun üstüne <b>seramik kalkan</b> kur":
        "Instala un <b>escudo cerámico</b> sobre tu semilla",
      "Halka sarı olunca kalkanı <b>Q</b> ile aç, <b>F</b> ile hasat et. Kalkan parselde kalır: yeniden ek ve <b>Q</b> ile kapat.":
        "Cuando el anillo se ponga amarillo, abre el escudo con <b>Q</b> y cosecha con <b>F</b>. El escudo se queda: vuelve a sembrar y cierra con <b>Q</b>.",
      "Halka sarıya dönene kadar bekle (sulamak hızlandırır)":
        "Espera a que el anillo se ponga amarillo (regar acelera)",
      "Kalkan Kontrolü": "Control del escudo",
      "Kalkan yalnızca boş parselden sökülür — önce hasat et":
        "El escudo solo se quita de una parcela vacía — cosecha primero",
      "Kalkan yerine oturdu. Servolar çalışıyor, kanatlar kendiliğinden kapandı.":
        "El escudo está en su sitio. Los servos funcionan y las alas se cerraron solas.",
      "Kalkanlı parselin yanına git": "Ve a la parcela con escudo",
      "Kalkanlı parselin yanında <b>Q</b>: kanatlar açılır. Açıkken sulayıp hasat edebilirsin ama bitki korunmaz. Tekrar <b>Q</b> ile kapat.":
        "Junto a la parcela con escudo pulsa <b>Q</b>: las alas se abren. Abierto puedes regar y cosechar, pero la planta queda desprotegida. Ciérralo otra vez con <b>Q</b>.",
      "Kalkanı <b>Q</b> ile aç": "Abre el escudo con <b>Q</b>",
      "Kalkanı <b>Q</b> ile aç ve yeniden kapat": "Abre el escudo con <b>Q</b> y vuelve a cerrarlo",
      "Kalkanı kurmak için bir parselin yanına git": "Acércate a una parcela para instalar el escudo",
      "Kapalıyken içeri elim yetişmez. Sulamak ya da hasat için Q ile açmam gerek.":
        "Cerrado no alcanzo el interior. Para regar o cosechar tengo que abrirlo con Q.",
      "Koruma Altında": "Bajo protección",
      "Parsele kurulur · Q ile açılıp kapanır · kapalıyken radyasyondan korur":
        "Se instala en una parcela · se abre y cierra con Q · cerrado protege de la radiación",
      "Patatesi büyüt, kalkanı aç ve <b>hasat et</b>":
        "Haz crecer la patata, abre el escudo y <b>cosecha</b>",
      "Patatesler olgunlaşmış ama kalkan kapalı, içeri uzanamıyorum.":
        "Las patatas están maduras pero el escudo está cerrado; no alcanzo el interior.",
      "Q ile kalkanı açıp hasat edeyim. Sonra yeniden ekip kapatırım.":
        "Abriré el escudo con Q y cosecharé. Luego volveré a sembrar y lo cerraré.",
      "Radyasyon dalgası birazdan yüzeye ulaşacak. Seramik kalkanlarını kapat, sonra hemen rokete gir.":
        "La onda de radiación llegará pronto a la superficie. Cierra tus escudos cerámicos y entra en el cohete de inmediato.",
      "Rokete gir → makine dairesi → <b>ALET SANDIĞI</b>":
        "Entra al cohete → sala de máquinas → <b>COFRE DE HERRAMIENTAS</b>",
      "Seramik Kalkan": "Escudo cerámico",
      "Seramik kalkan: <b>Al</b>": "Escudo cerámico: <b>Coger</b>",
      "Seramik kalkanı aç / kapat": "Abrir / cerrar escudo cerámico",
      "seramik kalkanı aç/kapat": "abrir/cerrar escudo cerámico",
      "Seramik radyasyonu kesiyor. Dünya'daki mühendislere teşekkür borçluyum.":
        "La cerámica bloquea la radiación. Les debo un agradecimiento a los ingenieros de la Tierra.",
      "Yakında seramik kalkan yok — kalkanlı bir parselin yanına git":
        "No hay escudo cerámico cerca — acércate a una parcela con escudo",
      "Yeşil radyasyon uyarısını bekle (her 3 günde bir)": "Espera el aviso verde de radiación (cada 3 días)",
      "İlk tohum toprakta… Mars'ta filiz görmek tuhaf olacak.":
        "La primera semilla está en la tierra… Será raro ver un brote en Marte.",
      "☢️ Dikkat! Radyasyon dalgası sürüyor — açık kalkan bitkiyi korumaz":
        "☢️ ¡Cuidado! La onda de radiación sigue — un escudo abierto no protege la planta",
      "☢️ Radyasyon! Bitki zarar görüyor — <b>Q</b> ile kalkanı kapat":
        "☢️ ¡Radiación! La planta sufre daño — cierra el escudo con <b>Q</b>",
      "🌱 Ekildi — şimdi <b>Q</b> ile kalkanı kapat": "🌱 Sembrado — ahora cierra el escudo con <b>Q</b>",
      "🌲 Mahsul hazır! Kalkan kapalı — <b>Q</b> ile aç, <b>F</b> ile hasat":
        "🌲 ¡Cosecha lista! Escudo cerrado — abre con <b>Q</b>, cosecha con <b>F</b>",
      "📡 Görev Kontrol: radyasyon dalgası yaklaşıyor — seramik kalkanlarını kapat!":
        "📡 Control de Misión: se acerca una onda de radiación — ¡cierra tus escudos cerámicos!",
      "🔒 Kalkan kapalı · <b>Q</b>: aç ve tohum ek": "🔒 Escudo cerrado · <b>Q</b>: abrir y sembrar",
      "🔒 Kalkan kapalı — patatese ulaşmak için <b>Q</b> ile aç":
        "🔒 Escudo cerrado — ábrelo con <b>Q</b> para llegar a las patatas",
      "🔒 Kalkan kapalı — sulamak için <b>Q</b> ile aç": "🔒 Escudo cerrado — ábrelo con <b>Q</b> para regar",
      "🔒 Kalkan kapalı — tohum ekmek için önce <b>Q</b> ile aç":
        "🔒 Escudo cerrado — ábrelo primero con <b>Q</b> para sembrar",
      "🔒 Kalkan kapalı — önce <b>Q</b> ile aç": "🔒 Escudo cerrado — ábrelo primero con <b>Q</b>",
      "🔒 Kalkan kapanıyor": "🔒 Escudo cerrándose",
      "🔒 Patatesler hazır ama kalkan kapalı · <b>Q</b>: aç":
        "🔒 Patatas listas pero escudo cerrado · <b>Q</b>: abrir",
      "🔓 Kalkan açıkken sulayıp hasat edebilirsin. Radyasyon gelmeden <b>Q</b> ile kapatmayı unutma.":
        "🔓 Con el escudo abierto puedes regar y cosechar. No olvides cerrarlo con <b>Q</b> antes de la radiación.",
      "🔓 Kalkan açılıyor": "🔓 Escudo abriéndose",
      "🛡️ Kalkan açılıyor…": "🛡️ Escudo abriéndose…",
      "🛡️ Kalkan kapalı · korunuyor · büyüyor %": "🛡️ Escudo cerrado · protegida · creciendo %",
      "🛡️ Kalkan kapanıyor — içerideki bitki artık radyasyondan korunuyor":
        "🛡️ Escudo cerrándose — la planta interior ya está protegida de la radiación",
      "🛡️ Kalkan kapanıyor…": "🛡️ Escudo cerrándose…",
      "🛡️ Kalkan kuruldu": "🛡️ Escudo instalado",
      "🛡️ Kalkan kuruldu. Tohumu ek, sonra <b>Q</b> ile kapat.":
        "🛡️ Escudo instalado. Siembra y luego ciérralo con <b>Q</b>.",
      "Tohumluk patates": "Patata de siembra",
      "🥔 Tohumluk patates": "🥔 Patata de siembra",
      tohumluk: "patata de siembra",
      "🥔 Tohumluk patatesi eline aldın — ekmek için tekrar <b>F</b>":
        "🥔 Tienes la patata de siembra — pulsa <b>F</b> otra vez para plantar",
      "Tohum yok — roketteki alet sandığından al ya da sağlıklı hasat yap":
        "Sin semillas — cógelas del cofre de herramientas del cohete o haz una cosecha sana",
      "🥔 Hasattan <b>1 tohumluk patates</b> çıktı — filizli gözleriyle yeniden ekilebilir":
        "🥔 La cosecha dio <b>1 patata de siembra</b> — sus ojos brotados se pueden volver a plantar",
      "🥀 Çürük yumrudan tohum çıkmaz — tohumu kaybettin":
        "🥀 Un tubérculo podrido no da semilla — has perdido la semilla",
      "Seramik kalkan da burada işe yaramaz: yalnızca gökten gelen dalgayı keser, topraktaki radyasyonu değil.":
        "El escudo cerámico tampoco sirve aquí: solo bloquea la onda que llega del cielo, no la radiación del suelo.",
    },
  };
  for (const l in X) if (I18N_DATA[l]) Object.assign(I18N_DATA[l], X[l]);
})();
