/* ek çeviriler: seramik kalkan + bayılma */
/* ============== ÇOK DİLLİ DESTEK (TR · EN · DE · ES) ==============
   Kaynak metinler Türkçedir; derleme sırasında T()/Tf() ile sarılır.
   Dil değişikliği sayfa yeniden yüklenerek uygulanır. */
const LANG = (() => {
  try {
    const s = JSON.parse(localStorage.getItem("uzay_oyunu_settings_v1"));
    return (s && s.lang) || "tr";
  } catch (e) {
    return "tr";
  }
})();
const LOCALE = { tr: "tr-TR", en: "en-US", de: "de-DE", es: "es-ES" }[LANG] || "tr-TR";
const I18N_D = LANG !== "tr" ? I18N_DATA[LANG] || {} : null;
function T(s) {
  if (!I18N_D) return s;
  const r = I18N_D[s];
  return r == null ? s : r;
}
function Tf(s, a) {
  return T(s).replace(/\{(\d+)\}/g, (m, i) => {
    const v = a[+i];
    return v == null ? "" : v;
  });
}
const PF = LANG === "tr" ? (t) => t : (t) => t.replace(/%(\d+(?:[.,]\d+)?)/g, "$1%");
const I18N_UI = {
  tr: {
    t: "Dil değiştiriliyor",
    m: "Dil değişikliğinin uygulanması için oyun yeniden başlatılacak. Görevin otomatik olarak kaydedilecek.",
    ok: "Uygula ve yeniden başlat",
    no: "Vazgeç",
  },
  en: {
    t: "Changing language",
    m: "The game will restart to apply the new language. Your mission will be saved automatically.",
    ok: "Apply and restart",
    no: "Cancel",
  },
  de: {
    t: "Sprache wird geändert",
    m: "Das Spiel wird neu gestartet, um die neue Sprache anzuwenden. Deine Mission wird automatisch gespeichert.",
    ok: "Übernehmen und neu starten",
    no: "Abbrechen",
  },
  es: {
    t: "Cambiando el idioma",
    m: "El juego se reiniciará para aplicar el nuevo idioma. Tu misión se guardará automáticamente.",
    ok: "Aplicar y reiniciar",
    no: "Cancelar",
  },
};
if (LANG !== "tr") {
  const P = CanvasRenderingContext2D.prototype,
    fT = P.fillText,
    sT = P.strokeText,
    mT = P.measureText;
  P.fillText = function (t, x, y, w) {
    return w === undefined ? fT.call(this, PF(String(t)), x, y) : fT.call(this, PF(String(t)), x, y, w);
  };
  P.strokeText = function (t, x, y, w) {
    return w === undefined ? sT.call(this, PF(String(t)), x, y) : sT.call(this, PF(String(t)), x, y, w);
  };
  P.measureText = function (t) {
    return mT.call(this, PF(String(t)));
  };
  document.documentElement.lang = LANG;
  const trNode = (n) => {
    const v = n.nodeValue;
    if (!v || !v.trim()) return;
    const k = v.trim(),
      r = T(k);
    let out = r !== k ? v.replace(k, r) : v;
    out = PF(out);
    if (out !== v) n.nodeValue = out;
  };
  const walk = (root) => {
    const it = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.parentNode && /^(SCRIPT|STYLE)$/.test(n.parentNode.nodeName) ? 2 : 1),
    });
    let n;
    while ((n = it.nextNode())) trNode(n);
  };
  walk(document.body);
  document.querySelectorAll("[placeholder],[title]").forEach((e) => {
    for (const a of ["placeholder", "title"]) {
      const v = e.getAttribute(a);
      if (v) {
        const r = T(v);
        if (r !== v) e.setAttribute(a, r);
      }
    }
  });
  document.title = T(document.title);
  new MutationObserver((ms) => {
    for (const m of ms) {
      if (m.type === "characterData") trNode(m.target);
      else
        m.addedNodes.forEach((n) => {
          if (n.nodeType === 3) trNode(n);
          else if (n.nodeType === 1 && !/^(SCRIPT|STYLE)$/.test(n.nodeName)) walk(n);
        });
    }
  }).observe(document.body, { childList: true, subtree: true, characterData: true });
}

/* ============== YARDIMCI ============== */
const $ = (id) => document.getElementById(id);
function fmtTime(s) {
  s = Math.max(0, Math.floor(s));
  const p = (n) => String(n).padStart(2, "0");
  return p(Math.floor(s / 3600)) + ":" + p(Math.floor(s / 60) % 60) + ":" + p(s % 60);
}
function toast(msg) {
  const t = $("toast");
  t.innerHTML = msg;
  t.style.opacity = 1;
  clearTimeout(toast._h);
  toast._h = setTimeout(() => (t.style.opacity = 0), 2400);
}
function focusGame() {
  try {
    window.focus();
  } catch (e) {}
  try {
    document.body.focus();
  } catch (e) {}
}

/* ============== AYARLAR (CFG) ============== */
const CFG = {
  walkSpeed: 220,
  runMultiplier: 1.6,
  springSpeed: 14,
  springAmount: 0.05,
  legSwing: 0.65,
  interactRange: 150,
  zoom: 1,
  worldHalf: 8400,
  stoneCount: 170,
  pickupRange: 80,
  cargoGoal: 10,
  slots: 4,
  stonesPerSlot: 4,
  hungerDrain: 0.3,
  thirstDrain: 0.42,
  hpDrainEmpty: 4,
  hpRegen: 1.2,
  drinkThirst: 35,
  eatHunger: 35,
  weightPerItem: 0.02,
  maxWeightPenalty: 0.3,
  farmGrow: 55,
  plotRange: 100,
  healAmount: 40,
  digRange: 240,
  maxPlots: 24, // kazma: tıklama menzili ve azami parsel
  eventMin: 80,
  eventMax: 160,
  meteorDmg: 26,
  meteorRadius: 90,
  flyDur: 2.0,
  waterRecycle: 70, // su geri dönüştürücü: her 70 sn'de stoka +1 su (tüketim ~83 sn'de 1 şişe → görev boyunca yeter)
};
const SAVE_KEY = "uzay_oyunu_saves_v1";
const SETTINGS_KEY = "uzay_oyunu_settings_v1";
const stoneCap = () => CFG.slots * CFG.stonesPerSlot;

/* ============== HİKAYE / İLERLEME ==============
   Roket Dünya'dan kalkar, Mars'a düşer. Oyuncu Mars'ta yerleşir,
   görevleri tamamlayarak Mars'ta üssünü kurar ve
   en sonda 1000 metal ile Dünya'ya geri döner. */
const PROG_ORDER = ["mars", "earth"];
const QUESTS = [
  {
    t: T("Donanım"),
    ic: "🧰",
    d: T("Roketteki alet sandığından <b>çapayı</b> al"),
    k: "kit",
    n: 1,
    how: T(
      "Roketin yanında <b>E</b> ile gir → makine dairesi → <b>ALET SANDIĞI</b> → <b>E</b> → Çapa: <b>Al</b>.",
    ),
  },
  {
    t: T("Toplayıcı"),
    ic: "🔩",
    d: T("Etrafa saçılmış <b>5 metal numune</b> topla"),
    k: "mined",
    n: 5,
    how: T("Haritadaki ◆ işaretlerine yürü, numunenin yanında <b>F</b>'ye bas."),
  },
  {
    t: T("Çiftçi"),
    ic: "🌱",
    d: T("Toprağı kaz ve <b>tohum ek</b>"),
    k: "planted",
    n: 1,
    how: T("Dışarıda yere <b>sol tıkla</b> (kaz), çukurun yanında <b>F</b> ile ek. Tohum alet sandığında."),
  },
  {
    t: T("Seramik Kalkan"),
    ic: "🛡️",
    d: T("Ektiğin tohumun üstüne <b>seramik kalkan</b> kur"),
    k: "covered",
    n: 1,
    how: T(
      "Alet sandığından <b>seramik kalkanı</b> al. Dışarıda eline al, ekili parselin yanında <b>F</b>. Kalkan kurulunca kendiliğinden kapanır.",
    ),
  },
  {
    t: T("Kalkan Kontrolü"),
    ic: "🔓",
    d: T("Kalkanı <b>Q</b> ile aç ve yeniden kapat"),
    k: "domeCycle",
    n: 1,
    how: T(
      "Kalkanlı parselin yanında <b>Q</b>: kanatlar açılır. Açıkken sulayıp hasat edebilirsin ama bitki korunmaz. Tekrar <b>Q</b> ile kapat.",
    ),
  },
  {
    t: T("Susuzluk"),
    ic: "💧",
    d: T("Bir şişe <b>su iç</b>"),
    k: "drunk",
    n: 1,
    how: T(
      "Su şişesini eline al (alttaki numara tuşu), sonra <b>F</b>'ye bas. Ya da roketteki <b>mutfakta</b> <b>İç</b>.",
    ),
  },
  {
    t: T("İlk Rapor"),
    ic: "📡",
    d: T("Dünya'ya <b>ilk raporunu gönder</b>"),
    k: "reported",
    n: 1,
    how: T(
      "Komuta güvertesi → solda <b>İLETİŞİM</b> masası → <b>E</b> → <b>Rapor hazırla</b> → gözlem seç, not yaz → <b>Dünya'ya gönder</b>.",
    ),
  },
  {
    t: T("Sığınak"),
    ic: "🌪️",
    d: T("Kum fırtınasını <b>roketin içinde atlat</b>"),
    k: "stormSafe",
    n: 1,
    how: T(
      "İlk fırtına <b>2. gün</b> gelir. Turuncu uyarı kartı çıkınca 45 sn içinde rokete gir ve fırtına bitene kadar içeride kal.",
    ),
  },
  {
    t: T("Mühendis"),
    ic: "🔧",
    d: T("Kum fırtınasından sonra <b>ana motoru onar</b>"),
    k: "repaired",
    n: 1,
    how: T(
      "2. gün gelen fırtına motoru bozar. Makine dairesi → <b>ANA MOTOR</b> → <b>E</b> → 4 aşamayı tamamla.",
    ),
  },
  {
    t: T("Kalkan"),
    ic: "🛡️",
    d: T("Radyasyon dalgasını <b>roketin içinde atlat</b>"),
    k: "radSafe",
    n: 1,
    how: T(
      "İlk dalga <b>3. günün</b> başında gelir. Yeşil uyarı kartı çıkınca rokete gir; en kolayı uyku kabininde uyumak.",
    ),
  },
  {
    t: T("Koruma Altında"),
    ic: "🛡️",
    d: T("Bitkin radyasyon dalgasını <b>kapalı kalkanın altında</b> atlatsın"),
    k: "shieldSaved",
    n: 1,
    how: T(
      "Dalga gelmeden kalkanı <b>Q</b> ile kapat. Kapalı kalkan dalgayı keser; açık kalan bitki büyümesini kaybeder.",
    ),
  },
  {
    t: T("Hasatçı"),
    ic: "🥔",
    d: T("Patatesi büyüt, kalkanı aç ve <b>hasat et</b>"),
    k: "harvested",
    n: 1,
    how: T(
      "Halka sarı olunca kalkanı <b>Q</b> ile aç, <b>F</b> ile hasat et. Kalkan parselde kalır: yeniden ek ve <b>Q</b> ile kapat.",
    ),
  },
  {
    t: T("Haberleşme"),
    ic: "📨",
    d: T("Dünya'nın raporuna verdiği <b>resmî yanıtı oku</b>"),
    k: "replyRead",
    n: 1,
    how: T(
      "Yanıt raporundan ~½ sol sonra gelir (ACİL: ~¼ sol). İletişim terminali → <b>Gelen kutusu</b> → YANIT etiketli mesajı aç.",
    ),
  },
  {
    t: T("Çürük Kargo"),
    ic: "📤",
    d: T("Çürük patatesi <b>kargoyla Dünya'ya gönder</b>"),
    k: "rotSample",
    n: 1,
    how: T(
      "Radyasyonu yüksek toprağa ekilen patates çürük çıkar. Çürük patatesi rokete götür → komuta güvertesi → <b>Kargo terminali</b> → <b>Dünya'ya gönder</b>.",
    ),
  },
  {
    t: T("Dünya'nın Cevabı"),
    ic: "🧪",
    d: T("Dünya'dan gelen <b>analiz mesajını</b> oku"),
    k: "rotAnalysis",
    n: 1,
    how: T(
      "Kargo ulaşınca Dünya kısa süre içinde cevap yazar. İletişim terminali → <b>Gelen kutusu</b> → ANALİZ etiketli mesaj.",
    ),
  },
  {
    t: T("Ölçüm"),
    ic: "📟",
    d: T("Radyasyon ölçerle <b>3 farklı yerde</b> toprağı ölç"),
    k: "measured",
    n: 3,
    how: T(
      "Roketteki <b>alet sandığından</b> radyasyon ölçeri al. Dışarıda eline al (numara tuşu) ve toprağa <b>sol tıkla</b>. Her ölçüm yere renkli bir bayrak diker.",
    ),
  },
  {
    t: T("Temiz Toprak"),
    ic: "🌿",
    d: T("Güvenli toprağa ek ve <b>sağlıklı hasat</b> al"),
    k: "cleanHarvest",
    n: 1,
    how: T("<b>1,0 µSv/h</b> altında ölçülen (yeşil bayraklı) yere kaz, tohum ek, sula ve hasat et."),
  },
  {
    t: T("Altın Avcısı"),
    ic: "🪙",
    d: T("Meteor kraterlerinden <b>3 altın parçası</b> topla"),
    k: "gold",
    n: 3,
    how: T(
      "Meteor düştükten sonra kraterin çevresinde parlayan sarı parçaları ara, yanında <b>F</b>'ye bas.",
    ),
  },
  {
    t: T("Jeolog"),
    ic: "🪨",
    d: T("Uzak bölgelerde <b>bilinmeyen bir taş</b> çıkar"),
    k: "rare",
    n: 1,
    how: T(
      "Alet sandığından <b>jeolog kazmasını</b> al. Tarayıcı bip sesi verince haritadaki <b>?</b> işaretine git ve taşı <b>F</b> ile kır.",
    ),
  },
  {
    t: T("Numune Analizi"),
    ic: "🔬",
    d: T("Bilinmeyen taşı <b>analiz için Dünya'ya gönder</b>"),
    k: "rockSent",
    n: 1,
    how: T("Komuta güvertesi → <b>Kargo terminali</b> → ANALİZ İÇİN satırında <b>Analize gönder</b>."),
  },
  {
    t: T("Terzi"),
    ic: "🧑‍🚀",
    d: T("Fabrikasyon atölyesinde <b>yeni bir kıyafet</b> üret"),
    k: "suit",
    n: 1,
    how: T(
      "Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b> → Kıyafet setleri → <b>Kaşif Mk-I</b> → Üret ve giy (4 metal).",
    ),
  },
  {
    t: T("Radyasyon Zırhı"),
    ic: "☢️",
    d: T("Radyasyona dayanıklı <b>Öncü Mk-II</b> kıyafetini üret"),
    k: "radSuit",
    n: 1,
    how: T("Fabrikasyon atölyesi → Kıyafet setleri → <b>Öncü Mk-II</b> (radyasyon hasarı %40 azalır)."),
  },
  {
    t: T("Zırh Ustası"),
    ic: "⚙️",
    d: T("Rokete <b>Titanyum Plakalar</b> zırhını tak"),
    k: "armor",
    n: 1,
    how: T(
      "Fabrikasyon atölyesi → <b>Roket geliştirme</b> → Titanyum Plakalar (fırtınada arıza olasılığı %60 → %35).",
    ),
  },
  {
    t: T("Kargo"),
    ic: "📦",
    d: T("Roketin kargosuna <b>10 numune</b> yükle"),
    k: "loaded",
    n: 10,
    how: T("Metal = 1, ⭐ yıldız = 2 numune. Roketin yanında <b>F</b>'ye bas."),
  },
  {
    t: T("Eve Dönüş"),
    ic: "🌍",
    d: T("Roketle <b>Dünya'ya dön</b>"),
    k: "traveled",
    n: 1,
    how: T("Komuta güvertesi (en üst kat) → <b>NAVİGASYON</b> → <b>E</b> → <b>EVE DÖN</b>."),
  },
];
const QUEST_VER = 7;
const START_PLANET = PROG_ORDER[0];
const progIdxOf = (k) => PROG_ORDER.indexOf(k);

/* ============== GEZEGENLER ============== */
const PLANETS = {
  earth: {
    name: T("Dünya"),
    ground: "#2f7d4f",
    dot: "#1b5233",
    speedMul: 1.0,
    order: 1,
    seedPrice: 5,
    waterPrice: 3,
    weather: "rain",
    atmo: "rgba(120,190,255,.10)",
    grow: 1.0,
    air: false,
    decor: ["grass", "rock", "grass", "speck"],
  },
  mars: {
    name: T("Mars"),
    ground: "#b3392a",
    dot: "#7e2217",
    speedMul: 1.12,
    order: 3,
    seedPrice: 7,
    waterPrice: 5,
    weather: "dust",
    atmo: "rgba(220,130,80,.13)",
    grow: 0.75,
    air: false,
    decor: ["rock", "crater", "crack", "speck"],
  },
};

/* ============== AYARLAR DEPOLAMA ============== */
function loadSettings() {
  const D = {
    master: 100,
    music: 60,
    sfx: 80,
    amb: 80,
    fps: 60,
    vsync: true,
    fullscreen: false,
    lang: "tr",
    diff: "normal",
    hints: true,
    intro: true,
    autosave: 3,
    floats: true,
    ultra: true,
    parts: 1,
    atmos: true,
    grain: true,
    hud: 1,
    map: 1,
    subs: 1,
    story: true,
    shake: 100,
    noflash: false,
    contrast: false,
  };
  try {
    const s = JSON.parse(localStorage.getItem(SETTINGS_KEY));
    if (s) return Object.assign(D, s);
  } catch (e) {}
  return D;
}
let settings = loadSettings();
function saveSettings() {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {}
}

/* ============== KAYIT SİSTEMİ ============== */
function loadSaves() {
  try {
    return JSON.parse(localStorage.getItem(SAVE_KEY)) || [];
  } catch (e) {
    return [];
  }
}
function writeSaves(list) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(list));
  } catch (e) {}
}
function newGameState() {
  return {
    planet: START_PLANET,
    visited: [START_PLANET],
    px: 170,
    py: 120,
    inventory: { stone: 0, star: 0, seed: 0, water: 1, potato: 0, medkit: 0 },
    slotOrder: [],
    farms: {},
    plots: {},
    kitOwned: true,
    kitCarried: false,
    stock: { water: 8, potato: 6, seed: 4, medkit: 3, ceramic: 6 },
    cargo: 0,
    recyT: 0, // roketteki erzak stoku + kargo bölmesi
    progIdx: 0,
    quest: 0,
    questVer: QUEST_VER,
    qstats: {
      mined: 0,
      kit: 0,
      planted: 0,
      drunk: 0,
      harvested: 0,
      loaded: 0,
      repaired: 0,
      traveled: 0,
      reported: 0,
      stormSafe: 0,
      radSafe: 0,
      replyRead: 0,
      gold: 0,
      rare: 0,
      suit: 0,
      rockSent: 0,
      radSuit: 0,
      armor: 0,
    },
    won: false,
    repair: { state: "ok", end: 0, stage: 0 }, // motor sağlam; 2. gündeki ilk fırtına bozar
    stormBroke: false,
    suit: "std",
    suitsOwned: ["std"],
    gold: 0,
    rk: { armor: 0, skin: "classic", owned: ["classic"] },
    hp: 100,
    hunger: 100,
    thirst: 100,
    o2: 100,
    o2Tank: 400,
    playTime: 0,
    worldTime: 0,
    sleeping: false,
    radiationActive: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}
let game = null,
  currentSaveId = null;

function refreshContinueButton() {
  const sv = loadSaves().sort((a, b) => b.updatedAt - a.updatedAt);
  $("mContinue").disabled = sv.length === 0;
  const el = $("mContSub");
  if (el)
    el.textContent = sv.length
      ? T("Son kayıt: ") +
        ((sv[0].state && sv[0].state.name) || sv[0].name || T("görev")) +
        T(" · Gün ") +
        (Math.floor(((sv[0].state && sv[0].state.worldTime) || 0) / DAY_SECONDS) + 1)
      : T("Kayıtlı görev yok");
}
function formatDate(ts) {
  const d = new Date(ts);
  return (
    d.toLocaleDateString(LOCALE) + " " + d.toLocaleTimeString(LOCALE, { hour: "2-digit", minute: "2-digit" })
  );
}
function planetLabel(k) {
  return (PLANETS[k] && PLANETS[k].name) || k;
}

function renderSavesList() {
  const saves = loadSaves().sort((a, b) => b.updatedAt - a.updatedAt);
  const el = $("savesList");
  el.innerHTML = "";
  if (saves.length === 0) {
    el.innerHTML = T('<div class="empty-note">Henüz kayıt yok.</div>');
    return;
  }
  saves.forEach((s) => {
    const st = s.state || {};
    const row = document.createElement("div");
    row.className = "save-item";
    row.innerHTML = `<div class="sv-ic">🚀</div><div><div class="name">${st.name || s.name}</div>
      <div class="meta">${planetLabel(st.planet)} · Sol ${Math.floor((st.worldTime || 0) / DAY_SECONDS) + 1} · ⏱ ${fmtTime(st.playTime || 0)} · ${formatDate(s.updatedAt)}</div></div>`;
    const btns = document.createElement("div");
    btns.className = "sv-b";
    const loadB = document.createElement("button");
    loadB.className = "ld";
    loadB.textContent = T("Yükle");
    loadB.onclick = () => {
      loadGame(s.id);
    };
    const delB = document.createElement("button");
    delB.className = "dl";
    delB.textContent = T("Sil");
    delB.onclick = () => {
      writeSaves(loadSaves().filter((x) => x.id !== s.id));
      renderSavesList();
      refreshContinueButton();
    };
    btns.appendChild(loadB);
    btns.appendChild(delB);
    row.appendChild(btns);
    el.appendChild(row);
  });
}
function loadGame(id) {
  const s = loadSaves().find((x) => x.id === id);
  if (!s) return;
  game = Object.assign(newGameState(), JSON.parse(JSON.stringify(s.state)));
  currentSaveId = id;
  storyReset();
  if (!game.farms) game.farms = {};
  if (!game.plots) game.plots = {};
  if (game.pickaxe) {
    game.kitOwned = true;
    game.kitCarried = true;
    delete game.pickaxe;
  } // eski kayıt: kazma → saha kiti
  game.kitOwned = true;
  if (game.kitCarried == null) game.kitCarried = false;
  delete game.coins;
  delete game.rocketEnergy;
  if (!game.stock) game.stock = { water: 8, potato: 6, seed: 4, medkit: 3 };
  if (game.stock.ceramic == null) game.stock.ceramic = 6; // eski kayıt: seramik kalkanlar eklendi
  if (!Number.isFinite(game.cargo)) game.cargo = 0;
  if (!Number.isFinite(game.recyT)) game.recyT = 0;
  ["kit", "loaded", "repaired"].forEach((k) => {
    if (game.qstats && game.qstats[k] == null) game.qstats[k] = 0;
  });
  if (game.stormBroke == null) game.stormBroke = game.repair && game.repair.state !== "ok";
  // eski kayıt göçü: farms[scene] (sabit 4 parsel) → plots[scene] (konum+ durum birleşik)
  Object.keys(game.farms).forEach((sc) => {
    if (Array.isArray(game.plots[sc]) && game.plots[sc].length) return;
    const fa = game.farms[sc];
    if (Array.isArray(fa))
      game.plots[sc] = fa.map((f, i) => ({
        x: (PLOTS_LEGACY[i] || { x: 0 }).x,
        y: (PLOTS_LEGACY[i] || { y: 0 }).y,
        g: (f && f.g) || 0,
        wet: (f && f.wet) || 0,
      }));
  });
  if (!Array.isArray(game.slotOrder)) game.slotOrder = SLOT_KEYS.filter((k) => (game.inventory[k] || 0) > 0);
  if (!game.repair) game.repair = { state: "ok", end: 0 }; // eski kayıt: roket tamirli sayılır
  if (game.repair.state === "repairing")
    game.repair = { state: Date.now() >= game.repair.end ? "ok" : "broken", end: 0, stage: 0 }; // eski süreli tamir
  if (game.repair.stage == null) game.repair.stage = 0;
  delete game.tentOwned;
  delete game.inTent;
  if (!Number.isFinite(game.worldTime)) game.worldTime = 0;
  game.sleeping = false;
  game.radiationActive = false;
  bedOpen = false;
  insideRocket = false;
  if (commOpen) closeComm();
  commDraft.note = "";
  commDraft.off.clear();
  commSel = null;
  if (game.comms && game.comms.trk) {
    game.comms.trk.st = null;
    game.comms.trk.rd = null;
  }
  if (typeof repairOpen !== "undefined" && repairOpen) closeRepair();
  $("bedScreen").classList.add("hidden");
  // eski kayıt: görev sistemi yok → tüm gezegenler açık sayılır
  if (!s.state.qstats) {
    game.progIdx = PROG_ORDER.length - 1;
    game.quest = QUESTS.length;
    game.qstats = {
      mined: 99,
      kit: 9,
      planted: 9,
      drunk: 9,
      harvested: 9,
      loaded: 99,
      repaired: 9,
      traveled: 9,
      reported: 9,
      stormSafe: 9,
      radSafe: 9,
      replyRead: 9,
      gold: 9,
      rare: 9,
      suit: 9,
    };
    game.won = !!s.state.won;
  }
  // eski 8 gezegenli ilerleme kaydı → sadece Mars + Dünya düzenine göre düzelt
  // eski görev zinciri (8 görev) → yeni zincir: yapılmış işleri say, yeni görevlerden devam et
  if (s.state.questVer !== QUEST_VER) {
    const Q = game.qstats;
    if (Q.repaired > 0 || game.stormBroke || game.worldTime > DAY_SECONDS * 2.4)
      Q.stormSafe = Math.max(Q.stormSafe || 0, 1);
    if (game.worldTime > DAY_SECONDS * 3.3) Q.radSafe = Math.max(Q.radSafe || 0, 1);
    const C = game.comms;
    if (C && C.sent && C.sent.length) Q.reported = Math.max(Q.reported || 0, 1);
    if (C && C.inbox && C.inbox.some((m) => m.kind === "reply" && m.read))
      Q.replyRead = Math.max(Q.replyRead || 0, 1);
    if (Array.isArray(game.suitsOwned) && game.suitsOwned.length > 1) Q.suit = Math.max(Q.suit || 0, 1);
    if (game.rare && Object.values(game.rare).some((v) => v > 0)) Q.rare = Math.max(Q.rare || 0, 1);
    Q.gold = Math.max(Q.gold || 0, game.gold || 0);
    if (
      Array.isArray(game.suitsOwned) &&
      game.suitsOwned.some((id) => {
        const S = SUITS.find((x) => x.id === id);
        return S && S.st.rad <= 0.6;
      })
    )
      Q.radSuit = Math.max(Q.radSuit || 0, 1);
    if (game.rk && game.rk.armor > 0) Q.armor = Math.max(Q.armor || 0, 1);
    if (C && C.flags && C.flags.rock && Object.keys(C.flags.rock).length)
      Q.rockSent = Math.max(Q.rockSent || 0, 1);
    const wasDone =
      s.state.questVer === 6
        ? game.quest >= 22
        : s.state.questVer === 5
          ? game.quest >= 22
          : s.state.questVer === 4
            ? game.quest >= 19
            : s.state.questVer === 3
              ? game.quest >= 20
              : s.state.questVer === 2
                ? game.quest >= 15
                : game.quest >= 8;
    game.quest = 0;
    while (game.quest < QUESTS.length && (Q[QUESTS[game.quest].k] || 0) >= QUESTS[game.quest].n) game.quest++;
    if (wasDone) game.quest = QUESTS.length;
    game.questVer = QUEST_VER;
  }
  game.quest = Math.min(game.quest, QUESTS.length);
  game.progIdx = game.quest >= QUESTS.length - 1 ? PROG_ORDER.length - 1 : 0;
  p.x = game.px;
  p.y = game.py;
  resetStormFx();
  $("savesScreen").classList.add("hidden");
  enterPlanet(game.planet, true);
  toast(T("Kayıt yüklendi"));
}
function doSave(name, quiet) {
  game.updatedAt = Date.now();
  game.px = p.x;
  game.py = p.y;
  let saves = loadSaves();
  if (currentSaveId) {
    const i = saves.findIndex((x) => x.id === currentSaveId);
    if (i >= 0) {
      saves[i].state = game;
      saves[i].updatedAt = game.updatedAt;
      if (name) saves[i].name = name;
    }
  } else {
    currentSaveId = "save_" + Date.now();
    saves.push({
      id: currentSaveId,
      name: name || T("Kayıt ") + (saves.length + 1),
      updatedAt: game.updatedAt,
      state: game,
    });
  }
  writeSaves(saves);
  refreshContinueButton();
  toast(quiet ? T("💾 Otomatik kaydedildi") : T("💾 Kaydedildi"));
}

/* ============== SES MOTORU (WebAudio) ============== */
const AU = {
  ac: null,
  ready: false,
  master: null,
  musicG: null,
  sfxG: null,
  bus: null,
  delay: null,
  nextT: 0,
  step: 0,
  timer: null,
};
function audioInit() {
  if (AU.ac) return;
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    AU.ac = new AC();
  } catch (e) {
    return;
  }
  const ac = AU.ac;
  AU.master = ac.createGain();
  AU.master.connect(ac.destination);
  AU.musicG = ac.createGain();
  AU.musicG.connect(AU.master);
  AU.sfxG = ac.createGain();
  AU.sfxG.connect(AU.master);
  // müzik barı + gecikme (uzay yankısı)
  AU.bus = ac.createGain();
  AU.bus.connect(AU.musicG);
  const dl = ac.createDelay(1.0);
  dl.delayTime.value = 0.34;
  const fb = ac.createGain();
  fb.gain.value = 0.34;
  const lp = ac.createBiquadFilter();
  lp.type = "lowpass";
  lp.frequency.value = 1400;
  dl.connect(lp);
  lp.connect(fb);
  fb.connect(dl);
  dl.connect(AU.musicG);
  AU.delay = dl;
  AU.bus.connect(dl);
  AU.nextT = ac.currentTime + 0.2;
  AU.ready = true;
  applyVol();
  AU.timer = setInterval(scheduleMusic, 200);
}
function ensureAudio() {
  audioInit();
  if (AU.ac && AU.ac.state === "suspended") AU.ac.resume();
}
function applyVol() {
  if (!AU.ready) return;
  AU.master.gain.value = settings.master / 100;
  AU.musicG.gain.value = (settings.music / 100) * 0.55;
  AU.sfxG.gain.value = settings.sfx / 100;
}
function tone(freq, dur, type, vol, slide, delay) {
  if (!AU.ready || settings.sfx <= 0) return;
  const ac = AU.ac,
    t = ac.currentTime + (delay || 0);
  const o = ac.createOscillator(),
    g = ac.createGain();
  o.type = type || "sine";
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, slide), t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(vol || 0.25, t + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g);
  g.connect(AU.sfxG);
  o.start(t);
  o.stop(t + dur + 0.06);
}
function noiseBurst(dur, vol, freq, delay) {
  if (!AU.ready || settings.sfx <= 0) return;
  const ac = AU.ac,
    t = ac.currentTime + (delay || 0),
    n = Math.floor(ac.sampleRate * dur);
  const buf = ac.createBuffer(1, n, ac.sampleRate),
    d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
  const src = ac.createBufferSource();
  src.buffer = buf;
  const f = ac.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = freq || 900;
  const g = ac.createGain();
  g.gain.value = vol || 0.3;
  src.connect(f);
  f.connect(g);
  g.connect(AU.sfxG);
  src.start(t);
}
/* ---------- yaşamsal sıkıntı sesi: kalp atışı + zorlu nefes (susuzluk/açlık/oksijen/can düşükken) ---------- */
const DIS = { next: 0, breath: 0, lvl: 0 };
function heartThump(v, delay) {
  if (!AU.ready || settings.sfx <= 0) return;
  const ac = AU.ac,
    t = ac.currentTime + (delay || 0);
  const o = ac.createOscillator(),
    g = ac.createGain(),
    f = ac.createBiquadFilter();
  o.type = "sine";
  o.frequency.setValueAtTime(62, t);
  o.frequency.exponentialRampToValueAtTime(34, t + 0.16);
  f.type = "lowpass";
  f.frequency.value = 160;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.55 * v, t + 0.006);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.22);
  o.connect(f);
  f.connect(g);
  g.connect(AU.sfxG);
  o.start(t);
  o.stop(t + 0.3);
  noiseBurst(0.05, 0.05 * v, 220, delay); // kapakçık tıkırtısı (çok kısık)
}
function breathNoise(dur, v, delay, inhale) {
  if (!AU.ready || settings.sfx <= 0) return;
  const ac = AU.ac,
    t = ac.currentTime + (delay || 0),
    n = Math.floor(ac.sampleRate * dur);
  const buf = ac.createBuffer(1, n, ac.sampleRate),
    d = buf.getChannelData(0);
  for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  const s = ac.createBufferSource();
  s.buffer = buf;
  const f = ac.createBiquadFilter();
  f.type = "bandpass";
  f.Q.value = 0.9;
  f.frequency.setValueAtTime(inhale ? 700 : 1100, t);
  f.frequency.linearRampToValueAtTime(inhale ? 1300 : 600, t + dur);
  const g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(v, t + dur * (inhale ? 0.6 : 0.25));
  g.gain.linearRampToValueAtTime(0.0001, t + dur);
  s.connect(f);
  f.connect(g);
  g.connect(AU.sfxG);
  s.start(t);
}
function updateDistress(dt) {
  if (!game || mode !== "play" || !AU.ready) return;
  const starving = game.hunger <= 0 || game.thirst <= 0,
    noO2 = game.o2 != null && game.o2 <= 0 && !insideRocket,
    low = game.hp < 30;
  let L = 0;
  if (starving) L = Math.max(L, 0.45 + (1 - game.hp / 100) * 0.45);
  if (noO2) L = Math.max(L, 1);
  if (low) L = Math.max(L, 0.35 + ((30 - game.hp) / 30) * 0.6);
  if (game.sleeping) L *= 0.5;
  DIS.lvl += (L - DIS.lvl) * Math.min(1, dt * 1.5);
  if (DIS.lvl < 0.05) {
    DIS.next = 0;
    return;
  }
  const now = AU.ac.currentTime,
    v = Math.min(1, DIS.lvl);
  const period = 1.1 - 0.5 * v; // nabız hızlanır (≈55 → 100 bpm)
  if (DIS.next < now) {
    DIS.next = now + 0.05;
  }
  if (DIS.next < now + 0.25) {
    const d = DIS.next - now;
    heartThump(0.55 + 0.45 * v, d);
    heartThump(0.32 + 0.3 * v, d + 0.2 + 0.06 * (1 - v));
    DIS.next += period;
  }
  DIS.breath -= dt;
  if (DIS.breath <= 0) {
    DIS.breath = 2.4 - 0.9 * v;
    const bv = 0.018 + 0.03 * v;
    breathNoise(0.55 + 0.2 * (1 - v), bv, 0, true);
    breathNoise(0.7, bv * 0.8, 0.75 - 0.15 * v, false);
  }
}

function sfx(name) {
  if (!AU.ready || settings.sfx <= 0) return;
  switch (name) {
    case "click":
      tone(520, 0.07, "square", 0.14, 760);
      break;
    case "pickup":
      tone(680, 0.09, "square", 0.18, 1080);
      tone(1080, 0.07, "square", 0.12, null, 0.06);
      break;
    case "star":
      tone(880, 0.1, "triangle", 0.2, 1320);
      tone(1320, 0.14, "triangle", 0.16, null, 0.08);
      break;
    case "coin":
      tone(880, 0.08, "square", 0.16, 1180);
      tone(1180, 0.12, "square", 0.16, null, 0.07);
      break;
    case "plant":
      tone(190, 0.16, "sine", 0.3, 90);
      noiseBurst(0.12, 0.16, 600);
      break;
    case "water":
      tone(700, 0.14, "sine", 0.18, 340);
      noiseBurst(0.16, 0.12, 1600);
      break;
    case "harvest":
      tone(520, 0.09, "triangle", 0.2, 780);
      tone(780, 0.09, "triangle", 0.18, 1040);
      tone(1040, 0.16, "triangle", 0.16, null, 0.16);
      break;
    case "eat":
      tone(300, 0.1, "sawtooth", 0.14, 220);
      noiseBurst(0.1, 0.1, 800, 0.03);
      break;
    case "drink":
      tone(420, 0.16, "sine", 0.16, 260);
      break;
    case "heal":
      tone(520, 0.1, "sine", 0.2, 780);
      tone(780, 0.16, "sine", 0.18, null, 0.1);
      break;
    case "error":
      tone(200, 0.16, "square", 0.18, 120);
      break;
    case "full":
      tone(300, 0.1, "square", 0.16, 240);
      break;
    case "hurt":
      tone(240, 0.3, "sawtooth", 0.3, 70);
      noiseBurst(0.25, 0.2, 500);
      break;
    case "boom":
      tone(110, 0.5, "sawtooth", 0.34, 40);
      noiseBurst(0.5, 0.3, 420);
      break;
    case "warn":
      tone(1046, 0.35, "sine", 0.12);
      tone(784, 0.45, "sine", 0.11, null, 0.16);
      tone(523, 0.6, "triangle", 0.07, null, 0.34);
      tone(1046, 0.25, "sine", 0.04, null, 0.5);
      break;
    case "travel":
      tone(160, 0.7, "sawtooth", 0.24, 1400);
      noiseBurst(0.7, 0.16, 2400);
      break;
    case "harvest2":
      tone(440, 0.12, "triangle", 0.2, 660);
      break;
    case "dig":
      noiseBurst(0.2, 0.22, 700, 0.05);
      tone(140, 0.14, "sawtooth", 0.2, 70);
      tone(90, 0.1, "square", 0.14, 60, 0.08);
      break;
  }
}
/* müzik: aşağıdaki ambient modülünde (scheduleMusic) */
addEventListener("pointerdown", ensureAudio, { passive: true });
addEventListener("keydown", ensureAudio);
document.addEventListener("visibilitychange", () => {
  if (!AU.ac) return;
  document.hidden ? AU.ac.suspend() : AU.ac.resume();
});

/* ============== CANVAS ============== */
const cv = $("c");
let ctx = cv.getContext("2d");
const mcv = $("menuBg"),
  mctx = mcv.getContext("2d");
let W, H, dpr;
function resize() {
  dpr = devicePixelRatio || 1;
  [cv, mcv].forEach((c) => {
    c.width = Math.max(1, innerWidth * dpr);
    c.height = Math.max(1, innerHeight * dpr);
  });
  W = innerWidth;
  H = innerHeight;
}
addEventListener("resize", resize);
resize();
setTimeout(() => {
  try {
    applyUiSettings();
  } catch (e) {}
}, 0);

function rng(s) {
  return () => {
    s = (s * 16807) % 2147483647;
    return s / 2147483647;
  };
}
const decor = {};
Object.keys(PLANETS).forEach((k, i) => {
  const r = rng(11 + i * 13),
    a = [],
    types = PLANETS[k].decor;
  for (let j = 0; j < 4200; j++) {
    a.push({
      x: (r() - 0.5) * CFG.worldHalf * 2,
      y: (r() - 0.5) * CFG.worldHalf * 2,
      r: 10 + r() * 55,
      type: types[Math.floor(r() * types.length)],
      rot: r() * 6.28,
    });
  }
  decor[k] = a;
});
const stars = [];
{
  const r = rng(5);
  for (let i = 0; i < 170; i++) stars.push({ x: r(), y: r(), h: r() });
}

/* roket her gezegende aynı sabit konumda; market ve çadırın işlevleri roketin içinde */
const ROCKET = { x: 300, y: -60 };
const DAY_SECONDS = 360,
  SLEEP_MULTIPLIER = 2,
  RADIATION_DURATION = 90,
  RADIATION_DAMAGE_PER_SECOND = 5.5,
  RAD_WARN = 40; // 1 gün = 10 dk
/* tarım parselleri artık dinamik: kazmayla açılır */
const PLOTS_LEGACY = [
  { x: -40, y: 50 },
  { x: 66, y: 50 },
  { x: -40, y: 190 },
  { x: 66, y: 190 },
]; // eski kayıt göçü için

function spawnStones(scene) {
  const L = CFG.worldHalf - 120,
    arr = [],
    r2 = rng(42 + PLANETS[scene].order * 17);
  const lp = (game && game.plots && game.plots[scene]) || [];
  let guard = 0;
  while (arr.length < CFG.stoneCount && guard++ < 20000) {
    // ilk 34 numune roketin çevresinde (ilk görevler için), kalanı tüm haritaya dağılır
    let x, y;
    if (arr.length < 34) {
      const a = r2() * 6.283,
        d = 300 + r2() * 1900;
      x = ROCKET.x + Math.cos(a) * d;
      y = ROCKET.y + Math.sin(a) * d;
    } else {
      x = (r2() * 2 - 1) * L;
      y = (r2() * 2 - 1) * L;
    }
    if (Math.hypot(x - ROCKET.x, y - ROCKET.y) <= 240) continue;
    if (lp.some((pl) => Math.hypot(x - pl.x, y - pl.y) < 150)) continue;
    arr.push({ x, y, ph: r2() * 6, taken: false });
  }
  return arr;
}
let stones = [],
  drops = [];

/* ============== PARÇACIKLAR ============== */
const parts = [],
  floats = [];
function burst(x, y, n, color, o) {
  n = Math.max(1, Math.round(n * (settings.parts || 1)));
  o = o || {};
  for (let i = 0; i < n; i++) {
    const a = Math.random() * 6.283,
      sp = (o.sp || 70) * (0.35 + Math.random() * 0.9),
      life = o.life || 0.6;
    parts.push({
      x,
      y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp - (o.up || 0),
      life,
      max: life,
      color,
      size: (o.size || 4) * (0.55 + Math.random() * 0.9),
      g: o.g == null ? 150 : o.g,
      drag: o.drag == null ? 2.2 : o.drag,
    });
  }
}
function addFloat(x, y, txt, color) {
  if (settings.floats === false) return;
  floats.push({ x, y, txt, life: 1.1, color: color || "#eef0ff" });
}
function updateParticles(dt) {
  for (let i = parts.length - 1; i >= 0; i--) {
    const q = parts[i];
    q.life -= dt;
    if (q.life <= 0) {
      parts.splice(i, 1);
      continue;
    }
    q.vx -= q.vx * q.drag * dt;
    q.vy -= q.vy * q.drag * dt;
    q.vy += q.g * dt;
    q.x += q.vx * dt;
    q.y += q.vy * dt;
  }
  for (let i = floats.length - 1; i >= 0; i--) {
    const f = floats[i];
    f.life -= dt;
    f.y -= 42 * dt;
    if (f.life <= 0) floats.splice(i, 1);
  }
  if (parts.length > 500) parts.splice(0, parts.length - 500);
}
function drawParticles() {
  for (const q of parts) {
    ctx.globalAlpha = Math.max(0, q.life / q.max);
    ctx.fillStyle = q.color;
    ctx.beginPath();
    ctx.arc(q.x, q.y, q.size, 0, 7);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.textAlign = "center";
  ctx.font = "700 17px sans-serif";
  for (const f of floats) {
    ctx.globalAlpha = Math.min(1, f.life * 1.4);
    ctx.fillStyle = f.color;
    ctx.strokeStyle = "rgba(0,0,0,.6)";
    ctx.lineWidth = 3;
    ctx.strokeText(f.txt, f.x, f.y);
    ctx.fillText(f.txt, f.x, f.y);
  }
  ctx.globalAlpha = 1;
}

/* ============== OYUNCU ============== */
const p = { x: 170, y: 120, sx: 1, sy: 1, t: 0, dir: 1, walk: 0, _running: false, action: null, actionT: 0 };
const keys = {};
let joy = { x: 0, y: 0 };
let scene = "earth",
  mode = "menu",
  paused = false,
  rocketOpen = false,
  marketOpen = false;
let shake = 0,
  flash = 0,
  warp = 0,
  stepDust = 0;
const ev = { type: null, t: 0, next: 45, spawnT: 0, meteors: [], goal: 0, spawned: 0 };

function rr(x, y, w, h, r, c) {
  ctx.fillStyle = c;
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, r);
  else ctx.rect(x, y, w, h);
  ctx.fill();
}
const HELD_ICONS = {
  pick: "⛏️",
  rotten: "🥔",
  radmeter: "☢",
  stone: "🔩",
  star: "⭐",
  water: "💧",
  potato: "🥔",
  seed: "🌱",
  medkit: "💊",
  pickaxe: "⛏️",
  ceramic: "🛡️",
  tuber: "🥔",
};
function heldItemKey() {
  if (!game) return null;
  if (p && p.action === "dig") return "pickaxe";
  if (p && p.action === "mine") return "pick";
  if (p && p.action === "drink") return "water";
  if (p && p.action === "eat") return "potato";
  if (p && p.action === "use") return "medkit";
  const k = (game.slotOrder || [])[selSlot];
  if (!k) return null;
  if (k === "kit") return game.kitCarried ? "pickaxe" : null;
  return (game.inventory[k] || 0) > 0 ? k : null;
}

/* ============== ASTRONOT — gelişmiş 2D iskelet modeli ==============
   Uzuvlar iki eklemli (kalça-diz-bot, omuz-dirsek-eldiven), kazma iki elle
   IK ile kavranır, göğüs paneli canlı veri gösterir, vizör yansımalıdır. */
const SUIT = {
  white: "#f6f7fc",
  light: "#e3e7f3",
  shade: "#c4cbde",
  dark: "#98a1bd",
  line: "#5f6886",
  orange: "#ff8c42",
  orangeD: "#c75d1e",
  navy: "#232b4d",
  steel: "#7f879f",
  glove: "#ff9a52",
};
function rrp(x, y, w, h, r) {
  ctx.beginPath();
  if (ctx.roundRect) ctx.roundRect(x, y, w, h, r);
  else ctx.rect(x, y, w, h);
}
function rotP(lx, ly, a) {
  const c = Math.cos(a),
    s = Math.sin(a);
  return { x: lx * c - ly * s, y: lx * s + ly * c };
}
function capsule(x1, y1, x2, y2, w, fill, stroke) {
  ctx.lineCap = "round";
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = w + 2.6;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();
  }
  ctx.strokeStyle = fill;
  ctx.lineWidth = w;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
}
/* iki kemikli ters kinematik: omuzdan hedefe uzanan kolun dirsek konumu */
function ik2(sx, sy, hx, hy, l1, l2, bend) {
  let dx = hx - sx,
    dy = hy - sy,
    d = Math.hypot(dx, dy);
  const mx = l1 + l2 - 0.05,
    mn = Math.abs(l1 - l2) + 0.05;
  if (d > mx) {
    dx *= mx / d;
    dy *= mx / d;
    d = mx;
  }
  if (d < mn) d = mn;
  const a = Math.acos(Math.max(-1, Math.min(1, (l1 * l1 + d * d - l2 * l2) / (2 * l1 * d))));
  const ea = Math.atan2(dy, dx) + bend * a;
  return { ex: sx + Math.cos(ea) * l1, ey: sy + Math.sin(ea) * l1, hx: sx + dx, hy: sy + dy };
}
let ASTRO_POSE = null; // sinematikler için: {b:[uyluk,baldır],f:[uyluk,baldır],ns:gölgesiz}
function drawLeg(hx, hy, ph, S, back) {
  let a1 = Math.sin(ph) * S; // uyluk açısı (ileri +)
  const bend = Math.max(0, Math.cos(ph)) * S * 1.15; // diz bükülmesi: bacak öne salınırken
  let a2 = a1 - bend;
  if (ASTRO_POSE && ASTRO_POSE.b) {
    const q = back ? ASTRO_POSE.b : ASTRO_POSE.f;
    a1 = q[0];
    a2 = q[1];
  }
  const L1 = 15,
    L2 = 14;
  const kx = hx + Math.sin(a1) * L1,
    ky = hy + Math.cos(a1) * L1;
  const fx = kx + Math.sin(a2) * L2,
    fy = ky + Math.cos(a2) * L2;
  const fill = back ? SUIT.shade : SUIT.light,
    line = back ? SUIT.dark : SUIT.line;
  capsule(hx, hy, kx, ky, 10, fill, line);
  ctx.fillStyle = back ? SUIT.dark : SUIT.steel;
  ctx.beginPath();
  ctx.arc(kx, ky, 4.2, 0, 7);
  ctx.fill(); // diz eklemi
  capsule(kx, ky, fx, fy, 9, fill, line);
  // bot
  ctx.save();
  ctx.translate(fx, fy);
  ctx.rotate(-a2 * 0.35);
  ctx.fillStyle = back ? SUIT.orangeD : SUIT.orange;
  rrp(-6, -4, 14, 9, 4);
  ctx.fill();
  ctx.strokeStyle = "rgba(90,40,10,.6)";
  ctx.lineWidth = 1.3;
  ctx.stroke();
  ctx.fillStyle = "rgba(40,20,10,.55)";
  rrp(-6, 3, 14, 2.5, 1);
  ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,.3)";
  rrp(-4, -3, 6, 2, 1);
  ctx.fill();
  ctx.restore();
  return { fx, fy };
}
function armSegs(sx, sy, ex, ey, hx, hy, back) {
  const fill = back ? SUIT.shade : SUIT.light,
    line = back ? SUIT.dark : SUIT.line;
  capsule(sx, sy, ex, ey, 8.5, fill, line);
  ctx.fillStyle = back ? SUIT.dark : SUIT.steel;
  ctx.beginPath();
  ctx.arc(ex, ey, 3.6, 0, 7);
  ctx.fill(); // dirsek
  capsule(ex, ey, hx, hy, 7.5, fill, line);
  // bilek bandı
  const dx = hx - ex,
    dy = hy - ey,
    d = Math.hypot(dx, dy) || 1;
  ctx.strokeStyle = back ? SUIT.orangeD : SUIT.orange;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(hx - (dx / d) * 4 - (dy / d) * 4.5, hy - (dy / d) * 4 + (dx / d) * 4.5);
  ctx.lineTo(hx - (dx / d) * 4 + (dy / d) * 4.5, hy - (dy / d) * 4 - (dx / d) * 4.5);
  ctx.stroke();
}
function drawArm(sx, sy, a1, a2, back) {
  const L1 = 13,
    L2 = 12;
  const ex = sx + Math.sin(a1) * L1,
    ey = sy + Math.cos(a1) * L1;
  const hx = ex + Math.sin(a1 + a2) * L2,
    hy = ey + Math.cos(a1 + a2) * L2;
  armSegs(sx, sy, ex, ey, hx, hy, back);
  return { hx, hy };
}
function glove(x, y, back) {
  ctx.fillStyle = back ? SUIT.orangeD : SUIT.glove;
  ctx.beginPath();
  ctx.arc(x, y, 5, 0, 7);
  ctx.fill();
  ctx.strokeStyle = "rgba(110,45,10,.65)";
  ctx.lineWidth = 1.3;
  ctx.stroke();
  ctx.fillStyle = "rgba(255,255,255,.35)";
  ctx.beginPath();
  ctx.arc(x - 1.5, y - 1.8, 1.6, 0, 7);
  ctx.fill();
}
/* vektörel kazma: sap + çelik başlık (sivri uç ileri bakar) */
function drawPickaxe(px, py, rot) {
  drawHoe(px, py, rot);
}
/* vektörel çapa: uzun ahşap sap + öne bakan geniş çelik ağız */
function drawHoe(px, py, rot) {
  ctx.save();
  ctx.translate(px, py);
  ctx.rotate(rot);
  ctx.scale(1.4, 1.4);
  const wg = ctx.createLinearGradient(-2.2, 0, 2.2, 0);
  wg.addColorStop(0, "#8a5a2b");
  wg.addColorStop(0.5, "#d39a58");
  wg.addColorStop(1, "#6e4320");
  ctx.fillStyle = wg;
  rrp(-2.2, -28, 4.4, 44, 2);
  ctx.fill();
  ctx.strokeStyle = "rgba(60,30,10,.6)";
  ctx.lineWidth = 0.9;
  ctx.stroke();
  ctx.strokeStyle = "rgba(80,45,15,.45)";
  ctx.lineWidth = 0.7;
  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.moveTo(-1.4, -20 + i * 7);
    ctx.lineTo(1, -16 + i * 7);
    ctx.stroke();
  }
  ctx.fillStyle = "#2a2f3f";
  rrp(-2.8, 6, 5.6, 9, 1.5);
  ctx.fill(); // kauçuk tutamak
  ctx.fillStyle = "#7a8299";
  rrp(-3.6, -31, 7.2, 6, 1.5);
  ctx.fill(); // bağlantı bileziği
  ctx.fillStyle = "#3f475f";
  ctx.beginPath();
  ctx.arc(0, -28, 1.1, 0, 7);
  ctx.fill();
  const sg = ctx.createLinearGradient(2, -34, 18, -14);
  sg.addColorStop(0, "#f1f4fa");
  sg.addColorStop(0.45, "#a7b0c8");
  sg.addColorStop(1, "#5c6684");
  ctx.fillStyle = sg;
  ctx.beginPath(); // boyun + geniş ağız
  ctx.moveTo(3, -31);
  ctx.quadraticCurveTo(10, -33, 13, -28);
  ctx.lineTo(19, -27);
  ctx.lineTo(21, -13);
  ctx.quadraticCurveTo(14, -11, 9, -13);
  ctx.lineTo(10, -26);
  ctx.quadraticCurveTo(7, -28, 3, -27);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "#3f475f";
  ctx.lineWidth = 1.1;
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,.75)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(10, -13.4);
  ctx.quadraticCurveTo(15, -12, 20.6, -13.6);
  ctx.stroke(); // bilenmiş kenar
  ctx.fillStyle = "rgba(255,255,255,.35)";
  ctx.beginPath();
  ctx.moveTo(13, -26);
  ctx.lineTo(17, -25.6);
  ctx.lineTo(18, -17);
  ctx.lineTo(14, -17);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "rgba(140,80,50,.55)";
  ctx.beginPath();
  ctx.ellipse(16, -14.6, 3.5, 1.2, 0, 0, 7);
  ctx.fill(); // toprak izi
  ctx.restore();
}

function astronaut(x, y, running, heldKey, actionT) {
  const t = performance.now() / 1000,
    ph = p.t,
    walk = p.walk;
  const S = CFG.legSwing * walk * (running ? 1.3 : 1);
  const bob = Math.abs(Math.sin(ph)) * 2.6 * walk; // adımda yukarı-aşağı
  const breathe = Math.sin(t * 2.4) * (1 - walk); // dururken nefes
  let lean = running ? 0.14 * walk : 0; // koşuda öne eğilme
  if (p.action === "mine" && actionT > 0) {
    // kazmayla vururken belden bükülme: kaldırırken geriye, vururken öne
    const pr = 1 - Math.min(1, actionT / (p.actionDur || 0.62)),
      E = (v) => v * v * (3 - 2 * v);
    lean =
      pr < 0.4
        ? -0.16 * E(pr / 0.4)
        : pr < 0.46
          ? -0.16
          : pr < 0.56
            ? -0.16 + 0.62 * ((pr - 0.46) / 0.1)
            : pr < 0.72
              ? 0.46
              : 0.46 * (1 - E((pr - 0.72) / 0.28));
  }
  const hpLow = !!(game && game.hp < 35);
  const storm = stormFx.I > 0.25 || !!(game && game.radiationActive && !insideRocket);
  const dig = heldKey === "pickaxe" || heldKey === "pick",
    acting = actionT > 0 && !dig;
  const prog = acting ? 1 - Math.min(1, actionT / (p.actionDur || 0.9)) : 0;
  const raise = !acting ? 0 : prog < 0.2 ? prog / 0.2 : prog > 0.85 ? (1 - prog) / 0.15 : 1; // kolu kaldır-tut-indir
  const blink = Math.sin(t * 6) > 0;

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(p.dir * p.sx, p.sy);
  // gölge
  if (!(ASTRO_POSE && ASTRO_POSE.ns)) {
    ctx.fillStyle = "rgba(0,0,0,.32)";
    ctx.beginPath();
    ctx.ellipse(0, 44, 24 - bob * 0.8, 7 - bob * 0.3, 0, 0, 7);
    ctx.fill();
  }
  // kask lambası: fırtına/radyasyonda zemine ışık konisi
  if (storm) {
    ctx.fillStyle = "rgba(255,230,160," + (0.09 + Math.sin(t * 9) * 0.02) + ")";
    ctx.beginPath();
    ctx.moveTo(6, -56);
    ctx.lineTo(110, -6);
    ctx.lineTo(110, 34);
    ctx.closePath();
    ctx.fill();
  }
  ctx.translate(0, -bob);

  // --- bacaklar
  drawLeg(-3, 16, ph + Math.PI, S, true);
  drawLeg(3, 16, ph, S, false);

  // --- üst gövde (kalçadan eğilir)
  ctx.save();
  ctx.translate(0, 16);
  ctx.rotate(lean);
  ctx.translate(0, -16 - breathe * 0.5);

  // kol planı: önce hedefler hesaplanır, çizim sırası korunur
  let drawBackArm,
    drawFrontArm,
    drawItem = null;
  if (dig) {
    // dururken: omuzda hafif nefes salınımı · yürürken: adımla birlikte sallanır
    const idle =
      Math.sin(ph) * 0.13 * walk +
      (running ? Math.sin(ph * 2) * 0.08 : 0) +
      breathe * 0.035 +
      Math.sin(t * 1.3) * 0.02 * (1 - walk);
    let rot = 0.6 + idle,
      px = 4 + Math.sin(ph) * 2 * walk,
      py = 6 + Math.abs(Math.cos(ph)) * 1.6 * walk + breathe * 0.6;
    if (actionT > 0 && p.action === "dig") {
      const pr = 1 - Math.min(1, actionT / (p.actionDur || 1)),
        E = (v) => v * v * (3 - 2 * v);
      if (pr < 0.36) {
        const q = E(pr / 0.36);
        rot = 0.6 + (-1.05 - 0.6) * q;
        px = 4 - 4 * q;
        py = 6 - 12 * q;
      } // geriye, baş üstüne kaldır
      else if (pr < 0.44) {
        const q = (pr - 0.36) / 0.08;
        rot = -1.05 - 0.07 * Math.sin(q * Math.PI);
        px = 0;
        py = -6;
      } // tepe noktasında kısa bekleme
      else if (pr < 0.55) {
        const q = (pr - 0.44) / 0.11;
        rot = -1.05 + (1.85 + 1.05) * q * q;
        px = 12 * q;
        py = -6 + 18 * q;
      } // ivmeli, sert iniş
      else if (pr < 0.67) {
        const q = (pr - 0.55) / 0.12;
        rot = 1.85 - 0.09 * Math.sin(q * Math.PI * 3) * (1 - q);
        px = 12;
        py = 12;
      } // toprağa saplanma titreşimi
      else {
        const q = E((pr - 0.67) / 0.33);
        rot = 1.85 + (0.6 - 1.85) * q + 0.25 * Math.sin(q * Math.PI);
        px = 12 - 8 * q;
        py = 12 - 6 * q;
      } // toprağı çekip geri al
    }
    if (actionT > 0 && p.action === "mine") {
      // kazma: başın üstünden tam savurma → taşa sert vuruş
      const pr = 1 - Math.min(1, actionT / (p.actionDur || 0.62)),
        E = (v) => v * v * (3 - 2 * v);
      if (pr < 0.4) {
        const q = E(pr / 0.4);
        rot = 0.5 + (-1.45 - 0.5) * q;
        px = 4 - 7 * q;
        py = 4 - 14 * q;
      } else if (pr < 0.46) {
        rot = -1.45 - 0.05 * Math.sin(((pr - 0.4) / 0.06) * Math.PI);
        px = -3;
        py = -10;
      } else if (pr < 0.56) {
        const q = (pr - 0.46) / 0.1;
        rot = -1.45 + (1.5 + 1.45) * q * q;
        px = -3 + 19 * q;
        py = -10 + 22 * q;
      } else if (pr < 0.72) {
        const q = (pr - 0.56) / 0.16;
        rot = 1.5 - 0.12 * Math.sin(q * Math.PI * 4) * (1 - q);
        px = 16;
        py = 12;
      } else {
        const q = E((pr - 0.72) / 0.28);
        rot = 1.5 + (0.5 - 1.5) * q;
        px = 16 - 12 * q;
        py = 12 - 8 * q;
      }
    }
    const g1 = rotP(0, 3, rot),
      g2 = rotP(0, -14, rot);
    const h1 = { x: px + g1.x, y: py + g1.y },
      h2 = { x: px + g2.x, y: py + g2.y };
    drawBackArm = () => {
      const k = ik2(-11, -13, h2.x, h2.y, 13, 12, 1);
      armSegs(-11, -13, k.ex, k.ey, k.hx, k.hy, true);
    };
    drawFrontArm = () => {
      const k = ik2(11, -13, h1.x, h1.y, 13, 12, 1);
      armSegs(11, -13, k.ex, k.ey, k.hx, k.hy, false);
    };
    drawItem = () => {
      if (heldKey === "pick") drawGeoPick(ctx, px, py, rot);
      else drawPickaxe(px, py, rot);
      glove(h2.x, h2.y, true);
      glove(h1.x, h1.y, false);
    };
  } else {
    const swing = Math.sin(ph) * S * 0.85;
    const bendB = 0.3 + Math.max(0, Math.sin(ph)) * 0.4,
      bendF = 0.3 + Math.max(0, -Math.sin(ph)) * 0.4;
    drawBackArm = () => {
      const h = drawArm(-11, -13, swing - 0.1, bendB, true);
      glove(h.hx, h.hy, true);
    };
    if (heldKey) {
      const rest = { x: 19, y: 3 + Math.sin(ph) * 2 * walk + breathe * 0.6 },
        vis = { x: 11, y: -36 };
      const hx = rest.x + (vis.x - rest.x) * raise,
        hy = rest.y + (vis.y - rest.y) * raise;
      drawFrontArm = () => {
        const k = ik2(11, -13, hx, hy, 13, 12, 1);
        armSegs(11, -13, k.ex, k.ey, k.hx, k.hy, false);
        glove(k.hx, k.hy, false);
      };
      drawItem = () => {
        ctx.save();
        ctx.translate(hx + 3, hy - 8);
        drawHeldArt(heldKey, acting, prog);
        ctx.restore();
      };
    } else {
      drawFrontArm = () => {
        const h = drawArm(11, -13, -swing + 0.1, bendF, false);
        glove(h.hx, h.hy, false);
      };
    }
  }

  // sırt çantası (yaşam destek ünitesi)
  const pg = ctx.createLinearGradient(-29, 0, -13, 0);
  pg.addColorStop(0, "#aab2cc");
  pg.addColorStop(1, "#dde2ee");
  ctx.fillStyle = pg;
  rrp(-29, -19, 16, 36, 5);
  ctx.fill();
  ctx.strokeStyle = SUIT.line;
  ctx.lineWidth = 1.6;
  ctx.stroke();
  for (const ty of [-14, -2]) {
    ctx.fillStyle = "#f0f2f8";
    rrp(-27, ty, 12, 9, 4);
    ctx.fill();
    ctx.strokeStyle = SUIT.dark;
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = ty < -10 ? "#38bdf8" : "#4ade80";
    ctx.fillRect(-27, ty + 3, 12, 2.2);
  }
  ctx.strokeStyle = "rgba(60,70,100,.5)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(-26, 9 + i * 2.2);
    ctx.lineTo(-16, 9 + i * 2.2);
    ctx.stroke();
  }
  ctx.fillStyle = blink ? "#4ade80" : "#1f6a38";
  ctx.beginPath();
  ctx.arc(-18, 14, 1.4, 0, 7);
  ctx.fill();
  if (game && game.kitCarried && !dig) {
    // çapa: elde değilken sırtta çapraz taşınır
    ctx.save();
    ctx.translate(-20, -4 + Math.sin(ph) * 1.2 * walk);
    ctx.rotate(-0.55 + Math.sin(ph) * 0.05 * walk);
    ctx.scale(0.62, 0.62);
    drawHoe(0, 0, 0);
    ctx.restore();
  }
  // hortum: çantadan kaska
  ctx.lineCap = "round";
  ctx.strokeStyle = "#b9c1d8";
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.moveTo(-24, -19);
  ctx.quadraticCurveTo(-31, -40, -15, -45);
  ctx.stroke();
  ctx.strokeStyle = "rgba(60,70,100,.5)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-24, -19);
  ctx.quadraticCurveTo(-31, -40, -15, -45);
  ctx.stroke();

  drawBackArm();

  // gövde
  const tg = ctx.createLinearGradient(-18, 0, 18, 0);
  tg.addColorStop(0, SUIT.white);
  tg.addColorStop(0.55, SUIT.light);
  tg.addColorStop(1, SUIT.shade);
  ctx.fillStyle = tg;
  rrp(-18, -24, 36, 44, 12);
  ctx.fill();
  ctx.strokeStyle = SUIT.line;
  ctx.lineWidth = 1.8;
  ctx.stroke();
  for (const s of [-1, 1]) {
    ctx.fillStyle = SUIT.orange;
    ctx.beginPath();
    ctx.ellipse(s * 13, -17, 7, 5, 0, 0, 7);
    ctx.fill();
    ctx.strokeStyle = SUIT.orangeD;
    ctx.lineWidth = 1;
    ctx.stroke();
  }
  ctx.strokeStyle = "rgba(95,104,134,.35)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-15, -6);
  ctx.quadraticCurveTo(0, -3, 15, -6);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-16, 4);
  ctx.quadraticCurveTo(0, 7, 16, 4);
  ctx.stroke();
  ctx.fillStyle = SUIT.orange;
  rrp(-18, 11, 36, 6, 2);
  ctx.fill();
  ctx.fillStyle = SUIT.navy;
  rrp(-4, 10, 8, 8, 2);
  ctx.fill();
  // göğüs kontrol paneli (canlı veri)
  ctx.fillStyle = SUIT.navy;
  rrp(-11, -13, 22, 15, 3.5);
  ctx.fill();
  ctx.strokeStyle = "#4a5580";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#0b1230";
  rrp(-8.5, -11, 11, 6, 1.5);
  ctx.fill();
  const hpF = game ? game.hp / 100 : 1,
    o2F = game ? game.thirst / 100 : 1;
  ctx.fillStyle = hpF < 0.35 ? "#ff5a5a" : "#4ade80";
  ctx.fillRect(-7.5, -10, 9 * hpF, 1.6);
  ctx.fillStyle = "#38bdf8";
  ctx.fillRect(-7.5, -7.6, 9 * o2F, 1.6);
  ctx.fillStyle = hpLow && blink ? "#ff3b3b" : hpLow ? "#5a1a1a" : "#4ade80";
  ctx.beginPath();
  ctx.arc(5.5, -9.5, 1.8, 0, 7);
  ctx.fill();
  if (hpLow && blink) {
    ctx.fillStyle = "rgba(255,60,60,.35)";
    ctx.beginPath();
    ctx.arc(5.5, -9.5, 4.5, 0, 7);
    ctx.fill();
  }
  ctx.fillStyle = Math.sin(t * 3) > 0 ? "#ffd34d" : "#7a5a1a";
  ctx.beginPath();
  ctx.arc(5.5, -5, 1.8, 0, 7);
  ctx.fill();
  ctx.fillStyle = "#8d96b8";
  for (const bx of [-8, -4, 0]) ctx.fillRect(bx, -3.2, 2.6, 2.2);
  // görev rozeti
  ctx.fillStyle = "#ff5a4a";
  ctx.beginPath();
  ctx.arc(13, -3, 3.2, 0, 7);
  ctx.fill();
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(13, -3, 1.2, 0, 7);
  ctx.fill();
  suitDecoTorso(t);
  suitDecoShoulders();

  // boyun halkası + kask
  ctx.fillStyle = SUIT.steel;
  rrp(-9, -29, 18, 8, 3);
  ctx.fill();
  ctx.strokeStyle = SUIT.line;
  ctx.lineWidth = 1.2;
  ctx.stroke();
  const headTilt =
    Math.sin(ph * 0.5) * 0.04 * walk +
    (acting ? -0.1 * raise : 0) +
    (running ? 0.08 * walk : 0) +
    Math.sin(t * 0.7) * 0.02 * (1 - walk);
  ctx.save();
  ctx.translate(2, -40);
  ctx.rotate(headTilt);
  const hg = ctx.createRadialGradient(-7, -8, 3, 0, 0, 22);
  hg.addColorStop(0, SUIT.white);
  hg.addColorStop(0.7, SUIT.light);
  hg.addColorStop(1, SUIT.shade);
  ctx.fillStyle = hg;
  ctx.beginPath();
  ctx.arc(0, 0, 20, 0, 7);
  ctx.fill();
  ctx.strokeStyle = SUIT.line;
  ctx.lineWidth = 2;
  ctx.stroke();
  // vizör (altın kaplama, yansımalı)
  const vg = ctx.createLinearGradient(-6, -12, 16, 10);
  vg.addColorStop(0, SUITX.visor[0]);
  vg.addColorStop(0.35, SUITX.visor[1]);
  vg.addColorStop(0.7, SUITX.visor[2]);
  vg.addColorStop(1, SUITX.visor[3]);
  ctx.fillStyle = vg;
  ctx.beginPath();
  ctx.ellipse(6, 0, 13.5, 11.5, 0, 0, 7);
  ctx.fill();
  ctx.strokeStyle = "#aab1cf";
  ctx.lineWidth = 2.2;
  ctx.stroke();
  ctx.strokeStyle = SUITX.trim;
  ctx.lineWidth = 0.9;
  ctx.beginPath();
  ctx.ellipse(6, 0, 12, 10, 0, 0, 7);
  ctx.stroke();
  ctx.save();
  ctx.beginPath();
  ctx.ellipse(6, 0, 13, 11, 0, 0, 7);
  ctx.clip();
  const sh = Math.sin(t * 0.9) * 2; // yansıma yavaşça kayar
  ctx.fillStyle = PLANETS[scene] ? PLANETS[scene].ground : "#b3392a";
  ctx.globalAlpha = 0.3;
  ctx.fillRect(-10, 5, 30, 8);
  ctx.globalAlpha = 1;
  ctx.fillStyle = "rgba(255,255,255,.7)";
  ctx.beginPath();
  ctx.ellipse(2 + sh * 0.3, -5.5, 5, 2.8, -0.55, 0, 7);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.45)";
  ctx.lineWidth = 1.3;
  ctx.beginPath();
  ctx.moveTo(-3 + sh, 6);
  ctx.lineTo(10 + sh, -8);
  ctx.stroke();
  ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.moveTo(1 + sh, 8);
  ctx.lineTo(13 + sh, -4);
  ctx.stroke();
  for (const [gx, gy] of [
    [12, -2],
    [9, 5],
  ]) {
    ctx.fillStyle = "rgba(255,255,255," + (0.6 + 0.4 * Math.sin(t * 3 + gx)) + ")";
    ctx.beginPath();
    ctx.arc(gx, gy, 0.9, 0, 7);
    ctx.fill();
  }
  ctx.restore();
  // kask lambası
  ctx.fillStyle = SUIT.steel;
  rrp(-6, -22, 10, 5, 2);
  ctx.fill();
  ctx.fillStyle = storm ? "#fff3b0" : "#ffe08a";
  ctx.beginPath();
  ctx.arc(2, -19.5, 2, 0, 7);
  ctx.fill();
  if (storm) {
    const lg = ctx.createRadialGradient(2, -19.5, 1, 2, -19.5, 14);
    lg.addColorStop(0, "rgba(255,235,170,.55)");
    lg.addColorStop(1, "rgba(255,235,170,0)");
    ctx.fillStyle = lg;
    ctx.beginPath();
    ctx.arc(2, -19.5, 14, 0, 7);
    ctx.fill();
  }
  // yan iletişim kutusu + anten
  ctx.fillStyle = SUIT.steel;
  rrp(-21, -4, 6, 9, 2);
  ctx.fill();
  ctx.strokeStyle = SUIT.line;
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.strokeStyle = "#c3c9e0";
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(-14, -14);
  ctx.lineTo(-19, -25);
  ctx.stroke();
  ctx.fillStyle = Math.sin(t * 4) > 0 ? "#ff5a5a" : "#7a2a2a";
  ctx.beginPath();
  ctx.arc(-19.5, -26, 2.4, 0, 7);
  ctx.fill();
  suitDecoHelmet(t);
  ctx.restore(); // kask

  drawFrontArm();
  if (drawItem) drawItem();
  ctx.restore(); // üst gövde
  ctx.restore();
}

/* ============== ROKET — ortak gövde modeli (oyun içi + sinematik) ============== */
function rocketBody(o) {
  const t = o.t != null ? o.t : performance.now() / 1000;
  const flame = Math.max(0, o.flame || 0),
    broken = !!o.broken,
    rep = o.repairing;
  // --- motor alevleri (3 nozul)
  if (flame > 0.01) {
    for (const [nx, k] of [
      [-13, 0.68],
      [13, 0.68],
      [0, 1],
    ]) {
      const L = flame * (40 + Math.random() * 16) * k,
        w = 10 * k;
      const gl = ctx.createRadialGradient(nx, 38, 2, nx, 38, L * 0.8);
      gl.addColorStop(0, "rgba(255,170,80,.45)");
      gl.addColorStop(1, "rgba(255,120,40,0)");
      ctx.fillStyle = gl;
      ctx.beginPath();
      ctx.arc(nx, 38, L * 0.8, 0, 7);
      ctx.fill();
      const fg = ctx.createLinearGradient(0, 36, 0, 36 + L);
      fg.addColorStop(0, "#ffb347");
      fg.addColorStop(0.5, "#ff7a2a");
      fg.addColorStop(1, "rgba(255,80,20,0)");
      ctx.fillStyle = fg;
      ctx.beginPath();
      ctx.moveTo(nx - w, 36);
      ctx.quadraticCurveTo(nx - w * 1.2, 36 + L * 0.45, nx, 36 + L);
      ctx.quadraticCurveTo(nx + w * 1.2, 36 + L * 0.45, nx + w, 36);
      ctx.closePath();
      ctx.fill();
      const ig = ctx.createLinearGradient(0, 36, 0, 36 + L * 0.65);
      ig.addColorStop(0, "#ffffff");
      ig.addColorStop(0.4, "#ffe9a8");
      ig.addColorStop(1, "rgba(255,220,120,0)");
      ctx.fillStyle = ig;
      ctx.beginPath();
      ctx.moveTo(nx - w * 0.5, 36);
      ctx.quadraticCurveTo(nx - w * 0.6, 36 + L * 0.3, nx, 36 + L * 0.65);
      ctx.quadraticCurveTo(nx + w * 0.6, 36 + L * 0.3, nx + w * 0.5, 36);
      ctx.closePath();
      ctx.fill();
      if (flame > 0.6 && k === 1) {
        ctx.fillStyle = "rgba(255,255,255,.55)";
        for (let i = 1; i <= 3; i++) {
          ctx.beginPath();
          ctx.ellipse(nx, 36 + L * 0.18 * i, w * 0.28, w * 0.14, 0, 0, 7);
          ctx.fill();
        }
      }
    }
  }
  // --- arka merkez kanat
  ctx.fillStyle = RSK.cfin;
  ctx.beginPath();
  ctx.moveTo(-6, 10);
  ctx.lineTo(6, 10);
  ctx.lineTo(4, 44);
  ctx.lineTo(-4, 44);
  ctx.closePath();
  ctx.fill();
  // --- gövde
  const hull = () => {
    ctx.beginPath();
    ctx.moveTo(0, -78);
    ctx.quadraticCurveTo(26, -40, 24, 30);
    ctx.lineTo(24, 34);
    ctx.lineTo(-24, 34);
    ctx.lineTo(-24, 30);
    ctx.quadraticCurveTo(-26, -40, 0, -78);
    ctx.closePath();
  };
  const bg = ctx.createLinearGradient(-26, 0, 26, 0);
  bg.addColorStop(0, RSK.hull[0]);
  bg.addColorStop(0.3, RSK.hull[1]);
  bg.addColorStop(0.7, RSK.hull[2]);
  bg.addColorStop(1, RSK.hull[3]);
  ctx.fillStyle = bg;
  hull();
  ctx.fill();
  ctx.save();
  hull();
  ctx.clip();
  ctx.strokeStyle = "rgba(70,78,110,.35)";
  ctx.lineWidth = 1.2;
  for (const py of [-46, -20, 20]) {
    ctx.beginPath();
    ctx.moveTo(-26, py);
    ctx.quadraticCurveTo(0, py + 3, 26, py);
    ctx.stroke();
  }
  ctx.fillStyle = "rgba(60,68,100,.5)";
  for (const py of [-44, -18, 22])
    for (let rx = -20; rx <= 20; rx += 8) {
      ctx.beginPath();
      ctx.arc(rx, py + (1 - Math.abs(rx) / 26) * 2.6, 0.9, 0, 7);
      ctx.fill();
    }
  // burun konisi
  const ng2 = ctx.createLinearGradient(-14, 0, 14, 0);
  ng2.addColorStop(0, RSK.nose[0]);
  ng2.addColorStop(0.45, RSK.nose[1]);
  ng2.addColorStop(1, RSK.nose[2]);
  ctx.fillStyle = ng2;
  ctx.beginPath();
  ctx.moveTo(0, -80);
  ctx.quadraticCurveTo(14, -66, 16, -52);
  ctx.lineTo(-16, -52);
  ctx.quadraticCurveTo(-14, -66, 0, -80);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#3b4260";
  ctx.fillRect(-18, -53, 36, 3);
  // renk bandı + isim + rozet
  ctx.fillStyle = RSK.band;
  ctx.fillRect(-26, -10, 52, 8);
  ctx.fillStyle = "#232b4d";
  ctx.fillRect(-26, -2, 52, 1.8);
  ctx.save();
  ctx.translate(-16, 10);
  ctx.rotate(-Math.PI / 2);
  ctx.font = "700 6.5px 'Segoe UI',sans-serif";
  ctx.textAlign = "center";
  ctx.fillStyle = RSK.text;
  ctx.fillText("ARES-1", 0, 0);
  ctx.restore();
  ctx.fillStyle = "#232b4d";
  ctx.fillRect(12, -18, 8, 6);
  ctx.fillStyle = "#ff5a4a";
  ctx.fillRect(12, -15, 8, 1.2);
  ctx.fillStyle = "#fff";
  ctx.fillRect(12, -17, 8, 0.8);
  ctx.fillStyle = "#2d3246";
  for (const rx of [-9, 9]) {
    ctx.beginPath();
    ctx.arc(rx, -49, 1.6, 0, 7);
    ctx.fill();
  } // RCS iticiler
  const sm = ctx.createLinearGradient(0, 12, 0, 34);
  sm.addColorStop(0, "rgba(40,30,30,0)");
  sm.addColorStop(1, "rgba(40,30,30,.45)");
  ctx.fillStyle = sm;
  ctx.fillRect(-26, 12, 52, 22);
  ctx.strokeStyle = "rgba(255,255,255,.6)";
  ctx.lineWidth = 2.2;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(-13, -56);
  ctx.quadraticCurveTo(-20, -14, -17, 24);
  ctx.stroke();
  rocketDecoInside(t);
  ctx.restore();
  ctx.strokeStyle = RSK.line;
  ctx.lineWidth = 2;
  hull();
  ctx.stroke();
  // --- yan kanatlar
  const fin = (sx) => {
    ctx.beginPath();
    ctx.moveTo(sx * 22, 4);
    ctx.lineTo(sx * 44, 42);
    ctx.lineTo(sx * 42, 46);
    ctx.lineTo(sx * 18, 34);
    ctx.closePath();
  };
  for (const sx of [-1, 1]) {
    ctx.save();
    if (broken && sx === -1) {
      ctx.translate(-22, 6);
      ctx.rotate(-0.45);
      ctx.translate(22, -6);
    }
    const fg = ctx.createLinearGradient(sx * 18, 10, sx * 44, 44);
    fg.addColorStop(0, RSK.fin[0]);
    fg.addColorStop(1, RSK.fin[1]);
    ctx.fillStyle = fg;
    fin(sx);
    ctx.fill();
    ctx.strokeStyle = RSK.finLine;
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,.35)";
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(sx * 24, 10);
    ctx.lineTo(sx * 40, 40);
    ctx.stroke();
    if (broken && sx === -1) {
      ctx.fillStyle = "rgba(20,10,10,.55)";
      ctx.beginPath();
      ctx.ellipse(-34, 34, 8, 5, 0.6, 0, 7);
      ctx.fill();
    }
    ctx.restore();
  }
  // --- motor eteği + nozullar
  const sk = ctx.createLinearGradient(-27, 0, 27, 0);
  sk.addColorStop(0, "#7d849e");
  sk.addColorStop(0.5, "#4a5068");
  sk.addColorStop(1, "#2d3246");
  ctx.fillStyle = sk;
  ctx.beginPath();
  ctx.moveTo(-24, 22);
  ctx.lineTo(24, 22);
  ctx.lineTo(27, 36);
  ctx.lineTo(-27, 36);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "#20243a";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,.12)";
  ctx.lineWidth = 1;
  for (let i = -20; i <= 20; i += 8) {
    ctx.beginPath();
    ctx.moveTo(i, 23);
    ctx.lineTo(i * 1.12, 35);
    ctx.stroke();
  }
  for (const [nx, k] of [
    [-13, 0.7],
    [13, 0.7],
    [0, 1],
  ]) {
    const w1 = 5 * k,
      w2 = 8.5 * k,
      y0 = 35,
      y1 = 35 + 10 * k;
    const ng = ctx.createLinearGradient(nx - w2, 0, nx + w2, 0);
    ng.addColorStop(0, "#c3c9dc");
    ng.addColorStop(0.5, "#5b6178");
    ng.addColorStop(1, "#23283b");
    ctx.fillStyle = ng;
    ctx.beginPath();
    ctx.moveTo(nx - w1, y0);
    ctx.lineTo(nx + w1, y0);
    ctx.lineTo(nx + w2, y1);
    ctx.lineTo(nx - w2, y1);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#15182a";
    ctx.lineWidth = 1.2;
    ctx.stroke();
    if (flame > 0.01) {
      ctx.fillStyle = "rgba(255,200,120," + (0.5 * flame).toFixed(2) + ")";
      ctx.beginPath();
      ctx.ellipse(nx, y1, w2 * 0.8, 1.6, 0, 0, 7);
      ctx.fill();
    }
  }
  // --- pencere (kabin ışıklı)
  const wr = ctx.createLinearGradient(-13, -43, 13, -17);
  wr.addColorStop(0, "#f3f5fb");
  wr.addColorStop(1, "#7a829f");
  ctx.fillStyle = wr;
  ctx.beginPath();
  ctx.arc(0, -30, 15, 0, 7);
  ctx.fill();
  ctx.strokeStyle = "#4a5170";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  const wg = ctx.createRadialGradient(-4, -34, 2, 0, -30, 12);
  wg.addColorStop(0, "#d8f3ff");
  wg.addColorStop(0.5, "#3f8fd8");
  wg.addColorStop(1, "#13335c");
  ctx.fillStyle = wg;
  ctx.beginPath();
  ctx.arc(0, -30, 11.5, 0, 7);
  ctx.fill();
  ctx.save();
  ctx.beginPath();
  ctx.arc(0, -30, 11.5, 0, 7);
  ctx.clip();
  if (!broken) {
    ctx.fillStyle = "rgba(255,220,150," + (0.22 + 0.1 * Math.sin(t * 2)).toFixed(2) + ")";
    ctx.beginPath();
    ctx.arc(3, -27, 6, 0, 7);
    ctx.fill();
  }
  ctx.strokeStyle = "rgba(255,255,255,.55)";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-8, -22);
  ctx.lineTo(4, -39);
  ctx.stroke();
  ctx.lineWidth = 0.8;
  ctx.beginPath();
  ctx.moveTo(-4, -20);
  ctx.lineTo(8, -36);
  ctx.stroke();
  ctx.restore();
  ctx.fillStyle = "#3b4260";
  for (let i = 0; i < 6; i++) {
    const a = (i * Math.PI) / 3 + 0.3;
    ctx.beginPath();
    ctx.arc(Math.cos(a) * 13.4, -30 + Math.sin(a) * 13.4, 1, 0, 7);
    ctx.fill();
  }
  // --- kapak + merdiven
  const hg = ctx.createLinearGradient(-9, 0, 9, 0);
  hg.addColorStop(0, "#dfe3ef");
  hg.addColorStop(1, "#a3abc6");
  ctx.fillStyle = hg;
  rrp(-9, -1, 18, 20, 4);
  ctx.fill();
  ctx.strokeStyle = "#4a5170";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.fillStyle = "#1b2a4a";
  rrp(-5, 2, 10, 6, 2);
  ctx.fill();
  ctx.strokeStyle = "#7a829f";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#ffb347";
  rrp(-2, 11, 4, 5, 1);
  ctx.fill();
  ctx.fillStyle = "#6f7698";
  for (const hy of [2, 15]) ctx.fillRect(-9.5, hy, 2, 2.5);
  ctx.strokeStyle = "rgba(60,68,100,.55)";
  ctx.lineWidth = 1.2;
  for (let i = 0; i < 4; i++) {
    ctx.beginPath();
    ctx.moveTo(12, 2 + i * 5);
    ctx.lineTo(19, 2 + i * 5);
    ctx.stroke();
  }
  rocketDecoOutside(t);
  // --- anten + uyarı ışığı
  ctx.strokeStyle = "#c3c9e0";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(0, -80);
  ctx.lineTo(0, -92);
  ctx.stroke();
  const bl = Math.sin(t * 5) > 0;
  ctx.fillStyle = bl ? "#ff5a5a" : "#6a2222";
  ctx.beginPath();
  ctx.arc(0, -93, 2.2, 0, 7);
  ctx.fill();
  if (bl) {
    ctx.fillStyle = "rgba(255,90,90,.25)";
    ctx.beginPath();
    ctx.arc(0, -93, 6, 0, 7);
    ctx.fill();
  }
  // --- hasar katmanı
  if (broken) {
    ctx.save();
    hull();
    ctx.clip();
    for (const [sx, sy, r] of [
      [12, -10, 16],
      [-14, 16, 12],
      [6, -50, 9],
    ]) {
      const g = ctx.createRadialGradient(sx, sy, 1, sx, sy, r);
      g.addColorStop(0, "rgba(20,16,20,.7)");
      g.addColorStop(1, "rgba(20,16,20,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(sx, sy, r, 0, 7);
      ctx.fill();
    }
    ctx.fillStyle = "#6f7698";
    ctx.beginPath();
    ctx.moveTo(10, -14);
    ctx.lineTo(22, -18);
    ctx.lineTo(24, -4);
    ctx.lineTo(14, 0);
    ctx.lineTo(8, -6);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#2a3047";
    ctx.beginPath();
    ctx.moveTo(13, -12);
    ctx.lineTo(21, -15);
    ctx.lineTo(22, -6);
    ctx.lineTo(15, -3);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(30,34,52,.85)";
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(14, 0);
    ctx.lineTo(10, 8);
    ctx.lineTo(13, 14);
    ctx.lineTo(8, 22);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(-12, -40);
    ctx.lineTo(-8, -34);
    ctx.lineTo(-12, -28);
    ctx.stroke();
    ctx.restore();
    // sarkan kablo + kıvılcım
    const wx = 28 + Math.sin(t * 3) * 1.5;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#2a2f45";
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(22, -6);
    ctx.bezierCurveTo(30, 4, 26, 14, wx, 22);
    ctx.stroke();
    ctx.strokeStyle = "#ffb347";
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.moveTo(22, -5);
    ctx.bezierCurveTo(29, 4, 25, 14, wx - 1, 21);
    ctx.stroke();
    if (Math.sin(t * 23) > 0.75) {
      ctx.fillStyle = "#fff6c0";
      ctx.beginPath();
      ctx.arc(wx, 22, 2.6, 0, 7);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,230,140,.9)";
      ctx.lineWidth = 1;
      for (let i = 0; i < 4; i++) {
        const a = t * 40 + i * 1.6;
        ctx.beginPath();
        ctx.moveTo(wx, 22);
        ctx.lineTo(wx + Math.cos(a) * 6, 22 + Math.sin(a) * 6);
        ctx.stroke();
      }
    }
    // yerinden çıkmış panel
    ctx.save();
    ctx.translate(-20, -20);
    ctx.rotate(0.5 + Math.sin(t * 2) * 0.03);
    ctx.fillStyle = "#c5ccdf";
    ctx.fillRect(0, 0, 9, 12);
    ctx.strokeStyle = "#4a5170";
    ctx.lineWidth = 1;
    ctx.strokeRect(0, 0, 9, 12);
    ctx.restore();
  }
  // --- tamir iskelesi + kaynak
  if (rep != null && rep !== false) {
    ctx.strokeStyle = "#c9a23a";
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(30, 34);
    ctx.lineTo(30, -40);
    ctx.moveTo(40, 34);
    ctx.lineTo(40, -40);
    ctx.stroke();
    ctx.lineWidth = 1.2;
    for (let yy = -40; yy < 34; yy += 14) {
      ctx.beginPath();
      ctx.moveTo(30, yy);
      ctx.lineTo(40, yy + 14);
      ctx.moveTo(40, yy);
      ctx.lineTo(30, yy + 14);
      ctx.moveTo(26, yy);
      ctx.lineTo(40, yy);
      ctx.stroke();
    }
    const wy = 24 - 64 * Math.min(1, rep),
      wx = 24;
    ctx.fillStyle = "rgba(120,220,160,.18)";
    ctx.fillRect(-24, wy, 48, 24 - wy);
    if (Math.sin(t * 31) > -0.2) {
      ctx.fillStyle = "#fffbe0";
      ctx.beginPath();
      ctx.arc(wx, wy, 2.2 + Math.random() * 1.5, 0, 7);
      ctx.fill();
      const g = ctx.createRadialGradient(wx, wy, 1, wx, wy, 16);
      g.addColorStop(0, "rgba(180,220,255,.6)");
      g.addColorStop(1, "rgba(180,220,255,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(wx, wy, 16, 0, 7);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,210,120,.9)";
      ctx.lineWidth = 1;
      for (let i = 0; i < 5; i++) {
        const a = Math.random() * 6.28,
          l = 4 + Math.random() * 9;
        ctx.beginPath();
        ctx.moveTo(wx, wy);
        ctx.lineTo(wx + Math.cos(a) * l, wy + Math.sin(a) * l);
        ctx.stroke();
      }
    }
  }
}

function drawRocket(x, y) {
  const t = performance.now() / 1000,
    PI = Math.PI;
  const rp = (game && game.repair) || { state: "ok", end: 0 };
  const broken = rp.state !== "ok",
    stg = broken ? rp.stage || 0 : 0,
    repairing = broken && stg > 0;
  const repProg = repairing ? stg / 4 : false;

  /* --- iniş platformu --- */
  ctx.save();
  ctx.translate(x, y + 58);
  ctx.fillStyle = "rgba(0,0,0,.32)";
  ctx.beginPath();
  ctx.arc(6, 8, 98, 0, 7);
  ctx.fill();
  const ag = ctx.createRadialGradient(-20, -24, 10, 0, 0, 96);
  ag.addColorStop(0, "#4a5069");
  ag.addColorStop(1, "#2b2f44");
  ctx.fillStyle = ag;
  ctx.beginPath();
  ctx.arc(0, 0, 94, 0, 7);
  ctx.fill();
  ctx.strokeStyle = "#aab3d6";
  ctx.lineWidth = 5;
  ctx.stroke();
  ctx.strokeStyle = "rgba(0,0,0,.25)";
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 6; i++) {
    const a = (i * PI) / 3;
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * 30, Math.sin(a) * 30);
    ctx.lineTo(Math.cos(a) * 92, Math.sin(a) * 92);
    ctx.stroke();
  }
  ctx.lineWidth = 7;
  ctx.strokeStyle = "#1b1e2e";
  ctx.beginPath();
  ctx.arc(0, 0, 80, 0, 7);
  ctx.stroke();
  ctx.strokeStyle = "#ffb347";
  ctx.setLineDash([13, 13]);
  ctx.lineDashOffset = -t * 10;
  ctx.beginPath();
  ctx.arc(0, 0, 80, 0, 7);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.lineDashOffset = 0;
  const ig = ctx.createRadialGradient(0, -10, 4, 0, 0, 64);
  ig.addColorStop(0, "#616887");
  ig.addColorStop(1, "#474d68");
  ctx.fillStyle = ig;
  ctx.beginPath();
  ctx.arc(0, 0, 64, 0, 7);
  ctx.fill();
  ctx.strokeStyle = "rgba(170,180,214,.6)";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,.22)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(0, 0, 40, 0, 7);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-52, 0);
  ctx.lineTo(52, 0);
  ctx.moveTo(0, -52);
  ctx.lineTo(0, 52);
  ctx.stroke();
  const sg = ctx.createRadialGradient(0, -8, 4, 0, -8, 34);
  sg.addColorStop(0, "rgba(15,12,18,.6)");
  sg.addColorStop(1, "rgba(15,12,18,0)");
  ctx.fillStyle = sg;
  ctx.beginPath();
  ctx.arc(0, -8, 34, 0, 7);
  ctx.fill();
  for (let i = 0; i < 8; i++) {
    const a = (i * PI) / 4,
      on = (Math.floor(t * 2.5) + i) % 2 === 0,
      lx = Math.cos(a) * 88,
      ly = Math.sin(a) * 88;
    if (on) {
      const g = ctx.createRadialGradient(lx, ly, 1, lx, ly, 12);
      g.addColorStop(0, "rgba(255,180,70,.55)");
      g.addColorStop(1, "rgba(255,180,70,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(lx, ly, 12, 0, 7);
      ctx.fill();
    }
    ctx.fillStyle = on ? "#ffd34d" : "#6a4a2a";
    ctx.beginPath();
    ctx.arc(lx, ly, 3.6, 0, 7);
    ctx.fill();
    ctx.strokeStyle = "#2b2f44";
    ctx.lineWidth = 1;
    ctx.stroke();
  }
  ctx.restore();

  /* --- servis kulesi (sağ) --- */
  ctx.save();
  ctx.translate(x + 70, y + 52);
  const tw = 14,
    th = 150;
  ctx.fillStyle = "#2b2f44";
  rrp(-12, -4, 24, 8, 2);
  ctx.fill();
  ctx.strokeStyle = "#9aa3bf";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-tw / 2, 0);
  ctx.lineTo(-tw / 2, -th);
  ctx.moveTo(tw / 2, 0);
  ctx.lineTo(tw / 2, -th);
  ctx.stroke();
  ctx.strokeStyle = "#6f7698";
  ctx.lineWidth = 1.5;
  for (let yy = 0; yy > -th; yy -= 18) {
    ctx.beginPath();
    ctx.moveTo(-tw / 2, yy);
    ctx.lineTo(tw / 2, yy - 18);
    ctx.moveTo(tw / 2, yy);
    ctx.lineTo(-tw / 2, yy - 18);
    ctx.moveTo(-tw / 2, yy);
    ctx.lineTo(tw / 2, yy);
    ctx.stroke();
  }
  ctx.fillStyle = "#aab3d6";
  rrp(-tw / 2 - 4, -108, tw + 8, 4, 1);
  ctx.fill();
  ctx.strokeStyle = "#aab3d6";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-tw / 2, -106);
  ctx.lineTo(-44, -96);
  ctx.stroke();
  ctx.strokeStyle = "#6f7698";
  ctx.lineWidth = 1.2;
  ctx.beginPath();
  ctx.moveTo(-tw / 2, -96);
  ctx.lineTo(-44, -96);
  ctx.stroke();
  // yakıt hortumu: hafif salınır
  const sw = Math.sin(t * 1.3) * 3;
  ctx.lineCap = "round";
  ctx.strokeStyle = "#ff8c42";
  ctx.lineWidth = 3.2;
  ctx.beginPath();
  ctx.moveTo(-44, -94);
  ctx.bezierCurveTo(-38 + sw, -72, -58 + sw, -66, -48, -52);
  ctx.stroke();
  ctx.strokeStyle = "rgba(0,0,0,.35)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(-44, -94);
  ctx.bezierCurveTo(-38 + sw, -72, -58 + sw, -66, -48, -52);
  ctx.stroke();
  ctx.fillStyle = "#3b4260";
  rrp(-51, -55, 6, 6, 1.5);
  ctx.fill();
  // durum ekranı
  const col = repairing ? "#ffd34d" : broken ? "#ff5a5a" : "#4ade80";
  ctx.fillStyle = "#0b1230";
  rrp(-9, -60, 18, 12, 2);
  ctx.fill();
  ctx.strokeStyle = "#3a4675";
  ctx.lineWidth = 1.2;
  ctx.stroke();
  for (let i = 0; i < 3; i++) {
    ctx.fillStyle = (broken ? Math.sin(t * 6 + i) > 0 : true) ? col : "#1a2140";
    ctx.fillRect(-6 + i * 4.5, -56, 3, 4);
  }
  // tepe feneri (dönen huzme)
  ctx.fillStyle = "#2b2f44";
  rrp(-5, -th - 8, 10, 8, 2);
  ctx.fill();
  ctx.save();
  ctx.translate(0, -th - 10);
  ctx.rotate(t * 2.4);
  const bg = ctx.createLinearGradient(0, 0, 38, 0);
  bg.addColorStop(0, "rgba(255,90,90,.45)");
  bg.addColorStop(1, "rgba(255,90,90,0)");
  ctx.fillStyle = bg;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(38, -7);
  ctx.lineTo(38, 7);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  ctx.fillStyle = "#ff5a5a";
  ctx.beginPath();
  ctx.arc(0, -th - 10, 3.4, 0, 7);
  ctx.fill();
  ctx.restore();

  /* --- iniş ayakları + roket gövdesi --- */
  ctx.save();
  ctx.translate(x, y);
  for (const sx of [-1, 1]) {
    ctx.lineCap = "round";
    ctx.strokeStyle = "#5b6178";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(sx * 20, 24);
    ctx.lineTo(sx * 40, 56);
    ctx.stroke();
    ctx.strokeStyle = "#c3c9dc";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(sx * 20, 24);
    ctx.lineTo(sx * 40, 56);
    ctx.stroke();
    ctx.strokeStyle = "#5b6178";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(sx * 27, 42);
    ctx.lineTo(sx * 23, 30);
    ctx.stroke();
    ctx.fillStyle = "#3b4260";
    ctx.beginPath();
    ctx.ellipse(sx * 41, 58, 9, 3.5, 0, 0, 7);
    ctx.fill();
  }
  const idle = broken || repairing ? 0 : 0.24 + Math.sin(t * 17) * 0.04;
  rocketBody({ flame: idle, broken, repairing: repProg, t });
  // kaza izi: tamir edilene kadar hasarlı bölgeden duman + kıvılcım + alev
  drawExSmoke(broken, repairing, t);
  ctx.restore();
}

/* ---------- roket dış duman sistemi: yumuşak, rüzgârla sürüklenen, yükseldikçe açılan duman ---------- */
const exSmoke = [],
  exEmb = [];
let exLast = 0,
  exAcc = 0,
  exBurstT = 0;
function drawExSmoke(broken, repairing, t) {
  const now = performance.now() / 1000,
    dt = Math.min(0.05, exLast ? now - exLast : 0);
  exLast = now;
  if (!broken && !exSmoke.length && !exEmb.length) return;
  const SI = Math.min(1, stormFx.I || 0),
    wx = Math.cos(stormFx.ang || 0) * (14 + SI * 150),
    HX = 16,
    HY = -10;
  const rate = broken ? (repairing ? 10 : 32) : 0;
  if (broken) {
    exAcc += dt * rate;
    exBurstT -= dt;
    if (exBurstT <= 0 && !repairing) {
      exBurstT = 2.5 + Math.random() * 3.5;
      exAcc += 9;
      for (let i = 0; i < 10; i++)
        exEmb.push({
          x: HX,
          y: HY,
          vx: (Math.random() - 0.3) * 90,
          vy: -60 - Math.random() * 110,
          l: 0,
          m: 0.6 + Math.random() * 0.7,
        });
    }
    while (exAcc > 1) {
      exAcc--;
      const dark = Math.random() < (repairing ? 0.25 : 0.7);
      exSmoke.push({
        x: HX + (Math.random() - 0.5) * 8,
        y: HY + (Math.random() - 0.5) * 6,
        vx: (Math.random() - 0.5) * 14 + 4,
        vy: -34 - Math.random() * 30,
        r: 5 + Math.random() * 5,
        l: 0,
        m: 4 + Math.random() * 3,
        dark,
        rot: Math.random() * 6,
        sp: (Math.random() - 0.5) * 0.8,
        seed: Math.random() * 9,
      });
    }
    if (!repairing && Math.random() < dt * 9)
      exEmb.push({
        x: HX + (Math.random() - 0.5) * 6,
        y: HY,
        vx: (Math.random() - 0.4) * 50,
        vy: -40 - Math.random() * 70,
        l: 0,
        m: 0.7 + Math.random() * 0.9,
      });
  }
  if (exSmoke.length > 140) exSmoke.splice(0, exSmoke.length - 140);
  if (broken && !repairing) {
    const fl = 0.6 + 0.25 * Math.sin(t * 23) + 0.15 * Math.sin(t * 37 + 1);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const hg = ctx.createRadialGradient(HX, HY, 1, HX, HY, 22 * fl);
    hg.addColorStop(0, "rgba(255,220,140,.85)");
    hg.addColorStop(0.35, "rgba(255,120,40,.45)");
    hg.addColorStop(1, "rgba(255,60,20,0)");
    ctx.fillStyle = hg;
    ctx.beginPath();
    ctx.arc(HX, HY, 22 * fl, 0, 7);
    ctx.fill();
    for (let i = 0; i < 3; i++) {
      const h = 8 + 6 * Math.sin(t * (11 + i * 3) + i * 2) + 6,
        w = 3.2 - i * 0.6,
        ox = (i - 1) * 3;
      const fg = ctx.createLinearGradient(0, HY, 0, HY - h);
      fg.addColorStop(0, "rgba(255,230,160,.9)");
      fg.addColorStop(0.5, "rgba(255,130,40,.7)");
      fg.addColorStop(1, "rgba(255,60,20,0)");
      ctx.fillStyle = fg;
      ctx.beginPath();
      ctx.moveTo(HX + ox - w, HY);
      ctx.quadraticCurveTo(
        HX + ox - w * 0.6 + Math.sin(t * 15 + i) * 2,
        HY - h * 0.6,
        HX + ox + Math.sin(t * 9 + i) * 2.5,
        HY - h,
      );
      ctx.quadraticCurveTo(HX + ox + w * 0.6, HY - h * 0.5, HX + ox + w, HY);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
  }
  const pd = puff("rgba(34,32,36,A)"),
    pl = puff("rgba(150,146,150,A)"),
    pw = puff("rgba(255,140,60,A)");
  for (let i = exSmoke.length - 1; i >= 0; i--) {
    const q = exSmoke[i];
    q.l += dt;
    const k = q.l / q.m;
    if (k >= 1) {
      exSmoke.splice(i, 1);
      continue;
    }
    q.vy *= 1 - dt * 0.25;
    q.vx += (wx - q.vx) * dt * (0.35 + k * 0.6) + Math.sin(now * 1.3 + q.seed) * dt * 10;
    q.x += q.vx * dt;
    q.y += q.vy * dt;
    q.r += dt * (9 + k * 14);
    q.rot += q.sp * dt;
    const a = Math.min(1, k * 7) * Math.pow(1 - k, 1.4) * (q.dark ? 0.9 : 0.65),
      R = q.r * 2.2;
    ctx.save();
    ctx.translate(q.x, q.y);
    ctx.rotate(q.rot);
    ctx.globalAlpha = Math.min(1, a * (1 - k * 0.75) * (q.dark ? 1.25 : 0.6));
    ctx.drawImage(pd, -R / 2, -R / 2, R, R);
    ctx.globalAlpha = a * (0.12 + k * 0.85);
    ctx.drawImage(pl, (-R / 2) * 1.05, (-R / 2) * 0.95, R * 1.05, R * 0.95);
    if (broken && !repairing && k < 0.12) {
      ctx.globalAlpha = (1 - k / 0.12) * 0.5;
      ctx.globalCompositeOperation = "lighter";
      ctx.drawImage(pw, -R / 3, -R / 3, R / 1.5, R / 1.5);
    }
    ctx.restore();
  }
  ctx.save();
  ctx.globalCompositeOperation = "lighter";
  for (let i = exEmb.length - 1; i >= 0; i--) {
    const e = exEmb[i];
    e.l += dt;
    if (e.l > e.m) {
      exEmb.splice(i, 1);
      continue;
    }
    e.vy += dt * 60;
    e.vx += (wx * 0.6 - e.vx) * dt * 0.8;
    const px = e.x,
      py = e.y;
    e.x += e.vx * dt;
    e.y += e.vy * dt;
    const k = e.l / e.m;
    ctx.strokeStyle =
      "rgba(255," +
      Math.round(200 - k * 120) +
      "," +
      Math.round(90 - k * 70) +
      "," +
      (1 - k).toFixed(3) +
      ")";
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(px, py);
    ctx.lineTo(e.x, e.y);
    ctx.stroke();
  }
  ctx.restore();
  ctx.globalAlpha = 1;
}
function drawStone(s) {
  const t = performance.now() / 500 + s.ph,
    k = 1 + Math.sin(t) * 0.05;
  const g = ctx.createRadialGradient(s.x, s.y + 6, 2, s.x, s.y + 6, 30);
  g.addColorStop(0, "rgba(220,230,255,.22)");
  g.addColorStop(1, "rgba(220,230,255,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(s.x, s.y + 6, 30, 0, 7);
  ctx.fill();
  ctx.save();
  ctx.translate(s.x, s.y);
  ctx.scale(k, k);
  drawItemArt(ctx, "stone", 44, { ph: s.ph || 0 });
  ctx.restore();
}
function drawDrop(d) {
  if (d.type === "gold") {
    drawGoldNugget(d.x, d.y, performance.now() / 1000, d.seed || 0);
    return;
  }
  const t = performance.now() / 400,
    bob = Math.sin(t + d.x) * 2.5;
  ctx.save();
  ctx.translate(d.x, d.y + bob);
  drawItemArt(ctx, d.type === "star" ? "star" : "stone", d.type === "star" ? 42 : 40, { ph: d.x });
  ctx.restore();
}

/* ============== DEKOR ÇİZİMİ ============== */
function drawDecor(c) {
  const S = PLANETS[scene];
  if (c.type === "speck") {
    ctx.globalAlpha = 0.1;
    ctx.fillStyle = S.dot;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, c.r * 2.4, c.r * 1.5, c.rot, 0, 7);
    ctx.fill();
  } else if (c.type === "crater") {
    ctx.globalAlpha = 0.5;
    ctx.fillStyle = "rgba(0,0,0,.32)";
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, c.r * 0.85, c.r * 0.6, c.rot, 0, 7);
    ctx.fill();
    ctx.globalAlpha = 0.75;
    ctx.strokeStyle = "rgba(255,255,255,.28)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, c.r * 0.95, c.r * 0.68, c.rot, 0.6, 3.4);
    ctx.stroke();
  } else if (c.type === "rock") {
    const g = ctx.createLinearGradient(c.x - c.r, c.y - c.r, c.x + c.r, c.y + c.r);
    g.addColorStop(0, "rgba(255,255,255,.30)");
    g.addColorStop(1, "rgba(0,0,0,.34)");
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, c.r * 0.7, c.r * 0.48, c.rot, 0, 7);
    ctx.fill();
    ctx.strokeStyle = "rgba(0,0,0,.3)";
    ctx.lineWidth = 2;
    ctx.stroke();
  } else if (c.type === "grass") {
    ctx.globalAlpha = 0.9;
    ctx.strokeStyle = "#39a35f";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    for (let i = -2; i <= 2; i++) {
      const bx = c.x + i * 7,
        by = c.y + Math.abs(i) * 3;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.quadraticCurveTo(bx + i * 3, by - c.r * 0.5, bx + i * 7, by - c.r * 0.85);
      ctx.stroke();
    }
  } else if (c.type === "crack") {
    ctx.globalAlpha = 0.55;
    ctx.strokeStyle = "rgba(0,0,0,.5)";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(c.x - c.r, c.y);
    for (let i = 1; i <= 5; i++) ctx.lineTo(c.x - c.r + c.r * 0.4 * i, c.y + Math.sin(i * 2.1 + c.rot) * 10);
    ctx.stroke();
    ctx.globalAlpha = 0.3;
    ctx.strokeStyle = "rgba(255,255,255,.4)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(c.x - c.r, c.y + 4);
    for (let i = 1; i <= 5; i++)
      ctx.lineTo(c.x - c.r + c.r * 0.4 * i, c.y + 4 + Math.sin(i * 2.1 + c.rot) * 10);
    ctx.stroke();
  } else if (c.type === "ice") {
    const g = ctx.createLinearGradient(c.x, c.y - c.r, c.x, c.y + c.r * 0.4);
    g.addColorStop(0, "#ffffff");
    g.addColorStop(1, "#7fd0ff");
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(c.x, c.y - c.r * 0.7);
    ctx.lineTo(c.x + c.r * 0.35, c.y);
    ctx.lineTo(c.x, c.y + c.r * 0.3);
    ctx.lineTo(c.x - c.r * 0.35, c.y);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 1.5;
    ctx.stroke();
  } else if (c.type === "crystal") {
    ctx.globalAlpha = 0.8;
    ctx.fillStyle = "#a78bfa";
    ctx.beginPath();
    ctx.moveTo(c.x, c.y - c.r * 0.8);
    ctx.lineTo(c.x + c.r * 0.3, c.y);
    ctx.lineTo(c.x, c.y + c.r * 0.2);
    ctx.lineTo(c.x - c.r * 0.3, c.y);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,.55)";
    ctx.beginPath();
    ctx.moveTo(c.x, c.y - c.r * 0.8);
    ctx.lineTo(c.x + c.r * 0.12, c.y);
    ctx.lineTo(c.x, c.y + c.r * 0.2);
    ctx.closePath();
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}

/* ============== TARIM ============== */
function farmArr() {
  if (!game.plots) game.plots = {};
  if (!Array.isArray(game.plots[scene])) game.plots[scene] = [];
  return game.plots[scene];
}
function plotStage(g) {
  return Math.min(1, g / CFG.farmGrow);
}
/* ============== ROKET İÇİ — 3 güverteli 2D kesit simülasyonu ==============
   Oyuncu hava kilidinden girer; A/D ile güvertede yürür, merdivende W/S ile
   güverte değiştirir, E ile istasyonları kullanır. Market ve çadır işlevleri
   buradaki istasyonlara taşındı. */
let insideRocket = false,
  bedOpen = false;
const ip = { deck: 0, x: -150, y: 0, dir: 1, climb: null };
const DECKS = [
  { name: T("MAKİNE DAİRESİ"), floor: 500, ceil: 372, xmin: -200, xmax: 200 },
  { name: T("YAŞAM GÜVERTESİ"), floor: 340, ceil: 206, xmin: -190, xmax: 190 },
  { name: T("KOMUTA GÜVERTESİ"), floor: 170, ceil: 34, xmin: -150, xmax: 150 },
];
const LADDERS = [
  { from: 0, to: 1, x: -196 },
  { from: 1, to: 2, x: 140 },
];
const STATIONS = [
  { deck: 0, x: -150, w: 30, key: "exit", name: T("Hava kilidi"), hint: T("<b>E</b>: Dışarı çık") },
  { deck: 0, x: -92, w: 24, key: "kit", name: T("Alet sandığı"), hint: T("<b>E</b>: Alet sandığını aç") },
  { deck: 0, x: -16, w: 38, key: "o2", name: T("O₂ tüpü"), hint: T("<b>E</b>: Oksijen doldur") },
  { deck: 0, x: 70, w: 34, key: "engine", name: T("Ana motor"), hint: T("<b>E</b>: Ana motoru onar") },
  { deck: 0, x: 150, w: 40, key: "repair", name: T("Tamir tezgâhı"), hint: T("<b>E</b>: Motor onarımı") },
  { deck: 1, x: -130, w: 40, key: "bed", name: T("Uyku kapsülü"), hint: T("<b>E</b>: Yat / uyu (zaman 2×)") },
  {
    deck: 1,
    x: -68,
    w: 26,
    key: "upg",
    name: T("Fabrikasyon atölyesi"),
    hint: T("<b>E</b>: Atölye · kıyafet & roket geliştirme"),
  },
  {
    deck: 1,
    x: 6,
    w: 44,
    key: "kitchen",
    name: T("Mutfak"),
    hint: T("<b>E</b>: Mutfağı aç · <b>F</b>: hızlı ye/iç"),
  },
  { deck: 1, x: 80, w: 32, key: "med", name: T("Revir"), hint: T("<b>E</b>: Revir dolabını aç") },
  { deck: 1, x: 172, w: 24, key: "food", name: T("Yemek kapsülü"), hint: T("<b>E</b>: Yemek kapsülünü aç") },
  {
    deck: 2,
    x: -108,
    w: 30,
    key: "comm",
    name: T("İletişim terminali"),
    hint: T("<b>E</b>: Dünya iletişim terminali"),
  },
  { deck: 2, x: -10, w: 56, key: "nav", name: T("Navigasyon"), hint: T("<b>E</b>: Navigasyon bilgisayarı") },
  { deck: 2, x: 92, w: 36, key: "trade", name: T("Kargo terminali"), hint: T("<b>E</b>: Kargo terminali") },
];
const DECK_H = 136;
function interiorScale() {
  return Math.min(W / 560, (H - 120) / 700);
}
function enterRocket() {
  insideRocket = true;
  ip.deck = 0;
  ip.x = -130;
  if (game.repair.state !== "ok") prewarmSmoke();
  else {
    inSmoke.length = 0;
    smokeLevel = 0;
  }
  ip.dir = 1;
  ip.climb = null;
  ip.y = DECKS[0].floor;
  p.walk = 0;
  keys.KeyW = keys.KeyS = keys.ArrowUp = keys.ArrowDown = false;
  sfx("click");
  toast(T("🚀 Roketin içindesin — <b>A/D</b> yürü · merdivende <b>W/S</b> · <b>E</b> kullan"));
}
function exitRocket() {
  insideRocket = false;
  game.sleeping = false;
  p.x = ROCKET.x;
  p.y = ROCKET.y + 118;
  p.dir = 1;
  sfx("click");
  toast(T("Hava kilidinden çıktın"));
}
function nearStation() {
  if (!insideRocket) return null;
  let b = null,
    bd = 1e9;
  for (const s of STATIONS) {
    if (s.deck !== ip.deck) continue;
    const d = Math.abs(ip.x - s.x);
    if (d < s.w && d < bd) {
      bd = d;
      b = s;
    }
  }
  return b;
}
function nearLadder() {
  for (const l of LADDERS) {
    if ((l.from === ip.deck || l.to === ip.deck) && Math.abs(ip.x - l.x) < 24) return l;
  }
  return null;
}
function stationAction() {
  const s = nearStation();
  if (!s) {
    sfx("error");
    toast(T("Yakında kullanılacak bir istasyon yok"));
    return;
  }
  switch (s.key) {
    case "exit":
      exitRocket();
      break;
    case "kit":
      openCapsule("kit");
      break;
    case "food":
      openCapsule("food");
      break;
    case "o2":
      startO2Fill();
      break;
    case "repair":
    case "engine":
      openRepair();
      break;
    case "bed":
      openBed();
      break;
    case "kitchen":
      openCapsule("kitchen");
      break;
    case "med":
      openCapsule("med");
      break;
    case "upg":
      openUpg();
      break;
    case "nav":
      openRocket("nav");
      break;
    case "comm":
      openComm();
      break;
    case "trade":
      openMarket();
      break;
  }
}
function insideF() {
  const s = nearStation();
  if (s && s.key === "trade") {
    depositSamples();
    return;
  }
  if (s && s.key === "kitchen") {
    useKitchen();
    return;
  }
  sfx("error");
  toast(T("Numuneleri komuta güvertesindeki <b>stok terminalinden</b> kargoya yükle"));
}
/* numuneleri (metal + yıldız) roketin kargo bölmesine yükle */
function sampleCount() {
  return (game.inventory.stone || 0) + (game.inventory.star || 0);
}
function depositSamples() {
  const st = game.inventory.stone || 0,
    sr = game.inventory.star || 0;
  if (st + sr <= 0) {
    sfx("error");
    toast(T("Çantanda numune yok — dışarıda metal ve ⭐ topla"));
    return 0;
  }
  const pts = st + sr * 2;
  game.cargo = (game.cargo || 0) + pts;
  game.inventory.stone = 0;
  game.inventory.star = 0;
  updateInv();
  if (!insideRocket) burst(ROCKET.x, ROCKET.y, 20, "#c9d2e0", { sp: 120, life: 0.7, size: 5, up: 120 });
  sfx("pickup");
  toast(
    "📦 " +
      pts +
      T(" numune kargoya yüklendi · kargo ") +
      Math.min(game.cargo, CFG.cargoGoal) +
      "/" +
      CFG.cargoGoal,
  );
  bumpQuest("loaded", pts);
  if (marketOpen) openMarket();
  return pts;
}
function useKitchen() {
  // her seferinde tek eylem: önce hangisi daha düşükse
  const S = game.stock;
  const drink = () => {
    if (S.water > 0) S.water--;
    else if ((game.inventory.water || 0) > 0) game.inventory.water--;
    else return false;
    game.thirst = Math.min(100, game.thirst + CFG.drinkThirst);
    startAct("drink", 1.8);
    sfx("drink");
    bumpQuest("drunk");
    return true;
  };
  const eat = () => {
    if (S.potato > 0) S.potato--;
    else if ((game.inventory.potato || 0) > 0) game.inventory.potato--;
    else return false;
    game.hunger = Math.min(100, game.hunger + CFG.eatHunger);
    startAct("eat", 2.0);
    sfx("eat");
    return true;
  };
  let did = false;
  if (game.thirst < 95 && (game.thirst <= game.hunger || game.hunger >= 95))
    did = drink() || (game.hunger < 95 && eat());
  else if (game.hunger < 95) did = eat() || (game.thirst < 95 && drink());
  if (did) {
    updateInv();
    updateStats();
    toast(T("🍽️ Yemek kapsülü stoku: 💧") + S.water + " 🥔" + S.potato);
  } else if (game.thirst >= 95 && game.hunger >= 95) {
    sfx("full");
    toast(T("Şu an aç ya da susuz değilsin"));
  } else {
    sfx("error");
    toast(T("Yemek kapsülü boş — patates yetiştir, su geri dönüştürücüyü bekle"));
  }
}
/* su geri dönüştürücü aralığı: zorluk susuzluğu hızlandırırsa geri dönüşüm de hızlanır → su hep yeter */
function recycleInt() {
  return CFG.waterRecycle / Math.max(1, dif().water || 1);
}
/* --- Mars saha kiti (takım çantası) --- */
function toggleKit() {
  game.kitCarried = !game.kitCarried;
  updateInv();
  if (game.kitCarried) bumpQuest("kit");
  sfx(game.kitCarried ? "pickup" : "click");
  toast(
    game.kitCarried
      ? T("Çapa sırtında — dışarıda yere <b>sol tıkla</b>, toprağı kaz")
      : T("Çapa alet sandığına bırakıldı"),
  );
}
/* --- yatak kabini: uyu / uyan sistemi --- */
let sleepT = 0,
  sleepDay = 0;
function updateSleep(dt) {
  if (!game || !game.sleeping) return;
  sleepT += dt;
  game.hp = Math.min(100, game.hp + CFG.hpRegen * (dif().regen || 1) * dt * 2.5); // uykuda hızlı iyileşme
  if (game.hunger < 15 || game.thirst < 15) {
    wakeUp(T("Açlık/susuzluktan uyandın — mutfağa git"));
    return;
  }
  if (gameDayNumber() > sleepDay) {
    wakeUp(T("🌅 Yeni güne uyandın"));
    return;
  }
}
function wakeUp(msg) {
  if (!game.sleeping) return;
  game.sleeping = false;
  sleepT = 0;
  updateBedPanel();
  if (bedOpen) $("bedScreen").classList.remove("hidden");
  sfx("harvest2");
  toast(msg);
}
function drawSleepOverlay() {
  if (!game || !game.sleeping) return;
  const a = Math.min(0.78, sleepT * 0.6);
  ctx.fillStyle = "rgba(2,3,12," + a + ")";
  ctx.fillRect(0, 0, W, H);
  ctx.save();
  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(255,255,255," + a + ")";
  ctx.font = "800 " + Math.round(Math.min(W, H) * 0.06) + "px 'Segoe UI',sans-serif";
  const inDay = (game.worldTime || 0) % DAY_SECONDS;
  ctx.fillText(T("😴 Uyuyorsun…"), W / 2, H * 0.42);
  ctx.font = "600 16px 'Segoe UI',sans-serif";
  ctx.fillStyle = "rgba(255,208,138," + a + ")";
  ctx.fillText(
    T("Gün ") + gameDayNumber() + T(" · sabaha ") + fmtTime(DAY_SECONDS - inDay) + T(" · zaman 2× hızlı"),
    W / 2,
    H * 0.42 + 34,
  );
  ctx.fillStyle = "rgba(255,255,255," + a * 0.7 + ")";
  ctx.font = "600 14px 'Segoe UI',sans-serif";
  ctx.fillText(T("E: uyan"), W / 2, H * 0.42 + 60);
  ctx.fillStyle = "rgba(200,210,255," + a * 0.8 + ")";
  for (let i = 0; i < 3; i++) {
    const ph = (sleepT * 0.5 + i * 0.33) % 1;
    ctx.font = "700 " + (14 + ph * 18) + "px sans-serif";
    ctx.globalAlpha = 1 - ph;
    ctx.fillText("z", W / 2 + 60 + ph * 40, H * 0.42 - 20 - ph * 60);
  }
  ctx.restore();
}
/* --- yatak kabini --- */
function updateBedPanel() {
  if (!game) return;
  const inDay = (game.worldTime || 0) % DAY_SECONDS;
  $("bedClock").textContent = T("Gün ") + gameDayNumber() + T(" · sabaha ") + fmtTime(DAY_SECONDS - inDay);
  $("bedMeters").innerHTML =
    conMeter(T("CAN"), game.hp, "linear-gradient(90deg,#16a34a,#4ade80)") +
    conMeter(T("TOKLUK"), game.hunger, "linear-gradient(90deg,#c2410c,#ffb347)") +
    conMeter(T("SU"), game.thirst, "linear-gradient(90deg,#1f7fb8,#7fe0ff)");
  $("bedStatus").textContent = game.sleeping
    ? T("Uyuyorsun; oyun zamanı 2× hızlanıyor. Roket gövdesi radyasyonu keser.")
    : radiationActiveNow()
      ? T("☢️ Dışarıda radyasyon var. Roket içindeyken güvendesin.")
      : T(
          "Uyumak zamanı 2× hızlandırır: mahsul daha çabuk büyür, can hızla yenilenir. Sabah olunca kendiliğinden uyanırsın.",
        );
  $("bedSleep").textContent = game.sleeping ? T("☀️ Uyan") : T("🛌 Uyu");
}
function openBed() {
  bedOpen = true;
  game.sleeping = false;
  $("bedScreen").classList.remove("hidden");
  updateBedPanel();
  focusGame();
}
function closeBed() {
  if (game) game.sleeping = false;
  sleepT = 0;
  bedOpen = false;
  $("bedScreen").classList.add("hidden");
  focusGame();
}
function toggleSleep() {
  if (!game || !bedOpen) return;
  if (game.sleeping) {
    wakeUp(T("Uyandın"));
    return;
  }
  game.sleeping = true;
  sleepT = 0;
  sleepDay = gameDayNumber();
  updateBedPanel();
  $("bedScreen").classList.add("hidden");
  focusGame();
  toast(game.sleeping ? T("Uyku başladı — zaman 2× hızlanıyor") : T("Uyandın"));
}
$("bedSleep").onclick = toggleSleep;
$("bedExit").onclick = closeBed;
$("bedX").onclick = closeBed;

/* --- iç mekân güncelleme --- */
function updateInside(dt, ix, iy, running) {
  const d = DECKS[ip.deck];
  if (ip.climb) {
    const c = ip.climb;
    c.t += dt * 2.2;
    ip.y = c.y0 + (c.y1 - c.y0) * Math.min(1, c.t);
    ip.x = c.x;
    p.t += dt * CFG.springSpeed * 0.8;
    p.walk = 1;
    if (c.t >= 1) {
      ip.deck = c.to;
      ip.y = DECKS[c.to].floor;
      ip.climb = null;
      sfx("click");
    }
    return;
  }
  const sp = CFG.walkSpeed * (running ? CFG.runMultiplier : 1) * 0.78;
  const nd = DECKS[ip.deck];
  if (ip.vx == null) {
    ip.vx = 0;
    ip.z = 0;
    ip.vz = 0;
  }
  if (cabinGravFail()) {
    // jeneratör arızalı: içerisi de 0,38 g
    gravMove(ip, ix * sp, null, dt);
    gravHop(ip, Math.abs(ix) > 0.05, running, dt, nd.floor - nd.ceil - 100);
    gravLand(ip, ip.x, -9999);
    if (keys.Space) {
      keys.Space = false;
      gravJump(ip);
    }
  } else {
    ip.vx = ix * sp;
    if (ip.z > 0 || ip.vz > 0) {
      gravHop(ip, false, false, dt);
      ip.landed = 0;
    }
    if (keys.Space) {
      keys.Space = false;
      gravJump(ip);
    }
  }
  const nx = Math.max(nd.xmin, Math.min(nd.xmax, ip.x + ip.vx * dt));
  if (nx === nd.xmin || nx === nd.xmax) ip.vx = 0;
  ip.x = nx;
  if (ix > 0.1) ip.dir = 1;
  if (ix < -0.1) ip.dir = -1;
  if (Math.abs(ix) > 0.05) {
    p.t += dt * CFG.springSpeed * (running ? 1.4 : 1);
    p.walk = Math.min(1, p.walk + dt * 8);
  } else p.walk = Math.max(0, p.walk - dt * 8);
  const k = Math.min(1, dt * 10);
  p.sx += (1 - p.sx) * k;
  p.sy += (1 - p.sy) * k;
  if (Math.abs(iy) > 0.5) {
    const l = nearLadder();
    if (l && !(ip.z > 1)) {
      const up = iy < 0,
        to = up ? Math.max(l.from, l.to) : Math.min(l.from, l.to);
      if (to !== ip.deck && (l.from === to || l.to === to)) {
        ip.climb = { t: 0, to, x: l.x, y0: DECKS[ip.deck].floor, y1: DECKS[to].floor };
        ip.dir = 1;
        sfx("click");
      }
    }
  }
  p.dir = ip.dir;
  p._running = running;
  p.actionT = Math.max(0, (p.actionT || 0) - dt);
  if (p.actionT <= 0) p.action = null;
}
function insideHint() {
  if (ip.climb) return "";
  const s = nearStation();
  if (s) {
    if (s.key === "o2")
      return (
        T("<b>E</b>: Oksijen doldur · giysi %") +
        Math.round(game.o2) +
        T(" · tüp %") +
        Math.round((game.o2Tank / o2Max()) * 100)
      );
    if (s.key === "kit" || s.key === "food" || s.key === "kitchen") {
      let n = 0;
      CAPSULES[s.key].items.forEach(([k]) => (n += capCount(k)));
      return s.hint + " · " + n + T(" öğe");
    }
    if (s.key === "comm") {
      const u = commUnread(),
        n = commUnsent().length;
      return (
        T("<b>E</b>: İletişim terminali") +
        (u ? " · 📨 " + u + T(" yeni mesaj") : "") +
        (n ? " · 📝 " + n + T(" gözlem") : "")
      );
    }
    if (s.key === "trade")
      return T("<b>E</b>: Kargo terminali") + (sampleCount() > 0 ? T(" · <b>F</b>: numuneleri yükle") : "");
    if (s.key === "repair" || s.key === "engine") {
      if (game.repair.state === "ok")
        return (s.key === "engine" ? T("Ana motor") : T("Tamir tezgâhı")) + T(" — motor çalışıyor ✔");
      return T("<b>E</b>: Ana motoru onar · aşama ") + ((game.repair.stage || 0) + 1) + "/4";
    }
    if (s.key === "med")
      return (
        s.hint +
        T(" · medikit ") +
        game.stock.medkit +
        T(" · çanta ") +
        (game.inventory.medkit || 0) +
        (game.hp < 100 ? T(" · <b>G</b>: hızlı kullan") : "")
      );
    if (s.key === "upg") {
      ensureUpg();
      return s.hint + T(" · metal ") + (game.inventory.stone || 0) + T(" · altın ") + (game.gold || 0);
    }
    return s.hint;
  }
  const l = nearLadder();
  if (l)
    return (
      T("<b>W</b>/<b>S</b>: Merdivenle ") +
      (ip.deck === Math.min(l.from, l.to) ? T("yukarı çık") : T("aşağı in"))
    );
  return "";
}

/* ============== İÇ MEKÂN ÇİZİMİ ============== */
function screenBox(x, y, w, h, col, glow) {
  ctx.fillStyle = "#0a1024";
  rrp(x, y, w, h, 3);
  ctx.fill();
  ctx.strokeStyle = col;
  ctx.lineWidth = 1.2;
  ctx.stroke();
  if (glow) {
    ctx.save();
    ctx.globalAlpha = 0.25;
    ctx.fillStyle = col;
    rrp(x - 2, y - 2, w + 4, h + 4, 5);
    ctx.fill();
    ctx.restore();
  }
}
function waveScreen(x, y, w, h, col, t, ph) {
  screenBox(x, y, w, h, col, true);
  ctx.save();
  ctx.beginPath();
  ctx.rect(x + 2, y + 2, w - 4, h - 4);
  ctx.clip();
  ctx.strokeStyle = "rgba(255,255,255,.08)";
  ctx.lineWidth = 1;
  for (let gx = x + 2; gx < x + w; gx += 8) {
    ctx.beginPath();
    ctx.moveTo(gx, y);
    ctx.lineTo(gx, y + h);
    ctx.stroke();
  }
  for (let gy = y + 2; gy < y + h; gy += 8) {
    ctx.beginPath();
    ctx.moveTo(x, gy);
    ctx.lineTo(x + w, gy);
    ctx.stroke();
  }
  ctx.strokeStyle = col;
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  for (let i = 0; i <= w; i += 2) {
    const xx = x + i,
      yy = y + h / 2 + Math.sin(i * 0.18 + t * 3 + ph) * h * 0.22 + Math.sin(i * 0.6 - t * 5 + ph) * h * 0.08;
    i ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy);
  }
  ctx.stroke();
  ctx.restore();
}
function radarScreen(x, y, r, col, t) {
  ctx.fillStyle = "#0a1024";
  ctx.beginPath();
  ctx.arc(x, y, r, 0, 7);
  ctx.fill();
  ctx.strokeStyle = col;
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.save();
  ctx.beginPath();
  ctx.arc(x, y, r, 0, 7);
  ctx.clip();
  ctx.strokeStyle = "rgba(255,255,255,.12)";
  ctx.lineWidth = 1;
  for (let k = 1; k <= 2; k++) {
    ctx.beginPath();
    ctx.arc(x, y, (r * k) / 3, 0, 7);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(x - r, y);
  ctx.lineTo(x + r, y);
  ctx.moveTo(x, y - r);
  ctx.lineTo(x, y + r);
  ctx.stroke();
  const a = (t * 2) % (Math.PI * 2);
  const g = ctx.createRadialGradient(x, y, 1, x, y, r);
  g.addColorStop(0, col);
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.globalAlpha = 0.45;
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.arc(x, y, r, a - 0.9, a);
  ctx.closePath();
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.fillStyle = "#fff";
  for (const [bx, by] of [
    [0.4, -0.3],
    [-0.5, 0.2],
    [0.1, 0.6],
  ]) {
    ctx.beginPath();
    ctx.arc(x + bx * r, y + by * r, 1.4, 0, 7);
    ctx.fill();
  }
  ctx.restore();
}
function led(x, y, col, on) {
  ctx.fillStyle = on ? col : "rgba(60,60,80,.9)";
  ctx.beginPath();
  ctx.arc(x, y, 2, 0, 7);
  ctx.fill();
  if (on) {
    ctx.globalAlpha = 0.35;
    ctx.beginPath();
    ctx.arc(x, y, 4.5, 0, 7);
    ctx.fill();
    ctx.globalAlpha = 1;
  }
}
function pipe(pts, w, col) {
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = "#20243a";
  ctx.lineWidth = w + 2.4;
  ctx.beginPath();
  pts.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1])));
  ctx.stroke();
  ctx.strokeStyle = col;
  ctx.lineWidth = w;
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,.25)";
  ctx.lineWidth = w * 0.3;
  ctx.stroke();
}
function hullPath() {
  ctx.beginPath();
  ctx.moveTo(0, -176);
  ctx.quadraticCurveTo(95, -120, 160, 20);
  ctx.quadraticCurveTo(222, 150, 236, 300);
  ctx.lineTo(240, 522);
  ctx.lineTo(-240, 522);
  ctx.lineTo(-236, 300);
  ctx.quadraticCurveTo(-222, 150, -160, 20);
  ctx.quadraticCurveTo(-95, -120, 0, -176);
  ctx.closePath();
}
function drawInterior() {
  const t = performance.now() / 1000,
    z = interiorScale();
  const S = PLANETS[scene];
  // dış arka plan: gezegen + yıldız
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, "#08060f");
  bg.addColorStop(0.6, "#1a0a0c");
  bg.addColorStop(1, S.ground);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);
  for (const s of stars) {
    ctx.fillStyle = "rgba(255,255,255," + (0.25 + s.h * 0.5) + ")";
    ctx.fillRect(s.x * W, s.y * H * 0.6, 1.2 + s.h, 1.2 + s.h);
  }
  {
    const wk = game.wake,
      e = (x) => (x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2);
    const k = wk ? (wk.t < 5.8 ? 1 : 1 - e(Math.min(1, (wk.t - 5.8) / 2.3))) : 0,
      C = wk ? wakeCam(wk.t) : { x: 0, y: 0, z: 1 },
      Z = 1 + (C.z - 1) * k,
      cx = C.x * k,
      cy = (176 + 10 / z) * (1 - k) + C.y * k;
    ctx.save();
    ctx.translate(W / 2, H / 2);
    ctx.scale(z * Z, z * Z);
    ctx.translate(-cx, -cy);
  }
  // dış gövde gölgesi
  ctx.save();
  ctx.translate(10, 12);
  ctx.fillStyle = "rgba(0,0,0,.45)";
  hullPath();
  ctx.fill();
  ctx.restore();
  // gövde kalın cidar
  ctx.fillStyle = "#8d94b2";
  hullPath();
  ctx.fill();
  ctx.save();
  hullPath();
  ctx.clip();
  // iç duvar
  const wg = ctx.createLinearGradient(-240, 0, 240, 0);
  wg.addColorStop(0, "#2b3048");
  wg.addColorStop(0.5, "#3b4160");
  wg.addColorStop(1, "#242840");
  ctx.fillStyle = wg;
  ctx.fillRect(-240, -180, 480, 710);
  // duvar kaburgaları
  ctx.strokeStyle = "rgba(0,0,0,.25)";
  ctx.lineWidth = 6;
  for (let yy = -150; yy < 520; yy += 46) {
    ctx.beginPath();
    ctx.moveTo(-240, yy);
    ctx.lineTo(240, yy);
    ctx.stroke();
  }
  ctx.strokeStyle = "rgba(255,255,255,.05)";
  ctx.lineWidth = 2;
  for (let xx = -220; xx < 240; xx += 60) {
    ctx.beginPath();
    ctx.moveTo(xx, -180);
    ctx.lineTo(xx, 530);
    ctx.stroke();
  }
  // burun bölmesi (kapalı: yük/paraşüt)
  ctx.fillStyle = "#2a2f47";
  ctx.fillRect(-240, -180, 480, 214);
  ctx.strokeStyle = "#4e5578";
  ctx.lineWidth = 2;
  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.moveTo(-100 + i * 10, -150 + i * 34);
    ctx.lineTo(100 - i * 10, -150 + i * 34);
    ctx.stroke();
  }
  ctx.fillStyle = "#ff8c42";
  ctx.font = "700 11px 'Segoe UI',sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(T("PARAŞÜT / YÜK BÖLMESİ"), 0, -60);
  ctx.strokeStyle = "#ffb347";
  ctx.setLineDash([6, 4]);
  ctx.strokeRect(-70, -50, 140, 50);
  ctx.setLineDash([]);
  ctx.fillStyle = "#d9dcea";
  for (let i = 0; i < 6; i++) (rrp(-62 + i * 22, -42, 18, 34, 3), ctx.fill());

  /* --- güverteler --- */
  DECKS.forEach((d, di) => {
    // zemin ızgarası
    const fg = ctx.createLinearGradient(0, d.floor - 10, 0, d.floor + 22);
    fg.addColorStop(0, "#6a7190");
    fg.addColorStop(1, "#3a3f5a");
    ctx.fillStyle = fg;
    ctx.fillRect(-240, d.floor, 480, 22);
    ctx.strokeStyle = "rgba(0,0,0,.4)";
    ctx.lineWidth = 1;
    for (let xx = -240; xx < 240; xx += 14) {
      ctx.beginPath();
      ctx.moveTo(xx, d.floor);
      ctx.lineTo(xx + 6, d.floor + 22);
      ctx.stroke();
    }
    ctx.fillStyle = "#9aa3bf";
    ctx.fillRect(-240, d.floor - 3, 480, 3);
    // uyarı şeridi
    ctx.save();
    ctx.beginPath();
    ctx.rect(-240, d.floor + 22, 480, 5);
    ctx.clip();
    ctx.fillStyle = "#1b1e2e";
    ctx.fillRect(-240, d.floor + 22, 480, 5);
    ctx.fillStyle = "#ffb347";
    for (let xx = -240; xx < 240; xx += 16) {
      ctx.beginPath();
      ctx.moveTo(xx, d.floor + 27);
      ctx.lineTo(xx + 8, d.floor + 27);
      ctx.lineTo(xx + 14, d.floor + 22);
      ctx.lineTo(xx + 6, d.floor + 22);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
    // tavan lambaları
    for (const lx of [-120, 0, 120]) {
      if (di === 2 && Math.abs(lx) > 100) continue;
      ctx.fillStyle = "#1b1e2e";
      rrp(lx - 16, d.ceil, 32, 5, 2);
      ctx.fill();
      const on = 0.8 + 0.2 * Math.sin(t * 7 + lx);
      ctx.fillStyle = "rgba(255,245,220," + on + ")";
      rrp(lx - 13, d.ceil + 4, 26, 3, 1);
      ctx.fill();
      const lg = ctx.createLinearGradient(0, d.ceil + 6, 0, d.ceil + 70);
      lg.addColorStop(0, "rgba(255,240,200,.14)");
      lg.addColorStop(1, "rgba(255,240,200,0)");
      ctx.fillStyle = lg;
      ctx.beginPath();
      ctx.moveTo(lx - 13, d.ceil + 6);
      ctx.lineTo(lx + 13, d.ceil + 6);
      ctx.lineTo(lx + 40, d.ceil + 70);
      ctx.lineTo(lx - 40, d.ceil + 70);
      ctx.closePath();
      ctx.fill();
    }
  });

  /* ===== GÜVERTE 1 — MAKİNE DAİRESİ ===== */
  {
    const F = DECKS[0].floor,
      C = DECKS[0].ceil;
    // borular
    pipe(
      [
        [-240, C + 14],
        [-120, C + 14],
        [-120, C + 40],
        [40, C + 40],
        [40, C + 14],
        [240, C + 14],
      ],
      6,
      "#8ea0b8",
    );
    pipe(
      [
        [-240, C + 26],
        [-122, C + 26],
        [-122, F - 10],
      ],
      4,
      "#d98b3a",
    );
    pipe(
      [
        [150, C + 30],
        [240, C + 30],
      ],
      4,
      "#5ad1ff",
    );
    // vanalar
    for (const [vx, vy] of [
      [-122, C + 26],
      [40, C + 40],
    ]) {
      ctx.fillStyle = "#c0392b";
      ctx.beginPath();
      ctx.arc(vx, vy, 5, 0, 7);
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(vx - 4, vy);
      ctx.lineTo(vx + 4, vy);
      ctx.stroke();
    }
    // hava kilidi (yuvarlak kapı)
    const ax = -150,
      ay = F - 58;
    ctx.fillStyle = "#1b1e2e";
    rrp(ax - 30, ay - 46, 60, 104, 8);
    ctx.fill();
    ctx.save();
    ctx.beginPath();
    ctx.rect(ax - 30, ay - 46, 60, 104);
    ctx.clip();
    ctx.fillStyle = "#ffb347";
    for (let i = -2; i < 8; i++) {
      ctx.beginPath();
      ctx.moveTo(ax - 30 + i * 14, ay + 58);
      ctx.lineTo(ax - 20 + i * 14, ay + 58);
      ctx.lineTo(ax - 6 + i * 14, ay + 44);
      ctx.lineTo(ax - 16 + i * 14, ay + 44);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
    const dg = ctx.createRadialGradient(ax - 8, ay - 8, 4, ax, ay, 30);
    dg.addColorStop(0, "#aab3d6");
    dg.addColorStop(1, "#5b6178");
    ctx.fillStyle = dg;
    ctx.beginPath();
    ctx.arc(ax, ay, 28, 0, 7);
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.strokeStyle = "#8d94b2";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(ax, ay, 21, 0, 7);
    ctx.stroke();
    ctx.fillStyle = "#13335c";
    ctx.beginPath();
    ctx.arc(ax, ay - 6, 8, 0, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,.35)";
    ctx.beginPath();
    ctx.arc(ax - 3, ay - 9, 3, 0, 7);
    ctx.fill();
    ctx.save();
    ctx.translate(ax, ay + 8);
    ctx.rotate(t * 0.4);
    ctx.strokeStyle = "#ffb347";
    ctx.lineWidth = 3;
    for (let i = 0; i < 3; i++) {
      ctx.rotate((Math.PI * 2) / 3);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, 9);
      ctx.stroke();
    }
    ctx.restore();
    for (let i = 0; i < 6; i++) {
      const a = (i * Math.PI) / 3;
      ctx.fillStyle = "#20243a";
      ctx.beginPath();
      ctx.arc(ax + Math.cos(a) * 25, ay + Math.sin(a) * 25, 1.8, 0, 7);
      ctx.fill();
    }
    led(ax - 22, ay - 40, "#4ade80", true);
    led(ax + 22, ay - 40, radiationActiveNow() ? "#e879f9" : "#ff5a5a", Math.sin(t * 4) > 0);
    ctx.fillStyle = "#d9dcea";
    ctx.font = "700 7px monospace";
    ctx.textAlign = "center";
    ctx.fillText(T("HAVA KİLİDİ"), ax, ay - 36);
    drawO2Tanks(F, C, t);
    const energy = 0.92;
    // motor çekirdeği
    const ex = 70,
      ey = F - 54;
    ctx.fillStyle = "#2d3246";
    rrp(ex - 40, C + 40, 80, F - C - 40, 10);
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.strokeStyle = "rgba(255,255,255,.1)";
    ctx.lineWidth = 1;
    for (let yy = C + 50; yy < F; yy += 10) {
      ctx.beginPath();
      ctx.moveTo(ex - 38, yy);
      ctx.lineTo(ex + 38, yy);
      ctx.stroke();
    }
    const broken = game.repair.state !== "ok";
    const pulse = broken ? 0.15 + 0.1 * Math.sin(t * 2) : 0.5 + 0.3 * Math.sin(t * 5) + energy * 0.2;
    const cg = ctx.createRadialGradient(ex, ey, 2, ex, ey, 30);
    cg.addColorStop(0, broken ? "rgba(255,80,60," + pulse + ")" : "rgba(255,220,140," + pulse + ")");
    cg.addColorStop(
      0.5,
      broken ? "rgba(200,50,40," + pulse * 0.5 + ")" : "rgba(90,209,255," + pulse * 0.5 + ")",
    );
    cg.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(ex, ey, 30, 0, 7);
    ctx.fill();
    ctx.strokeStyle = "#aab3d6";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(ex, ey, 18, 0, 7);
    ctx.stroke();
    ctx.save();
    ctx.translate(ex, ey);
    ctx.rotate(broken ? t * 0.3 : t * 6);
    ctx.fillStyle = "#5b6178";
    for (let i = 0; i < 6; i++) {
      ctx.rotate(Math.PI / 3);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(15, -4);
      ctx.lineTo(15, 4);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
    ctx.fillStyle = broken ? "#ff5a5a" : "#ffd34d";
    ctx.beginPath();
    ctx.arc(ex, ey, 4, 0, 7);
    ctx.fill();
    ctx.fillStyle = "#ffd34d";
    ctx.font = "700 9px monospace";
    ctx.textAlign = "center";
    ctx.fillText(T("ANA MOTOR"), ex, C + 54);
    // gösterge paneli
    for (let i = 0; i < 4; i++) {
      const gx = ex - 30 + i * 17,
        gy = C + 62;
      ctx.fillStyle = "#0a1024";
      ctx.beginPath();
      ctx.arc(gx + 6, gy + 6, 6, 0, 7);
      ctx.fill();
      ctx.strokeStyle = "#8d94b2";
      ctx.lineWidth = 1;
      ctx.stroke();
      const na = -2.2 + (i === 0 ? energy * 2.8 : (0.5 + 0.5 * Math.sin(t * 1.3 + i)) * 2.8);
      ctx.strokeStyle = i === 0 ? "#5ad1ff" : "#ffb347";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(gx + 6, gy + 6);
      ctx.lineTo(gx + 6 + Math.cos(na) * 4.5, gy + 6 + Math.sin(na) * 4.5);
      ctx.stroke();
    }
    if (broken) {
      // arıza: kıvılcım + duman
      if (Math.sin(t * 19) > 0.6) {
        ctx.fillStyle = "#fff6c0";
        ctx.beginPath();
        ctx.arc(ex + 20 + Math.sin(t * 7) * 4, ey - 20, 2.2, 0, 7);
        ctx.fill();
      }
      // motor kapağında çatlak + patlak boru
      ctx.strokeStyle = "#0b0d18";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(ex + 14, C + 42);
      ctx.lineTo(ex + 22, C + 52);
      ctx.lineTo(ex + 18, C + 60);
      ctx.lineTo(ex + 28, C + 70);
      ctx.stroke();
      const hg = ctx.createRadialGradient(ex + 24, C + 54, 1, ex + 24, C + 54, 14);
      hg.addColorStop(0, "rgba(255,140,60," + (0.5 + 0.3 * Math.sin(t * 11)) + ")");
      hg.addColorStop(1, "rgba(255,80,30,0)");
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(ex + 24, C + 54, 14, 0, 7);
      ctx.fill();
      ctx.fillStyle = "#0b0d18";
      ctx.beginPath();
      ctx.moveTo(34, C + 35);
      ctx.lineTo(46, C + 37);
      ctx.lineTo(43, C + 45);
      ctx.lineTo(36, C + 44);
      ctx.closePath();
      ctx.fill();
    }
    // tamir tezgâhı
    const rx = 150;
    ctx.fillStyle = "#5a3a1e";
    rrp(rx - 40, F - 44, 80, 8, 2);
    ctx.fill();
    ctx.fillStyle = "#3b2a25";
    ctx.fillRect(rx - 36, F - 36, 6, 36);
    ctx.fillRect(rx + 30, F - 36, 6, 36);
    ctx.fillStyle = "#2d3246";
    rrp(rx - 34, F - 30, 68, 24, 3);
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 1;
    ctx.stroke();
    for (let i = 0; i < 2; i++) {
      ctx.fillStyle = "#9aa3bf";
      rrp(rx - 30 + i * 34, F - 26, 28, 7, 1);
      ctx.fill();
      ctx.fillStyle = "#ffb347";
      ctx.beginPath();
      ctx.arc(rx - 16 + i * 34, F - 22.5, 1.5, 0, 7);
      ctx.fill();
    }
    // alet panosu
    ctx.fillStyle = "#3b4160";
    rrp(rx - 40, C + 50, 80, 56, 4);
    ctx.fill();
    ctx.strokeStyle = "#6f7698";
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.strokeStyle = "#c9d2e0";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(rx - 30, C + 60);
    ctx.lineTo(rx - 30, C + 92);
    ctx.stroke(); // tornavida
    ctx.fillStyle = "#c0392b";
    rrp(rx - 33, C + 58, 6, 12, 2);
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(rx - 14, C + 60);
    ctx.lineTo(rx - 6, C + 94);
    ctx.stroke(); // anahtar
    ctx.strokeStyle = "#c9d2e0";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(rx - 14, C + 60, 5, 0.5, 5.5);
    ctx.stroke();
    ctx.fillStyle = "#5b6178";
    rrp(rx + 4, C + 58, 14, 20, 2);
    ctx.fill();
    ctx.fillStyle = "#ffb347";
    rrp(rx + 6, C + 60, 10, 6, 1);
    ctx.fill(); // matkap
    ctx.fillStyle = "#d9dcea";
    rrp(rx + 24, C + 58, 10, 36, 2);
    ctx.fill();
    ctx.fillStyle = "#1b1e2e";
    rrp(rx + 26, C + 60, 6, 8, 1);
    ctx.fill();
    const rep = game.repair;
    ctx.fillStyle = "#0a1024";
    rrp(rx - 34, C + 108, 68, 14, 2);
    ctx.fill();
    const rs = rep.stage || 0;
    ctx.fillStyle = rep.state === "ok" ? "#4ade80" : rs > 0 ? "#ffd34d" : "#ff5a5a";
    ctx.font = "700 8px monospace";
    ctx.textAlign = "center";
    ctx.fillText(
      rep.state === "ok" ? T("MOTOR: ÇALIŞIYOR") : rs > 0 ? T("ONARIM ") + rs + "/4" : T("MOTOR: ONARIM"),
      rx,
      C + 118,
    );
    // sandıklar
    for (const [cx, cy, cw, ch] of [
      [224, F - 22, 26, 22],
      [224, F - 44, 22, 22],
    ]) {
      ctx.fillStyle = "#6a4a2a";
      rrp(cx - cw / 2, cy, cw, ch, 2);
      ctx.fill();
      ctx.strokeStyle = "#3b2a25";
      ctx.lineWidth = 1.2;
      ctx.stroke();
      ctx.strokeStyle = "#9a7a4a";
      ctx.beginPath();
      ctx.moveTo(cx - cw / 2, cy + ch / 2);
      ctx.lineTo(cx + cw / 2, cy + ch / 2);
      ctx.stroke();
    }
    drawToolChest(-88, F, t);
    // pervane/havalandırma
    ctx.fillStyle = "#1b1e2e";
    ctx.beginPath();
    ctx.arc(200, C + 60, 16, 0, 7);
    ctx.fill();
    ctx.save();
    ctx.translate(200, C + 60);
    ctx.rotate(t * 5);
    ctx.fillStyle = "#8d94b2";
    for (let i = 0; i < 4; i++) {
      ctx.rotate(Math.PI / 2);
      ctx.beginPath();
      ctx.ellipse(8, 0, 8, 3, 0, 0, 7);
      ctx.fill();
    }
    ctx.restore();
    ctx.strokeStyle = "#6f7698";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(200, C + 60, 16, 0, 7);
    ctx.stroke();
  }

  /* ===== GÜVERTE 2 — YAŞAM ===== */
  {
    const F = DECKS[1].floor,
      C = DECKS[1].ceil;
    // lombozlar
    for (const px of []) {
      ctx.fillStyle = "#6f7698";
      ctx.beginPath();
      ctx.arc(px, C + 60, 22, 0, 7);
      ctx.fill();
      ctx.strokeStyle = "#20243a";
      ctx.lineWidth = 2;
      ctx.stroke();
      const vg = ctx.createLinearGradient(0, C + 42, 0, C + 78);
      vg.addColorStop(0, "#1a0a10");
      vg.addColorStop(0.55, "#4a1a10");
      vg.addColorStop(0.56, S.ground);
      vg.addColorStop(1, S.dot);
      ctx.fillStyle = vg;
      ctx.beginPath();
      ctx.arc(px, C + 60, 16, 0, 7);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,.3)";
      ctx.beginPath();
      ctx.ellipse(px - 5, C + 52, 5, 2.5, -0.6, 0, 7);
      ctx.fill();
      for (let i = 0; i < 4; i++) {
        const a = (i * Math.PI) / 2 + 0.8;
        ctx.fillStyle = "#20243a";
        ctx.beginPath();
        ctx.arc(px + Math.cos(a) * 19.5, C + 60 + Math.sin(a) * 19.5, 1.6, 0, 7);
        ctx.fill();
      }
    }
    drawPodBase(t);
    drawSuitPod(-68, F, C, t);
    // mutfak
    ctx.save();
    ctx.translate(6, 0);
    ctx.scale(0.84, 1);
    ctx.translate(10, 0);
    const kx = -10;
    ctx.fillStyle = "#4e5578";
    rrp(kx - 60, C + 22, 120, 34, 3);
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 1;
    ctx.stroke(); // üst dolaplar
    for (let i = 0; i < 3; i++) {
      ctx.strokeStyle = "#6f7698";
      ctx.strokeRect(kx - 56 + i * 40, C + 26, 36, 26);
      ctx.fillStyle = "#ffb347";
      ctx.fillRect(kx - 40 + i * 40, C + 48, 8, 2);
    }
    const cg = ctx.createLinearGradient(0, F - 40, 0, F);
    cg.addColorStop(0, "#8d94b2");
    cg.addColorStop(1, "#4e5578");
    ctx.fillStyle = cg;
    rrp(kx - 62, F - 40, 124, 40, 3);
    ctx.fill();
    ctx.fillStyle = "#c9d2e0";
    ctx.fillRect(kx - 62, F - 42, 124, 4); // tezgâh
    ctx.fillStyle = "#2d3246";
    rrp(kx - 56, F - 32, 30, 26, 2);
    ctx.fill();
    ctx.strokeStyle = "#6f7698";
    ctx.strokeRect(kx - 54, F - 30, 26, 22); // dolap
    // mikrodalga
    ctx.fillStyle = "#2d3246";
    rrp(kx - 20, F - 70, 40, 26, 3);
    ctx.fill();
    ctx.fillStyle = "#13335c";
    rrp(kx - 17, F - 67, 24, 20, 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,220,150," + (0.2 + 0.15 * Math.sin(t * 3)) + ")";
    rrp(kx - 15, F - 65, 20, 16, 2);
    ctx.fill();
    ctx.fillStyle = "#0a1024";
    rrp(kx + 9, F - 67, 9, 8, 1);
    ctx.fill();
    ctx.fillStyle = "#4ade80";
    ctx.font = "700 5px monospace";
    ctx.fillText(String(Math.floor(t) % 60).padStart(2, "0"), kx + 13.5, F - 61);
    led(kx + 13, F - 54, "#4ade80", true);
    // su sebili
    ctx.fillStyle = "#d9dcea";
    rrp(kx + 26, F - 76, 22, 34, 3);
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = "#38bdf8";
    rrp(kx + 29, F - 73, 16, 18, 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,.35)";
    ctx.beginPath();
    ctx.ellipse(kx + 37, F - 64 + Math.sin(t * 2) * 1.5, 6, 1.6, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = "#5ad1ff";
    ctx.fillRect(kx + 35, F - 48, 4, 6);
    // tabak, bardak, buhar
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.ellipse(kx - 40, F - 43, 8, 2.5, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = "#e8b873";
    ctx.beginPath();
    ctx.ellipse(kx - 40, F - 44.5, 4, 1.8, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = "#38bdf8";
    rrp(kx + 52, F - 50, 6, 8, 1);
    ctx.fill();
    for (let i = 0; i < 3; i++) {
      const ph = (t * 0.6 + i * 0.33) % 1;
      ctx.fillStyle = "rgba(255,255,255," + 0.25 * (1 - ph) + ")";
      ctx.beginPath();
      ctx.arc(kx - 40 + Math.sin(ph * 5 + i) * 3, F - 50 - ph * 22, 2 + ph * 3, 0, 7);
      ctx.fill();
    }
    ctx.fillStyle = "#d9dcea";
    ctx.font = "700 7px monospace";
    ctx.textAlign = "center";
    ctx.fillText(T("MUTFAK"), kx, C + 16);
    ctx.restore();
    // revir dolabı
    const mx = 80;
    ctx.fillStyle = "#f1f4fa";
    rrp(mx - 24, C + 22, 48, 60, 4);
    ctx.fill();
    ctx.strokeStyle = "#9aa3bf";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = "#ff5a5a";
    ctx.fillRect(mx - 4, C + 34, 8, 24);
    ctx.fillRect(mx - 12, C + 42, 24, 8);
    ctx.strokeStyle = "#c9d2e0";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(mx, C + 24);
    ctx.lineTo(mx, C + 80);
    ctx.stroke();
    ctx.fillStyle = "#9aa3bf";
    ctx.fillRect(mx - 6, C + 64, 3, 6);
    ctx.fillRect(mx + 3, C + 64, 3, 6);
    const mk = game.stock.medkit || 0;
    ctx.fillStyle = "#0a1024";
    rrp(mx - 20, C + 86, 40, 12, 2);
    ctx.fill();
    ctx.fillStyle = mk > 0 ? "#4ade80" : "#ff5a5a";
    ctx.font = "700 7px monospace";
    ctx.textAlign = "center";
    ctx.fillText(T("MEDİKİT ×") + mk, mx, C + 95);
    // sedye
    ctx.fillStyle = "#5b6178";
    rrp(mx - 30, F - 30, 60, 5, 2);
    ctx.fill();
    ctx.fillStyle = "#d9dcea";
    rrp(mx - 28, F - 37, 56, 8, 3);
    ctx.fill();
    ctx.fillStyle = "#6f7698";
    ctx.fillRect(mx - 26, F - 25, 4, 25);
    ctx.fillRect(mx + 22, F - 25, 4, 25);
    // kalp monitörü
    waveScreen(mx + 26, C + 30, 24, 20, "#4ade80", t, 0);
    ctx.fillStyle = "#4ade80";
    ctx.font = "700 6px monospace";
    ctx.textAlign = "left";
    ctx.fillText("HR" + Math.round(70 + game.hp * 0.1 + Math.sin(t) * 2), mx + 27, C + 58);
    ctx.fillStyle = "#d9dcea";
    ctx.font = "700 7px monospace";
    ctx.textAlign = "center";
    ctx.fillText(T("REVİR"), mx, C + 16);
    drawCapsule("food", 172, F, C, t);
  }

  /* ===== GÜVERTE 3 — KOMUTA ===== */
  {
    const F = DECKS[2].floor,
      C = DECKS[2].ceil;
    // ön cam (sol) — iletişim masasına yer açmak için dikeyde sıkıştırıldı
    ctx.save();
    ctx.translate(0, C + 14);
    ctx.scale(1, 0.72);
    ctx.translate(0, -(C + 14));
    const wx = -112,
      wy = C + 48;
    ctx.fillStyle = "#6f7698";
    rrp(wx - 46, wy - 34, 92, 68, 16);
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.save();
    rrp(wx - 40, wy - 28, 80, 56, 12);
    ctx.clip();
    const sky = ctx.createLinearGradient(0, wy - 28, 0, wy + 28);
    sky.addColorStop(0, "#0a0712");
    sky.addColorStop(0.5, "#3a1410");
    sky.addColorStop(0.62, S.ground);
    sky.addColorStop(1, S.dot);
    ctx.fillStyle = sky;
    ctx.fillRect(wx - 40, wy - 28, 80, 56);
    for (let i = 0; i < 14; i++) {
      ctx.fillStyle = "rgba(255,255,255," + (0.4 + (i % 3) * 0.2) + ")";
      ctx.fillRect(wx - 38 + ((i * 23) % 78), wy - 26 + ((i * 11) % 22), 1.2, 1.2);
    }
    for (let i = 0; i < 4; i++) {
      const ph = (t * 0.08 + i * 0.25) % 1;
      ctx.fillStyle = "rgba(230,154,112,.35)";
      ctx.beginPath();
      ctx.ellipse(wx - 40 + ph * 80, wy + 12 + Math.sin(i * 2 + t) * 4, 6, 2, 0, 0, 7);
      ctx.fill();
    }
    if (stormFx.I > 0.01) {
      // camdan görünen kum fırtınası
      ctx.fillStyle = "rgba(186,104,54," + 0.82 * Math.min(1, stormFx.I) + ")";
      ctx.fillRect(wx - 40, wy - 28, 80, 56);
      ctx.strokeStyle = "rgba(255,214,170," + 0.6 * stormFx.I + ")";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < 22; i++) {
        const x = wx - 44 + ((i * 23 + t * (260 + (i % 4) * 80)) % 92),
          y = wy - 26 + ((i * 13) % 52);
        ctx.moveTo(x, y);
        ctx.lineTo(x - 9, y - 1);
      }
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(0,0,0,.35)";
    for (const [cx, cr] of [
      [wx - 20, 7],
      [wx + 18, 5],
    ]) {
      ctx.beginPath();
      ctx.ellipse(cx, wy + 18, cr, cr * 0.4, 0, 0, 7);
      ctx.fill();
    }
    ctx.restore();
    ctx.strokeStyle = "rgba(255,255,255,.35)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(wx - 30, wy + 20);
    ctx.lineTo(wx + 10, wy - 22);
    ctx.stroke();
    ctx.strokeStyle = "#8d94b2";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(wx, wy - 34);
    ctx.lineTo(wx, wy + 34);
    ctx.stroke();
    ctx.restore();
    // iletişim terminali — modern: ince masa, kavisli ekran, holografik Dünya
    {
      const cx = -108,
        u = commUnread(),
        tx = !!commTx,
        hc = u ? [255, 200, 80] : tx ? [255, 140, 66] : [90, 209, 255],
        H = `rgba(${hc[0]},${hc[1]},${hc[2]},`;
      // masa: ince beyaz tabla + LED alt ışık
      ctx.fillStyle = "rgba(0,0,0,.35)";
      ctx.beginPath();
      ctx.ellipse(cx, F - 1, 36, 3, 0, 0, 7);
      ctx.fill();
      ctx.fillStyle = "#2a2f45";
      rrp(cx - 4, F - 28, 8, 27, 2);
      ctx.fill();
      ctx.fillStyle = "#3b4160";
      rrp(cx - 16, F - 3, 32, 3, 1.5);
      ctx.fill();
      const dg = ctx.createLinearGradient(0, F - 34, 0, F - 27);
      dg.addColorStop(0, "#f4f6fb");
      dg.addColorStop(1, "#a9b1c9");
      ctx.fillStyle = dg;
      rrp(cx - 36, F - 34, 72, 7, 3.5);
      ctx.fill();
      ctx.save();
      ctx.shadowColor = H + "1)";
      ctx.shadowBlur = 10;
      ctx.fillStyle = H + ".95)";
      rrp(cx - 32, F - 27.5, 64, 1.6, 1);
      ctx.fill();
      ctx.restore();
      const ug = ctx.createLinearGradient(0, F - 27, 0, F);
      ug.addColorStop(0, H + ".22)");
      ug.addColorStop(1, H + "0)");
      ctx.fillStyle = ug;
      ctx.fillRect(cx - 34, F - 27, 68, 26);
      // kavisli ultra geniş ekran
      ctx.fillStyle = "#1d2234";
      rrp(cx - 3, F - 44, 6, 10, 2);
      ctx.fill();
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx - 34, F - 70);
      ctx.quadraticCurveTo(cx, F - 74, cx + 34, F - 70);
      ctx.lineTo(cx + 33, F - 44);
      ctx.quadraticCurveTo(cx, F - 47, cx - 33, F - 44);
      ctx.closePath();
      ctx.fillStyle = "#05080f";
      ctx.fill();
      ctx.strokeStyle = "#6b7390";
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.clip();
      const sg = ctx.createLinearGradient(cx - 34, 0, cx + 34, 0);
      sg.addColorStop(0, "#071426");
      sg.addColorStop(0.5, "#0b2140");
      sg.addColorStop(1, "#071426");
      ctx.fillStyle = sg;
      ctx.fillRect(cx - 34, F - 74, 68, 32);
      // ekran içeriği: sinyal dalgası + çubuklar + metin
      ctx.strokeStyle = H + ".9)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i <= 30; i++) {
        const x = cx - 30 + i,
          y =
            F - 55 + Math.sin(i * 0.6 + t * (tx ? 14 : 3.5)) * (tx ? 4.5 : 2) * Math.sin(i * 0.15 + t * 0.6);
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.stroke();
      for (let i = 0; i < 5; i++) {
        const hh = 3 + i * 2,
          on = i < (tx ? 5 : 4);
        ctx.fillStyle = on ? H + ".9)" : "rgba(255,255,255,.12)";
        ctx.fillRect(cx + 8 + i * 4, F - 49 - hh, 2.6, hh);
      }
      ctx.fillStyle = H + ".95)";
      ctx.font = "700 5px monospace";
      ctx.textAlign = "left";
      ctx.fillText(
        tx
          ? T("UPLINK ") + Math.round(((performance.now() - commTx.t0) / commTx.dur) * 100) + "%"
          : u
            ? u + T(" YENİ MESAJ")
            : T("AĞ · AKTİF"),
        cx - 30,
        F - 64,
      );
      ctx.fillStyle = "rgba(255,255,255,.07)";
      ctx.beginPath();
      ctx.moveTo(cx - 30, F - 70);
      ctx.lineTo(cx - 18, F - 70);
      ctx.lineTo(cx - 28, F - 46);
      ctx.lineTo(cx - 33, F - 46);
      ctx.fill();
      ctx.restore();
      // holografik Dünya küresi
      const gx = cx + 22,
        gy = F - 92,
        R = 11,
        rot = t * 0.8;
      ctx.save();
      ctx.globalCompositeOperation = "lighter";
      const cone = ctx.createLinearGradient(0, gy, 0, F - 34);
      cone.addColorStop(0, H + "0)");
      cone.addColorStop(1, H + ".28)");
      ctx.fillStyle = cone;
      ctx.beginPath();
      ctx.moveTo(gx - R, gy + 2);
      ctx.lineTo(gx + R, gy + 2);
      ctx.lineTo(gx + 3, F - 34);
      ctx.lineTo(gx - 3, F - 34);
      ctx.closePath();
      ctx.fill();
      const hg = ctx.createRadialGradient(gx, gy, 0, gx, gy, R * 1.6);
      hg.addColorStop(0, H + ".25)");
      hg.addColorStop(1, H + "0)");
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.arc(gx, gy, R * 1.6, 0, 7);
      ctx.fill();
      ctx.strokeStyle = H + ".85)";
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.arc(gx, gy, R, 0, 7);
      ctx.stroke();
      for (let k = -2; k <= 2; k++) {
        const yy = gy + k * R * 0.38,
          rr = Math.sqrt(Math.max(0, R * R - (k * R * 0.38) ** 2));
        ctx.beginPath();
        ctx.ellipse(gx, yy, rr, rr * 0.22, 0, 0, 7);
        ctx.stroke();
      }
      for (let k = 0; k < 4; k++) {
        const a = rot + (k * Math.PI) / 4,
          w = Math.abs(Math.cos(a)) * R;
        ctx.beginPath();
        ctx.ellipse(gx, gy, w, R, 0, 0, 7);
        ctx.stroke();
      }
      ctx.fillStyle = H + ".9)";
      for (let k = 0; k < 6; k++) {
        const a = rot * 1.3 + k * 1.05,
          x = gx + Math.cos(a) * R * 0.8,
          z = Math.sin(a);
        if (z > 0) {
          ctx.beginPath();
          ctx.arc(x, gy + Math.sin(k * 2.1) * R * 0.5, 0.9, 0, 7);
          ctx.fill();
        }
      }
      // yörüngedeki uydu + sinyal dalgaları
      const sa = t * 1.6,
        sx2 = gx + Math.cos(sa) * R * 1.5,
        sy2 = gy + Math.sin(sa) * R * 0.45;
      ctx.fillStyle = "#fff";
      ctx.fillRect(sx2 - 1, sy2 - 1, 2, 2);
      if (u || tx) {
        for (let k = 0; k < 3; k++) {
          const ph = (t * 0.9 + k / 3) % 1;
          ctx.strokeStyle = H + (1 - ph) * 0.7 + ")";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(gx, gy, R + 3 + ph * 10, -0.9, 0.9);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(gx, gy, R + 3 + ph * 10, Math.PI - 0.9, Math.PI + 0.9);
          ctx.stroke();
        }
      }
      ctx.restore();
      // projektör yuvası + mikrofon
      ctx.fillStyle = "#c9d0e2";
      rrp(gx - 6, F - 37, 12, 3, 1.5);
      ctx.fill();
      ctx.fillStyle = H + ".9)";
      ctx.fillRect(gx - 3, F - 37.5, 6, 1);
      ctx.strokeStyle = "#8d94b2";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(cx - 26, F - 34);
      ctx.quadraticCurveTo(cx - 30, F - 46, cx - 24, F - 50);
      ctx.stroke();
      ctx.fillStyle = "#1d2234";
      ctx.beginPath();
      ctx.arc(cx - 24, F - 50, 2, 0, 7);
      ctx.fill();
      ctx.fillStyle = "#d9dcea";
      ctx.font = "700 6px monospace";
      ctx.textAlign = "center";
      ctx.fillText(T("İLETİŞİM"), cx - 6, F - 18);
    }
    // ana konsol (navigasyon)
    const nx = -10;
    const kg = ctx.createLinearGradient(0, F - 50, 0, F);
    kg.addColorStop(0, "#5b6178");
    kg.addColorStop(1, "#2d3246");
    ctx.fillStyle = kg;
    ctx.beginPath();
    ctx.moveTo(nx - 56, F - 48);
    ctx.lineTo(nx + 56, F - 48);
    ctx.lineTo(nx + 62, F);
    ctx.lineTo(nx - 62, F);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    // büyük nav ekranı
    screenBox(nx - 40, C + 22, 80, 54, "#5ad1ff", true);
    ctx.save();
    ctx.beginPath();
    ctx.rect(nx - 38, C + 24, 76, 50);
    ctx.clip();
    for (let i = 0; i < 18; i++) {
      ctx.fillStyle = "rgba(255,255,255,.5)";
      ctx.fillRect(nx - 38 + ((i * 29) % 76), C + 24 + ((i * 17) % 50), 1, 1);
    }
    const mxp = nx - 22,
      exp = nx + 24,
      oy = C + 52;
    ctx.strokeStyle = "rgba(90,209,255,.5)";
    ctx.setLineDash([3, 3]);
    ctx.lineDashOffset = -t * 8;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(mxp, oy);
    ctx.quadraticCurveTo(nx, oy - 22, exp, oy);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#e0663a";
    ctx.beginPath();
    ctx.arc(mxp, oy, 7, 0, 7);
    ctx.fill();
    ctx.fillStyle = "#5ab0f0";
    ctx.beginPath();
    ctx.arc(exp, oy, 8, 0, 7);
    ctx.fill();
    ctx.fillStyle = "#3fa866";
    ctx.beginPath();
    ctx.arc(exp - 2, oy - 2, 3, 0, 7);
    ctx.fill();
    const rp = (t * 0.25) % 1;
    const qx = mxp + (exp - mxp) * rp,
      qy = oy - (22 * 4 * rp * (1 - rp)) / 2;
    if (game.progIdx >= PROG_ORDER.length - 1) {
      ctx.fillStyle = "#fff";
      ctx.beginPath();
      ctx.moveTo(qx, qy - 4);
      ctx.lineTo(qx + 4, qy + 3);
      ctx.lineTo(qx - 4, qy + 3);
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillStyle = "#5ad1ff";
    ctx.font = "700 6px monospace";
    ctx.textAlign = "center";
    ctx.fillText(T("MARS"), mxp, oy + 14);
    ctx.fillText(T("DÜNYA"), exp, oy + 16);
    ctx.textAlign = "left";
    ctx.fillStyle = "#9fe3ff";
    ctx.fillText(
      T("NAV v2.1 · SOL ") +
        gameDayNumber() +
        T(" · KARGO ") +
        Math.min(game.cargo, CFG.cargoGoal) +
        "/" +
        CFG.cargoGoal,
      nx - 36,
      C + 31,
    );
    ctx.fillStyle = game.repair.state === "ok" ? "#4ade80" : "#ff5a5a";
    ctx.fillText(game.repair.state === "ok" ? T("SİSTEM: HAZIR") : T("KALKIŞ KİLİTLİ"), nx - 36, C + 70);
    ctx.restore();
    // yan ekranlar
    waveScreen(nx + 44, C + 58, 30, 18, "#ffb347", t, 1);
    radarScreen(nx + 58, C + 38, 12, "#4ade80", t);
    // klavye, düğmeler, LED'ler
    ctx.fillStyle = "#1b1e2e";
    rrp(nx - 30, F - 40, 60, 12, 2);
    ctx.fill();
    for (let r = 0; r < 2; r++)
      for (let i = 0; i < 10; i++) {
        ctx.fillStyle = "#6f7698";
        ctx.fillRect(nx - 27 + i * 5.8, F - 38 + r * 5, 4, 3.5);
      }
    for (let i = 0; i < 8; i++)
      led(
        nx - 50 + i * 14,
        F - 22,
        ["#4ade80", "#ffd34d", "#5ad1ff", "#ff5a5a"][i % 4],
        Math.sin(t * (2 + i * 0.7) + i) > -0.2,
      );
    for (let i = 0; i < 3; i++) {
      ctx.fillStyle = "#c0392b";
      ctx.beginPath();
      ctx.arc(nx + 30 + i * 12, F - 30, 4, 0, 7);
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,.3)";
      ctx.beginPath();
      ctx.arc(nx + 29 + i * 12, F - 31, 1.5, 0, 7);
      ctx.fill();
    }
    ctx.fillStyle = "#ffb347";
    ctx.fillRect(nx - 52, F - 32, 10, 3);
    ctx.fillRect(nx - 52, F - 27, 10, 3); // şalterler
    ctx.fillStyle = "#d9dcea";
    ctx.font = "700 7px monospace";
    ctx.textAlign = "center";
    ctx.fillText(T("NAVİGASYON"), nx, C + 16);
    // ticaret / tedarik terminali
    const tx = 92;
    ctx.fillStyle = "#3b4160";
    rrp(tx - 26, C + 20, 52, F - C - 20, 4);
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    screenBox(tx - 20, C + 28, 40, 46, "#ffb347", true);
    ctx.save();
    ctx.beginPath();
    ctx.rect(tx - 18, C + 30, 36, 42);
    ctx.clip();
    ctx.font = "700 6px monospace";
    ctx.textAlign = "left";
    const SK = game.stock,
      rows = [
        ["💧", SK.water],
        ["🥔", SK.potato],
        ["💊", SK.medkit],
      ];
    rows.forEach((r, i) => {
      ctx.fillStyle = "#ffe3c0";
      ctx.fillText(r[0] + " ×" + r[1], tx - 16, C + 40 + i * 9);
    });
    const tick = (t * 14) % 80;
    ctx.fillStyle = "#ffd34d";
    ctx.fillText(
      T("KARGO ") + Math.min(game.cargo, CFG.cargoGoal) + "/" + CFG.cargoGoal + "  ",
      tx + 20 - tick,
      C + 68,
    );
    ctx.fillStyle = "rgba(255,179,71," + (0.08 + 0.05 * Math.sin(t * 6)) + ")";
    ctx.fillRect(tx - 18, C + 30 + ((t * 30) % 42), 36, 3);
    ctx.restore();
    ctx.fillStyle = "#1b1e2e";
    rrp(tx - 18, C + 80, 36, 10, 2);
    ctx.fill();
    for (let i = 0; i < 6; i++) {
      ctx.fillStyle = "#6f7698";
      ctx.fillRect(tx - 16 + i * 5.8, C + 82, 4, 6);
    }
    ctx.fillStyle = "#0a1024";
    rrp(tx - 14, C + 96, 28, 14, 3);
    ctx.fill();
    ctx.strokeStyle = "#4ade80";
    ctx.lineWidth = 1;
    ctx.stroke(); // kart yuvası
    ctx.fillStyle = "#4ade80";
    ctx.fillRect(tx - 10, C + 102, 20, 2);
    led(tx + 18, C + 24, "#4ade80", Math.sin(t * 3) > 0);
    ctx.fillStyle = "#d9dcea";
    ctx.font = "700 7px monospace";
    ctx.textAlign = "center";
    ctx.fillText(T("STOK"), tx, C + 16);
    // sinyal anteni paneli
    ctx.strokeStyle = "#8d94b2";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(130, C + 20);
    ctx.lineTo(130, C + 4);
    ctx.stroke();
    ctx.fillStyle = Math.sin(t * 5) > 0 ? "#ff5a5a" : "#6a2222";
    ctx.beginPath();
    ctx.arc(130, C + 3, 2, 0, 7);
    ctx.fill();
  }

  /* --- merdivenler --- */
  for (const l of LADDERS) {
    const top = DECKS[l.to].floor,
      bot = DECKS[l.from].floor;
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(l.x - 9, top - 4);
    ctx.lineTo(l.x - 9, bot);
    ctx.moveTo(l.x + 9, top - 4);
    ctx.lineTo(l.x + 9, bot);
    ctx.stroke();
    ctx.strokeStyle = "#ffb347";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(l.x - 9, top - 4);
    ctx.lineTo(l.x - 9, bot);
    ctx.moveTo(l.x + 9, top - 4);
    ctx.lineTo(l.x + 9, bot);
    ctx.stroke();
    ctx.strokeStyle = "#c9d2e0";
    ctx.lineWidth = 2.5;
    for (let yy = top + 8; yy < bot; yy += 14) {
      ctx.beginPath();
      ctx.moveTo(l.x - 9, yy);
      ctx.lineTo(l.x + 9, yy);
      ctx.stroke();
    }
    // güverte deliği
    ctx.fillStyle = "#1b1e2e";
    ctx.fillRect(l.x - 16, top - 1, 32, 24);
    ctx.strokeStyle = "#ffb347";
    ctx.lineWidth = 2;
    ctx.strokeRect(l.x - 16, top - 1, 32, 24);
  }

  updateDrawInSmoke(game.repair.state !== "ok", t); // duman oyuncunun arkasında kalır
  /* --- oyuncu --- */
  const near = nearStation();
  if (near && !ip.climb && !game.wake) {
    // istasyon vurgusu
    const d = DECKS[ip.deck];
    ctx.fillStyle = "rgba(255,211,77," + (0.08 + 0.05 * Math.sin(t * 5)) + ")";
    rrp(near.x - near.w, d.ceil + 8, near.w * 2, d.floor - d.ceil - 8, 6);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,211,77,.5)";
    ctx.lineWidth = 1.2;
    ctx.stroke();
  }
  drawQuestTarget(t);
  const py = (ip.climb ? ip.y : DECKS[ip.deck].floor) - 45;
  if (ip.deck === 0 && !game.sleeping && !ip.climb) drawO2FillFx(DECKS[0].floor, DECKS[0].ceil, t, ip.x, py); // hortum gövdenin arkasında
  if (ip.climb) {
    // tırmanma: merdivene yaslı, kollar yukarı
    ctx.save();
    ctx.translate(ip.x, py);
    ctx.scale(0.92, 1);
    ctx.translate(-ip.x, -py);
    astronaut(ip.x, py, false, null, 0);
    ctx.restore();
  } else if (game.wake) {
    drawWakeAstro(t);
  } else if (game.sleeping) {
    // kapsülde sırt üstü
    const F1 = DECKS[1].floor,
      pd = p.dir;
    p.dir = 1;
    ASTRO_POSE = { ns: true, b: [0, 0], f: [0, 0] };
    ctx.save();
    ctx.translate(-120, F1 - 37);
    ctx.rotate(-Math.PI / 2);
    ctx.scale(0.52, 0.52 + Math.sin(t * 1.6) * 0.008);
    astronaut(0, -16, false, null, 0);
    ctx.restore();
    ASTRO_POSE = null;
    p.dir = pd;
  } else {
    const hk = heldItemKey();
    drawAstroGrav(ip.x, py, ip.climb ? 0 : ip.z || 0, p._running, hk === "pickaxe" ? null : hk, p.actionT);
  }
  drawPodCanopy(t);

  ctx.restore(); // hull clip
  // cidar konturu
  ctx.strokeStyle = "#5f6886";
  ctx.lineWidth = 5;
  hullPath();
  ctx.stroke();
  ctx.strokeStyle = "#c9d2e0";
  ctx.lineWidth = 1.5;
  hullPath();
  ctx.stroke();
  // kesit perçinleri
  ctx.fillStyle = "#9aa3bf";
  for (let yy = -120; yy < 520; yy += 40) {
    for (const s of [-1, 1]) {
      const xx =
        s * (yy < 20 ? 60 + (yy + 176) * 0.55 : yy < 300 ? 160 + (yy - 20) * 0.27 : 236 + (yy - 300) * 0.018);
      ctx.beginPath();
      ctx.arc(xx * 0.985, yy, 1.6, 0, 7);
      ctx.fill();
    }
  }
  // dış kanatlar (kesit dışında dekor)
  ctx.fillStyle = "#b7291f";
  ctx.beginPath();
  ctx.moveTo(-238, 380);
  ctx.lineTo(-300, 522);
  ctx.lineTo(-240, 522);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(238, 380);
  ctx.lineTo(300, 522);
  ctx.lineTo(240, 522);
  ctx.closePath();
  ctx.fill();
  // güverte adı rozeti
  ctx.restore();
  const dn = DECKS[ip.deck];
  ctx.save();
  ctx.textAlign = "center";
  ctx.font = "800 13px 'Segoe UI',sans-serif";
  ctx.fillStyle = "rgba(0,0,0,.55)";
  const alH = $("alerts").offsetHeight,
    by = 14 + (alH ? alH + 8 : 0);
  rrp(W / 2 - 110, by, 220, 24, 8);
  ctx.fill();
  ctx.fillStyle = "#ffd08a";
  ctx.fillText("🚀 " + dn.name, W / 2, by + 17);
  ctx.restore();
  // iç vinyet
  const vg = ctx.createRadialGradient(
    W / 2,
    H / 2,
    Math.min(W, H) * 0.3,
    W / 2,
    H / 2,
    Math.max(W, H) * 0.75,
  );
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(0,0,0,.5)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);
  if (flash > 0) {
    ctx.fillStyle = "rgba(255,60,60," + flash * 0.4 * (settings.noflash ? 0.35 : 1) + ")";
    ctx.fillRect(0, 0, W, H);
  }
}

/* ============== ANA MOTOR ONARIMI — 4 aşamalı mini oyun ==============
   1) Kabloları bağla  2) Yanık sigortaları değiştir + ana şalter
   3) Basınç kalibrasyonu (zamanlama)  4) Ateşleme dizisi (hafıza)
   Tamamlanan aşamalar game.repair.stage içinde saklanır. */
let repairOpen = false;
const RP_STEPS = [
  { ic: "🔌", nm: T("Kablolar") },
  { ic: "⚡", nm: T("Sigortalar") },
  { ic: "🎚️", nm: T("Basınç") },
  { ic: "🔥", nm: T("Ateşleme") },
];
const rp = { stage: 0, cleanup: [], timers: [], raf: 0, busy: false };
const SVGNS = "http://www.w3.org/2000/svg";
function svgEl(tag, attrs, parent) {
  const e = document.createElementNS(SVGNS, tag);
  for (const k in attrs) e.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(e);
  return e;
}
function svgPt(svg, ev) {
  const pt = svg.createSVGPoint();
  pt.x = ev.clientX;
  pt.y = ev.clientY;
  return pt.matrixTransform(svg.getScreenCTM().inverse());
}
function rpLater(fn, ms) {
  const id = setTimeout(fn, ms);
  rp.timers.push(id);
  return id;
}
function rpCleanup() {
  rp.cleanup.forEach((f) => {
    try {
      f();
    } catch (e) {}
  });
  rp.cleanup = [];
  rp.timers.forEach(clearTimeout);
  rp.timers = [];
  cancelAnimationFrame(rp.raf);
  rp.busy = false;
}
function rpBase(area) {
  const svg = svgEl(
    "svg",
    { viewBox: "0 0 460 260", width: "100%", height: "100%", preserveAspectRatio: "xMidYMid meet" },
    area,
  );
  const defs = svgEl("defs", {}, svg);
  defs.innerHTML = `
    <linearGradient id="rpSteel" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3b4670"/><stop offset="1" stop-color="#222a4a"/></linearGradient>
    <linearGradient id="rpGlass" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#cfe9ff" stop-opacity=".55"/><stop offset=".5" stop-color="#7fb6e0" stop-opacity=".18"/><stop offset="1" stop-color="#cfe9ff" stop-opacity=".4"/></linearGradient>
    <radialGradient id="rpHole"><stop offset="0" stop-color="#000"/><stop offset="1" stop-color="#1a2140"/></radialGradient>
    <pattern id="rpGrid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0V20" fill="none" stroke="rgba(120,160,255,.07)" stroke-width="1"/></pattern>`;
  svgEl("rect", { x: 0, y: 0, width: 460, height: 260, fill: "url(#rpGrid)" }, svg);
  return svg;
}
function screw(svg, x, y) {
  svgEl("circle", { cx: x, cy: y, r: 3.2, fill: "#8d96b8", stroke: "#1a2140", "stroke-width": 1 }, svg);
  svgEl("line", { x1: x - 2, y1: y - 2, x2: x + 2, y2: y + 2, stroke: "#1a2140", "stroke-width": 1 }, svg);
}
function sparkAt(svg, x, y, col) {
  const g = svgEl("g", {}, svg);
  for (let i = 0; i < 8; i++) {
    const a = Math.random() * 6.28,
      l = 8 + Math.random() * 12;
    svgEl(
      "line",
      {
        x1: x,
        y1: y,
        x2: x + Math.cos(a) * l,
        y2: y + Math.sin(a) * l,
        stroke: col || "#ffe9a8",
        "stroke-width": 1.6,
        "stroke-linecap": "round",
      },
      g,
    );
  }
  svgEl("circle", { cx: x, cy: y, r: 5, fill: "#fff" }, g);
  g.animate(
    [
      { opacity: 1, transform: "scale(1)" },
      { opacity: 0, transform: "scale(1.4)" },
    ],
    { duration: 420, easing: "ease-out" },
  ).onfinish = () => g.remove();
  g.style.transformOrigin = x + "px " + y + "px";
}
function shakeStage() {
  $("rpStage").animate(
    [
      { transform: "translateX(0)" },
      { transform: "translateX(-6px)" },
      { transform: "translateX(5px)" },
      { transform: "translateX(-3px)" },
      { transform: "translateX(0)" },
    ],
    { duration: 260 },
  );
}

/* ---------- açma / kapama ---------- */
function openRepair() {
  if (!game.repair || game.repair.state === "ok") {
    sfx("click");
    toast(T("✅ Ana motor çalışıyor — onarım gerekmiyor"));
    return;
  }
  repairOpen = true;
  rp.stage = Math.max(0, Math.min(3, game.repair.stage || 0));
  $("repairScreen").classList.remove("hidden");
  renderRepair();
}
function closeRepair() {
  repairOpen = false;
  rpCleanup();
  $("repairScreen").classList.add("hidden");
  focusGame();
}
function renderRepair() {
  rpCleanup();
  const st = $("rpSteps");
  st.innerHTML = "";
  RP_STEPS.forEach((s, i) => {
    const d = document.createElement("div");
    d.className = "step" + (i < rp.stage ? " done" : i === rp.stage ? " on" : "");
    d.innerHTML = `<span class="si">${i < rp.stage ? "✔" : s.ic}</span><span>${i + 1}. ${s.nm}</span>`;
    st.appendChild(d);
  });
  $("rpChip").textContent = T("AŞAMA ") + Math.min(4, rp.stage + 1) + "/4";
  $("rpFootR").textContent = T("İLERLEME ") + Math.round((rp.stage / 4) * 100) + "%";
  const area = $("rpStage");
  area.innerHTML = "";
  [rpWires, rpFuses, rpPressure, rpIgnite][rp.stage](area);
}
function rpStageDone(label) {
  if (rp.busy) return;
  rp.busy = true;
  sfx("star");
  rp.stage++;
  game.repair.stage = rp.stage;
  const area = $("rpStage");
  const ok = document.createElement("div");
  ok.className = "rp-ok";
  ok.innerHTML = "<b>✔</b>" + label;
  area.appendChild(ok);
  if (rp.stage >= 4) {
    rpLater(finishRepair, 900);
    return;
  }
  rpLater(renderRepair, 1000);
}
function finishRepair() {
  rpCleanup();
  game.repair = { state: "ok", end: 0, stage: 0 };
  bumpQuest("repaired");
  if (rkArmor() === 0) storyTrigger("stormLesson");
  RP_STEPS.forEach((s, i) => {
    const d = $("rpSteps").children[i];
    if (d) {
      d.className = "step done";
      d.firstChild.textContent = "✔";
    }
  });
  $("rpChip").textContent = T("TAMAMLANDI");
  $("rpFootR").textContent = T("İLERLEME 100%");
  $("rpIns").innerHTML = T("Tüm sistemler <b>çevrimiçi</b>. Roket kalkışa hazır.");
  const area = $("rpStage");
  area.innerHTML = "";
  const svg = rpBase(area);
  const g = svgEl("g", {}, svg);
  for (let i = 0; i < 3; i++) {
    const c = svgEl(
      "circle",
      { cx: 230, cy: 92, r: 40, fill: "none", stroke: "#4ade80", "stroke-width": 2, opacity: 0.6 },
      g,
    );
    c.animate(
      [
        { r: 40, opacity: 0.6 },
        { r: 110, opacity: 0 },
      ],
      { duration: 1600, delay: i * 500, iterations: Infinity },
    );
  }
  svgEl("circle", { cx: 230, cy: 92, r: 44, fill: "#0f2a24", stroke: "#4ade80", "stroke-width": 3 }, svg);
  const ck = svgEl(
    "path",
    {
      d: "M208 93 L224 109 L254 76",
      fill: "none",
      stroke: "#4ade80",
      "stroke-width": 8,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-dasharray": 80,
      "stroke-dashoffset": 80,
    },
    svg,
  );
  ck.animate([{ strokeDashoffset: 80 }, { strokeDashoffset: 0 }], {
    duration: 500,
    fill: "forwards",
    easing: "ease-out",
  });
  const tx = svgEl(
    "text",
    {
      x: 230,
      y: 168,
      "text-anchor": "middle",
      fill: "#e8f1ff",
      "font-size": 17,
      "font-weight": 800,
      "letter-spacing": "3",
    },
    svg,
  );
  tx.textContent = T("MOTOR ÇEVRİMİÇİ");
  const t2 = svgEl(
    "text",
    {
      x: 230,
      y: 188,
      "text-anchor": "middle",
      fill: "#8d9cc0",
      "font-size": 11,
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  t2.textContent = T("İTKİ ÇEKİRDEĞİ STABİL · KALKIŞ KİLİDİ AÇIK");
  const b = document.createElement("button");
  b.className = "cbtn pri rp-close";
  b.textContent = T("Harika — kapat");
  b.onclick = closeRepair;
  area.appendChild(b);
  sfx("travel");
  toast(T("🔧 Ana motor onarıldı — roket kalkışa hazır!"));
  shake = Math.max(shake, 6);
}

/* ---------- 1) KABLOLAR ---------- */
function rpWires(area) {
  $("rpIns").innerHTML = T(
    "Kopan <b>güç kablolarını</b> aynı renkteki motor soketlerine sürükle (ya da önce kabloya, sonra sokete tıkla).",
  );
  const svg = rpBase(area);
  const COLS = ["#ff5a5a", "#ffd34d", "#38bdf8", "#4ade80"],
    DARK = ["#8a2626", "#8a6d12", "#155f86", "#1d7a43"];
  let order = [0, 1, 2, 3];
  do {
    order.sort(() => Math.random() - 0.5);
  } while (order.every((v, i) => v === i));
  const Y = (i) => 52 + i * 52;
  // paneller
  for (const [px, lab] of [
    [14, T("GÜÇ ÜNİTESİ")],
    [376, T("ANA MOTOR")],
  ]) {
    svgEl(
      "rect",
      {
        x: px,
        y: 22,
        width: 70,
        height: 222,
        rx: 10,
        fill: "url(#rpSteel)",
        stroke: "#5b6aa0",
        "stroke-width": 1.2,
      },
      svg,
    );
    const t = svgEl(
      "text",
      {
        x: px + 35,
        y: 16,
        "text-anchor": "middle",
        fill: "#8d9cc0",
        "font-size": 9,
        "font-weight": 700,
        "letter-spacing": "1.5",
        "font-family": "ui-monospace,Consolas,monospace",
      },
      svg,
    );
    t.textContent = lab;
    screw(svg, px + 8, 30);
    screw(svg, px + 62, 30);
    screw(svg, px + 8, 236);
    screw(svg, px + 62, 236);
  }
  // ortadaki uyarı
  const warn = svgEl(
    "text",
    {
      x: 230,
      y: 134,
      "text-anchor": "middle",
      fill: "#ff5a5a",
      "font-size": 13,
      "font-weight": 800,
      "letter-spacing": "4",
      opacity: 0.35,
    },
    svg,
  );
  warn.textContent = T("⚠ DEVRE AÇIK");
  warn.animate([{ opacity: 0.15 }, { opacity: 0.5 }], {
    duration: 600,
    iterations: Infinity,
    direction: "alternate",
  });
  const wiresG = svgEl("g", {}, svg);
  // soketler (sağ)
  const sockets = order.map((ci, j) => {
    const y = Y(j),
      g = svgEl("g", { style: "cursor:pointer" }, svg);
    svgEl("rect", { x: 384, y: y - 16, width: 52, height: 32, rx: 8, fill: "#141b36", stroke: "#3a4675" }, g);
    const ring = svgEl(
      "circle",
      { cx: 398, cy: y, r: 11, fill: "url(#rpHole)", stroke: COLS[ci], "stroke-width": 3 },
      g,
    );
    svgEl("circle", { cx: 398, cy: y, r: 3, fill: "#000" }, g);
    const led = svgEl("circle", { cx: 424, cy: y, r: 4, fill: "#3a2020" }, g);
    return { x: 398, y, ci, ring, led, g, done: false };
  });
  // fişler (sol)
  const plugs = [0, 1, 2, 3].map((i) => {
    const y = Y(i),
      g = svgEl("g", { style: "cursor:grab" }, svg);
    svgEl("rect", { x: 20, y: y - 16, width: 52, height: 32, rx: 8, fill: "#141b36", stroke: "#3a4675" }, g);
    svgEl(
      "line",
      { x1: 24, y1: y, x2: 62, y2: y, stroke: DARK[i], "stroke-width": 10, "stroke-linecap": "round" },
      g,
    );
    svgEl(
      "line",
      { x1: 24, y1: y, x2: 62, y2: y, stroke: COLS[i], "stroke-width": 6, "stroke-linecap": "round" },
      g,
    );
    const head = svgEl(
      "rect",
      { x: 60, y: y - 9, width: 22, height: 18, rx: 4, fill: COLS[i], stroke: DARK[i], "stroke-width": 2 },
      g,
    );
    svgEl("rect", { x: 80, y: y - 4, width: 8, height: 3, fill: "#c9d2e0" }, g);
    svgEl("rect", { x: 80, y: y + 1, width: 8, height: 3, fill: "#c9d2e0" }, g);
    // kopuk tel uçları
    const fr = svgEl(
      "path",
      { d: `M84 ${y} l6 -5 l4 7 l5 -6`, fill: "none", stroke: "#ffe9a8", "stroke-width": 1.2, opacity: 0.0 },
      g,
    );
    fr.animate([{ opacity: 0 }, { opacity: 1 }, { opacity: 0 }], {
      duration: 300 + i * 90,
      iterations: Infinity,
    });
    return { x: 86, y, i, g, head, done: false };
  });
  function wirePath(x1, y1, x2, y2, ci) {
    const g = svgEl("g", { style: "pointer-events:none" }, wiresG);
    const d = `M${x1} ${y1} C ${x1 + 110} ${y1}, ${x2 - 110} ${y2}, ${x2} ${y2}`;
    svgEl(
      "path",
      {
        d,
        fill: "none",
        stroke: "rgba(0,0,0,.45)",
        "stroke-width": 11,
        "stroke-linecap": "round",
        transform: "translate(2,4)",
      },
      g,
    );
    svgEl("path", { d, fill: "none", stroke: DARK[ci], "stroke-width": 10, "stroke-linecap": "round" }, g);
    svgEl("path", { d, fill: "none", stroke: COLS[ci], "stroke-width": 6, "stroke-linecap": "round" }, g);
    svgEl(
      "path",
      {
        d,
        fill: "none",
        stroke: "rgba(255,255,255,.35)",
        "stroke-width": 1.6,
        "stroke-linecap": "round",
        transform: "translate(0,-1.5)",
      },
      g,
    );
    return g;
  }
  let drag = null,
    sel = null,
    count = 0;
  function connect(pl, sk) {
    if (sk.done || pl.done) return false;
    if (sk.ci !== pl.i) {
      sfx("error");
      sparkAt(svg, sk.x, sk.y, "#ff7b7b");
      shakeStage();
      sk.ring.animate([{ strokeWidth: 3 }, { strokeWidth: 7 }, { strokeWidth: 3 }], { duration: 300 });
      return false;
    }
    pl.done = sk.done = true;
    count++;
    wirePath(pl.x, pl.y, sk.x, sk.y, pl.i);
    sk.led.setAttribute("fill", "#4ade80");
    sk.led.style.filter = "drop-shadow(0 0 4px #4ade80)";
    pl.g.style.cursor = "default";
    pl.g.style.opacity = ".85";
    sparkAt(svg, sk.x, sk.y);
    sfx("pickup");
    if (count === 4) {
      warn.textContent = T("✔ DEVRE KAPALI");
      warn.setAttribute("fill", "#4ade80");
      rpLater(() => rpStageDone(T("Kablolar bağlandı")), 350);
    }
    return true;
  }
  function sockAt(p) {
    return sockets.find((s) => Math.hypot(p.x - s.x, p.y - s.y) < 24);
  }
  function plugAt(p) {
    return plugs.find((q) => !q.done && p.x > 14 && p.x < 96 && Math.abs(p.y - q.y) < 20);
  }
  svg.addEventListener("pointerdown", (ev) => {
    const p = svgPt(svg, ev);
    const pl = plugAt(p);
    if (pl) {
      drag = { pl, sx: p.x, sy: p.y, moved: false, el: null };
      svg.setPointerCapture(ev.pointerId);
      plugs.forEach((q) => q.head.setAttribute("stroke-width", 2));
      pl.head.setAttribute("stroke-width", 4);
      sfx("click");
      return;
    }
    const sk = sockAt(p);
    if (sk && sel) {
      connect(sel, sk);
      sel.head.setAttribute("stroke-width", 2);
      sel = null;
    }
  });
  svg.addEventListener("pointermove", (ev) => {
    if (!drag) return;
    const p = svgPt(svg, ev);
    if (Math.hypot(p.x - drag.sx, p.y - drag.sy) > 5) drag.moved = true;
    if (!drag.moved) return;
    if (drag.el) drag.el.remove();
    drag.el = wirePath(drag.pl.x, drag.pl.y, p.x, p.y, drag.pl.i);
  });
  svg.addEventListener("pointerup", (ev) => {
    if (!drag) return;
    const p = svgPt(svg, ev);
    if (drag.el) drag.el.remove();
    if (!drag.moved) {
      sel = drag.pl;
    } // tıkla-bağla modu
    else {
      const sk = sockAt(p);
      if (sk) connect(drag.pl, sk);
      else sfx("full");
      drag.pl.head.setAttribute("stroke-width", 2);
      sel = null;
    }
    drag = null;
  });
}

/* ---------- 2) SİGORTALAR ---------- */
function rpFuses(area) {
  $("rpIns").innerHTML = T(
    "Kısa devre <b>sigortaları yaktı</b>. Kararmış olanlara tıklayıp değiştir, sonra <b>ana şalteri</b> kaldır. Sağlamlara dokunma!",
  );
  const svg = rpBase(area);
  svgEl(
    "rect",
    {
      x: 18,
      y: 20,
      width: 310,
      height: 222,
      rx: 12,
      fill: "url(#rpSteel)",
      stroke: "#5b6aa0",
      "stroke-width": 1.2,
    },
    svg,
  );
  screw(svg, 28, 30);
  screw(svg, 318, 30);
  screw(svg, 28, 232);
  screw(svg, 318, 232);
  const lab = svgEl(
    "text",
    {
      x: 173,
      y: 40,
      "text-anchor": "middle",
      fill: "#8d9cc0",
      "font-size": 9,
      "font-weight": 700,
      "letter-spacing": "2",
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  lab.textContent = T("SİGORTA PANOSU · 40A");
  const N = 10,
    burnt = new Set();
  while (burnt.size < 4) burnt.add(Math.floor(Math.random() * N));
  let left = 4;
  const fuses = [];
  for (let i = 0; i < N; i++) {
    const col = i % 5,
      row = Math.floor(i / 5),
      x = 48 + col * 57,
      y = 56 + row * 92;
    const g = svgEl("g", { style: "cursor:pointer" }, svg);
    svgEl(
      "rect",
      { x: x - 16, y: y - 6, width: 32, height: 76, rx: 6, fill: "#141b36", stroke: "#3a4675" },
      g,
    );
    svgEl("rect", { x: x - 9, y: y - 2, width: 18, height: 10, rx: 2, fill: "#aab3d6" }, g);
    svgEl("rect", { x: x - 9, y: y + 54, width: 18, height: 10, rx: 2, fill: "#aab3d6" }, g);
    const tube = svgEl("rect", { x: x - 8, y: y + 8, width: 16, height: 46, rx: 3 }, g);
    const fil = svgEl("path", { fill: "none", "stroke-width": 1.8, "stroke-linecap": "round" }, g);
    const soot = svgEl("ellipse", { cx: x, cy: y + 31, rx: 6, ry: 12, fill: "rgba(0,0,0,.6)" }, g);
    svgEl("rect", { x: x - 8, y: y + 8, width: 16, height: 46, rx: 3, fill: "url(#rpGlass)" }, g);
    const led = svgEl("circle", { cx: x, cy: y + 76, r: 3.5 }, svg);
    const f = { i, x, y, g, tube, fil, soot, led, bad: burnt.has(i) };
    fuses.push(f);
    paint(f);
    g.addEventListener("pointerdown", () => clickFuse(f));
  }
  function paint(f) {
    const { x, y } = f;
    if (f.bad) {
      f.tube.setAttribute("fill", "#1b1210");
      f.fil.setAttribute("d", `M${x} ${y + 10} l-3 7 l5 6 M${x} ${y + 52} l3 -8 l-4 -6`);
      f.fil.setAttribute("stroke", "#5a3a2a");
      f.soot.setAttribute("opacity", 1);
      f.led.setAttribute("fill", "#ff3b3b");
      if (!f.blink)
        f.blink = f.led.animate([{ opacity: 1 }, { opacity: 0.15 }], {
          duration: 420 + Math.random() * 300,
          iterations: Infinity,
          direction: "alternate",
        });
    } else {
      f.tube.setAttribute("fill", "#2a2410");
      f.fil.setAttribute("d", `M${x} ${y + 10} l-3 7 l6 7 l-6 7 l6 7 l-6 7 l3 7`);
      f.fil.setAttribute("stroke", "#ffd34d");
      f.fil.style.filter = "drop-shadow(0 0 3px #ffb347)";
      f.soot.setAttribute("opacity", 0);
      f.led.setAttribute("fill", "#4ade80");
      if (f.blink) {
        f.blink.cancel();
        f.blink = null;
      }
    }
  }
  function clickFuse(f) {
    if (lever.on) return;
    if (!f.bad) {
      sfx("error");
      sparkAt(svg, f.x, f.y + 30, "#ff7b7b");
      shakeStage();
      return;
    }
    f.bad = false;
    left--;
    f.g.animate(
      [{ transform: "translateY(0)" }, { transform: "translateY(-10px)" }, { transform: "translateY(0)" }],
      { duration: 280, easing: "ease-out" },
    );
    f.g.style.transformOrigin = "center";
    paint(f);
    sparkAt(svg, f.x, f.y + 30, "#fff3b0");
    sfx("pickup");
    cnt.textContent = T("YANIK: ") + left;
    if (left === 0) {
      cnt.textContent = T("ŞALTERİ KALDIR");
      cnt.setAttribute("fill", "#ffd34d");
      leverHint.animate([{ opacity: 0.2 }, { opacity: 1 }], {
        duration: 500,
        iterations: Infinity,
        direction: "alternate",
      });
    }
  }
  // ana şalter
  svgEl(
    "rect",
    {
      x: 346,
      y: 20,
      width: 96,
      height: 222,
      rx: 12,
      fill: "url(#rpSteel)",
      stroke: "#5b6aa0",
      "stroke-width": 1.2,
    },
    svg,
  );
  const t = svgEl(
    "text",
    {
      x: 394,
      y: 40,
      "text-anchor": "middle",
      fill: "#8d9cc0",
      "font-size": 9,
      "font-weight": 700,
      "letter-spacing": "2",
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  t.textContent = T("ANA ŞALTER");
  svgEl("rect", { x: 376, y: 64, width: 36, height: 130, rx: 8, fill: "#0a1024", stroke: "#3a4675" }, svg);
  for (let i = 0; i < 6; i++)
    svgEl(
      "rect",
      {
        x: 369,
        y: 70 + i * 22,
        width: 8,
        height: 4,
        fill: i < 2 ? "#4ade80" : i < 4 ? "#ffd34d" : "#ff5a5a",
        opacity: 0.7,
      },
      svg,
    );
  const leverG = svgEl("g", { style: "cursor:pointer" }, svg);
  svgEl("rect", { x: 388, y: 76, width: 12, height: 106, rx: 6, fill: "#20284a" }, leverG);
  const handle = svgEl("g", {}, leverG);
  svgEl(
    "rect",
    { x: 378, y: 160, width: 32, height: 22, rx: 6, fill: "#c0392b", stroke: "#6e1a14", "stroke-width": 2 },
    handle,
  );
  svgEl("rect", { x: 382, y: 163, width: 24, height: 5, rx: 2, fill: "rgba(255,255,255,.35)" }, handle);
  const cnt = svgEl(
    "text",
    {
      x: 394,
      y: 216,
      "text-anchor": "middle",
      fill: "#ff7b7b",
      "font-size": 10,
      "font-weight": 800,
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  cnt.textContent = T("YANIK: 4");
  const leverHint = svgEl(
    "text",
    { x: 394, y: 232, "text-anchor": "middle", fill: "#ffd34d", "font-size": 14, opacity: 0 },
    svg,
  );
  leverHint.textContent = "▲";
  const lever = { on: false };
  leverG.addEventListener("pointerdown", () => {
    if (lever.on) return;
    if (left > 0) {
      sfx("error");
      shakeStage();
      cnt.animate([{ opacity: 1 }, { opacity: 0.2 }, { opacity: 1 }], { duration: 300 });
      return;
    }
    lever.on = true;
    handle.animate([{ transform: "translateY(0)" }, { transform: "translateY(-84px)" }], {
      duration: 280,
      fill: "forwards",
      easing: "cubic-bezier(.3,1.6,.6,1)",
    });
    leverHint.getAnimations().forEach((a) => a.cancel());
    leverHint.setAttribute("opacity", 0);
    cnt.textContent = T("GÜÇ VAR");
    cnt.setAttribute("fill", "#4ade80");
    sfx("boom");
    shake = Math.max(shake, 5);
    fuses.forEach((f, k) =>
      rpLater(() => {
        f.led.style.filter = "drop-shadow(0 0 5px #4ade80)";
        f.fil.animate([{ opacity: 0.3 }, { opacity: 1 }], { duration: 200 });
      }, k * 40),
    );
    rpLater(() => rpStageDone(T("Sigortalar değiştirildi")), 600);
  });
}

/* ---------- 3) BASINÇ KALİBRASYONU ---------- */
function rpPressure(area) {
  $("rpIns").innerHTML = T(
    "İbre <b>yeşil bölgedeyken</b> KİLİTLE'ye bas (ya da <b>Space</b>). 3 başarılı kilit gerekli; her kilitte bölge daralır.",
  );
  const svg = rpBase(area);
  const cx = 170,
    cy = 206,
    R = 150;
  svgEl(
    "rect",
    {
      x: 14,
      y: 16,
      width: 312,
      height: 228,
      rx: 12,
      fill: "url(#rpSteel)",
      stroke: "#5b6aa0",
      "stroke-width": 1.2,
    },
    svg,
  );
  screw(svg, 24, 26);
  screw(svg, 316, 26);
  screw(svg, 24, 234);
  screw(svg, 316, 234);
  const lab = svgEl(
    "text",
    {
      x: cx,
      y: 236,
      "text-anchor": "middle",
      fill: "#8d9cc0",
      "font-size": 9,
      "font-weight": 700,
      "letter-spacing": "2",
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  lab.textContent = T("YAKIT HATTI BASINCI · kPa");
  const P = (a) => ({
    x: cx + Math.cos(Math.PI + a * Math.PI) * R * 0.82,
    y: cy + Math.sin(Math.PI + a * Math.PI) * R * 0.82,
  });
  const arc = (a0, a1, r) => {
    const s = { x: cx + Math.cos(Math.PI + a0 * Math.PI) * r, y: cy + Math.sin(Math.PI + a0 * Math.PI) * r },
      e = { x: cx + Math.cos(Math.PI + a1 * Math.PI) * r, y: cy + Math.sin(Math.PI + a1 * Math.PI) * r };
    return `M${s.x} ${s.y} A ${r} ${r} 0 0 1 ${e.x} ${e.y}`;
  };
  svgEl("path", { d: arc(0, 1, R * 0.82), fill: "none", stroke: "#0a1024", "stroke-width": 26 }, svg);
  svgEl("path", { d: arc(0, 0.12, R * 0.82), fill: "none", stroke: "#7a2a2a", "stroke-width": 22 }, svg);
  svgEl("path", { d: arc(0.88, 1, R * 0.82), fill: "none", stroke: "#7a2a2a", "stroke-width": 22 }, svg);
  const zone = svgEl(
    "path",
    {
      fill: "none",
      stroke: "#4ade80",
      "stroke-width": 22,
      style: "filter:drop-shadow(0 0 6px rgba(74,222,128,.7))",
    },
    svg,
  );
  for (let i = 0; i <= 20; i++) {
    const a = i / 20,
      r1 = R * 0.66,
      r2 = R * (i % 5 ? 0.7 : 0.73);
    svgEl(
      "line",
      {
        x1: cx + Math.cos(Math.PI + a * Math.PI) * r1,
        y1: cy + Math.sin(Math.PI + a * Math.PI) * r1,
        x2: cx + Math.cos(Math.PI + a * Math.PI) * r2,
        y2: cy + Math.sin(Math.PI + a * Math.PI) * r2,
        stroke: "#8d9cc0",
        "stroke-width": i % 5 ? 1 : 2,
      },
      svg,
    );
  }
  const needle = svgEl("g", {}, svg);
  svgEl(
    "polygon",
    {
      points: `${cx - 4},${cy} ${cx + 4},${cy} ${cx},${cy - R * 0.78}`,
      fill: "#ff8c42",
      stroke: "#7a3a12",
      "stroke-width": 1,
    },
    needle,
  );
  svgEl("circle", { cx, cy, r: 11, fill: "#2a3354", stroke: "#aab3d6", "stroke-width": 2 }, svg);
  svgEl("circle", { cx, cy, r: 4, fill: "#ff8c42" }, svg);
  const read = svgEl(
    "text",
    {
      x: cx,
      y: cy - 34,
      "text-anchor": "middle",
      fill: "#e8f1ff",
      "font-size": 18,
      "font-weight": 800,
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  // sağ: lambalar + düğme
  svgEl(
    "rect",
    {
      x: 340,
      y: 16,
      width: 106,
      height: 228,
      rx: 12,
      fill: "url(#rpSteel)",
      stroke: "#5b6aa0",
      "stroke-width": 1.2,
    },
    svg,
  );
  const lamps = [0, 1, 2].map((i) =>
    svgEl(
      "circle",
      { cx: 363 + i * 30, cy: 48, r: 9, fill: "#20284a", stroke: "#3a4675", "stroke-width": 2 },
      svg,
    ),
  );
  const tl = svgEl(
    "text",
    {
      x: 393,
      y: 74,
      "text-anchor": "middle",
      fill: "#8d9cc0",
      "font-size": 9,
      "font-weight": 700,
      "letter-spacing": "1.5",
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  tl.textContent = T("KİLİT 0/3");
  const btnG = svgEl("g", { style: "cursor:pointer" }, svg);
  svgEl("circle", { cx: 393, cy: 160, r: 44, fill: "#141b36", stroke: "#3a4675", "stroke-width": 2 }, btnG);
  const btn = svgEl(
    "circle",
    { cx: 393, cy: 156, r: 36, fill: "#e8692a", stroke: "#ffb27a", "stroke-width": 2 },
    btnG,
  );
  svgEl("ellipse", { cx: 385, cy: 142, rx: 16, ry: 7, fill: "rgba(255,255,255,.25)" }, btnG);
  const bt = svgEl(
    "text",
    {
      x: 393,
      y: 161,
      "text-anchor": "middle",
      fill: "#1d0c04",
      "font-size": 13,
      "font-weight": 900,
      "letter-spacing": "1",
    },
    btnG,
  );
  bt.textContent = T("KİLİTLE");
  let hits = 0,
    pos = 0,
    dir = 1,
    speed = 0.55,
    zw = 0.2,
    z0 = 0,
    last = performance.now(),
    cool = 0;
  function newZone() {
    z0 = 0.15 + Math.random() * (0.7 - zw);
    zone.setAttribute("d", arc(z0, z0 + zw, R * 0.82));
  }
  newZone();
  function loop(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    pos += dir * speed * dt;
    if (pos > 1) {
      pos = 1;
      dir = -1;
    }
    if (pos < 0) {
      pos = 0;
      dir = 1;
    }
    const a = -90 + pos * 180;
    needle.setAttribute("transform", `rotate(${a} ${cx} ${cy})`);
    const inZ = pos >= z0 && pos <= z0 + zw;
    read.textContent = String(Math.round(180 + pos * 620)).padStart(3, "0");
    read.setAttribute("fill", inZ ? "#4ade80" : "#e8f1ff");
    rp.raf = requestAnimationFrame(loop);
  }
  rp.raf = requestAnimationFrame(loop);
  function lock() {
    if (rp.busy || performance.now() < cool) return;
    cool = performance.now() + 180;
    btn.animate(
      [{ transform: "translateY(0)" }, { transform: "translateY(4px)" }, { transform: "translateY(0)" }],
      { duration: 140 },
    );
    if (pos >= z0 && pos <= z0 + zw) {
      lamps[hits].setAttribute("fill", "#4ade80");
      lamps[hits].style.filter = "drop-shadow(0 0 6px #4ade80)";
      hits++;
      tl.textContent = T("KİLİT ") + hits + "/3";
      sfx("pickup");
      const pt = P(pos);
      sparkAt(svg, pt.x, pt.y, "#b8ffcf");
      if (hits >= 3) {
        cancelAnimationFrame(rp.raf);
        rpStageDone(T("Basınç kalibre edildi"));
        return;
      }
      zw = Math.max(0.08, zw * 0.7);
      speed *= 1.3;
      newZone();
    } else {
      sfx("error");
      shakeStage();
      if (hits > 0) {
        hits--;
        lamps[hits].setAttribute("fill", "#20284a");
        lamps[hits].style.filter = "";
      }
      tl.textContent = T("KİLİT ") + hits + "/3";
      zone.animate([{ stroke: "#ff5a5a" }, { stroke: "#4ade80" }], { duration: 350 });
    }
  }
  btnG.addEventListener("pointerdown", lock);
  const kh = (e) => {
    if (e.code === "Space" && repairOpen) {
      e.preventDefault();
      lock();
    }
  };
  addEventListener("keydown", kh);
  rp.cleanup.push(() => removeEventListener("keydown", kh));
}

/* ---------- 4) ATEŞLEME DİZİSİ ---------- */
function rpIgnite(area) {
  $("rpIns").innerHTML = T("Ateşleme dizisini <b>izle</b>, sonra düğmelere <b>aynı sırayla</b> bas.");
  const svg = rpBase(area);
  const COLS = ["#ff5a5a", "#ffd34d", "#38bdf8", "#4ade80"],
    DIM = ["#5a2222", "#5a4a14", "#163e5a", "#1a4a2e"],
    FREQ = [330, 440, 554, 660],
    LBL = ["A", "B", "C", "D"];
  svgEl(
    "rect",
    {
      x: 14,
      y: 16,
      width: 236,
      height: 228,
      rx: 12,
      fill: "url(#rpSteel)",
      stroke: "#5b6aa0",
      "stroke-width": 1.2,
    },
    svg,
  );
  screw(svg, 24, 26);
  screw(svg, 240, 26);
  screw(svg, 24, 234);
  screw(svg, 240, 234);
  const pads = [0, 1, 2, 3].map((i) => {
    const x = 36 + (i % 2) * 104,
      y = 36 + Math.floor(i / 2) * 104,
      g = svgEl("g", { style: "cursor:pointer" }, svg);
    svgEl(
      "rect",
      { x, y, width: 92, height: 92, rx: 16, fill: "#0a1024", stroke: "#3a4675", "stroke-width": 2 },
      g,
    );
    const face = svgEl("rect", { x: x + 8, y: y + 8, width: 76, height: 76, rx: 12, fill: DIM[i] }, g);
    svgEl("rect", { x: x + 14, y: y + 12, width: 64, height: 16, rx: 6, fill: "rgba(255,255,255,.08)" }, g);
    const t = svgEl(
      "text",
      {
        x: x + 46,
        y: y + 56,
        "text-anchor": "middle",
        fill: "rgba(255,255,255,.55)",
        "font-size": 22,
        "font-weight": 900,
        "font-family": "ui-monospace,Consolas,monospace",
      },
      g,
    );
    t.textContent = LBL[i];
    g.addEventListener("pointerdown", () => press(i));
    return { g, face };
  });
  // sağ ekran
  svgEl(
    "rect",
    {
      x: 264,
      y: 16,
      width: 182,
      height: 228,
      rx: 12,
      fill: "url(#rpSteel)",
      stroke: "#5b6aa0",
      "stroke-width": 1.2,
    },
    svg,
  );
  svgEl(
    "rect",
    {
      x: 278,
      y: 34,
      width: 154,
      height: 84,
      rx: 8,
      fill: "#0a1024",
      stroke: "#5ad1ff",
      "stroke-opacity": 0.5,
    },
    svg,
  );
  const s1 = svgEl(
    "text",
    {
      x: 355,
      y: 68,
      "text-anchor": "middle",
      fill: "#5ad1ff",
      "font-size": 15,
      "font-weight": 800,
      "letter-spacing": "2",
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  const s2 = svgEl(
    "text",
    {
      x: 355,
      y: 94,
      "text-anchor": "middle",
      fill: "#8d9cc0",
      "font-size": 10,
      "font-family": "ui-monospace,Consolas,monospace",
    },
    svg,
  );
  const L = 5,
    seq = Array.from({ length: L }, () => Math.floor(Math.random() * 4));
  const dots = seq.map((_, k) =>
    svgEl(
      "circle",
      {
        cx: 355 - (L - 1) * 12 + k * 24,
        cy: 146,
        r: 7,
        fill: "#20284a",
        stroke: "#3a4675",
        "stroke-width": 2,
      },
      svg,
    ),
  );
  const rb = svgEl("g", { style: "cursor:pointer" }, svg);
  svgEl("rect", { x: 300, y: 180, width: 110, height: 40, rx: 10, fill: "#20284a", stroke: "#3a4675" }, rb);
  const rt = svgEl(
    "text",
    {
      x: 355,
      y: 205,
      "text-anchor": "middle",
      fill: "#aab3d6",
      "font-size": 11,
      "font-weight": 800,
      "letter-spacing": "1",
    },
    rb,
  );
  rt.textContent = T("↻ TEKRAR İZLE");
  let input = [],
    playing = false;
  function light(i, ms) {
    const f = pads[i].face;
    f.setAttribute("fill", COLS[i]);
    f.style.filter = `drop-shadow(0 0 14px ${COLS[i]})`;
    tone(FREQ[i], (ms / 1000) * 0.9, "triangle", 0.22);
    rpLater(() => {
      f.setAttribute("fill", DIM[i]);
      f.style.filter = "";
    }, ms);
  }
  function setDots(n, col) {
    dots.forEach((d, k) => {
      d.setAttribute("fill", k < n ? col : "#20284a");
    });
  }
  function play() {
    playing = true;
    input = [];
    setDots(0);
    s1.textContent = T("İZLE");
    s1.setAttribute("fill", "#ffd34d");
    s2.textContent = T("Dizi oynatılıyor…");
    seq.forEach((v, k) =>
      rpLater(
        () => {
          light(v, 340);
          setDots(k + 1, "#ffd34d");
        },
        500 + k * 520,
      ),
    );
    rpLater(
      () => {
        playing = false;
        setDots(0);
        s1.textContent = T("SIRA SENDE");
        s1.setAttribute("fill", "#5ad1ff");
        s2.textContent = "0 / " + L;
      },
      500 + L * 520,
    );
  }
  function press(i) {
    if (playing || rp.busy) return;
    light(i, 220);
    input.push(i);
    const k = input.length - 1;
    if (seq[k] !== i) {
      sfx("error");
      shakeStage();
      s1.textContent = T("HATA");
      s1.setAttribute("fill", "#ff5a5a");
      s2.textContent = T("Dizi yeniden oynatılıyor");
      setDots(seq.length, "#ff5a5a");
      playing = true;
      rpLater(play, 900);
      return;
    }
    setDots(input.length, "#4ade80");
    s2.textContent = input.length + " / " + L;
    if (input.length === L) {
      s1.textContent = T("ATEŞLEME");
      s1.setAttribute("fill", "#4ade80");
      s2.textContent = T("İtki çekirdeği aktif");
      pads.forEach((p, j) => rpLater(() => light(j, 300), j * 90));
      rpLater(() => rpStageDone(T("Ateşleme dizisi doğru")), 500);
    }
  }
  rb.addEventListener("pointerdown", () => {
    if (!playing && !rp.busy) play();
  });
  play();
}

/* ---------- İÇ MEKÂN DUMAN SİSTEMİ (arızada) ---------- */
const inSmoke = [],
  inSparks = [];
let smokeLast = 0,
  smokeAcc = 0,
  smokeLevel = 0;
const puffCache = {};
function puff(col) {
  if (puffCache[col]) return puffCache[col];
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d");
  const gr = g.createRadialGradient(32, 32, 1, 32, 32, 32);
  gr.addColorStop(0, col.replace("A", "1"));
  gr.addColorStop(0.5, col.replace("A", ".55"));
  gr.addColorStop(1, col.replace("A", "0"));
  g.fillStyle = gr;
  g.fillRect(0, 0, 64, 64);
  return (puffCache[col] = c);
}
function prewarmSmoke() {
  inSmoke.length = 0;
  smokeLevel = 1;
  smokeLast = 0;
  const D0 = DECKS[0],
    D1 = DECKS[1],
    LX = LADDERS[0].x;
  for (let k = 0; k < 230; k++) {
    const deck = k < 185 ? 0 : 1,
      d = DECKS[deck];
    const col = deck === 0 && k < 45; // motorun üstünde yükselen sütun
    const x = col
      ? 84 + (Math.random() - 0.5) * 30
      : deck === 0
        ? d.xmin - 20 + Math.random() * (d.xmax - d.xmin + 40)
        : LX + Math.random() * 200;
    const y = col ? D0.ceil + 20 + Math.random() * 40 : d.ceil + 10 + Math.random() * (deck === 0 ? 50 : 30);
    inSmoke.push({
      x,
      y,
      vx: (Math.random() - 0.5) * 20,
      vy: col ? -40 : 0,
      r: 16 + Math.random() * 22,
      life: 1 + Math.random() * 4,
      max: 7 + Math.random() * 6,
      dark: Math.random() < 0.55,
      deck,
    });
  }
}
function updateDrawInSmoke(broken, t) {
  const now = performance.now() / 1000;
  const dt = Math.min(0.05, smokeLast ? now - smokeLast : 0);
  smokeLast = now;
  smokeLevel = broken ? Math.min(1, smokeLevel + dt * 0.35) : Math.max(0, smokeLevel - dt * 0.25);
  const D0 = DECKS[0],
    D1 = DECKS[1],
    LX = LADDERS[0].x;
  if (broken) {
    smokeAcc += dt * (34 + smokeLevel * 56);
    while (smokeAcc > 1) {
      smokeAcc--;
      const r = Math.random();
      const src =
        r < 0.6
          ? { x: 94, y: D0.ceil + 52, vx: (Math.random() - 0.2) * 40 }
          : r < 0.9
            ? { x: 40, y: D0.ceil + 42, vx: (Math.random() - 0.5) * 70 }
            : { x: -16, y: D0.ceil + 64, vx: (Math.random() - 0.5) * 30 };
      inSmoke.push({
        x: src.x + (Math.random() - 0.5) * 12,
        y: src.y,
        vx: src.vx,
        vy: -35 - Math.random() * 45,
        r: 9 + Math.random() * 9,
        life: 0,
        max: 7 + Math.random() * 6,
        dark: Math.random() < 0.55,
        deck: 0,
      });
    }
    if (Math.random() < dt * 14) {
      for (let i = 0; i < 6; i++)
        inSparks.push({
          x: 94,
          y: D0.ceil + 54,
          vx: (Math.random() - 0.5) * 160,
          vy: -60 - Math.random() * 90,
          life: 0,
          max: 0.5 + Math.random() * 0.4,
        });
    }
    if (inSmoke.length > 340) inSmoke.splice(0, inSmoke.length - 340);
  }
  // tavan sisi (birikmiş duman bandı)
  if (smokeLevel > 0) {
    for (const [d, amt] of [
      [D0, 1],
      [D1, 0.55],
    ]) {
      const h = 50 + smokeLevel * 58 * amt;
      const g = ctx.createLinearGradient(0, d.ceil, 0, d.ceil + h);
      g.addColorStop(0, "rgba(46,49,62," + 0.9 * smokeLevel * amt + ")");
      g.addColorStop(0.55, "rgba(70,74,90," + 0.45 * smokeLevel * amt + ")");
      g.addColorStop(1, "rgba(70,74,90,0)");
      ctx.fillStyle = g;
      ctx.fillRect(d.xmin - 40, d.ceil, d.xmax - d.xmin + 80, h);
    }
    // kırmızı alarm darbesi
    const al = (Math.sin(t * 5) * 0.5 + 0.5) * 0.12 * smokeLevel;
    ctx.fillStyle = "rgba(255,40,40," + al + ")";
    ctx.fillRect(-240, D0.ceil, 480, D0.floor - D0.ceil);
    ctx.fillStyle = "rgba(255,40,40," + al * 0.6 + ")";
    ctx.fillRect(-240, D1.ceil, 480, D1.floor - D1.ceil);
    for (const [bx, by] of [
      [0, D0.ceil + 4],
      [-60, D1.ceil + 4],
    ]) {
      // dönen alarm lambaları
      ctx.fillStyle = "#3a1414";
      rrp(bx - 7, by, 14, 7, 2);
      ctx.fill();
      ctx.save();
      ctx.translate(bx, by + 8);
      ctx.rotate(t * 4);
      const bg = ctx.createLinearGradient(0, 0, 90, 0);
      bg.addColorStop(0, "rgba(255,60,60," + 0.35 * smokeLevel + ")");
      bg.addColorStop(1, "rgba(255,60,60,0)");
      ctx.fillStyle = bg;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(90, -14);
      ctx.lineTo(90, 14);
      ctx.closePath();
      ctx.fill();
      ctx.rotate(Math.PI);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(90, -14);
      ctx.lineTo(90, 14);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
      ctx.fillStyle = Math.sin(t * 8) > 0 ? "#ff5a5a" : "#a02020";
      ctx.beginPath();
      ctx.arc(bx, by + 8, 4, 0, 7);
      ctx.fill();
    }
  }
  // partiküller: düşük çözünürlüklü ayrı katmana çizilir (yumuşak + hızlı)
  const SD = 3,
    cv = ctx.canvas;
  if (!updateDrawInSmoke.c) updateDrawInSmoke.c = document.createElement("canvas");
  const sc = updateDrawInSmoke.c,
    sw = Math.ceil(cv.width / SD),
    sh = Math.ceil(cv.height / SD);
  if (sc.width !== sw || sc.height !== sh) {
    sc.width = sw;
    sc.height = sh;
  }
  const sx = sc.getContext("2d"),
    m = ctx.getTransform();
  sx.setTransform(1, 0, 0, 1, 0, 0);
  sx.clearRect(0, 0, sw, sh);
  sx.setTransform(m.a / SD, m.b / SD, m.c / SD, m.d / SD, m.e / SD, m.f / SD);
  for (let i = inSmoke.length - 1; i >= 0; i--) {
    const s = inSmoke[i];
    s.life += dt;
    if (s.life > s.max) {
      inSmoke.splice(i, 1);
      continue;
    }
    s.r += dt * Math.max(3, 13 - s.life * 1.2);
    s.vy = Math.max(-60, s.vy - dt * 16);
    s.x += s.vx * dt;
    s.y += s.vy * dt;
    s.vx *= 1 - dt * 0.35;
    const d = DECKS[s.deck];
    if (s.deck === 0 && Math.abs(s.x - LX) < 16 && s.y < D0.ceil + 24) {
      s.deck = 1;
      s.vy = Math.min(s.vy, -40);
    } // merdiven boşluğundan yukarı sızar
    if (s.deck === 1 && s.y > D1.floor - 4) s.x += (LX - s.x) * Math.min(1, dt * 5);
    const ceil = DECKS[s.deck].ceil + 8 + s.r * 0.3;
    if (s.y < ceil) {
      s.y = ceil;
      s.vy = 0;
      const away = s.deck === 0 ? (s.x < 70 ? -1 : 1) : 1;
      s.vx = Math.max(-55, Math.min(55, s.vx + away * 36 * dt));
    }
    if (s.x < d.xmin - 30) {
      s.x = d.xmin - 30;
      s.vx = Math.abs(s.vx) * 0.3;
    }
    if (s.x > d.xmax + 30) {
      s.x = d.xmax + 30;
      s.vx = -Math.abs(s.vx) * 0.3;
    }
    const a = Math.min(1, s.life * 2.5) * (1 - s.life / s.max) * (s.dark ? 0.82 : 0.6);
    sx.globalAlpha = a;
    const img = puff(s.dark ? "rgba(38,40,52,A)" : "rgba(150,156,176,A)");
    const rr = Math.min(s.r, 56);
    sx.drawImage(img, s.x - rr, s.y - rr, rr * 2, rr * 2);
  }
  sx.globalAlpha = 1;
  if (inSmoke.length) {
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(sc, 0, 0, sw * SD, sh * SD);
    ctx.restore();
  }
  for (let i = inSparks.length - 1; i >= 0; i--) {
    const k = inSparks[i];
    k.life += dt;
    if (k.life > k.max) {
      inSparks.splice(i, 1);
      continue;
    }
    k.vy += 260 * dt;
    k.x += k.vx * dt;
    k.y += k.vy * dt;
    if (k.y > D0.floor) {
      k.y = D0.floor;
      k.vy *= -0.35;
      k.vx *= 0.6;
    }
    ctx.strokeStyle =
      "rgba(255," + Math.round(200 + 55 * (1 - k.life / k.max)) + ",140," + (1 - k.life / k.max) + ")";
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(k.x, k.y);
    ctx.lineTo(k.x - k.vx * 0.03, k.y - k.vy * 0.03);
    ctx.stroke();
  }
}

$("rpX").onclick = closeRepair;
/* ============== KUM FIRTINASI — takvimli + gerçekçi ==============
   İlk fırtına 2. gün gelir ve sağlam motoru bozar; sonra her 5 günde bir.
   Gün içinde: 0:10'da uyarı, 0:45'te başlar, ~2 dakika sürer. */
const STORM_START = 90,
  STORM_DUR = 150,
  STORM_WARN = 45; // gün içinde 1:30'da başlar, 2:30 sürer, 45 sn önce uyarı
const stormFx = {
  I: 0,
  k: 0,
  gust: 0,
  gustT: 4,
  gustDur: 0,
  phase: "none",
  u: 0,
  tLeft: 0,
  tTo: 0,
  ang: 0,
  broke: false,
};
function resetStormFx() {
  Object.assign(stormFx, { I: 0, k: 0, gust: 0, gustT: 4, gustDur: 0, phase: "none" });
  windAudio(0, 0);
}
const isStormDay = (d) => d >= 2 && (d - 2) % 5 === 0;
const smooth = (x) => {
  x = Math.max(0, Math.min(1, x));
  return x * x * (3 - 2 * x);
};
function stormInfo() {
  const wt = Math.max(0, Number(game.worldTime) || 0),
    day = Math.floor(wt / DAY_SECONDS) + 1,
    inDay = wt % DAY_SECONDS;
  if (isStormDay(day)) {
    if (inDay < STORM_START && inDay >= STORM_START - STORM_WARN - desFx().stormWarn)
      return { phase: "warn", k: 0, tTo: STORM_START - inDay };
    if (inDay >= STORM_START && inDay < STORM_START + STORM_DUR) {
      const u = inDay - STORM_START;
      return {
        phase: "active",
        u,
        k: Math.min(smooth(u / 20), smooth((STORM_DUR - u) / 24)),
        tLeft: STORM_START + STORM_DUR - inDay,
      };
    }
  }
  return { phase: "none", k: 0 };
}
/* bir sonraki fırtınaya kalan oyun saniyesi */
function nextStormIn() {
  const wt = Math.max(0, Number(game.worldTime) || 0),
    day = Math.floor(wt / DAY_SECONDS) + 1,
    inDay = wt % DAY_SECONDS;
  for (let d = day; d < day + 12; d++) {
    if (!isStormDay(d)) continue;
    const start = (d - 1) * DAY_SECONDS + STORM_START;
    if (start + STORM_DUR > wt) return Math.max(0, start - wt);
  }
  return Infinity;
}
function updateStorm(simDt, dt) {
  if (!game || scene === "earth") {
    stormFx.I = Math.max(0, stormFx.I - dt);
    stormFx.phase = "none";
    windAudio(0, 0);
    showStormBanner(null);
    return;
  }
  const S = stormInfo();
  stormFx.phase = S.phase;
  stormFx.k = S.k;
  stormFx.tLeft = S.tLeft || 0;
  stormFx.tTo = S.tTo || 0;
  stormFx.u = S.u || 0;
  // esinti (gust): fırtına zirvedeyken ani rüzgâr darbeleri
  stormFx.gustT -= dt;
  if (S.phase === "active" && S.k > 0.55 && stormFx.gustT <= 0) {
    stormFx.gustDur = 1.1 + Math.random() * 0.9;
    stormFx.gustT = 4 + Math.random() * 6;
    if (!insideRocket) shake = Math.max(shake, 4 + S.k * 4);
  }
  stormFx.gustDur = Math.max(0, stormFx.gustDur - dt);
  const gTarget = stormFx.gustDur > 0 ? Math.sin(Math.min(1, stormFx.gustDur / 1.6) * Math.PI) : 0;
  stormFx.gust += (gTarget - stormFx.gust) * Math.min(1, dt * 6);
  const t = performance.now() / 1000;
  const target =
    S.k * (0.82 + 0.12 * Math.sin(t * 0.9) + 0.06 * Math.sin(t * 2.7)) + stormFx.gust * 0.3 * S.k;
  stormFx.I += (Math.min(1.15, target) - stormFx.I) * Math.min(1, dt * 2.2);
  if (stormFx.I < 0.002) stormFx.I = 0;
  stormFx.ang = 0.18 * Math.sin(t * 0.13) + 0.06 * Math.sin(t * 0.7);
  // ilk fırtına: zirvede roketi vurur
  if (S.phase === "active" && S.u > 30 && game.repair.state === "ok") {
    const dn = gameDayNumber();
    if (!game.stormBroke) stormBreakRocket();
    else if (game.stormRoll !== dn) {
      game.stormRoll = dn;
      const A = rkArmor(),
        ch = A ? ARMOR[A - 1].chance : BASE_STORM_BREAK;
      if (Math.random() < ch) stormBreakRocket();
      else if (A > 0) toast(T("🛡️ Fırtına kalkanı roketi korudu — motor sağlam"));
    }
  }
  if (insideRocket && stormFx.I > 0.05)
    shake = Math.max(shake, (stormFx.I * 1.6 + stormFx.gust * 3) * (1 - rkArmor() * 0.22)); // gövde sarsılır
  windAudio(
    (insideRocket ? stormFx.I * 0.35 : stormFx.I) * ((settings.amb == null ? 80 : settings.amb) / 80),
    stormFx.gust,
  );
  showStormBanner(S);
}
function stormBreakRocket() {
  storyTrigger("engine");
  game.stormBroke = true;
  game.repair = { state: "broken", end: 0, stage: 0 };
  {
    const C = commState();
    if (C.trk.st) C.trk.st.broke = true;
    C.flags.brokeAt = game.worldTime;
    commsObs("engine_fail", {});
  }
  shake = Math.max(shake, 22);
  flash = Math.max(flash, 0.35);
  sfx("boom");
  setTimeout(() => sfx("boom"), 260);
  if (!insideRocket) {
    burst(ROCKET.x + 14, ROCKET.y - 16, 46, "#ffb347", { sp: 280, life: 0.9, size: 6 });
    burst(ROCKET.x + 10, ROCKET.y - 30, 30, "#9aa0b4", { sp: 120, life: 1.4, size: 9, up: 90 });
  }
  toast(T("💥 Şiddetli bir esinti roketi savurdu — motordan duman yükseliyor!"));
}
/* rüzgâr sesi: döngüsel gürültü → bant geçiren filtre */
const WA = { src: null, f: null, g: null };
function windAudio(level, gust) {
  if (!AU.ac || !AU.ready) return;
  try {
    if (!WA.src) {
      const ac = AU.ac,
        len = ac.sampleRate * 2,
        buf = ac.createBuffer(1, len, ac.sampleRate),
        d = buf.getChannelData(0);
      let last = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        last = (last + 0.02 * w) / 1.02;
        d[i] = last * 3.2 + w * 0.08;
      }
      WA.src = ac.createBufferSource();
      WA.src.buffer = buf;
      WA.src.loop = true;
      WA.f = ac.createBiquadFilter();
      WA.f.type = "bandpass";
      WA.f.Q.value = 0.8;
      WA.f.frequency.value = 400;
      WA.g = ac.createGain();
      WA.g.gain.value = 0;
      WA.src.connect(WA.f);
      WA.f.connect(WA.g);
      WA.g.connect(AU.sfxG);
      WA.src.start();
    }
    const now = AU.ac.currentTime;
    WA.g.gain.setTargetAtTime(Math.min(0.9, level * 0.55 + gust * 0.25), now, 0.25);
    WA.f.frequency.setTargetAtTime(260 + level * 420 + gust * 520, now, 0.3);
  } catch (e) {}
}

/* --- toz bulutu dokusu (döşenebilir fbm gürültü) --- */
let dustTex = null;
function buildDustTex() {
  const N = 256,
    c = document.createElement("canvas");
  c.width = c.height = N;
  const g = c.getContext("2d"),
    img = g.createImageData(N, N);
  const H1 = (x, y) => {
    const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
    return n - Math.floor(n);
  };
  const vn = (x, y, p) => {
    const xi = Math.floor(x),
      yi = Math.floor(y),
      u = x - xi,
      v = y - yi,
      s = (a) => a * a * (3 - 2 * a),
      m = (a) => ((a % p) + p) % p;
    const a = H1(m(xi), m(yi)),
      b = H1(m(xi + 1), m(yi)),
      cc = H1(m(xi), m(yi + 1)),
      d = H1(m(xi + 1), m(yi + 1)),
      su = s(u),
      sv = s(v);
    return (a + (b - a) * su) * (1 - sv) + (cc + (d - cc) * su) * sv;
  };
  for (let y = 0; y < N; y++)
    for (let x = 0; x < N; x++) {
      let sum = 0,
        amp = 0.55,
        f = 4;
      for (let o = 0; o < 5; o++) {
        sum += amp * vn((x / N) * f, (y / N) * f, f);
        amp *= 0.5;
        f *= 2;
      }
      const a = Math.max(0, Math.min(1, (sum - 0.36) * 2.1)),
        i = (y * N + x) * 4;
      img.data[i] = 200 + sum * 40;
      img.data[i + 1] = 120 + sum * 40;
      img.data[i + 2] = 64 + sum * 30;
      img.data[i + 3] = a * 255;
    }
  g.putImageData(img, 0, 0);
  dustTex = { c, pat: null };
}
function drawSandstorm() {
  const I = Math.min(1.1, stormFx.I);
  if (I <= 0.003) return;
  if (!dustTex) buildDustTex();
  const t = performance.now() / 1000,
    z = (CFG.zoom * Math.min(W, H)) / 700,
    a = stormFx.ang,
    ca = Math.cos(a),
    sa = Math.sin(a);
  ctx.save();
  // 1) güneş kararır + turuncu pus
  ctx.fillStyle = "rgba(22,9,4," + (0.28 * I).toFixed(3) + ")";
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = "rgba(176,96,48," + (0.3 * I).toFixed(3) + ")";
  ctx.fillRect(0, 0, W, H);
  // 2) parallax toz bulutları (kamera + rüzgârla akar)
  if (!dustTex.pat) dustTex.pat = ctx.createPattern(dustTex.c, "repeat");
  const layers = [
    [3.6, 0.55, 0.55],
    [2.4, 1.0, 0.48],
    [1.5, 1.7, 0.36],
  ];
  for (const [sc, spd, al] of layers) {
    const tile = 256 * sc,
      ox = -(t * spd * 230 * (0.6 + I * 0.6)) - p.x * z * spd * 0.7,
      oy = Math.sin(t * 0.4 * spd) * 30 * sc - p.y * z * spd * 0.7 + ox * sa * 0.6;
    const m = new DOMMatrix()
      .translateSelf((((ox % tile) + tile) % tile) - tile, (((oy % tile) + tile) % tile) - tile)
      .scaleSelf(sc, sc);
    dustTex.pat.setTransform(m);
    ctx.globalAlpha = Math.min(1, al * I * (1 + stormFx.gust * 0.5));
    ctx.fillStyle = dustTex.pat;
    ctx.fillRect(0, 0, W, H);
  }
  ctx.globalAlpha = 1;
  // 3) kum taneleri: rüzgâr yönünde hızlı ince çizgiler
  const n = Math.round(260 * Math.min(1, I));
  ctx.lineCap = "round";
  for (let pass = 0; pass < 2; pass++) {
    ctx.strokeStyle = pass
      ? "rgba(255,226,186," + (0.55 * I).toFixed(3) + ")"
      : "rgba(214,150,96," + (0.5 * I).toFixed(3) + ")";
    ctx.lineWidth = pass ? 1.1 : 1.8;
    ctx.beginPath();
    for (let i = pass; i < n; i += 2) {
      const sp = 900 + (i % 7) * 180 + stormFx.gust * 900,
        L = 18 + (i % 5) * 12 + I * 26;
      const x = ((i * 173.3 + t * sp) % (W + 300)) - 150,
        y0 = ((i * 97.7) % (H + 60)) - 30;
      const y = y0 + Math.sin(t * 3 + i) * 10 + x * sa * 0.3;
      ctx.moveTo(x, y);
      ctx.lineTo(x - L * ca, y - L * sa);
    }
    ctx.stroke();
  }
  // 4) iri kum zerreleri
  ctx.fillStyle = "rgba(255,214,170," + (0.5 * I).toFixed(3) + ")";
  for (let i = 0; i < Math.round(90 * Math.min(1, I)); i++) {
    const x = ((i * 131.7 + t * (1300 + (i % 5) * 220)) % (W + 60)) - 30,
      y = ((i * 71.3 + Math.sin(t * 5 + i) * 26) % (H + 30)) - 15;
    ctx.fillRect(x, y, 1.5 + (i % 3) * 0.8, 1.5 + (i % 3) * 0.8);
  }
  // 5) esinti dalgası: ekranı süpüren yoğun toz perdesi
  if (stormFx.gust > 0.05) {
    const gx = W * (1.4 - ((t * 0.55) % 1) * 1.8),
      gw = W * 0.7;
    const gg = ctx.createLinearGradient(gx - gw, 0, gx + gw, 0);
    gg.addColorStop(0, "rgba(190,110,60,0)");
    gg.addColorStop(0.5, "rgba(205,128,70," + (0.45 * stormFx.gust * I).toFixed(3) + ")");
    gg.addColorStop(1, "rgba(190,110,60,0)");
    ctx.fillStyle = gg;
    ctx.fillRect(0, 0, W, H);
  }
  // 6) görüş mesafesi: oyuncu çevresi hariç her yer tozla kaplanır
  const r0 = Math.min(W, H) * (0.42 - 0.28 * Math.min(1, I)),
    r1 = Math.max(W, H) * (0.95 - 0.4 * Math.min(1, I));
  const vg = ctx.createRadialGradient(W / 2, H / 2, r0, W / 2, H / 2, r1);
  vg.addColorStop(0, "rgba(150,80,40,0)");
  vg.addColorStop(0.55, "rgba(150,80,40," + (0.55 * I).toFixed(3) + ")");
  vg.addColorStop(1, "rgba(120,62,30," + (0.92 * Math.min(1, I)).toFixed(3) + ")");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}
/* zemin seviyesinde savrulan kum şeritleri (dünya uzayında) */
function drawGroundDrift() {
  const I = Math.min(1, stormFx.I);
  if (I <= 0.02) return;
  const t = performance.now() / 1000;
  ctx.save();
  ctx.lineCap = "round";
  for (let i = 0; i < 46; i++) {
    const span = 1600,
      ox = ((i * 211 + t * (260 + (i % 4) * 60)) % span) - span / 2,
      y = p.y + ((i * 137) % 1200) - 600 + Math.sin(t * 0.8 + i) * 14;
    const x = p.x + ox,
      L = 60 + (i % 5) * 30;
    ctx.strokeStyle = "rgba(240,190,140," + (0.22 * I).toFixed(3) + ")";
    ctx.lineWidth = 3 + (i % 3);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.bezierCurveTo(x - L * 0.33, y - 6, x - L * 0.66, y + 6, x - L, y + Math.sin(i) * 4);
    ctx.stroke();
  }
  ctx.restore();
}

/* ============== UYARI KARTLARI (fırtına + radyasyon) ============== */
const AL_ICONS = {
  storm:
    '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#2a0e04" stroke-width="2.3" stroke-linecap="round"><path d="M3 8h10.5a3 3 0 1 0-3-3"/><path d="M3 12.5h15.5a3 3 0 1 1-3 3"/><path d="M3 17h7a2.4 2.4 0 1 1-2.4 2.4"/></svg>',
  rad: '<svg class="spin" viewBox="0 0 24 24" width="26" height="26"><path fill="#1a0b00" d="M12 12 7.5 4.2A9 9 0 0 1 16.5 4.2ZM12 12 21 12A9 9 0 0 1 16.5 19.8ZM12 12 7.5 19.8A9 9 0 0 1 3 12Z"/><circle cx="12" cy="12" r="3.4" fill="#facc15"/><circle cx="12" cy="12" r="2" fill="#1a0b00"/></svg>',
  safe: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#04210f" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4.5 6v5.5c0 4.6 3.2 8 7.5 9.5 4.3-1.5 7.5-4.9 7.5-9.5V6Z"/><path d="m8.6 12.2 2.4 2.4 4.5-4.6"/></svg>',
};
const mmss = (s) => {
  s = Math.max(0, Math.ceil(s));
  return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
};
function setAlert(id, cls, icon, title, sub, bar, time) {
  const el = $(id);
  if (!cls) {
    if (!el.classList.contains("hidden")) el.classList.add("hidden");
    el._k = "";
    return;
  }
  const key = cls + "|" + icon;
  if (el._k !== key) {
    el._k = key;
    el.className = "alert " + cls;
    el.innerHTML = `<div class="al-ic">${AL_ICONS[icon]}</div><div class="al-tx"><b></b><span></span><div class="al-bar"><i></i></div></div><div class="al-time"></div>`;
  }
  el.querySelector("b").textContent = title;
  el.querySelector("span").textContent = sub;
  el.querySelector(".al-bar i").style.width = Math.max(0, Math.min(100, bar * 100)) + "%";
  el.querySelector(".al-time").textContent = time;
}
function showStormBanner(S) {
  if (!S || S.phase === "none" || mode !== "play") {
    setAlert("stormBanner");
    return;
  }
  if (S.phase === "warn") {
    setAlert(
      "stormBanner",
      "storm warn",
      "storm",
      T("Kum fırtınası yaklaşıyor"),
      insideRocket ? T("Roketin içindesin — güvendesin") : T("Rüzgâr hızlanıyor · görüş azalacak"),
      1 - S.tTo / STORM_WARN,
      mmss(S.tTo),
    );
    return;
  }
  const kmh = Math.round(40 + stormFx.I * 95 + stormFx.gust * 30);
  if (insideRocket)
    setAlert(
      "stormBanner",
      "storm safe",
      "safe",
      T("Roket içi güvenli"),
      T("Dışarıda kum fırtınası · rüzgâr ") + kmh + " km/s",
      S.tLeft / STORM_DUR,
      mmss(S.tLeft),
    );
  else
    setAlert(
      "stormBanner",
      "storm",
      "storm",
      T("Kum fırtınası"),
      T("Rüzgâr ") + kmh + T(" km/s · görüş çok düşük"),
      S.tLeft / STORM_DUR,
      mmss(S.tLeft),
    );
}

/* ============== EŞYA ÇİZİMLERİ — tek kaynak: canvas ==============
   drawItemArt(c,key,size,o) 48×48'lik birim kutuya çizer (0,0 merkez).
   Aynı çizim envanter ikonu (dataURL), kapsül ekranı, el ve yerde kullanılır. */
function drawItemArt(c, key, size, o) {
  o = o || {};
  c.save();
  c.scale(size / 48, size / 48);
  c.lineJoin = "round";
  c.lineCap = "round";
  switch (key) {
    case "pick": {
      drawPickArt(c);
      break;
    }
    case "water": {
      // plastik su şişesi
      const fill = o.fill == null ? 1 : Math.max(0, Math.min(1, o.fill)),
        tilt = o.tilt || 0;
      const body = () => {
        c.beginPath();
        c.moveTo(-5, -14);
        c.lineTo(5, -14);
        c.lineTo(5, -11);
        c.bezierCurveTo(5, -8.5, 9.5, -8, 9.5, -3);
        c.lineTo(9.5, 16);
        c.quadraticCurveTo(9.5, 21, 4.5, 21);
        c.lineTo(-4.5, 21);
        c.quadraticCurveTo(-9.5, 21, -9.5, 16);
        c.lineTo(-9.5, -3);
        c.bezierCurveTo(-9.5, -8, -5, -8.5, -5, -11);
        c.closePath();
      };
      c.fillStyle = "rgba(0,0,0,.18)";
      c.beginPath();
      c.ellipse(1, 21.5, 10, 2.4, 0, 0, 7);
      c.fill();
      c.save();
      body();
      c.clip();
      c.fillStyle = "rgba(210,236,255,.22)";
      c.fillRect(-12, -16, 24, 40);
      if (fill > 0) {
        const lvl = 21 - 27 * fill;
        c.save();
        c.translate(0, lvl);
        c.rotate(-tilt);
        const wg = c.createLinearGradient(0, 0, 0, 30);
        wg.addColorStop(0, "#7fd8ff");
        wg.addColorStop(1, "#1773c4");
        c.fillStyle = wg;
        c.fillRect(-30, 0, 60, 60);
        c.fillStyle = "rgba(255,255,255,.55)";
        c.fillRect(-30, -0.6, 60, 1.6);
        c.restore();
        if (o.bubbles) {
          const t = performance.now() / 1000;
          c.fillStyle = "rgba(255,255,255,.75)";
          for (let i = 0; i < 5; i++) {
            const ph = (t * 1.6 + i * 0.21) % 1;
            c.beginPath();
            c.arc(-4 + i * 2, 19 - ph * (21 - lvl + 2), 0.9 + (i % 2) * 0.5, 0, 7);
            c.fill();
          }
        }
      }
      c.restore();
      body();
      c.strokeStyle = "rgba(150,200,236,.95)";
      c.lineWidth = 1.3;
      c.stroke();
      c.strokeStyle = "rgba(150,200,236,.55)";
      c.lineWidth = 1;
      for (const y of [-1, 14]) {
        c.beginPath();
        c.moveTo(-9.5, y);
        c.quadraticCurveTo(0, y + 1.6, 9.5, y);
        c.stroke();
      }
      c.fillStyle = "#f4f8ff";
      c.fillRect(-9.5, 3, 19, 8);
      c.fillStyle = "#1f6fd1";
      c.fillRect(-9.5, 3, 19, 1.6);
      c.fillRect(-9.5, 9.4, 19, 1.6);
      c.fillStyle = "#1f8fe0";
      c.beginPath();
      c.moveTo(0, 4.6);
      c.quadraticCurveTo(2.6, 7.4, 1.9, 8.4);
      c.arc(0, 8, 1.95, 0, Math.PI);
      c.quadraticCurveTo(-2.6, 7.4, 0, 4.6);
      c.fill();
      c.fillStyle = "rgba(255,255,255,.7)";
      c.fillRect(-7.5, -4, 1.8, 22);
      const cg = c.createLinearGradient(-6, 0, 6, 0);
      cg.addColorStop(0, "#1a5fb8");
      cg.addColorStop(0.5, "#3d8cf0");
      cg.addColorStop(1, "#164f9c");
      c.fillStyle = cg;
      rrc(c, -6, -21, 12, 7, 1.6);
      c.fill();
      c.strokeStyle = "rgba(0,0,0,.25)";
      c.lineWidth = 0.8;
      for (let x = -4; x <= 4; x += 2) {
        c.beginPath();
        c.moveTo(x, -20.4);
        c.lineTo(x, -14.6);
        c.stroke();
      }
      c.fillStyle = "#0e3f80";
      c.fillRect(-5.5, -14.5, 11, 1.3);
      break;
    }
    case "potato": {
      // yumrulu patates (ısırık izleriyle)
      const bites = o.bites || 0,
        B = [
          [11, -5, 6.5],
          [13.5, 3, 6],
          [6, -11, 5.6],
        ];
      c.fillStyle = "rgba(0,0,0,.2)";
      c.beginPath();
      c.ellipse(1, 13, 15, 3.4, 0, 0, 7);
      c.fill();
      c.save();
      if (bites > 0) {
        c.beginPath();
        c.rect(-30, -30, 60, 60);
        for (let i = 0; i < bites; i++) {
          const b = B[i];
          c.moveTo(b[0] + b[2], b[1]);
          c.arc(b[0], b[1], b[2], 0, 7, true);
        }
        c.clip("evenodd");
      }
      const pg = c.createRadialGradient(-5, -6, 2, 0, 0, 18);
      pg.addColorStop(0, "#ecc488");
      pg.addColorStop(0.6, "#c48a4a");
      pg.addColorStop(1, "#8a5a2a");
      c.fillStyle = pg;
      c.beginPath();
      c.moveTo(-15, -1);
      c.bezierCurveTo(-16, -9, -8, -13, -1, -12);
      c.bezierCurveTo(6, -14, 15, -10, 15, -2);
      c.bezierCurveTo(16, 6, 10, 12, 1, 11.5);
      c.bezierCurveTo(-7, 12.5, -14, 8, -15, -1);
      c.closePath();
      c.fill();
      c.strokeStyle = "#6e4520";
      c.lineWidth = 1.2;
      c.stroke();
      c.fillStyle = "rgba(110,70,32,.75)";
      for (const [x, y, r] of [
        [-8, -4, 1.3],
        [-2, 4, 1.1],
        [6, -6, 1.2],
        [8, 5, 1],
        [-10, 4, 0.9],
        [1, -8, 0.9],
      ]) {
        c.beginPath();
        c.ellipse(x, y, r * 1.4, r, 0.4, 0, 7);
        c.fill();
      }
      c.fillStyle = "rgba(255,236,200,.45)";
      c.beginPath();
      c.ellipse(-6, -7, 5, 2.2, -0.4, 0, 7);
      c.fill();
      c.fillStyle = "rgba(90,55,25,.35)";
      for (let i = 0; i < 14; i++) {
        c.fillRect(-12 + ((i * 7.3) % 24), -8 + ((i * 5.1) % 16), 0.9, 0.9);
      }
      c.restore();
      for (let i = 0; i < bites; i++) {
        const b = B[i];
        c.strokeStyle = "#f6e6b2";
        c.lineWidth = 2.2;
        c.beginPath();
        c.arc(b[0], b[1], b[2] + 0.6, Math.PI * 0.55, Math.PI * 1.45);
        c.stroke();
      }
      break;
    }
    case "rotten": {
      // çürük patates: kararmış, buruşmuş, küf lekeli
      const t = performance.now() / 1000;
      c.fillStyle = "rgba(0,0,0,.22)";
      c.beginPath();
      c.ellipse(1, 13, 14, 3, 0, 0, 7);
      c.fill();
      const pg = c.createRadialGradient(-4, -5, 2, 0, 0, 18);
      pg.addColorStop(0, "#8a7350");
      pg.addColorStop(0.55, "#5c4630");
      pg.addColorStop(1, "#2e2216");
      c.fillStyle = pg;
      c.beginPath();
      c.moveTo(-14, 0);
      c.bezierCurveTo(-15, -8, -8, -11, -2, -10);
      c.bezierCurveTo(4, -13, 13, -9, 14, -2);
      c.bezierCurveTo(15, 5, 9, 11, 1, 10.5);
      c.bezierCurveTo(-6, 11.5, -13, 7, -14, 0);
      c.closePath();
      c.fill();
      c.strokeStyle = "#1f160c";
      c.lineWidth = 1.2;
      c.stroke();
      c.strokeStyle = "rgba(20,12,6,.6)";
      c.lineWidth = 0.9;
      c.beginPath();
      c.moveTo(-9, -3);
      c.quadraticCurveTo(-4, -1, -6, 4);
      c.moveTo(3, -7);
      c.quadraticCurveTo(7, -3, 5, 2);
      c.stroke();
      c.fillStyle = "#1a120a";
      for (const [x, y, r] of [
        [-6, -4, 3.4],
        [5, 3, 4],
        [8, -5, 2.4],
        [-3, 5, 2],
      ]) {
        c.beginPath();
        c.ellipse(x, y, r, r * 0.75, 0.3, 0, 7);
        c.fill();
      }
      c.fillStyle = "#9fb86a";
      for (const [x, y, r] of [
        [-7, -5, 1.3],
        [6, 2, 1.6],
        [4, 4, 1],
        [-2, 6, 1],
        [9, -5, 0.9],
      ]) {
        c.beginPath();
        c.arc(x, y, r, 0, 7);
        c.fill();
      }
      c.fillStyle = "#d8e6b8";
      for (const [x, y] of [
        [6.4, 1.6],
        [-7.3, -5.3],
      ]) {
        c.beginPath();
        c.arc(x, y, 0.6, 0, 7);
        c.fill();
      }
      if (o.sparkle !== false) {
        c.strokeStyle = "rgba(170,190,110,.55)";
        c.lineWidth = 1.2;
        for (let i = 0; i < 3; i++) {
          const ph = (t * 0.6 + i / 3) % 1,
            x = -6 + i * 6;
          c.globalAlpha = 1 - ph;
          c.beginPath();
          c.moveTo(x, -12 - ph * 10);
          c.quadraticCurveTo(x + 3, -15 - ph * 10, x, -18 - ph * 10);
          c.stroke();
        }
        c.globalAlpha = 1;
      }
      break;
    }
    case "radmeter": {
      // DZ-7: grafit gövde, turuncu tampon, yuvarlak renkli ekran, üstte sensör çubuğu
      const t = performance.now() / 1000,
        act = !!o.active;
      c.fillStyle = "rgba(0,0,0,.22)";
      c.beginPath();
      c.ellipse(0, 19, 14, 3, 0, 0, 7);
      c.fill();
      c.strokeStyle = "#9aa5c0";
      c.lineWidth = 2;
      c.beginPath();
      c.moveTo(-6, -15);
      c.lineTo(-9, -24);
      c.stroke(); // sensör çubuğu
      c.fillStyle = "#2a303f";
      c.beginPath();
      c.ellipse(-9.5, -25.5, 4.2, 2.4, -0.3, 0, 7);
      c.fill();
      c.fillStyle = act ? "#7fe7ff" : "#3fb3c9";
      c.beginPath();
      c.ellipse(-9.5, -25.8, 2.6, 1.3, -0.3, 0, 7);
      c.fill();
      c.fillStyle = "#ff8c42";
      rrc(c, -13, -17, 26, 35, 7);
      c.fill(); // turuncu tampon
      const bg = c.createLinearGradient(-11, -15, 11, 16);
      bg.addColorStop(0, "#3a4256");
      bg.addColorStop(1, "#161a24");
      c.fillStyle = bg;
      rrc(c, -11, -15, 22, 31, 5.5);
      c.fill();
      c.fillStyle = "#0a1020";
      c.beginPath();
      c.arc(0, -4, 8, 0, 7);
      c.fill(); // yuvarlak ekran
      const u = act ? 0.5 + 0.5 * Math.sin(t * 3) : 0.35,
        col = u < 0.33 ? "#4ade80" : u < 0.66 ? "#fbbf24" : "#ff5d5d";
      c.strokeStyle = "rgba(255,255,255,.12)";
      c.lineWidth = 2.2;
      c.beginPath();
      c.arc(0, -4, 5.6, Math.PI * 0.75, Math.PI * 2.25);
      c.stroke();
      c.strokeStyle = col;
      c.beginPath();
      c.arc(0, -4, 5.6, Math.PI * 0.75, Math.PI * 0.75 + Math.PI * 1.5 * Math.max(0.08, u));
      c.stroke();
      c.fillStyle = col;
      c.fillRect(-2.2, -4.8, 4.4, 1.8);
      c.fillStyle = "#ff8c42";
      for (const bx of [-5, 0, 5]) {
        c.beginPath();
        c.arc(bx, 9, 1.7, 0, 7);
        c.fill();
      } // tuşlar
      c.fillStyle = "#9aa5c0";
      for (let k = 0; k < 3; k++) c.fillRect(-6 + k * 4, 13, 2.4, 1.2); // hoparlör ızgarası
      c.fillStyle = act && Math.sin(t * 22) > 0.4 ? "#ff5d5d" : "#5a2020";
      c.beginPath();
      c.arc(8, -12.5, 1.3, 0, 7);
      c.fill();
      c.fillStyle = "rgba(255,255,255,.18)";
      c.beginPath();
      c.ellipse(-3, -8, 3.5, 1.6, -0.6, 0, 7);
      c.fill();
      break;
    }
    case "seed": {
      // tohum paketi
      c.fillStyle = "rgba(0,0,0,.2)";
      c.beginPath();
      c.ellipse(1, 21, 12, 2.6, 0, 0, 7);
      c.fill();
      const pg = c.createLinearGradient(-11, 0, 11, 0);
      pg.addColorStop(0, "#efe2c4");
      pg.addColorStop(1, "#d8c69c");
      c.fillStyle = pg;
      c.beginPath();
      c.moveTo(-11, -14);
      for (let i = 0; i <= 11; i++) c.lineTo(-11 + i * 2, -14 - (i % 2 ? 2 : 0));
      c.lineTo(11, 19);
      c.quadraticCurveTo(11, 21, 9, 21);
      c.lineTo(-9, 21);
      c.quadraticCurveTo(-11, 21, -11, 19);
      c.closePath();
      c.fill();
      c.strokeStyle = "#9c8758";
      c.lineWidth = 1;
      c.stroke();
      c.fillStyle = "#3f8f4f";
      rrc(c, -9, -9, 18, 17, 2);
      c.fill();
      const sg = c.createLinearGradient(0, -9, 0, 8);
      sg.addColorStop(0, "#bfe8ff");
      sg.addColorStop(1, "#e8d4a8");
      c.fillStyle = sg;
      rrc(c, -8, -8, 16, 15, 1.6);
      c.fill();
      c.fillStyle = "#7a4f2a";
      c.fillRect(-8, 3, 16, 4);
      c.strokeStyle = "#2f7d4f";
      c.lineWidth = 1.4;
      c.beginPath();
      c.moveTo(0, 3);
      c.quadraticCurveTo(1, -1, 0, -4);
      c.stroke();
      c.fillStyle = "#3fa866";
      for (const [x, y, r] of [
        [-3.4, -2, -0.6],
        [3.4, -3, 0.6],
        [-1.5, -5.6, -0.3],
        [2, -6.4, 0.4],
      ]) {
        c.beginPath();
        c.ellipse(x, y, 2.8, 1.5, r, 0, 7);
        c.fill();
      }
      c.fillStyle = "#e2a85e";
      c.beginPath();
      c.ellipse(-3, 4.6, 2.2, 1.4, 0, 0, 7);
      c.fill();
      c.beginPath();
      c.ellipse(3, 5, 2, 1.3, 0, 0, 7);
      c.fill();
      c.fillStyle = "#2f5d3a";
      c.fillRect(-9, 10, 18, 4);
      c.fillStyle = "#fff";
      c.fillRect(-6.5, 11.3, 8, 1.2);
      c.fillRect(3, 11.3, 3, 1.2);
      c.fillStyle = "#8a6a3c";
      for (const [x, y] of [
        [-6, 17],
        [-2, 18],
        [2.5, 16.8],
        [6, 18],
      ]) {
        c.beginPath();
        c.ellipse(x, y, 1.2, 0.8, 0.5, 0, 7);
        c.fill();
      }
      break;
    }
    case "medkit": {
      // ilk yardım çantası
      c.fillStyle = "rgba(0,0,0,.22)";
      c.beginPath();
      c.ellipse(0, 17, 17, 3, 0, 0, 7);
      c.fill();
      c.strokeStyle = "#8a93ad";
      c.lineWidth = 2.6;
      c.beginPath();
      c.moveTo(-6, -10);
      c.lineTo(-6, -14);
      c.quadraticCurveTo(-6, -16, -4, -16);
      c.lineTo(4, -16);
      c.quadraticCurveTo(6, -16, 6, -14);
      c.lineTo(6, -10);
      c.stroke();
      const bg = c.createLinearGradient(0, -10, 0, 16);
      bg.addColorStop(0, "#ffffff");
      bg.addColorStop(1, "#cfd6e6");
      c.fillStyle = bg;
      rrc(c, -16, -10, 32, 26, 4);
      c.fill();
      c.strokeStyle = "#8a93ad";
      c.lineWidth = 1.2;
      c.stroke();
      c.fillStyle = "#e2e7f2";
      c.fillRect(-16, -2, 32, 1.6);
      c.fillStyle = "#ef4444";
      rrc(c, -3.5, -7, 7, 18, 1);
      c.fill();
      rrc(c, -9, -1.5, 18, 7, 1);
      c.fill();
      c.fillStyle = "rgba(255,255,255,.35)";
      c.fillRect(-3.5, -7, 7, 2);
      c.fillStyle = "#8a93ad";
      c.fillRect(-14, -3, 3, 4);
      c.fillRect(11, -3, 3, 4);
      c.fillStyle = "rgba(255,255,255,.7)";
      c.fillRect(-14, -8, 6, 1.6);
      break;
    }
    case "kit": {
      // çapa ikonu
      c.fillStyle = "rgba(0,0,0,.22)";
      c.beginPath();
      c.ellipse(0, 19, 16, 3, 0, 0, 7);
      c.fill();
      c.save();
      c.rotate(0.62);
      const wg = c.createLinearGradient(-2.6, 0, 2.6, 0);
      wg.addColorStop(0, "#8a5a2b");
      wg.addColorStop(0.5, "#d39a58");
      wg.addColorStop(1, "#6e4320");
      c.fillStyle = wg;
      rrc(c, -2.6, -20, 5.2, 40, 2.4);
      c.fill();
      c.strokeStyle = "#5a3416";
      c.lineWidth = 1;
      c.stroke();
      c.fillStyle = "#2a2f3f";
      rrc(c, -3.2, 10, 6.4, 10, 2);
      c.fill();
      c.fillStyle = "#7a8299";
      rrc(c, -4, -23, 8, 6, 1.6);
      c.fill();
      const sg = c.createLinearGradient(2, -26, 20, -6);
      sg.addColorStop(0, "#f1f4fa");
      sg.addColorStop(0.45, "#a7b0c8");
      sg.addColorStop(1, "#5c6684");
      c.fillStyle = sg;
      c.beginPath();
      c.moveTo(3, -23);
      c.quadraticCurveTo(11, -25, 14, -20);
      c.lineTo(21, -19);
      c.lineTo(23, -3);
      c.quadraticCurveTo(15, -1, 10, -3);
      c.lineTo(11, -18);
      c.quadraticCurveTo(8, -20, 3, -19);
      c.closePath();
      c.fill();
      c.strokeStyle = "#3f475f";
      c.lineWidth = 1.2;
      c.stroke();
      c.strokeStyle = "rgba(255,255,255,.8)";
      c.lineWidth = 1.2;
      c.beginPath();
      c.moveTo(11, -3.4);
      c.quadraticCurveTo(16, -2, 22.4, -3.6);
      c.stroke();
      c.restore();
      break;
    }
    case "stone": {
      // metal numune: kaya içinde parlak damar
      c.fillStyle = "rgba(0,0,0,.25)";
      c.beginPath();
      c.ellipse(1, 14, 16, 3.4, 0, 0, 7);
      c.fill();
      const rg = c.createLinearGradient(-14, -12, 14, 14);
      rg.addColorStop(0, "#7a5a4e");
      rg.addColorStop(1, "#3b2a25");
      c.fillStyle = rg;
      c.beginPath();
      c.moveTo(-15, 4);
      c.lineTo(-11, -8);
      c.lineTo(-2, -13);
      c.lineTo(9, -10);
      c.lineTo(15, -1);
      c.lineTo(12, 10);
      c.lineTo(-1, 14);
      c.lineTo(-12, 11);
      c.closePath();
      c.fill();
      c.strokeStyle = "#2a1c18";
      c.lineWidth = 1.1;
      c.stroke();
      const mg = c.createLinearGradient(-8, -9, 9, 8);
      mg.addColorStop(0, "#ffffff");
      mg.addColorStop(0.4, "#c9d2e0");
      mg.addColorStop(1, "#7f8aa3");
      c.fillStyle = mg;
      c.beginPath();
      c.moveTo(-6, -7);
      c.lineTo(3, -10);
      c.lineTo(9, -3);
      c.lineTo(6, 6);
      c.lineTo(-3, 7);
      c.lineTo(-8, 1);
      c.closePath();
      c.fill();
      c.strokeStyle = "rgba(60,70,90,.7)";
      c.lineWidth = 0.8;
      c.beginPath();
      c.moveTo(3, -10);
      c.lineTo(1, -1);
      c.lineTo(9, -3);
      c.moveTo(1, -1);
      c.lineTo(-3, 7);
      c.moveTo(1, -1);
      c.lineTo(-8, 1);
      c.stroke();
      c.fillStyle = "rgba(255,255,255,.85)";
      c.beginPath();
      c.moveTo(-5, -6);
      c.lineTo(2, -8.6);
      c.lineTo(0, -3);
      c.closePath();
      c.fill();
      c.fillStyle = "#d7deee";
      c.fillRect(9, 4, 2, 2);
      c.fillRect(-11, 3, 1.6, 1.6);
      if (o.sparkle !== false) {
        const t = performance.now() / 1000,
          a = 0.5 + 0.5 * Math.sin(t * 4 + (o.ph || 0));
        c.globalAlpha = a;
        c.strokeStyle = "#fff";
        c.lineWidth = 1.2;
        c.beginPath();
        c.moveTo(-1, -12);
        c.lineTo(-1, -6);
        c.moveTo(-4, -9);
        c.lineTo(2, -9);
        c.stroke();
        c.globalAlpha = 1;
      }
      break;
    }
    case "star": {
      // yıldız kırıntısı: kehribar kristal kümesi
      const t = performance.now() / 1000;
      const gl = c.createRadialGradient(0, 0, 2, 0, 0, 22);
      gl.addColorStop(0, "rgba(255,214,100,.55)");
      gl.addColorStop(1, "rgba(255,180,60,0)");
      c.fillStyle = gl;
      c.beginPath();
      c.arc(0, 0, 22, 0, 7);
      c.fill();
      c.fillStyle = "rgba(0,0,0,.2)";
      c.beginPath();
      c.ellipse(1, 15, 12, 2.6, 0, 0, 7);
      c.fill();
      const cry = (x, y, w, h, r) => {
        c.save();
        c.translate(x, y);
        c.rotate(r);
        const g = c.createLinearGradient(-w, 0, w, 0);
        g.addColorStop(0, "#fff4c2");
        g.addColorStop(0.5, "#ffc83d");
        g.addColorStop(1, "#d9831a");
        c.fillStyle = g;
        c.beginPath();
        c.moveTo(0, -h);
        c.lineTo(w, -h * 0.55);
        c.lineTo(w, h * 0.2);
        c.lineTo(0, h * 0.45);
        c.lineTo(-w, h * 0.2);
        c.lineTo(-w, -h * 0.55);
        c.closePath();
        c.fill();
        c.strokeStyle = "#a85d0c";
        c.lineWidth = 0.8;
        c.stroke();
        c.fillStyle = "rgba(255,255,255,.6)";
        c.beginPath();
        c.moveTo(0, -h);
        c.lineTo(-w, -h * 0.55);
        c.lineTo(0, -h * 0.2);
        c.closePath();
        c.fill();
        c.restore();
      };
      cry(-7, 6, 4, 10, -0.45);
      cry(7, 7, 3.6, 9, 0.5);
      cry(0, 4, 5.5, 16, 0);
      c.globalAlpha = 0.6 + 0.4 * Math.sin(t * 5);
      c.fillStyle = "#fff";
      c.beginPath();
      c.arc(-1, -8, 1.6, 0, 7);
      c.fill();
      c.globalAlpha = 1;
      break;
    }
    case "book": {
      // deri kaplı saha rehberi
      c.fillStyle = "rgba(0,0,0,.25)";
      c.beginPath();
      c.ellipse(1, 20, 17, 3, 0, 0, 7);
      c.fill();
      c.fillStyle = "#efe3c6";
      rrc(c, -13, -17, 29, 35, 2);
      c.fill(); // sayfalar
      c.strokeStyle = "#c9b48a";
      c.lineWidth = 0.7;
      for (let y = -14; y < 16; y += 2.4) {
        c.beginPath();
        c.moveTo(13.5, y);
        c.lineTo(15.6, y);
        c.stroke();
      }
      const bg = c.createLinearGradient(-16, 0, 14, 0);
      bg.addColorStop(0, "#4a220f");
      bg.addColorStop(0.25, "#7a3a1a");
      bg.addColorStop(1, "#5a2a12");
      c.fillStyle = bg;
      rrc(c, -16, -19, 29, 37, 3);
      c.fill();
      c.strokeStyle = "#2a1206";
      c.lineWidth = 1.2;
      c.stroke();
      c.fillStyle = "#3a1a0a";
      c.fillRect(-16, -19, 5, 37); // sırt
      c.strokeStyle = "rgba(255,210,150,.35)";
      c.setLineDash([2, 2]);
      c.lineWidth = 0.8;
      rrc(c, -9, -16, 19, 31, 2);
      c.stroke();
      c.setLineDash([]);
      c.strokeStyle = "#ffcf6b";
      c.lineWidth = 1.4;
      c.beginPath();
      c.arc(1, -3, 6.5, 0, 7);
      c.stroke(); // amblem
      c.fillStyle = "#ffcf6b";
      c.beginPath();
      c.moveTo(1, -8);
      c.lineTo(3, -1);
      c.lineTo(1, 0);
      c.lineTo(-1, -1);
      c.closePath();
      c.fill();
      c.fillRect(-5, 7, 12, 1.6);
      c.fillRect(-3, 10.5, 8, 1.2);
      c.fillStyle = "#d43d2d";
      c.beginPath();
      c.moveTo(8, 17);
      c.lineTo(8, 24);
      c.lineTo(10, 22);
      c.lineTo(12, 24);
      c.lineTo(12, 17);
      c.closePath();
      c.fill(); // ayraç
      break;
    }
    case "tuber": {
      // tohumluk patates: gözlerinden filiz sürmüş yumru
      drawItemArt(c, "potato", 48, {});
      const sprout = (x, y, a, l) => {
        c.save();
        c.translate(x, y);
        c.rotate(a);
        c.strokeStyle = "#3f7d2a";
        c.lineWidth = 2.2;
        c.beginPath();
        c.moveTo(0, 0);
        c.quadraticCurveTo(2, -l * 0.5, 0, -l);
        c.stroke();
        c.fillStyle = "#7bd34a";
        c.beginPath();
        c.ellipse(3.2, -l + 1, 3.6, 1.8, -0.5, 0, 7);
        c.fill();
        c.beginPath();
        c.ellipse(-3, -l + 2.4, 3, 1.5, 0.6, 0, 7);
        c.fill();
        c.fillStyle = "#d9f7b0";
        c.beginPath();
        c.arc(0, 0, 1.6, 0, 7);
        c.fill();
        c.restore();
      };
      sprout(-6, -10, -0.35, 11);
      sprout(5, -11, 0.3, 13);
      sprout(12, -3, 1.1, 8);
      break;
    }
    case "ceramic": {
      // seramik kalkan kubbesi
      c.fillStyle = "rgba(0,0,0,.2)";
      c.beginPath();
      c.ellipse(0, 17, 21, 4, 0, 0, 7);
      c.fill();
      const dg = c.createLinearGradient(-18, -14, 18, 16);
      dg.addColorStop(0, "#fffaf0");
      dg.addColorStop(0.55, "#e6dccb");
      dg.addColorStop(1, "#a99d88");
      c.fillStyle = dg;
      c.beginPath();
      c.moveTo(-19, 14);
      c.bezierCurveTo(-19, -16, 19, -16, 19, 14);
      c.closePath();
      c.fill();
      c.strokeStyle = "#6f6553";
      c.lineWidth = 1.4;
      c.stroke();
      c.strokeStyle = "rgba(111,101,83,.55)";
      c.lineWidth = 1;
      for (const yy of [-2, 6]) {
        c.beginPath();
        c.moveTo(-17.6, yy + (yy < 0 ? 2 : 0));
        c.quadraticCurveTo(0, yy - 3, 17.6, yy + (yy < 0 ? 2 : 0));
        c.stroke();
      }
      for (const xx of [-9, 0, 9]) {
        c.beginPath();
        c.moveTo(xx, 14);
        c.quadraticCurveTo(xx * 0.75, -1, xx * 0.4, -8.5);
        c.stroke();
      }
      c.fillStyle = "#7b8ba8";
      rrc(c, -21, 12, 42, 5, 2.2);
      c.fill();
      c.strokeStyle = "#3e4860";
      c.lineWidth = 1;
      c.stroke();
      c.fillStyle = "#4ade80";
      c.beginPath();
      c.arc(0, 14.5, 1.4, 0, 7);
      c.fill();
      c.strokeStyle = "rgba(255,255,255,.8)";
      c.lineWidth = 1.6;
      c.beginPath();
      c.moveTo(-12, -1);
      c.quadraticCurveTo(-9, -8, -2, -10.5);
      c.stroke();
      break;
    }
    case "o2": {
      // oksijen tüpü ikonu
      const g = c.createLinearGradient(-8, 0, 8, 0);
      g.addColorStop(0, "#9fe6ff");
      g.addColorStop(0.5, "#e8fbff");
      g.addColorStop(1, "#3aa5d8");
      c.fillStyle = g;
      rrc(c, -8, -12, 16, 30, 7);
      c.fill();
      c.strokeStyle = "#1d6f9c";
      c.lineWidth = 1.2;
      c.stroke();
      c.fillStyle = "#5b6178";
      c.fillRect(-3, -18, 6, 6);
      c.fillStyle = "#2a3354";
      c.fillRect(-6, -19, 12, 2.4);
      c.fillStyle = "#1d6f9c";
      c.font = "900 9px 'Segoe UI',sans-serif";
      c.textAlign = "center";
      c.fillText("O₂", 0, 6);
      break;
    }
  }
  c.restore();
}
function rrc(c, x, y, w, h, r) {
  c.beginPath();
  if (c.roundRect) c.roundRect(x, y, w, h, r);
  else c.rect(x, y, w, h);
}
const _iconCache = {};
function itemIconURL(key) {
  if (_iconCache[key]) return _iconCache[key];
  const cv = document.createElement("canvas");
  cv.width = cv.height = 192;
  const c = cv.getContext("2d");
  c.translate(96, 96);
  // zemin gölgesi: nesne masada duruyormuş gibi
  const sh = c.createRadialGradient(0, 70, 2, 0, 70, 62);
  sh.addColorStop(0, "rgba(0,0,0,.45)");
  sh.addColorStop(1, "rgba(0,0,0,0)");
  c.fillStyle = sh;
  c.save();
  c.scale(1, 0.28);
  c.beginPath();
  c.arc(0, 250, 62, 0, 7);
  c.fill();
  c.restore();
  drawItemArt(c, key, 160, { sparkle: false });
  // hacim: sol üstten ışık, sağ alttan gölge (yalnızca nesnenin üstüne)
  c.globalCompositeOperation = "source-atop";
  const lg = c.createLinearGradient(-70, -80, 70, 80);
  lg.addColorStop(0, "rgba(255,255,255,.22)");
  lg.addColorStop(0.45, "rgba(255,255,255,0)");
  lg.addColorStop(0.7, "rgba(0,0,0,0)");
  lg.addColorStop(1, "rgba(0,0,0,.28)");
  c.fillStyle = lg;
  c.fillRect(-96, -96, 192, 192);
  c.globalCompositeOperation = "source-over";
  return (_iconCache[key] = cv.toDataURL());
}
const ITEM_NAMES = {
  pick: T("Jeolog kazması"),
  rotten: T("Çürük patates"),
  radmeter: T("DZ-7 radyasyon ölçer"),
  water: T("Su şişesi"),
  potato: T("Patates"),
  seed: T("Patates tohumu"),
  medkit: T("Medikit"),
  kit: T("Çapa"),
  stone: T("Metal numune"),
  star: T("Yıldız kristali"),
  ceramic: T("Seramik kalkan"),
  tuber: T("Tohumluk patates"),
};

/* --- eylem animasyonları: içme / yeme / medikit --- */
function startAct(kind, dur) {
  p.action = kind;
  p.actionT = dur;
  p.actionDur = dur;
  if (kind === "drink") {
    // yudum sesleri
    [380, 820, 1240].forEach((ms) =>
      setTimeout(() => {
        tone(210, 0.09, "sine", 0.2, 120);
        tone(150, 0.07, "sine", 0.12, 90, 0.05);
      }, ms),
    );
  } else if (kind === "eat") {
    // ısırık + çiğneme
    [420, 900, 1380].forEach((ms) =>
      setTimeout(() => {
        noiseBurst(0.07, 0.16, 1800);
        tone(240, 0.06, "square", 0.08, 180, 0.02);
      }, ms),
    );
  }
}
/* el: tutulan eşyayı çiz; içerken şişe vizöre eğilir ve boşalır, yerken ısırık alınır */
function drawHeldArt(key, acting, prog) {
  const t = performance.now() / 1000;
  const hold = Math.max(0, Math.min(1, (prog - 0.2) / 0.65));
  if (key === "pickaxe") {
    ctx.save();
    ctx.scale(0.55, 0.55);
    drawHoe(0, 10, 0.4);
    ctx.restore();
    return;
  }
  const k = key === "pickaxe" ? "kit" : key;
  if (acting && p.action === "drink" && k === "water") {
    const tilt =
      -1.25 * Math.min(1, prog / 0.25) * (prog > 0.85 ? (1 - prog) / 0.15 : 1) +
      Math.sin(t * 9) * 0.04 * hold;
    ctx.save();
    ctx.rotate(tilt);
    drawItemArt(ctx, "water", 28, { fill: 1 - hold * 0.95, tilt, bubbles: hold > 0 && hold < 1 });
    ctx.restore();
    return;
  }
  if (acting && p.action === "eat" && k === "potato") {
    const bites = Math.min(3, Math.floor(hold * 3.4));
    ctx.save();
    ctx.rotate(-0.35 * Math.min(1, prog / 0.2));
    drawItemArt(ctx, "potato", 24, { bites });
    ctx.restore();
    // kırıntılar
    if (hold > 0 && hold < 1) {
      ctx.fillStyle = "#e8c88a";
      for (let i = 0; i < 5; i++) {
        const ph = (t * 1.8 + i * 0.2) % 1;
        ctx.fillRect(-4 + i * 2.2 + ph * 3, 4 + ph * 22, 1.6, 1.6);
      }
    }
    return;
  }
  drawItemArt(ctx, k, k === "kit" ? 22 : k === "radmeter" ? 24 : 21, { active: k === "radmeter" && !!radM });
}

/* ============== OKSİJEN ==============
   Dışarıda giysi oksijeni azalır; roket içinde azalmaz ama yalnızca
   makine dairesindeki O₂ tüpünden doldurulur. Tüp jeneratörle yavaşça dolar. */
const O2 = { drain: 100 / 220, runMul: 1.35, tankMax: 400, tankRegen: 1.2, fillRate: 42, hpDrain: 5 }; // tüp jeneratörü en kötü koşulda bile tüketimi karşılar → O₂ görev boyunca yeter
function o2Max() {
  return (game && game.design && game.design.fx && game.design.fx.tankMax) || O2.tankMax;
}
let o2Fill = null;
function updateO2(simDt, dt, running) {
  if (game.o2 == null) game.o2 = 100;
  if (game.o2Tank == null) game.o2Tank = o2Max();
  if (!insideRocket && scene !== "earth") {
    const prev = game.o2;
    game.o2 = Math.max(
      0,
      game.o2 -
        O2.drain *
          suitSt().o2 *
          dif().o2 *
          (running ? O2.runMul : 1) *
          (1 + stormFx.I * 0.25 * suitSt().storm) *
          simDt,
    );
    if (prev > 30 && game.o2 <= 30) {
      sfx("warn");
      toast(T("🫁 Oksijen %30 — rokete dönüp tüpten doldur"));
    }
    if (prev > 10 && game.o2 <= 10) {
      sfx("warn");
      toast(T("⚠️ Oksijen kritik! Hemen rokete dön"));
    }
    if (game.o2 <= 0) {
      game.hp = Math.max(0, game.hp - O2.hpDrain * simDt);
    }
  }
  if (scene === "earth") game.o2 = Math.min(100, game.o2 + 20 * simDt);
  if (o2Fill) {
    o2Fill.t += dt;
    const amt = Math.min(O2.fillRate * dt, 100 - game.o2, game.o2Tank);
    game.o2 += amt;
    game.o2Tank -= amt;
    if (Math.random() < dt * 10 && o2Fill.t > 0.3) o2Fill.puffs++;
    if (
      game.o2 >= 99.9 ||
      game.o2Tank <= 0 ||
      !insideRocket ||
      ip.deck !== 0 ||
      (nearStation() || {}).key !== "o2"
    )
      stopO2Fill(game.o2 >= 99.9);
  } else {
    const fx = desFx();
    game.o2Tank = Math.min(
      o2Max(),
      game.o2Tank +
        O2.tankRegen *
          fx.regen *
          (fx.solar && stormFx.phase === "active" ? Math.max(0.6, fx.stormRegen) : 1) *
          simDt,
    );
  }
  hissAudio(o2Fill ? 0.5 : 0);
}
function startO2Fill() {
  if (game.o2 >= 99.5) {
    sfx("full");
    toast(T("🫁 Giysi oksijeni zaten dolu"));
    return;
  }
  if (game.o2Tank < 2) {
    sfx("error");
    toast(T("O₂ tüpü boş — jeneratör dolduruyor, biraz bekle"));
    return;
  }
  o2Fill = { t: 0, from: game.o2, puffs: 0 };
  p.dir = 1;
  ip.dir = 1;
  ip.x = 18; // sırt çantası tüplere dönük
  sfx("click");
  tone(900, 0.12, "sine", 0.12, 500);
}
function stopO2Fill(full) {
  if (!o2Fill) return;
  o2Fill = null;
  hissAudio(0);
  if (full) {
    sfx("heal");
    toast(T("🫁 Oksijen dolu · tüp %") + Math.round((game.o2Tank / o2Max()) * 100));
  } else if (game.o2Tank <= 0) {
    sfx("error");
    toast(T("O₂ tüpü boşaldı — jeneratör dolduruyor"));
  }
}
/* tıslama sesi */
const HS = { src: null, g: null };
function hissAudio(level) {
  if (!AU.ac || !AU.ready) return;
  try {
    if (!HS.src) {
      const ac = AU.ac,
        len = ac.sampleRate,
        buf = ac.createBuffer(1, len, ac.sampleRate),
        d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      HS.src = ac.createBufferSource();
      HS.src.buffer = buf;
      HS.src.loop = true;
      const f = ac.createBiquadFilter();
      f.type = "highpass";
      f.frequency.value = 2600;
      HS.g = ac.createGain();
      HS.g.gain.value = 0;
      HS.src.connect(f);
      f.connect(HS.g);
      HS.g.connect(AU.sfxG);
      HS.src.start();
    }
    HS.g.gain.setTargetAtTime(level * 0.22, AU.ac.currentTime, 0.08);
  } catch (e) {}
}
/* roket içi: O₂ tüpleri + dolum efekti */
function drawO2Tanks(F, C, t) {
  const lvl = Math.max(0, Math.min(1, game.o2Tank / o2Max()));
  for (const [tx, lab] of [
    [-36, "A"],
    [4, "B"],
  ]) {
    const tg = ctx.createLinearGradient(tx - 18, 0, tx + 18, 0);
    tg.addColorStop(0, "#7a9cc0");
    tg.addColorStop(0.4, "#eef7ff");
    tg.addColorStop(1, "#4a6a90");
    ctx.fillStyle = tg;
    rrp(tx - 18, C + 56, 36, F - C - 62, 13);
    ctx.fill();
    ctx.strokeStyle = "#20243a";
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.fillStyle = "#1d6f9c";
    ctx.fillRect(tx - 18, C + 72, 36, 6);
    ctx.fillRect(tx - 18, F - 28, 36, 4);
    ctx.fillStyle = "#fff";
    ctx.font = "900 9px 'Segoe UI',sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("O₂", tx, C + 77.5);
    const gx = tx - 6,
      gy = C + 84,
      gh = F - C - 118;
    ctx.fillStyle = "#0a1024";
    rrp(gx, gy, 12, gh, 3);
    ctx.fill();
    const lg = ctx.createLinearGradient(0, gy + gh - gh * lvl, 0, gy + gh);
    lg.addColorStop(0, "#bff3ff");
    lg.addColorStop(1, "#2aa0d8");
    ctx.fillStyle = lg;
    if (lvl > 0.01) {
      rrp(gx + 1, gy + gh - gh * lvl + 1, 10, Math.max(0, gh * lvl - 2), 2);
      ctx.fill();
    }
    for (let i = 0; i < 3; i++) {
      const bph = (t * 0.6 + i * 0.33 + (lab === "A" ? 0.2 : 0)) % 1;
      if (bph < lvl) {
        ctx.fillStyle = "rgba(255,255,255,.6)";
        ctx.beginPath();
        ctx.arc(gx + 4 + i * 2.5, gy + gh - bph * gh, 1.2, 0, 7);
        ctx.fill();
      }
    }
    ctx.strokeStyle = "#5ad1ff";
    ctx.lineWidth = 1;
    rrp(gx, gy, 12, gh, 3);
    ctx.stroke();
  }
  // ortak manifold + vana
  ctx.fillStyle = "#5b6178";
  rrp(-40, C + 46, 48, 8, 3);
  ctx.fill();
  ctx.strokeStyle = "#20243a";
  ctx.lineWidth = 1;
  ctx.stroke();
  const vx = -16,
    vy = C + 44;
  ctx.save();
  ctx.translate(vx, vy);
  ctx.rotate(o2Fill ? t * 8 : 0);
  ctx.strokeStyle = "#ef4444";
  ctx.lineWidth = 2.4;
  ctx.beginPath();
  ctx.arc(0, 0, 6, 0, 7);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-6, 0);
  ctx.lineTo(6, 0);
  ctx.moveTo(0, -6);
  ctx.lineTo(0, 6);
  ctx.stroke();
  ctx.restore();
  // durum ekranı
  ctx.fillStyle = "#0a1024";
  rrp(-34, F - 22, 36, 13, 2);
  ctx.fill();
  ctx.strokeStyle = "#5ad1ff";
  ctx.lineWidth = 0.8;
  ctx.stroke();
  ctx.fillStyle = lvl < 0.15 ? "#ff7b7b" : "#7fe0ff";
  ctx.font = "700 7px monospace";
  ctx.textAlign = "center";
  ctx.fillText("O₂ " + Math.round(lvl * 100) + "%", -16, F - 13);
  ctx.fillStyle = "#d9dcea";
  ctx.font = "700 7px monospace";
  ctx.fillText(T("OKSİJEN"), -16, C + 40 - 6);
}
function drawO2FillFx(F, C, t, px, py) {
  if (!o2Fill) return;
  const vx = -16,
    vy = C + 44,
    bx = px - 21 * ip.dir,
    by = py + 2;
  // hortum (sarkık bezier) + akış ışıkları
  const c1x = vx,
    c1y = vy + 70,
    c2x = bx - 30 * ip.dir,
    c2y = by + 40;
  const bez = (u) => {
    const a = 1 - u;
    return {
      x: a * a * a * vx + 3 * a * a * u * c1x + 3 * a * u * u * c2x + u * u * u * bx,
      y: a * a * a * vy + 3 * a * a * u * c1y + 3 * a * u * u * c2y + u * u * u * by,
    };
  };
  const k = Math.min(1, o2Fill.t / 0.35); // hortum takılma animasyonu
  ctx.lineCap = "round";
  const path = () => {
    ctx.beginPath();
    ctx.moveTo(vx, vy);
    for (let i = 1; i <= 24; i++) {
      const q = bez((i / 24) * k);
      ctx.lineTo(q.x, q.y);
    }
  };
  ctx.strokeStyle = "#1b2140";
  ctx.lineWidth = 6;
  path();
  ctx.stroke();
  ctx.strokeStyle = "#3a7fb0";
  ctx.lineWidth = 4;
  path();
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,.35)";
  ctx.lineWidth = 1.2;
  path();
  ctx.stroke();
  if (k >= 1) {
    for (let i = 0; i < 7; i++) {
      const u = (t * 1.4 + i / 7) % 1,
        q = bez(u);
      const g = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, 5);
      g.addColorStop(0, "rgba(200,250,255,.95)");
      g.addColorStop(1, "rgba(90,209,255,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(q.x, q.y, 5, 0, 7);
      ctx.fill();
    }
    // bağlantı uçları
    ctx.fillStyle = "#c9d2e0";
    ctx.beginPath();
    ctx.arc(bx, by, 3, 0, 7);
    ctx.fill();
    // soğuk gaz buharı
    for (let i = 0; i < 10; i++) {
      const ph = (t * 1.1 + i * 0.1) % 1,
        src = i % 2 ? { x: vx, y: vy } : { x: bx, y: by };
      ctx.fillStyle = "rgba(225,245,255," + 0.38 * (1 - ph) + ")";
      ctx.beginPath();
      ctx.arc(src.x + Math.sin(i * 2.1 + t) * 6 * ph + ((i % 3) - 1) * 4, src.y - ph * 26, 3 + ph * 9, 0, 7);
      ctx.fill();
    }
    // giysi parıltısı
    const pul = 0.5 + 0.5 * Math.sin(t * 6);
    const ag = ctx.createRadialGradient(px, py - 10, 8, px, py - 10, 62);
    ag.addColorStop(0, "rgba(120,230,255," + (0.18 + 0.1 * pul) + ")");
    ag.addColorStop(1, "rgba(90,209,255,0)");
    ctx.fillStyle = ag;
    ctx.beginPath();
    ctx.arc(px, py - 10, 62, 0, 7);
    ctx.fill();
    for (let i = 0; i < 8; i++) {
      const a = t * 2 + i * 0.785,
        r = 30 + 8 * Math.sin(t * 3 + i);
      ctx.fillStyle = "rgba(190,245,255," + (0.5 + 0.4 * Math.sin(t * 5 + i)) + ")";
      ctx.fillRect(px + Math.cos(a) * r, py - 10 + Math.sin(a) * r * 0.9, 2, 2);
    }
  }
  // baş üstünde dolum halkası
  const hx = px,
    hy = py - 96,
    v = game.o2 / 100;
  ctx.fillStyle = "rgba(10,16,36,.85)";
  ctx.beginPath();
  ctx.arc(hx, hy, 15, 0, 7);
  ctx.fill();
  ctx.strokeStyle = "rgba(90,209,255,.25)";
  ctx.lineWidth = 3.5;
  ctx.beginPath();
  ctx.arc(hx, hy, 12, 0, 7);
  ctx.stroke();
  ctx.strokeStyle = "#7fe0ff";
  ctx.shadowColor = "#5ad1ff";
  ctx.shadowBlur = 8;
  ctx.beginPath();
  ctx.arc(hx, hy, 12, -Math.PI / 2, -Math.PI / 2 + v * Math.PI * 2);
  ctx.stroke();
  ctx.shadowBlur = 0;
  ctx.fillStyle = "#e8fbff";
  ctx.font = "800 7.5px ui-monospace,monospace";
  ctx.textAlign = "center";
  ctx.fillText(Math.round(game.o2) + "%", hx, hy + 2.5);
}

/* ============== KAPSÜLLER (Kit + Yemek) ==============
   Açılabilir basınçlı saklama bölmeleri: kapak açılır, içerik ve adetler görünür. */
const CAPSULES = {
  kit: {
    title: T("Alet Sandığı"),
    ic: "kit",
    sub: "Makine dairesi · saha aletleri ve tohum",
    items: [
      ["kit", T("Toprağı kazar ve parsel açar"), 1],
      ["pick", T("Yalnızca bilinmeyen (?) taşları kırar"), 1],
      ["radmeter", T("Toprağın radyasyonunu ölçer · ekimden önce kullan"), 1],
      ["seed", T("Dışarıdaki parsele ekilir"), 12],
      ["ceramic", T("Parsele kurulur · Q ile açılıp kapanır · kapalıyken radyasyondan korur"), 6],
    ],
  },
  med: {
    title: T("Revir"),
    ic: "medkit",
    sub: T("Yaşam güvertesi · tıbbi dolap ve sedye"),
    items: [["medkit", T("Canı +") + 40 + T(" yeniler · yanında taşıyıp G ile kullan"), 8]],
  },
  kitchen: {
    title: T("Mutfak"),
    ic: "water",
    sub: T("Yaşam güvertesi · dolaplar, su sebili ve buzdolabı"),
    items: [
      ["water", T("Şişe su · su sebilinden geri dönüştürülür"), 12],
      ["potato", T("Haşlanmış patates · açlığı giderir"), 16],
    ],
  },
  food: {
    title: T("Yemek Kapsülü"),
    ic: "potato",
    sub: T("Yaşam güvertesi · soğuk saklama + su geri dönüştürücü"),
    items: [
      ["water", T("Susuzluğu giderir · geri dönüştürülür"), 12],
      ["potato", T("Açlığı giderir · tarladan yetişir"), 16],
    ],
  },
};
let capOpen = null;
const capAnim = { kit: 0, food: 0 };
function capCount(key) {
  if (key === "kit") return game.kitCarried ? 0 : 1;
  if (key === "radmeter") return game.inventory.radmeter > 0 ? 0 : 1;
  if (key === "pick") return (game.inventory.pick || 0) > 0 ? 0 : 1;
  return game.stock[key] || 0;
}
function bagCount(key) {
  if (key === "kit") return game.kitCarried ? 1 : 0;
  return game.inventory[key] || 0;
}
function openCapsule(kind) {
  capOpen = kind;
  sfx("click");
  noiseBurst(0.45, 0.14, 3200);
  tone(140, 0.3, "sine", 0.12, 90);
  $("capScreen").classList.remove("hidden");
  renderCapsule(true);
}
function closeCapsule() {
  capOpen = null;
  $("capScreen").classList.add("hidden");
  focusGame();
}
function renderCapsule(first) {
  const C = CAPSULES[capOpen];
  if (!C) return;
  $("capTitle").textContent = C.title;
  $("capSub").textContent = C.sub;
  $("capPutTo").textContent = capOpen === "kit" ? T("sandığa") : T("kapsüle");
  $("capIc").innerHTML = '<img src="' + itemIconURL(C.ic) + '" alt="">';
  const items = C.items;
  let tot = 0,
    cap = 0;
  items.forEach(([k, , m]) => {
    tot += capCount(k);
    cap += m;
  });
  $("capChip").textContent = tot + " / " + cap;
  const g = $("capGrid");
  g.innerHTML = "";
  items.forEach(([k, desc, max], i) => {
    const n = capCount(k),
      b = bagCount(k);
    const el = document.createElement("div");
    el.className = "cap-cell" + (n <= 0 ? " empty" : "") + (first ? " pop" : "");
    el.style.animationDelay = i * 70 + "ms";
    el.innerHTML = Tf(
      `<div class="cap-art"><img src="{0}" alt=""><span class="cap-n">×{1}</span></div>
      <div class="cap-nm">{2}</div><div class="cap-ds">{3}</div>
      <div class="cap-bar"><i style="width:{4}%"></i></div>
      <div class="cap-meta"><span>{5} {6}/{7}</span><span>ÇANTA {8}</span></div>`,
      [
        itemIconURL(k),
        n,
        ITEM_NAMES[k],
        desc,
        Math.min(100, (n / max) * 100),
        capOpen === "kit" ? T("SANDIK") : T("KAPSÜL"),
        n,
        max,
        b,
      ],
    );
    const act = document.createElement("div");
    act.className = "cap-act";
    const take = document.createElement("button");
    take.className = "cbtn pri";
    take.textContent = T("Al");
    take.disabled = n <= 0;
    take.onclick = () => {
      if (capCount(k) <= 0) return;
      if (k === "kit") {
        game.kitCarried = true;
        bumpQuest("kit");
      } else if (k === "radmeter") {
        game.inventory.radmeter = 1;
      } else if (k === "pick") {
        game.inventory.pick = 1;
      } else {
        game.stock[k]--;
        game.inventory[k] = (game.inventory[k] || 0) + 1;
      }
      sfx("pickup");
      updateInv();
      renderCapsule();
    };
    const put = document.createElement("button");
    put.className = "cbtn";
    put.textContent = T("Koy");
    put.disabled = b <= 0 || n >= max;
    put.onclick = () => {
      if (bagCount(k) <= 0 || capCount(k) >= max) return;
      if (k === "kit") game.kitCarried = false;
      else if (k === "radmeter") game.inventory.radmeter = 0;
      else if (k === "pick") game.inventory.pick = 0;
      else {
        game.inventory[k]--;
        game.stock[k] = (game.stock[k] || 0) + 1;
      }
      sfx("click");
      updateInv();
      renderCapsule();
    };
    act.append(take, put);
    if (k === "medkit") {
      const use = document.createElement("button");
      use.className = "cbtn";
      use.textContent = T("Kullan");
      use.disabled = n <= 0 || game.hp >= 100;
      use.onclick = () => {
        if (game.stock.medkit <= 0) return;
        if (game.hp >= 100) {
          sfx("full");
          return;
        }
        game.stock.medkit--;
        game.hp = Math.min(100, game.hp + CFG.healAmount);
        startAct("use", 1.2);
        sfx("heal");
        updateStats();
        updateInv();
        closeCapsule();
        toast(T("❤️ Revirde tedavi oldun · +") + CFG.healAmount + T(" can"));
      };
      act.appendChild(use);
    }
    if (k === "water" || k === "potato") {
      const use = document.createElement("button");
      use.className = "cbtn";
      use.textContent = k === "water" ? T("İç") : T("Ye");
      use.disabled = n <= 0;
      use.onclick = () => {
        if (game.stock[k] <= 0) return;
        if (k === "water") {
          if (game.thirst >= 99) {
            sfx("full");
            return;
          }
          game.stock.water--;
          game.thirst = Math.min(100, game.thirst + CFG.drinkThirst);
          startAct("drink", 1.8);
          sfx("drink");
          bumpQuest("drunk");
        } else {
          if (game.hunger >= 99) {
            sfx("full");
            return;
          }
          game.stock.potato--;
          game.hunger = Math.min(100, game.hunger + CFG.eatHunger);
          startAct("eat", 2.0);
          sfx("eat");
        }
        updateStats();
        closeCapsule();
      };
      act.appendChild(use);
    }
    el.appendChild(act);
    g.appendChild(el);
  });
  if (capOpen === "med") {
    $("capFootR").textContent = T("CAN %") + Math.round(game.hp);
    return;
  }
  $("capFootR").textContent =
    capOpen === "food" || capOpen === "kitchen"
      ? T("💧 +1 su / ") + Math.round((recycleInt() / 60) * 10) / 10 + T(" dk")
      : T("KİLİT: AÇIK");
}
/* roket içi kapsül çizimi (lx: merkez, F: zemin) */
function drawCapsule(kind, lx, F, C, t) {
  const a = (capAnim[kind] = capAnim[kind] + ((capOpen === kind ? 1 : 0) - capAnim[kind]) * 0.14);
  const W2 = 22,
    top = C + 40,
    h = F - top;
  // taban
  ctx.fillStyle = "#2a2f47";
  rrp(lx - W2 - 3, F - 8, (W2 + 3) * 2, 8, 2);
  ctx.fill();
  // gövde
  const g = ctx.createLinearGradient(lx - W2, 0, lx + W2, 0);
  g.addColorStop(0, "#6f7698");
  g.addColorStop(0.35, "#e3e8f4");
  g.addColorStop(1, "#4e5578");
  ctx.fillStyle = g;
  rrp(lx - W2, top + 8, W2 * 2, h - 14, 10);
  ctx.fill();
  ctx.strokeStyle = "#20243a";
  ctx.lineWidth = 1.6;
  ctx.stroke();
  ctx.fillStyle = kind === "food" ? "#16a34a" : "#ff8c42";
  ctx.fillRect(lx - W2, top + 20, W2 * 2, 4);
  ctx.fillRect(lx - W2, F - 22, W2 * 2, 3);
  // iç bölme (kapak açılınca görünür)
  const wy = top + 30,
    wh = h - 58;
  ctx.fillStyle = "#0e1430";
  rrp(lx - W2 + 5, wy, W2 * 2 - 10, wh, 6);
  ctx.fill();
  const lightA = 0.15 + 0.75 * a;
  const ig = ctx.createLinearGradient(0, wy, 0, wy + wh);
  ig.addColorStop(0, "rgba(190,240,255," + lightA * 0.55 + ")");
  ig.addColorStop(1, "rgba(90,209,255," + lightA * 0.08 + ")");
  ctx.fillStyle = ig;
  rrp(lx - W2 + 5, wy, W2 * 2 - 10, wh, 6);
  ctx.fill();
  // içerik silüetleri: rafta küçük eşyalar
  const C2 = CAPSULES[kind].items;
  ctx.save();
  rrp(lx - W2 + 5, wy, W2 * 2 - 10, wh, 6);
  ctx.clip();
  C2.forEach(([k], i) => {
    const n = capCount(k),
      row = wy + 10 + (i * (wh - 14)) / C2.length;
    ctx.fillStyle = "rgba(255,255,255,.12)";
    ctx.fillRect(lx - W2 + 6, row + 12, W2 * 2 - 12, 1.4);
    for (let j = 0; j < Math.min(3, n); j++) {
      ctx.save();
      ctx.translate(lx - 10 + j * 10, row + 4);
      drawItemArt(ctx, k, 12, { sparkle: false });
      ctx.restore();
    }
  });
  ctx.restore();
  // kayar kapak (yukarı açılır)
  ctx.save();
  rrp(lx - W2 + 4, wy - 2, W2 * 2 - 8, wh + 4, 6);
  ctx.clip();
  const lid = wh * a;
  const lg = ctx.createLinearGradient(lx - W2, 0, lx + W2, 0);
  lg.addColorStop(0, "#8b93b3");
  lg.addColorStop(0.5, "#d5dbea");
  lg.addColorStop(1, "#6f7698");
  ctx.fillStyle = lg;
  ctx.fillRect(lx - W2 + 4, wy - 2 - lid, W2 * 2 - 8, wh + 4);
  ctx.fillStyle = "rgba(19,51,92,.85)";
  rrp(lx - 8, wy + wh / 2 - 10 - lid, 16, 20, 8);
  ctx.fill(); // kapak penceresi
  ctx.fillStyle = "rgba(255,255,255,.35)";
  ctx.fillRect(lx - 5, wy + wh / 2 - 7 - lid, 2, 12);
  ctx.strokeStyle = "rgba(40,46,70,.6)";
  ctx.lineWidth = 1;
  for (let y = wy + 6; y < wy + wh; y += 8) {
    ctx.beginPath();
    ctx.moveTo(lx - W2 + 6, y - lid);
    ctx.lineTo(lx + W2 - 6, y - lid);
    ctx.stroke();
  }
  ctx.restore();
  // açılırken buhar
  if (a > 0.05 && a < 0.95) {
    for (let i = 0; i < 6; i++) {
      const ph = (t * 1.5 + i / 6) % 1;
      ctx.fillStyle = "rgba(230,245,255," + 0.35 * (1 - ph) + ")";
      ctx.beginPath();
      ctx.arc(lx - 14 + i * 5.5, wy - ph * 20, 2 + ph * 6, 0, 7);
      ctx.fill();
    }
  }
  // tepe kubbe + sayaç ekranı
  ctx.fillStyle = "#5b6178";
  rrp(lx - W2 + 2, top, W2 * 2 - 4, 12, 6);
  ctx.fill();
  ctx.strokeStyle = "#20243a";
  ctx.lineWidth = 1;
  ctx.stroke();
  let tot = 0;
  C2.forEach(([k]) => (tot += capCount(k)));
  ctx.fillStyle = "#0a1024";
  rrp(lx - 13, F - 38, 26, 11, 2);
  ctx.fill();
  ctx.fillStyle = tot > 0 ? "#7fe0ff" : "#ff7b7b";
  ctx.font = "700 7px monospace";
  ctx.textAlign = "center";
  ctx.fillText(tot + T(" ÖĞE"), lx, F - 30);
  led(lx + W2 - 6, top + 6, a > 0.5 ? "#ffd34d" : "#4ade80", true);
  ctx.fillStyle = "#d9dcea";
  ctx.font = "700 6.5px monospace";
  ctx.textAlign = "center";
  ctx.fillText(kind === "food" ? T("YEMEK KAPSÜLÜ") : T("KİT KAPSÜLÜ"), lx, top - 4);
}

/* makine dairesi: alet sandığı (kapak menteşeden açılır) */
function drawToolChest(lx, F, t) {
  const a = (capAnim.kit = capAnim.kit + ((capOpen === "kit" ? 1 : 0) - capAnim.kit) * 0.14);
  const w = 64,
    h = 34,
    x0 = lx - w / 2,
    y0 = F - h - 4;
  ctx.fillStyle = "rgba(0,0,0,.35)";
  ctx.beginPath();
  ctx.ellipse(lx, F - 1, w * 0.58, 4, 0, 0, 7);
  ctx.fill();
  ctx.fillStyle = "#2a2f47";
  ctx.fillRect(x0 + 4, F - 5, 8, 5);
  ctx.fillRect(x0 + w - 12, F - 5, 8, 5); // ayaklar
  // iç ışık (kapak açıkken)
  if (a > 0.02) {
    const ig = ctx.createLinearGradient(0, y0 - 40 * a, 0, y0);
    ig.addColorStop(0, "rgba(255,214,120,0)");
    ig.addColorStop(1, "rgba(255,214,120," + 0.35 * a + ")");
    ctx.fillStyle = ig;
    ctx.beginPath();
    ctx.moveTo(x0 + 4, y0);
    ctx.lineTo(x0 - 10, y0 - 46 * a);
    ctx.lineTo(x0 + w + 10, y0 - 46 * a);
    ctx.lineTo(x0 + w - 4, y0);
    ctx.closePath();
    ctx.fill();
  }
  // gövde: ahşap paneller + metal köşebent
  const bg = ctx.createLinearGradient(0, y0, 0, y0 + h);
  bg.addColorStop(0, "#8a5a2b");
  bg.addColorStop(1, "#5c3818");
  ctx.fillStyle = bg;
  rrp(x0, y0, w, h, 3);
  ctx.fill();
  ctx.strokeStyle = "#3b2410";
  ctx.lineWidth = 1.4;
  ctx.stroke();
  ctx.strokeStyle = "rgba(40,22,8,.55)";
  ctx.lineWidth = 1;
  for (let i = 1; i < 3; i++) {
    ctx.beginPath();
    ctx.moveTo(x0 + 2, y0 + (i * h) / 3);
    ctx.lineTo(x0 + w - 2, y0 + (i * h) / 3);
    ctx.stroke();
  }
  ctx.fillStyle = "#9aa3bd";
  for (const cx of [x0, x0 + w - 6])
    for (const cy of [y0, y0 + h - 6]) {
      rrp(cx, cy, 6, 6, 1);
      ctx.fill();
    }
  ctx.fillStyle = "#7a8299";
  ctx.fillRect(x0 + w / 2 - 14, y0, 3, h);
  ctx.fillRect(x0 + w / 2 + 11, y0, 3, h);
  // ön etiket + kilit
  ctx.fillStyle = "#ff8c42";
  rrp(lx - 15, y0 + h / 2 - 4, 30, 9, 2);
  ctx.fill();
  ctx.fillStyle = "#3a1a05";
  ctx.font = "800 5.6px monospace";
  ctx.textAlign = "center";
  ctx.fillText("ARES-1 TOOLS", lx, y0 + h / 2 + 2.2);
  // içerik: çapa sapı + ölçer (kapak açılınca yükselir)
  if (a > 0.05) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(x0 - 20, y0 - 60, w + 40, 60);
    ctx.clip();
    if (!game.kitCarried) {
      ctx.save();
      ctx.translate(lx - 12, y0 + 6 - 14 * a);
      ctx.rotate(-0.35);
      ctx.scale(0.5, 0.5);
      drawHoe(0, 0, 0);
      ctx.restore();
    }
    if (capCount("radmeter") > 0) {
      ctx.save();
      ctx.translate(lx + 14, y0 - 6 * a);
      drawItemArt(ctx, "radmeter", 16, { sparkle: false });
      ctx.restore();
    }
    if ((game.stock.seed || 0) > 0) {
      ctx.save();
      ctx.translate(lx + 2, y0 - 4 * a);
      drawItemArt(ctx, "seed", 12, {});
      ctx.restore();
    }
    ctx.restore();
  }
  // kapak: arka kenardaki menteşeden döner
  ctx.save();
  ctx.translate(x0, y0);
  const lidH = 10,
    ang = -a * 1.9;
  ctx.translate(0, 0);
  ctx.transform(1, 0, 0, Math.cos(ang), 0, 0);
  const lg = ctx.createLinearGradient(0, -lidH, 0, 0);
  lg.addColorStop(0, "#a06a34");
  lg.addColorStop(1, "#6e4320");
  ctx.fillStyle = lg;
  rrp(-2, -lidH, w + 4, lidH, 3);
  ctx.fill();
  ctx.strokeStyle = "#3b2410";
  ctx.lineWidth = 1.3;
  ctx.stroke();
  ctx.fillStyle = "#9aa3bd";
  ctx.fillRect(w / 2 - 14, -lidH, 3, lidH);
  ctx.fillRect(w / 2 + 11, -lidH, 3, lidH);
  ctx.fillStyle = "#d4a843";
  rrp(w / 2 - 3, -3, 6, 6, 1);
  ctx.fill();
  ctx.restore();
  if (a > 0.5) {
    ctx.fillStyle = "rgba(255,230,160," + 0.6 * a + ")";
    for (let i = 0; i < 4; i++) {
      const ph = (t * 0.8 + i / 4) % 1;
      ctx.beginPath();
      ctx.arc(x0 + 10 + i * 14, y0 - 4 - ph * 26, 1.2, 0, 7);
      ctx.fill();
    }
  }
  ctx.fillStyle = "#d9dcea";
  ctx.font = "700 6.5px monospace";
  ctx.textAlign = "center";
  ctx.fillText(T("ALET SANDIĞI"), lx, y0 - 14 - 30 * a);
}
$("capX").onclick = closeCapsule;
/* ============== KAZILMIŞ TOPRAK (gerçekçi parsel) ============== */
const plotShapes = new WeakMap(),
  plotBorn = new WeakMap();
function plotShape(pl) {
  let s = plotShapes.get(pl);
  if (s) return s;
  const r = rng((Math.abs(Math.round(pl.x * 7.3 + pl.y * 13.1)) % 2147483646) + 1);
  const N = 22,
    hole = [],
    mound = [];
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2;
    hole.push([Math.cos(a) * (40 + r() * 7), Math.sin(a) * (23 + r() * 4)]);
    mound.push([Math.cos(a) * (52 + r() * 10), Math.sin(a) * (31 + r() * 7)]);
  }
  const clods = [],
    pebbles = [],
    specks = [];
  for (let i = 0; i < 16; i++) {
    const a = r() * 6.28,
      d = 0.75 + r() * 0.45;
    clods.push([Math.cos(a) * 48 * d, Math.sin(a) * 29 * d, 2.5 + r() * 4.5, r() * 3]);
  }
  for (let i = 0; i < 9; i++) pebbles.push([(r() - 0.5) * 70, (r() - 0.5) * 36, 1.2 + r() * 1.8]);
  for (let i = 0; i < 40; i++) specks.push([(r() - 0.5) * 78, (r() - 0.5) * 42, r()]);
  s = { hole, mound, clods, pebbles, specks, seedR: r() };
  plotShapes.set(pl, s);
  return s;
}
function polyPath(pts, cx, cy, k) {
  ctx.beginPath();
  pts.forEach(([x, y], i) => {
    const X = cx + x * k,
      Y = cy + y * k;
    i ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y);
  });
  ctx.closePath();
}
function drawPlot(pl, g) {
  if (pl.fill > 0) {
    ctx.save();
    ctx.globalAlpha = 1 - pl.fill;
    drawPlot0(pl, g, 1 - pl.fill * 0.55);
    ctx.restore();
    return;
  }
  drawPlot0(pl, g, 1);
}
function drawPlot0(pl, g, shrink) {
  const x = pl.x,
    y = pl.y,
    S = plotShape(pl),
    t = performance.now() / 1000;
  if (!plotBorn.has(pl)) plotBorn.set(pl, t - 5);
  const age = t - plotBorn.get(pl),
    grow = Math.min(1, age / 0.45),
    k = (0.35 + 0.65 * (1 - Math.pow(1 - grow, 3))) * shrink;
  const wet = g && g.wet > 0 ? Math.min(1, g.wet / 10) : 0;
  // atılan toprak yığını (kenar)
  ctx.fillStyle = "rgba(0,0,0,.22)";
  polyPath(S.mound, x + 3, y + 6, k);
  ctx.fill();
  const mg = ctx.createRadialGradient(x, y - 10, 10, x, y, 62 * k);
  mg.addColorStop(0, "#9a5e3c");
  mg.addColorStop(1, "#7a4128");
  ctx.fillStyle = mg;
  polyPath(S.mound, x, y, k);
  ctx.fill();
  for (const [cx, cy, r, rot] of S.clods) {
    // topaklar
    ctx.fillStyle = "#6a3820";
    ctx.beginPath();
    ctx.ellipse(x + cx * k + 1, y + cy * k + 1.5, r, r * 0.7, rot, 0, 7);
    ctx.fill();
    ctx.fillStyle = "#a56a44";
    ctx.beginPath();
    ctx.ellipse(x + cx * k, y + cy * k, r, r * 0.7, rot, 0, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,210,170,.25)";
    ctx.beginPath();
    ctx.ellipse(x + cx * k - r * 0.3, y + cy * k - r * 0.25, r * 0.45, r * 0.28, rot, 0, 7);
    ctx.fill();
  }
  // çukur
  const hg = ctx.createLinearGradient(x, y - 26 * k, x, y + 24 * k);
  hg.addColorStop(0, wet ? "#2a160c" : "#3b2214");
  hg.addColorStop(0.5, wet ? "#3a2112" : "#56331d");
  hg.addColorStop(1, wet ? "#4a2c18" : "#6e4428");
  ctx.fillStyle = hg;
  polyPath(S.hole, x, y, k);
  ctx.fill();
  ctx.save();
  polyPath(S.hole, x, y, k);
  ctx.clip();
  // iç gölge (derinlik): üst kenar koyu
  const sh = ctx.createLinearGradient(x, y - 26 * k, x, y - 6 * k);
  sh.addColorStop(0, "rgba(10,4,2,.6)");
  sh.addColorStop(1, "rgba(10,4,2,0)");
  ctx.fillStyle = sh;
  ctx.fillRect(x - 60, y - 30, 120, 30);
  // sürülmüş sıralar (sırt + gölge)
  for (let i = -1; i <= 1; i++) {
    const ry = y + i * 10 * k;
    ctx.strokeStyle = "rgba(20,8,3,.5)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x - 40 * k, ry + 2.5);
    ctx.quadraticCurveTo(x, ry + 6, x + 40 * k, ry + 2.5);
    ctx.stroke();
    ctx.strokeStyle = wet ? "rgba(120,80,50,.55)" : "rgba(170,110,70,.6)";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(x - 40 * k, ry - 1);
    ctx.quadraticCurveTo(x, ry + 2.5, x + 40 * k, ry - 1);
    ctx.stroke();
  }
  for (const [sx, sy, v] of S.specks) {
    ctx.fillStyle = v < 0.5 ? "rgba(20,8,3,.45)" : "rgba(200,140,95,.35)";
    ctx.fillRect(x + sx * k, y + sy * k, 1.5, 1.5);
  }
  for (const [px2, py2, r] of S.pebbles) {
    ctx.fillStyle = "#8a7d74";
    ctx.beginPath();
    ctx.ellipse(x + px2 * k, y + py2 * k, r, r * 0.75, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,.35)";
    ctx.fillRect(x + px2 * k - r * 0.4, y + py2 * k - r * 0.5, r * 0.6, r * 0.4);
  }
  if (wet) {
    // ıslak parlama + küçük su birikintisi
    ctx.fillStyle = "rgba(140,200,255," + 0.18 * wet + ")";
    ctx.beginPath();
    ctx.ellipse(x - 12, y + 6, 14, 4, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255," + 0.3 * wet + ")";
    ctx.beginPath();
    ctx.ellipse(x - 16, y + 5, 5, 1.2, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255," + 0.18 * wet + ")";
    for (let i = 0; i < 5; i++) ctx.fillRect(x - 30 + i * 14, y - 6 + (i % 2) * 10, 3, 1);
  }
  ctx.restore();
  // alt kenar ışığı
  ctx.strokeStyle = "rgba(255,190,140,.3)";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  S.hole.forEach(([hx, hy], i) => {
    if (hy < 4) return;
    const X = x + hx * k,
      Y = y + hy * k;
    ctx.lineTo(X, Y);
  });
  ctx.stroke();
  if (age < 0.6) {
    ctx.fillStyle = "rgba(200,130,80," + 0.5 * (1 - age / 0.6) + ")";
    ctx.beginPath();
    ctx.ellipse(x, y, 60 * (1 + age), 30 * (1 + age), 0, 0, 7);
    ctx.fill();
  }
  if (!g || g.g <= 0) {
    // boş: ekim çukurcukları
    ctx.fillStyle = "rgba(15,6,2,.55)";
    for (const ox of [-20, 0, 20]) {
      ctx.beginPath();
      ctx.ellipse(x + ox * k, y + 1, 3.2, 1.8, 0, 0, 7);
      ctx.fill();
    }
    if (g && g.cov) drawCeramicDome(x, y, k, t, g);
    return;
  }
  const burnt = !domeSafe(g) && game.radiationActive && scene !== "earth";
  drawPotatoPlant(
    x,
    y,
    plotStage(g.g),
    t,
    g.g >= CFG.farmGrow,
    (g.g >= CFG.farmGrow * 0.75 && plotRots(g)) || burnt,
  );
  if (g.cov) drawCeramicDome(x, y, k, t, g);
}
/* ============== SERAMİK KALKAN ==============
   Parsele kurulan iki kanatlı seramik kubbe. Q ile açılır/kapanır (servo + hidrolik pistonlar).
   Kapalıyken radyasyon dalgasını keser ama bitkiye erişilemez (sulama/hasat için açmak gerekir).
   g.cov = kalkan kurulu · g.shut = hedef durum (1 kapalı) · g.oa = kapanma animasyonu (0 açık → 1 kapalı) */
const DOME_SPEED = 1 / 1.1; // tam açılma/kapanma ~1,1 sn
function domeClosed(g) {
  return !!(g && g.cov && g.shut && (g.oa == null ? 1 : g.oa) >= 0.98);
}
function domeSafe(g) {
  return domeClosed(g);
}
function domeMoving(g) {
  return !!(g && g.cov && Math.abs((g.shut ? 1 : 0) - (g.oa || 0)) > 0.01);
}
function updateDomes(dt) {
  for (const g of farmArr()) {
    if (!g || !g.cov) continue;
    if (g.oa == null) g.oa = g.shut ? 1 : 0;
    const tg = g.shut ? 1 : 0;
    if (g.oa === tg) continue;
    const was = g.oa;
    g.oa = tg > g.oa ? Math.min(1, g.oa + dt * DOME_SPEED) : Math.max(0, g.oa - dt * DOME_SPEED);
    if (g.oa === tg) {
      // hareket bitti: kilit sesi + toz
      if (tg === 1) {
        tone(110, 0.16, "square", 0.06, 70);
        noiseBurst(0.18, 0.1, 900);
        burst(g.x, g.y + 12, 10, "#d9cfbd", { sp: 60, life: 0.6, size: 3, up: 10 });
      } else {
        tone(180, 0.1, "triangle", 0.05, 140);
      }
    } else if (Math.floor(was * 6) !== Math.floor(g.oa * 6))
      tone(tg ? 520 + g.oa * 260 : 780 - g.oa * 260, 0.05, "sawtooth", 0.012); // servo vızıltısı
  }
}
function setDome(g, shut, quiet) {
  if (!g || !g.cov) return;
  if (g.oa == null) g.oa = g.shut ? 1 : 0;
  g.shut = shut ? 1 : 0;
  if (!quiet) {
    noiseBurst(0.35, 0.06, 2600);
    tone(shut ? 440 : 620, 0.28, "sine", 0.035, shut ? 300 : 900);
    burst(g.x, g.y - 10, 12, "rgba(230,240,255,.8)", { sp: 70, life: 0.7, size: 4, up: 40 });
  }
}
function drawCeramicDome(x, y, k, t, g) {
  const c = g.oa == null ? (g.shut ? 1 : 0) : g.oa,
    R = 50 * k,
    Hh = 64 * k,
    by = y + 14 * k,
    open = 1 - c,
    ang = open * 1.32;
  const rad = game.radiationActive && scene !== "earth",
    moving = domeMoving(g);
  ctx.save();
  ctx.fillStyle = "rgba(0,0,0," + (0.12 + 0.1 * c) + ")";
  ctx.beginPath();
  ctx.ellipse(x + 3, by + 4, R + 6 + open * 24, 13 * k, 0, 0, 7);
  ctx.fill();
  // taban halkası (arka yarı)
  ctx.strokeStyle = "#3e4860";
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.ellipse(x, by, R + 2, 7 * k, 0, Math.PI, 0);
  ctx.stroke();
  ctx.strokeStyle = "#7b8ba8";
  ctx.lineWidth = 4.5;
  ctx.beginPath();
  ctx.ellipse(x, by, R + 2, 7 * k, 0, Math.PI, 0);
  ctx.stroke();
  const dome = () => {
    ctx.beginPath();
    ctx.moveTo(x - R, by);
    ctx.bezierCurveTo(x - R, by - Hh * 1.33, x + R, by - Hh * 1.33, x + R, by);
    ctx.closePath();
  };
  // iki kanat: her biri dış alt köşesindeki menteşe etrafında dışa doğru açılır
  for (const sd of [-1, 1]) {
    const hx = x + sd * R,
      hy = by;
    ctx.save();
    ctx.translate(hx, hy);
    ctx.rotate(sd * ang);
    ctx.translate(-hx, -hy);
    ctx.beginPath();
    ctx.rect(sd < 0 ? x - R - 4 : x, by - Hh * 1.2, R + 4, Hh * 1.2 + 2);
    ctx.clip();
    const dg = ctx.createLinearGradient(x - R, by - Hh, x + R, by);
    dg.addColorStop(0, "rgba(255,250,238,.84)");
    dg.addColorStop(0.5, "rgba(232,222,204,.72)");
    dg.addColorStop(1, "rgba(160,148,128,.86)");
    ctx.fillStyle = dg;
    dome();
    ctx.fill();
    ctx.save();
    dome();
    ctx.clip();
    ctx.strokeStyle = "rgba(96,86,70,.45)";
    ctx.lineWidth = 1.1;
    for (const f of [0.3, 0.58, 0.82]) {
      const yy = by - Hh * f;
      ctx.beginPath();
      ctx.moveTo(x - R, yy + 6 * k * (1 - f));
      ctx.quadraticCurveTo(x, yy - 8 * k * (1 - f), x + R, yy + 6 * k * (1 - f));
      ctx.stroke();
    }
    for (const f of [-0.66, -0.33, 0.33, 0.66]) {
      ctx.beginPath();
      ctx.moveTo(x + f * R, by);
      ctx.quadraticCurveTo(x + f * R * 0.8, by - Hh * 0.55, x + f * R * 0.35, by - Hh);
      ctx.stroke();
    }
    if (sd < 0) {
      ctx.strokeStyle = "rgba(255,255,255,.7)";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(x - R * 0.62, by - Hh * 0.38);
      ctx.quadraticCurveTo(x - R * 0.48, by - Hh * 0.86, x - R * 0.08, by - Hh * 0.98);
      ctx.stroke();
    }
    // orta conta kenarı (açıkken ışıklı şerit)
    ctx.strokeStyle =
      open > 0.02 ? "rgba(90,209,255," + (0.5 + 0.4 * Math.sin(t * 6)) + ")" : "rgba(70,62,50,.6)";
    ctx.lineWidth = open > 0.02 ? 2.2 : 1.4;
    ctx.beginPath();
    ctx.moveTo(x, by - Hh + 1);
    ctx.lineTo(x, by);
    ctx.stroke();
    ctx.restore();
    ctx.strokeStyle = "#6f6553";
    ctx.lineWidth = 1.6;
    dome();
    ctx.stroke();
    if (rad && c >= 0.98) {
      const pu = 0.5 + 0.5 * Math.sin(t * 5);
      ctx.strokeStyle = "rgba(163,230,53," + (0.35 + 0.35 * pu) + ")";
      ctx.lineWidth = 3;
      ctx.shadowColor = "#a3e635";
      ctx.shadowBlur = 12;
      dome();
      ctx.stroke();
      ctx.shadowBlur = 0;
    }
    ctx.restore();
    // hidrolik piston: tabandan kanadın ortasına
    if (open > 0.03) {
      const ax = x + sd * R * 0.55,
        ay = by - 2,
        mx = x + sd * R * 0.5,
        my = by - Hh * 0.55;
      const q = rotP(mx - hx, my - hy, sd * ang),
        ex = hx + q.x,
        ey = hy + q.y;
      const midx = ax + (ex - ax) * 0.55,
        midy = ay + (ey - ay) * 0.55;
      ctx.lineCap = "round";
      ctx.strokeStyle = "#2b3248";
      ctx.lineWidth = 5.5;
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(midx, midy);
      ctx.stroke();
      ctx.strokeStyle = "#d7dce8";
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(midx, midy);
      ctx.lineTo(ex, ey);
      ctx.stroke();
      ctx.fillStyle = "#7b8ba8";
      ctx.beginPath();
      ctx.arc(ax, ay, 2.6, 0, 7);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(ex, ey, 2.2, 0, 7);
      ctx.fill();
    }
  }
  // tarama ışığı: hareket sırasında kubbeyi yukarıdan aşağı süpürür
  if (moving) {
    const sy = by - Hh * (0.5 + 0.5 * Math.sin(t * 7));
    ctx.save();
    ctx.globalAlpha = 0.55;
    const lg = ctx.createLinearGradient(0, sy - 6, 0, sy + 6);
    lg.addColorStop(0, "rgba(90,209,255,0)");
    lg.addColorStop(0.5, "rgba(140,230,255,.9)");
    lg.addColorStop(1, "rgba(90,209,255,0)");
    ctx.fillStyle = lg;
    ctx.fillRect(x - R - 8, sy - 6, R * 2 + 16, 12);
    ctx.restore();
  }
  // taban halkası (ön yarı) + durum ışığı
  ctx.strokeStyle = "#3e4860";
  ctx.lineWidth = 7;
  ctx.beginPath();
  ctx.ellipse(x, by, R + 2, 7 * k, 0, 0, Math.PI);
  ctx.stroke();
  ctx.strokeStyle = "#7b8ba8";
  ctx.lineWidth = 4.5;
  ctx.beginPath();
  ctx.ellipse(x, by, R + 2, 7 * k, 0, 0, Math.PI);
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,.35)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.ellipse(x, by - 1.5, R + 2, 7 * k, 0, 0.25, Math.PI - 0.25);
  ctx.stroke();
  const col = moving ? "#fbbf24" : c >= 0.98 ? (rad ? "#a3e635" : "#4ade80") : "#ff8c42";
  ctx.fillStyle = col;
  ctx.shadowColor = col;
  ctx.shadowBlur = 8;
  ctx.globalAlpha = moving ? (Math.sin(t * 16) > 0 ? 1 : 0.3) : 0.65 + 0.35 * Math.sin(t * 2.5);
  for (const lx of [-12, 0, 12]) {
    ctx.beginPath();
    ctx.arc(x + lx * k, by + 6 * k, 1.9, 0, 7);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;
  ctx.restore();
}
function coverPlot(g) {
  if (!g) {
    sfx("error");
    toast(T("Kalkanı kurmak için bir parselin yanına git"));
    return false;
  }
  if (g.cov) {
    sfx("full");
    toast(T("Bu parselde zaten seramik kalkan var · <b>Q</b> ile aç/kapat"));
    return false;
  }
  if ((game.inventory.ceramic || 0) <= 0) {
    sfx("error");
    toast(T("Seramik kalkan yok — roketteki alet sandığından al"));
    return false;
  }
  game.inventory.ceramic--;
  updateInv();
  const planted = g.g > 0;
  g.cov = 1;
  g.oa = 0;
  g.shut = 0;
  g.idle = 0;
  g.fill = 0;
  if (planted)
    setTimeout(() => {
      if (g.cov && !g.shut) {
        setDome(g, 1);
        toast(T("🛡️ Kalkan kapanıyor — içerideki bitki artık radyasyondan korunuyor"));
      }
    }, 650);
  p.dir = g.x < p.x ? -1 : 1;
  burst(g.x, g.y - 20, 18, "#efe6d4", { sp: 110, life: 0.6, size: 4, up: 60 });
  addFloat(g.x, g.y - 70, T("🛡️ Kalkan kuruldu"), "#efe6d4");
  sfx("plant");
  tone(660, 0.08, "triangle", 0.05);
  tone(990, 0.12, "triangle", 0.045, null, 0.08);
  bumpQuest("covered");
  if (!planted) toast(T("🛡️ Kalkan kuruldu. Tohumu ek, sonra <b>Q</b> ile kapat."));
  storyTrigger("domeFirst");
  return true;
}
/* Q: en yakın kalkanı aç/kapat · Shift+Q: boş parseldeki kalkanı sök */
function nearestDome() {
  let b = null,
    bd = CFG.plotRange + 30;
  farmArr().forEach((g) => {
    if (!g || !g.cov) return;
    const d = Math.hypot(p.x - g.x, p.y - g.y);
    if (d < bd) {
      bd = d;
      b = g;
    }
  });
  return b;
}
function pressQ(shift) {
  if (
    mode !== "play" ||
    paused ||
    !game ||
    insideRocket ||
    rocketOpen ||
    marketOpen ||
    repairOpen ||
    capOpen ||
    commOpen ||
    upgOpen ||
    o2Fill ||
    bookOpen ||
    bedOpen ||
    winOpen ||
    fly ||
    radM ||
    brk
  )
    return;
  const g = nearestDome();
  if (!g) {
    sfx("error");
    toast(T("Yakında seramik kalkan yok — kalkanlı bir parselin yanına git"));
    return;
  }
  p.dir = g.x < p.x ? -1 : 1;
  if (shift) {
    if (g.g > 0) {
      sfx("error");
      toast(T("Kalkan yalnızca boş parselden sökülür — önce hasat et"));
      return;
    }
    g.cov = 0;
    g.shut = 0;
    g.oa = 0;
    game.inventory.ceramic = (game.inventory.ceramic || 0) + 1;
    updateInv();
    burst(g.x, g.y - 10, 14, "#efe6d4", { sp: 90, life: 0.6, size: 4, up: 40 });
    addFloat(g.x, g.y - 60, T("+1 🛡️ kalkan söküldü"), "#efe6d4");
    sfx("pickup");
    return;
  }
  const close = !g.shut;
  setDome(g, close);
  if (close) {
    if ((game.qstats.domeOpen || 0) > 0) bumpQuest("domeCycle");
    addFloat(g.x, g.y - 74, T("🔒 Kalkan kapanıyor"), "#cfe8ff");
  } else {
    game.qstats.domeOpen = (game.qstats.domeOpen || 0) + 1;
    updateQuest();
    addFloat(g.x, g.y - 74, T("🔓 Kalkan açılıyor"), "#ffd8a8");
    if (game.radiationActive && scene !== "earth" && g.g > 0)
      toast(T("☢️ Dikkat! Radyasyon dalgası sürüyor — açık kalkan bitkiyi korumaz"));
    else if (!game._domeOpenTip) {
      game._domeOpenTip = 1;
      toast(
        T("🔓 Kalkan açıkken sulayıp hasat edebilirsin. Radyasyon gelmeden <b>Q</b> ile kapatmayı unutma."),
      );
    }
  }
}
function drawPotatoPlant(x, y, k, t, ready, rot) {
  const sway = Math.sin(t * 1.6 + x * 0.01) * (1 + stormFx.I * 6) * 0.04;
  const leaf = (lx, ly, len, ang, col) => {
    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(ang + sway);
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(len * 0.5, -len * 0.42, len, 0);
    ctx.quadraticCurveTo(len * 0.5, len * 0.42, 0, 0);
    ctx.fill();
    ctx.strokeStyle = "rgba(20,60,30,.5)";
    ctx.lineWidth = 0.8;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(len * 0.92, 0);
    ctx.stroke();
    ctx.restore();
  };
  if (k < 0.15) {
    // filiz: iki çenek yaprağı
    const s = k / 0.15;
    ctx.strokeStyle = "#7fbf5a";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, y + 2);
    ctx.lineTo(x, y - 4 - 6 * s);
    ctx.stroke();
    leaf(x, y - 4 - 6 * s, 5 + 4 * s, -2.6, "#8fd16a");
    leaf(x, y - 4 - 6 * s, 5 + 4 * s, -0.5, "#8fd16a");
    return;
  }
  const wilt = rot ? (ready ? 1 : 0.45) : 0,
    stems = k < 0.6 ? 3 : 5,
    H = (12 + 34 * k) * (1 - 0.22 * wilt),
    cols = rot
      ? ready
        ? ["#6b5a2a", "#8a7434"]
        : ["#5f8a3a", "#7a9a3a"]
      : ready
        ? ["#7a9a3a", "#93ad48"]
        : ["#2f7d4f", "#3fa866"];
  for (let i = 0; i < stems; i++) {
    const a = -Math.PI / 2 + (i - (stems - 1) / 2) * (0.42 + 0.5 * wilt) + sway,
      h = H * (0.75 + (0.25 * ((i * 7) % 3)) / 2);
    const ex = x + Math.cos(a) * h * 0.55,
      ey = y + 2 + Math.sin(a) * h;
    ctx.strokeStyle = "#2f6d3f";
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(x + (i - (stems - 1) / 2) * 3, y + 3);
    ctx.quadraticCurveTo(x + Math.cos(a) * h * 0.2, y - h * 0.5, ex, ey);
    ctx.stroke();
    // bileşik yapraklar
    for (let j = 0; j < 3; j++) {
      const u = 0.45 + j * 0.25,
        lx = x + (ex - x) * u,
        ly = y + (ey - y) * u;
      leaf(lx, ly, 6 + 8 * k, a - 0.9, cols[j % 2]);
      leaf(lx, ly, 6 + 8 * k, a + 0.9 - Math.PI * 0, cols[(j + 1) % 2]);
    }
    leaf(ex, ey, 7 + 8 * k, a, cols[0]);
    if (k >= 0.85 && !(rot && ready)) {
      // çiçekler
      ctx.fillStyle = "#f5f0ff";
      for (let f = 0; f < 5; f++) {
        const fa = f * 1.256 + t * 0.2;
        ctx.beginPath();
        ctx.ellipse(ex + Math.cos(fa) * 2.6, ey - 3 + Math.sin(fa) * 2.6, 1.8, 1.1, fa, 0, 7);
        ctx.fill();
      }
      ctx.fillStyle = "#ffd34d";
      ctx.beginPath();
      ctx.arc(ex, ey - 3, 1.2, 0, 7);
      ctx.fill();
    }
  }
  if (ready && rot) {
    // çürümüş: kararmış yumrular, sinekler, soluk halka
    for (const [ox, oy, r] of [
      [-18, 6, 1],
      [16, 8, 0.9],
      [0, 12, 1.1],
    ]) {
      ctx.save();
      ctx.translate(x + ox, y + oy);
      drawItemArt(ctx, "rotten", 16 * r, { sparkle: false });
      ctx.restore();
    }
    ctx.fillStyle = "#141414";
    for (let i = 0; i < 4; i++) {
      const a = t * (2.4 + i * 0.5) + i * 1.7,
        fx = x + Math.cos(a) * (18 + i * 5),
        fy = y - 18 + Math.sin(a * 1.3) * 9;
      ctx.beginPath();
      ctx.arc(fx, fy, 1.4, 0, 7);
      ctx.fill();
      ctx.fillStyle = "rgba(220,220,220,.5)";
      ctx.beginPath();
      ctx.ellipse(fx - 1.5, fy - 1.4, 1.6, 0.8, -0.5 + Math.sin(t * 40 + i) * 0.4, 0, 7);
      ctx.fill();
      ctx.fillStyle = "#141414";
    }
    ctx.strokeStyle = "rgba(150,130,80,.7)";
    ctx.lineWidth = 2.4;
    ctx.setLineDash([3, 7]);
    ctx.lineDashOffset = -t * 8;
    ctx.beginPath();
    ctx.ellipse(x, y, 62, 36, 0, 0, 7);
    ctx.stroke();
    ctx.setLineDash([]);
  } else if (ready) {
    // topraktan görünen patatesler + parıltı halkası
    for (const [ox, oy, r] of [
      [-18, 6, 1],
      [16, 8, 0.9],
      [0, 12, 1.1],
    ]) {
      ctx.save();
      ctx.translate(x + ox, y + oy);
      drawItemArt(ctx, "potato", 16 * r, {});
      ctx.restore();
    }
    const pu = 0.45 + 0.35 * Math.sin(t * 4.5);
    ctx.strokeStyle = "rgba(255,211,77," + pu + ")";
    ctx.lineWidth = 2.4;
    ctx.setLineDash([6, 6]);
    ctx.lineDashOffset = -t * 20;
    ctx.beginPath();
    ctx.ellipse(x, y, 62, 36, 0, 0, 7);
    ctx.stroke();
    ctx.setLineDash([]);
  } else {
    // büyüme halkası
    ctx.strokeStyle = "rgba(0,0,0,.35)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(x, y, 60, 34, 0, 0, 7);
    ctx.stroke();
    ctx.strokeStyle = "rgba(127,224,140,.85)";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.ellipse(x, y, 60, 34, 0, -Math.PI / 2, -Math.PI / 2 + k * Math.PI * 2);
    ctx.stroke();
  }
}

/* ============== METEOR DÜŞÜŞLERİ (gerçekçi) ==============
   Gökyüzünden çapraz giren alev topu → iz dumanı → çarpma: parlama,
   şok dalgası, toz bulutu, saçılan kaya parçaları, kalıcı tüten krater. */
const MET_T = 2.6,
  MET_ALT = 1100;
const metFx = [],
  craters = {};
let mflash = 0;
function spawnMeteor() {
  const a = Math.random() * 6.283,
    dist = 140 + Math.random() * 420;
  const x = Math.max(-CFG.worldHalf + 60, Math.min(CFG.worldHalf - 60, p.x + Math.cos(a) * dist)),
    y = Math.max(-CFG.worldHalf + 60, Math.min(CFG.worldHalf - 60, p.y + Math.sin(a) * dist));
  const dir = Math.random() < 0.5 ? -1 : 1;
  ev.meteors.push({
    x,
    y,
    t: MET_T,
    T: MET_T,
    dx: dir * (0.55 + Math.random() * 0.35),
    size: 0.8 + Math.random() * 0.6,
    seed: Math.random() * 1000,
  });
  // yaklaşma uğultusu
  meteorWhoosh(MET_T);
  commsObs("meteor", { n: 1, near: Math.hypot(x - p.x, y - p.y) });
}
function metHead(m) {
  const u = Math.max(0, m.t / m.T),
    alt = u * u * MET_ALT;
  return { x: m.x - m.dx * alt, y: m.y - alt * 0.85, alt, u };
}
function updateMeteorFx(dt) {
  for (const m of ev.meteors) {
    // iz: duman + kıvılcım
    const h = metHead(m);
    for (let i = 0; i < 3; i++)
      metFx.push({
        k: "smoke",
        x: h.x + (Math.random() - 0.5) * 8,
        y: h.y + (Math.random() - 0.5) * 8,
        vx: (Math.random() - 0.5) * 12,
        vy: -6 - Math.random() * 8,
        r: 5 + m.size * 5,
        life: 0,
        max: 1.6 + Math.random() * 1.4,
      });
    if (Math.random() < 0.8)
      metFx.push({
        k: "spark",
        x: h.x,
        y: h.y,
        vx: (Math.random() - 0.5) * 160 + m.dx * -60,
        vy: (Math.random() - 0.5) * 160,
        life: 0,
        max: 0.35 + Math.random() * 0.3,
      });
  }
  for (let i = metFx.length - 1; i >= 0; i--) {
    const f = metFx[i];
    f.life += dt;
    if (f.life > f.max) {
      metFx.splice(i, 1);
      continue;
    }
    if (f.k === "debris") {
      f.vz -= 520 * dt;
      f.z += f.vz * dt;
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      if (f.z <= 0) {
        f.z = 0;
        f.vz *= -0.35;
        f.vx *= 0.6;
        f.vy *= 0.6;
        if (Math.abs(f.vz) < 30) f.vz = 0;
      }
      f.rot += f.vr * dt;
    } else if (f.k === "dust") {
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      f.vx *= 1 - dt * 1.6;
      f.vy *= 1 - dt * 1.6;
      f.r += dt * (28 - f.life * 6);
    } else if (f.k === "smoke" || f.k === "spark") {
      f.x += f.vx * dt;
      f.y += f.vy * dt;
      if (f.k === "smoke") {
        f.r += dt * 16;
        f.vx *= 1 - dt;
      }
    }
  }
  if (metFx.length > 700) metFx.splice(0, metFx.length - 700);
  mflash = Math.max(0, mflash - dt * 2.2);
  const cr = craters[scene];
  if (cr)
    for (const c of cr) {
      c.heat = Math.max(0, c.heat - dt / 24);
    }
}
function impact(m) {
  const d = Math.hypot(p.x - m.x, p.y - m.y),
    near = Math.max(0, 1 - d / 900),
    S = m.size;
  // krater (kalıcı)
  (craters[scene] = craters[scene] || []).push({ x: m.x, y: m.y, r: 34 + S * 22, heat: 1, seed: m.seed });
  if (craters[scene].length > 40) craters[scene].shift();
  // toz bulutu
  for (let i = 0; i < 26; i++) {
    const a = Math.random() * 6.28,
      sp = 60 + Math.random() * 190;
    metFx.push({
      k: "dust",
      x: m.x,
      y: m.y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp * 0.6 - 20,
      r: 14 + Math.random() * 16,
      life: 0,
      max: 2.2 + Math.random() * 1.6,
    });
  }
  // kaya parçaları (yükseklikli, gölgeli)
  for (let i = 0; i < 18; i++) {
    const a = Math.random() * 6.28,
      sp = 80 + Math.random() * 260;
    metFx.push({
      k: "debris",
      x: m.x,
      y: m.y,
      z: 4,
      vz: 180 + Math.random() * 320,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp * 0.7,
      s: 2 + Math.random() * 4.5,
      rot: 0,
      vr: (Math.random() - 0.5) * 14,
      life: 0,
      max: 2.4 + Math.random(),
      hot: Math.random() < 0.45,
    });
  }
  for (let i = 0; i < 30; i++) {
    const a = Math.random() * 6.28,
      sp = 120 + Math.random() * 320;
    metFx.push({
      k: "spark",
      x: m.x,
      y: m.y,
      vx: Math.cos(a) * sp,
      vy: Math.sin(a) * sp,
      life: 0,
      max: 0.4 + Math.random() * 0.5,
    });
  }
  metFx.push({ k: "shock", x: m.x, y: m.y, life: 0, max: 0.7, R: 220 + S * 80 });
  metFx.push({ k: "flash", x: m.x, y: m.y, life: 0, max: 0.35, R: 120 + S * 40 });
  mflash = Math.max(mflash, 0.55 * near + 0.05);
  shake = Math.max(shake, 4 + 16 * near);
  meteorImpact(Math.max(0.25, near), Math.min(0.7, d * 0.00055)); // ses mesafeye göre gecikir
  if (d < CFG.meteorRadius && !insideRocket) {
    const md = Math.round(CFG.meteorDmg * dif().met);
    damage(md);
    addFloat(p.x, p.y - 56, "-" + md + " ❤️", "#ff5a5a");
  }
  if (Math.random() < 0.7)
    drops.push({ x: m.x, y: m.y, type: Math.random() < 0.55 ? "star" : "stone", taken: false });
  if (scene !== "earth" && Math.random() < 0.8) {
    const n = 1 + (Math.random() < 0.45 ? 1 : 0) + (S > 1.2 && Math.random() < 0.5 ? 1 : 0);
    for (let i = 0; i < n; i++) {
      const a = Math.random() * 6.28,
        r = 30 + Math.random() * 50;
      drops.push({
        x: m.x + Math.cos(a) * r,
        y: m.y + Math.sin(a) * r * 0.7,
        type: "gold",
        n: 1,
        taken: false,
        seed: Math.random() * 10,
      });
    }
  }
}
/* zeminde: kraterler (dekordan sonra) */
function drawCraters(vis) {
  const cr = craters[scene];
  if (!cr) return;
  const t = performance.now() / 1000;
  for (const c of cr) {
    if (!vis(c)) continue;
    const r = c.r;
    const rg = ctx.createRadialGradient(c.x, c.y, r * 0.5, c.x, c.y, r * 1.9);
    rg.addColorStop(0, "rgba(25,8,4,.45)");
    rg.addColorStop(1, "rgba(25,8,4,0)");
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, r * 1.9, r * 1.15, 0, 0, 7);
    ctx.fill(); // yanık iz
    ctx.fillStyle = "#8a4a30";
    ctx.beginPath();
    ctx.ellipse(c.x, c.y + 2, r * 1.12, r * 0.68, 0, 0, 7);
    ctx.fill(); // sırt
    const ig = ctx.createLinearGradient(c.x, c.y - r * 0.6, c.x, c.y + r * 0.6);
    ig.addColorStop(0, "#1e0b06");
    ig.addColorStop(1, "#5a2a18");
    ctx.fillStyle = ig;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y, r * 0.9, r * 0.52, 0, 0, 7);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,190,150,.35)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(c.x, c.y + 1, r * 0.95, r * 0.56, 0, 0.2, Math.PI - 0.2);
    ctx.stroke();
    if (c.heat > 0) {
      // soğuyan sıcak merkez + tütme
      const hg = ctx.createRadialGradient(c.x, c.y, 1, c.x, c.y, r * 0.7);
      hg.addColorStop(0, "rgba(255,200,90," + 0.9 * c.heat + ")");
      hg.addColorStop(0.5, "rgba(255,90,30," + 0.55 * c.heat + ")");
      hg.addColorStop(1, "rgba(120,20,0,0)");
      ctx.fillStyle = hg;
      ctx.beginPath();
      ctx.ellipse(c.x, c.y, r * 0.7, r * 0.42, 0, 0, 7);
      ctx.fill();
      for (let i = 0; i < 5; i++) {
        const ph = (t * 0.4 + i * 0.2 + c.seed) % 1;
        ctx.fillStyle = "rgba(120,110,105," + 0.32 * c.heat * (1 - ph) + ")";
        ctx.beginPath();
        ctx.arc(c.x + Math.sin(i * 2.3 + t) * 10 + ph * 14, c.y - ph * 70, 6 + ph * 16, 0, 7);
        ctx.fill();
      }
    }
  }
}
/* zeminde: yaklaşan meteorun gölgesi + ısınan zemin */
function drawMeteor(m) {
  const k = Math.max(0, Math.min(1, m.t / m.T)),
    q = 1 - k,
    sh = 10 + 46 * q;
  ctx.fillStyle = "rgba(20,6,4," + (0.08 + 0.32 * q) + ")";
  ctx.beginPath();
  ctx.ellipse(m.x, m.y, sh, sh * 0.45, 0, 0, 7);
  ctx.fill();
  const hg = ctx.createRadialGradient(m.x, m.y, 1, m.x, m.y, sh * 1.6);
  hg.addColorStop(0, "rgba(255,170,80," + 0.45 * q * q + ")");
  hg.addColorStop(1, "rgba(255,120,40,0)");
  ctx.fillStyle = hg;
  ctx.beginPath();
  ctx.arc(m.x, m.y, sh * 1.6, 0, 7);
  ctx.fill();
}
/* gökyüzünde: alev topu + iz + çarpma efektleri (her şeyin üstünde) */
function drawMeteorSky() {
  const t = performance.now() / 1000;
  // önce duman/toz (arkada), sonra parlak öğeler
  for (const f of metFx) {
    const a = 1 - f.life / f.max;
    if (f.k === "smoke") {
      ctx.fillStyle = "rgba(70,58,54," + 0.28 * a + ")";
      ctx.beginPath();
      ctx.arc(f.x, f.y, f.r, 0, 7);
      ctx.fill();
    } else if (f.k === "dust") {
      ctx.fillStyle = "rgba(176,104,64," + 0.42 * a + ")";
      ctx.beginPath();
      ctx.arc(f.x, f.y, f.r, 0, 7);
      ctx.fill();
      ctx.fillStyle = "rgba(214,150,104," + 0.22 * a + ")";
      ctx.beginPath();
      ctx.arc(f.x - f.r * 0.25, f.y - f.r * 0.3, f.r * 0.6, 0, 7);
      ctx.fill();
    }
  }
  for (const f of metFx) {
    const a = 1 - f.life / f.max;
    if (f.k === "debris") {
      ctx.fillStyle = "rgba(0,0,0," + 0.3 * a + ")";
      ctx.beginPath();
      ctx.ellipse(f.x, f.y, f.s, f.s * 0.45, 0, 0, 7);
      ctx.fill();
      ctx.save();
      ctx.translate(f.x, f.y - f.z);
      ctx.rotate(f.rot);
      ctx.fillStyle = f.hot && f.life < 1.2 ? "#ff8a3c" : "#5a3a30";
      ctx.beginPath();
      ctx.moveTo(-f.s, -f.s * 0.4);
      ctx.lineTo(0, -f.s);
      ctx.lineTo(f.s, 0);
      ctx.lineTo(f.s * 0.3, f.s * 0.8);
      ctx.lineTo(-f.s * 0.8, f.s * 0.6);
      ctx.closePath();
      ctx.fill();
      if (f.hot && f.life < 1.2) {
        ctx.fillStyle = "rgba(255,220,140," + (0.8 - f.life * 0.6) + ")";
        ctx.fillRect(-f.s * 0.3, -f.s * 0.3, f.s * 0.6, f.s * 0.6);
      }
      ctx.restore();
    } else if (f.k === "spark") {
      ctx.strokeStyle = "rgba(255," + (180 + Math.round(70 * a)) + ",120," + a + ")";
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(f.x, f.y);
      ctx.lineTo(f.x - f.vx * 0.03, f.y - f.vy * 0.03);
      ctx.stroke();
    } else if (f.k === "shock") {
      const u = f.life / f.max,
        R = f.R * (1 - Math.pow(1 - u, 3));
      ctx.strokeStyle = "rgba(255,226,190," + 0.75 * (1 - u) + ")";
      ctx.lineWidth = 8 * (1 - u) + 1;
      ctx.beginPath();
      ctx.ellipse(f.x, f.y, R, R * 0.55, 0, 0, 7);
      ctx.stroke();
      ctx.strokeStyle = "rgba(200,120,70," + 0.45 * (1 - u) + ")";
      ctx.lineWidth = 16 * (1 - u);
      ctx.beginPath();
      ctx.ellipse(f.x, f.y, R * 0.8, R * 0.44, 0, 0, 7);
      ctx.stroke();
    } else if (f.k === "flash") {
      const u = f.life / f.max,
        g = ctx.createRadialGradient(f.x, f.y, 0, f.x, f.y, f.R * (1 + u));
      g.addColorStop(0, "rgba(255,255,240," + (1 - u) + ")");
      g.addColorStop(0.3, "rgba(255,200,110," + 0.8 * (1 - u) + ")");
      g.addColorStop(1, "rgba(255,120,40,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(f.x, f.y, f.R * (1 + u), 0, 7);
      ctx.fill();
    }
  }
  for (const m of ev.meteors) {
    const h = metHead(m),
      S = m.size,
      len = 180 + 260 * (1 - h.u) * 0 + 220 * S;
    // iyonize iz (konik)
    const tx = h.x - m.dx * len * 0.9,
      ty = h.y - len * 0.78; // iz: geldiği yöne doğru (arkada)
    const ang = Math.atan2(ty - h.y, tx - h.x),
      nx = -Math.sin(ang),
      ny = Math.cos(ang),
      w = 10 * S;
    const tg = ctx.createLinearGradient(h.x, h.y, tx, ty);
    tg.addColorStop(0, "rgba(255,236,190,.95)");
    tg.addColorStop(0.25, "rgba(255,150,60,.65)");
    tg.addColorStop(1, "rgba(255,90,30,0)");
    ctx.fillStyle = tg;
    ctx.beginPath();
    ctx.moveTo(h.x + nx * w, h.y + ny * w);
    ctx.lineTo(tx, ty);
    ctx.lineTo(h.x - nx * w, h.y - ny * w);
    ctx.closePath();
    ctx.fill();
    // plazma başı + korona
    const fl = 0.85 + 0.15 * Math.sin(t * 40 + m.seed);
    const R0 = 46 * S * fl;
    const cg = ctx.createRadialGradient(h.x, h.y, 0, h.x, h.y, R0);
    cg.addColorStop(0, "rgba(255,255,240,1)");
    cg.addColorStop(0.18, "rgba(255,236,170,.95)");
    cg.addColorStop(0.45, "rgba(255,140,50,.45)");
    cg.addColorStop(1, "rgba(255,80,20,0)");
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(h.x, h.y, R0, 0, 7);
    ctx.fill();
    // ön yüzde sıkışan şok parlaması (hareket yönünde basık)
    ctx.save();
    ctx.translate(h.x, h.y);
    ctx.rotate(Math.atan2(0.85, m.dx));
    ctx.fillStyle = "rgba(255,250,225,.95)";
    ctx.beginPath();
    ctx.ellipse(2, 0, 9 * S, 6 * S, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,1)";
    ctx.beginPath();
    ctx.ellipse(3, 0, 4.5 * S, 3.2 * S, 0, 0, 7);
    ctx.fill();
    ctx.restore();
  }
}

/* ============== METEOR SESLERİ ============== */
function _noiseSrc(dur, brown) {
  const ac = AU.ac,
    len = Math.max(1, Math.floor(ac.sampleRate * dur)),
    b = ac.createBuffer(1, len, ac.sampleRate),
    d = b.getChannelData(0);
  let l = 0;
  for (let i = 0; i < len; i++) {
    const w = Math.random() * 2 - 1;
    if (brown) {
      l = (l + 0.03 * w) / 1.03;
      d[i] = l * 3.2;
    } else d[i] = w;
  }
  const s = ac.createBufferSource();
  s.buffer = b;
  return s;
}
/* yaklaşan meteor: yükselen hava yırtılması + derin gürleme + atmosfer çıtırtısı */
function meteorWhoosh(dur) {
  if (!AU.ac || !AU.ready) return;
  try {
    const ac = AU.ac,
      t = ac.currentTime;
    const n = _noiseSrc(dur + 0.4, true),
      bp = ac.createBiquadFilter();
    bp.type = "bandpass";
    bp.Q.value = 1.1;
    bp.frequency.setValueAtTime(220, t);
    bp.frequency.exponentialRampToValueAtTime(1900, t + dur * 0.88);
    bp.frequency.exponentialRampToValueAtTime(500, t + dur + 0.2);
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.55, t + dur * 0.92);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.3);
    n.connect(bp);
    bp.connect(g);
    g.connect(AU.sfxG);
    n.start(t);
    n.stop(t + dur + 0.4);
    const o = ac.createOscillator();
    o.type = "sawtooth";
    o.frequency.setValueAtTime(36, t);
    o.frequency.linearRampToValueAtTime(62, t + dur);
    const lp = ac.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 140;
    const g2 = ac.createGain();
    g2.gain.setValueAtTime(0.0001, t);
    g2.gain.exponentialRampToValueAtTime(0.22, t + dur * 0.95);
    g2.gain.exponentialRampToValueAtTime(0.0001, t + dur + 0.12);
    o.connect(lp);
    lp.connect(g2);
    g2.connect(AU.sfxG);
    o.start(t);
    o.stop(t + dur + 0.2);
    for (let i = 0; i < 10; i++) {
      // plazma çıtırtısı
      const tt = t + dur * (0.35 + 0.6 * Math.random()),
        c = _noiseSrc(0.04, false),
        hp = ac.createBiquadFilter();
      hp.type = "highpass";
      hp.frequency.value = 3200;
      const cg = ac.createGain();
      cg.gain.setValueAtTime(0.0001, tt);
      cg.gain.exponentialRampToValueAtTime(0.08 + 0.06 * Math.random(), tt + 0.005);
      cg.gain.exponentialRampToValueAtTime(0.0001, tt + 0.04);
      c.connect(hp);
      hp.connect(cg);
      cg.connect(AU.sfxG);
      c.start(tt);
    }
  } catch (e) {}
}
/* çarpma: derin gümleme + patlama dalgası + düşen kaya pıtırtısı */
function meteorImpact(v, delay) {
  if (!AU.ac || !AU.ready) return;
  try {
    const ac = AU.ac,
      t = ac.currentTime + delay;
    const o = ac.createOscillator();
    o.type = "sine";
    o.frequency.setValueAtTime(95, t);
    o.frequency.exponentialRampToValueAtTime(26, t + 1.1);
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.95 * v, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.8);
    o.connect(g);
    g.connect(AU.sfxG);
    o.start(t);
    o.stop(t + 1.9);
    const n = _noiseSrc(2.2, true),
      lp = ac.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.setValueAtTime(2400, t);
    lp.frequency.exponentialRampToValueAtTime(140, t + 1.4);
    const ng = ac.createGain();
    ng.gain.setValueAtTime(0.0001, t);
    ng.gain.exponentialRampToValueAtTime(0.9 * v, t + 0.02);
    ng.gain.exponentialRampToValueAtTime(0.0001, t + 2.1);
    n.connect(lp);
    lp.connect(ng);
    ng.connect(AU.sfxG);
    n.start(t);
    n.stop(t + 2.2);
    const cr = _noiseSrc(0.12, false),
      hp = ac.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 1500; // ilk çatlama
    const cg = ac.createGain();
    cg.gain.setValueAtTime(0.5 * v, t);
    cg.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
    cr.connect(hp);
    hp.connect(cg);
    cg.connect(AU.sfxG);
    cr.start(t);
    for (let i = 0; i < 9; i++) {
      // geri düşen kaya parçaları
      const tt = t + 0.35 + Math.random() * 1.4,
        c = _noiseSrc(0.07, false),
        bp = ac.createBiquadFilter();
      bp.type = "bandpass";
      bp.frequency.value = 700 + Math.random() * 1600;
      bp.Q.value = 3;
      const pg = ac.createGain();
      pg.gain.setValueAtTime(0.0001, tt);
      pg.gain.exponentialRampToValueAtTime((0.12 + 0.12 * Math.random()) * v, tt + 0.006);
      pg.gain.exponentialRampToValueAtTime(0.0001, tt + 0.07);
      c.connect(bp);
      bp.connect(pg);
      pg.connect(AU.sfxG);
      c.start(tt);
    }
  } catch (e) {}
}

/* ============== MÜZİK — sakin, uzay temalı ambient ==============
   Am9 → Fmaj7 → Cmaj7 → G6 dizisi: yumuşak pad, derin bas, yankılı çan arpejleri. */
const MUS = {
  bpm: 64,
  bar: 0,
  arpSeed: 1,
  chords: [
    [45, 57, 60, 64, 71],
    [41, 53, 57, 60, 64],
    [36, 48, 52, 55, 59],
    [43, 50, 55, 59, 64],
  ],
};
const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);
function padNote(f, t, dur, vol) {
  const ac = AU.ac,
    flt = ac.createBiquadFilter(),
    g = ac.createGain();
  flt.type = "lowpass";
  flt.frequency.setValueAtTime(380, t);
  flt.frequency.linearRampToValueAtTime(950, t + dur * 0.5);
  flt.frequency.linearRampToValueAtTime(420, t + dur);
  flt.Q.value = 0.6;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(vol, t + 1.6);
  g.gain.setValueAtTime(vol, t + dur - 0.4);
  g.gain.linearRampToValueAtTime(0.0001, t + dur + 2.2);
  for (const det of [-7, 6]) {
    const o = ac.createOscillator();
    o.type = "sawtooth";
    o.frequency.value = f;
    o.detune.value = det;
    o.connect(flt);
    o.start(t);
    o.stop(t + dur + 2.4);
  }
  flt.connect(g);
  g.connect(AU.musicG);
}
function bellNote(f, t, vol) {
  const ac = AU.ac,
    g = ac.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 1.6);
  const o = ac.createOscillator();
  o.type = "sine";
  o.frequency.value = f;
  const o2 = ac.createOscillator();
  o2.type = "sine";
  o2.frequency.value = f * 2.76;
  const g2 = ac.createGain();
  g2.gain.setValueAtTime(vol * 0.35, t);
  g2.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
  o.connect(g);
  o2.connect(g2);
  g2.connect(g);
  g.connect(AU.bus);
  o.start(t);
  o2.start(t);
  o.stop(t + 1.7);
  o2.stop(t + 0.6);
}
function bassNote(f, t, dur, vol) {
  const ac = AU.ac,
    o = ac.createOscillator(),
    g = ac.createGain(),
    lp = ac.createBiquadFilter();
  o.type = "triangle";
  o.frequency.value = f;
  lp.type = "lowpass";
  lp.frequency.value = 260;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(vol, t + 0.25);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(lp);
  lp.connect(g);
  g.connect(AU.musicG);
  o.start(t);
  o.stop(t + dur + 0.1);
}
function scheduleMusic() {
  if (!AU.ready) return;
  if (mode === "intro") {
    AU.nextT = AU.ac.currentTime + 0.4;
    return;
  } // açılış sinemasının kendi müziği var
  const ac = AU.ac,
    beat = 60 / MUS.bpm,
    barLen = beat * 4;
  if (!MUS.init) {
    MUS.init = true;
    try {
      AU.delay.delayTime.value = beat * 0.75;
    } catch (e) {}
  }
  while (AU.nextT < ac.currentTime + 1.2) {
    const t = AU.nextT,
      ch = MUS.chords[Math.floor(MUS.bar / 2) % MUS.chords.length],
      first = MUS.bar % 2 === 0;
    if (first) for (let i = 1; i < ch.length - 1; i++) padNote(mtof(ch[i]), t, barLen * 2 - 0.2, 0.026);
    bassNote(mtof(ch[0]), t, barLen * 0.95, 0.14);
    if (!first) bassNote(mtof(ch[0] + 7), t + beat * 2, barLen * 0.45, 0.08);
    // arpej: her ölçüde değişen, seyrek çan notaları
    const pat = [
      [0, 2, 1, 3],
      [1, 3, 2, 4],
      [0, 2, 4, 3],
      [2, 1, 3, 0],
    ][Math.floor(MUS.bar / 4) % 4];
    for (let s = 0; s < 8; s++) {
      MUS.arpSeed = (MUS.arpSeed * 16807) % 2147483647;
      const r = MUS.arpSeed / 2147483647;
      if (r < (s % 2 ? 0.32 : 0.62)) {
        const n = ch[1 + (pat[s % 4] % (ch.length - 1))] + 12;
        bellNote(mtof(n), t + (s * beat) / 2, 0.045 + (s === 0 ? 0.02 : 0));
      }
    }
    if (MUS.bar % 8 === 7) bellNote(mtof(ch[ch.length - 1] + 24), t + beat * 3, 0.03); // yüksek parıltı
    AU.nextT += barLen;
    MUS.bar++;
  }
}

/* ============== REHBER KİTAP ============== */
let bookOpen = false,
  bookPages = [],
  bookSpread = 0,
  bookBusy = false;
function _ic(k, cls) {
  return `<img class="bk-ic ${cls || ""}" src="${itemIconURL(k)}" alt="">`;
}
function bookCalendar() {
  const d0 = gameDayNumber(),
    wt = game.worldTime || 0,
    inDay = wt % DAY_SECONDS;
  let rows = "";
  for (let d = d0; d < d0 + 10; d++) {
    const ev = [];
    if (d >= 3 && d % 3 === 0) ev.push(Tf(`<span class="ev rd">☢ Radyasyon · 00:00–01:30</span>`, []));
    if (isStormDay(d)) ev.push(Tf(`<span class="ev st">🌪 Kum fırtınası · 01:30–04:00</span>`, []));
    rows += Tf(`<tr class="{0}"><td>Gün {1}{2}</td><td>{3}</td></tr>`, [
      d === d0 ? "today" : "",
      d,
      d === d0 ? " ◀" : "",
      ev.join(" ") || T("<span class='ev ok'>Sakin</span>"),
    ]);
  }
  const ns = nextStormIn(),
    nsd = isFinite(ns) ? Math.floor((wt + ns) / DAY_SECONDS) + 1 : "–";
  return { rows, nsd, left: mmss(DAY_SECONDS - inDay) };
}
function buildBookPages() {
  const cal = bookCalendar();
  const P = [];
  P.push(
    Tf(
      `<div class="pg-cover"><div class="emb"><span>ARES-1</span><i></i></div>
    <h1>SAHA REHBERİ</h1><div class="sub">Mars Yüzey Operasyonları El Kitabı</div>
    <p class="c">Bu kitap çantanda hep durur. <kbd>R</kbd> ile aç / kapat.</p>
    <p class="c sm">Sayfa çevirmek için ◀ ▶ düğmeleri ya da klavyede <kbd>←</kbd> <kbd>→</kbd>.</p>
    <p class="c sm">Kitap açıkken oyun zamanı durur.</p>
    <div class="sig">— ARES-1 Görev Kontrol</div></div>`,
      [],
    ),
  );
  const toc = [
    [T("İlk adımlar ve kontroller"), 2],
    [T("Oksijen"), 3],
    [T("Yemek ve su"), 4],
    [T("Roketin içi"), 5],
    [T("Tarım"), 6],
    [T("Numuneler ve kargo"), 7],
    [T("⚠ Kum fırtınası"), 8],
    [T("⚠ Radyasyon dalgası"), 10],
    [T("⚠ Meteor yağmuru"), 11],
    [T("Motor onarımı"), 12],
    [T("Uyku ve zaman"), 13],
    [T("Felaket takvimi"), 14],
    [T("Dünya ile iletişim"), 15],
    [T("Kıyafet & roket geliştirme"), 16],
    [T("Acil durum listesi"), 17],
    [T("Görev mimarisi"), 18],
  ];
  P.push(
    Tf(
      `<h2>İçindekiler</h2><ol class="toc">{0}</ol>
    <div class="note">İpucu: bir başlığa tıklarsan o sayfaya gidersin.</div>`,
      [
        toc
          .map(
            ([n, pg], i) =>
              `<li><a data-go="${pg}"><span>${i + 1}. ${n}</span><em></em><b>${pg + 1}</b></a></li>`,
          )
          .join(""),
      ],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 1</small>İlk adımlar</h2>
    <table class="keys"><tr><td><kbd>W A S D</kbd></td><td>Yürü · <kbd>Shift</kbd> koş</td></tr>
    <tr><td><kbd>1</kbd>…<kbd>7</kbd></td><td>Eşyayı eline al · aynı tuşa tekrar bas = kullan</td></tr>
    <tr><td><kbd>F</kbd></td><td>Topla · elindekiyle ek, sula, iç, ye</td></tr>
    <tr><td><kbd>E</kbd></td><td>Rokete gir · istasyonu kullan</td></tr>
    <tr><td><kbd>G</kbd></td><td>Medikit kullan</td></tr>
    <tr><td>Sol tık</td><td>Çapa elindeyken yeri kaz</td></tr>
    <tr><td><kbd>R</kbd></td><td>Bu rehberi aç</td></tr></table>
    <div class="tip"><b>Altın kural:</b> sadece <u>elindeki</u> eşyayı kullanırsın. Çapa elindeyken su içemezsin; önce suyu eline al.</div>
    <p>Sol üstte <b>gün ve saat</b>, altında <b>görev kartı</b> var. Görev kartındaki 💡 satırı ne yapacağını adım adım söyler.</p>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 2</small>Oksijen {0}</h2>
    <p>Mars'ın havası solunamaz. Giysindeki oksijen dışarıda yaklaşık <b>3,5 dakikada</b> biter. Koşarken %35, fırtınada %25 daha hızlı azalır.</p>
    <ul><li><b>%30</b>'da uyarı alırsın, <b>%10</b>'da alarm çalar.</li>
    <li><b>%0</b>'da her saniye ~5 can kaybedersin, ekran kararır.</li>
    <li>Roketin içinde oksijen azalmaz.</li></ul>
    <div class="tip"><b>Doldurma:</b> rokete gir → makine dairesi → <b>O₂ tüpleri</b> → <kbd>E</kbd>. Hortum sırt çantana bağlanır ve giysi dolar.</div>
    <p>Tüplerin de bir kapasitesi var. Boşalırsa oksijen jeneratörü onları yavaşça yeniden doldurur; tüp göstergesini takip et.</p>`,
      [_ic("o2", "r")],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 3</small>Yemek ve su {0}</h2>
    <p><b>Su</b> yaklaşık 4, <b>tokluk</b> yaklaşık 5,5 dakikada biter. Biri sıfırlanırsa saniyede 4 can gider.</p>
    <ul><li>{1} <b>Su şişesi:</b> +35 su. Eline al ve <kbd>F</kbd>'ye bas.</li>
    <li>{2} <b>Patates:</b> +35 tokluk. Eline al ve <kbd>F</kbd>'ye bas.</li></ul>
    <div class="tip"><b>Mutfak:</b> yaşam güvertesindeki mutfakta <kbd>E</kbd> → envanteri açılır. Oradan çantana alabilir ya da hemen içip yiyebilirsin.</div>
    <p>Su stoku sınırlıdır ama <b>su geri dönüştürücü</b> her 2,5 dakikada 1 şişe üretir. Patatesi ise tarlada sen yetiştirirsin.</p>`,
      [_ic("water", "r"), _ic("water", "i"), _ic("potato", "i")],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 4</small>Roketin içi</h2>
    <p>Roket 3 katlıdır. Merdivenin yanında <kbd>W</kbd>/<kbd>S</kbd> ile kat değiştirirsin.</p>
    <div class="deck"><b>3 · Komuta güvertesi</b><span>Navigasyon (kalkış) · Kargo terminali</span></div>
    <div class="deck"><b>2 · Yaşam güvertesi</b><span>Uyku kabini · Mutfak · Revir · Yemek kapsülü</span></div>
    <div class="deck"><b>1 · Makine dairesi</b><span>Hava kilidi (çıkış) · Alet sandığı · O₂ tüpleri · Ana motor · Tamir tezgâhı</span></div>
    <div class="tip">Roketin gövdesi seni <b>radyasyondan, fırtınadan ve meteorlardan</b> korur. Bir felaket yaklaşırken en güvenli yer burasıdır.</div>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 5</small>Tarım {0}</h2>
    <ol><li>Alet sandığından {1} <b>çapayı</b> al. Çapayı eline al ve yere <b>sol tıkla</b>.</li>
    <li>{2} <b>Tohumu</b> eline al, çukurun yanında <kbd>F</kbd>.</li>
    <li>{3} <b>Suyu</b> eline al, <kbd>F</kbd> ile sula. Islak toprak bitkiyi 2,4 kat hızlı büyütür.</li>
    <li>Halka <b>sarı</b> olunca <kbd>F</kbd> ile hasat et: 1–2 patates + 1 tohumluk patates. Çürük hasattan tohum çıkmaz.</li></ol>
    <p>Büyümesi sulamadan yaklaşık 75 saniye sürer. Bitki aşamaları: filiz → fide → çiçekli bitki → hasat.</p>
    <div class="warn">Kum fırtınasında bitkiler sallanır ama zarar görmez. Parselleri roketin yakınına aç ki fırtınada kaybolmayasın.</div>`,
      [_ic("seed", "r"), _ic("kit", "i"), _ic("seed", "i"), _ic("water", "i")],
    ) +
      T(
        `<div class="warn"><b>Seramik kalkan:</b> Radyasyon dalgasında açıkta kalan bitkiler büyümesini kaybeder. Alet sandığındaki kalkanı eline al, parselin yanında <kbd>F</kbd> ile kur. <kbd>Q</kbd> kanatları açar/kapatır: kapalıyken bitki korunur ama sulayamaz, hasat edemezsin. Kalkan parselde kalır; boş parselden <kbd>Shift+Q</kbd> ile sökülür.</div>`,
      ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 6</small>Numuneler ve kargo {0}</h2>
    <p>Görevin bilimsel amacı Mars numunelerini Dünya'ya götürmek.</p>
    <ul><li>{1} <b>Metal numune</b> = 1 puan. Haritada ◆ olarak görünür.</li>
    <li>{2} <b>Yıldız kristali</b> = 2 puan. Meteor çarpınca kraterde kalabilir.</li></ul>
    <div class="tip">Roketin yanında <kbd>F</kbd> ya da komuta güvertesindeki <b>kargo terminali</b> ile kargoya yükle. Hedef: <b>10 numune</b>.</div>
    <p>Çantana en fazla {3} metal numune sığar. Dolunca rokete dönüp boşalt.</p>`,
      [_ic("stone", "r"), _ic("stone", "i"), _ic("star", "i"), stoneCap()],
    ),
  );
  P.push(
    Tf(
      `<h2 class="danger"><small>Bölüm 7 · Felaket</small>🌪 Kum fırtınası (1/2)</h2>
    <p><b>Ne zaman?</b> İlki <b>2. gün</b> gelir, sonra <b>her 5 günde bir</b> tekrarlar (7, 12, 17…). Günün 01:30'unda başlar, <b>2,5 dakika</b> sürer.</p>
    <p><b>Uyarı:</b> başlamadan <b>45 saniye</b> önce turuncu bir kart çıkar ve geri sayar.</p>
    <p><b>Neler olur?</b></p>
    <ul><li>Görüş birkaç metreye düşer, gökyüzü kararır.</li>
    <li>Rüzgâr (130 km/s'ye kadar) seni savurur, rüzgâra karşı yürümek zorlaşır.</li>
    <li>Harita sinyali kaybolur: "SİNYAL ZAYIF".</li>
    <li>Oksijen %25 daha hızlı tükenir.</li>
    <li>Ani esintiler ekranı sarsar.</li></ul>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2 class="danger"><small>Bölüm 7 · Felaket</small>🌪 Kum fırtınası (2/2)</h2>
    <div class="warn"><b>İLK FIRTINA ROKETİ VURUR!</b> 2. gündeki fırtına zirvedeyken sert bir esinti roketi savurur ve <b>ana motor bozulur</b>. Motordan duman yükselir, kalkış kilitlenir.</div>
    <p><b>Ne yapmalı?</b></p>
    <ol><li>Uyarı kartını görünce işini bırak, <b>rokete dön</b>.</li>
    <li>Fırtına bitene kadar içeride kal. Bu arada ye, iç, oksijen doldur.</li>
    <li>Dışarıda yakalanırsan haritadaki roket okunu takip et.</li>
    <li>Fırtına bitince motoru onar (Bölüm 10).</li></ol>
    <p class="sm">Sonraki fırtınalarda motor <b>%60</b> olasılıkla yeniden bozulabilir; fırtına kalkanı bu riski azaltır (Bölüm 14).</p>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2 class="danger"><small>Bölüm 8 · Felaket</small>☢ Radyasyon dalgası</h2>
    <p><b>Ne zaman?</b> Güneş patlaması <b>3. günden itibaren her 3 günde bir</b> (3, 6, 9…), günün en başında (00:00) gelir ve <b>1,5 dakika</b> sürer.</p>
    <p><b>Uyarı:</b> önceki günün bitmesine <b>40 saniye</b> kala yeşil kart çıkar.</p>
    <ul><li>Dışarıdaysan ekran <b>yeşile</b> döner ve saniyede ~3 can kaybedersin — standart giysiyle 30 saniyede ölürsün! Kalkan Mk-III ve ARES Elite setleri hasarı büyük ölçüde azaltır.</li>
    <li>Başının üstünde "☢" hasar yazıları belirir.</li>
    <li>Dalganın tamamını dışarıda geçirmek kesin ölümdür!</li></ul>
    <div class="tip"><b>Korunma:</b> rokete gir. Gövde zırhı radyasyonu tamamen keser, içeride can kaybetmezsin. En iyi taktik: dalga gecesinde roketin <b>uyku kabininde</b> uyumak.</div>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2 class="danger"><small>Bölüm 9 · Felaket</small>☄ Meteor yağmuru</h2>
    <p>Meteorlar <b>uyarı vermeden</b>, rastgele zamanlarda 1–3 tane düşer. Kum fırtınası sırasında düşmez.</p>
    <p><b>Belirtiler:</b> önce yükselen bir uğultu duyulur. Gökyüzünde iz bırakan bir ateş topu belirir ve yerde <b>büyüyen bir gölge</b> oluşur. Gölge çarpma noktasıdır!</p>
    <ul><li>Çarpma yarıçapı ~9 m, hasar <b>26 can</b>.</li>
    <li>Çarpma kalıcı bir krater bırakır. Krater bir süre sıcak kalır ve tüter.</li></ul>
    <div class="tip"><b>Fırsat:</b> kraterlerde sık sık {0} <b>yıldız kristali</b> ya da metal numune kalır. Gölgeden uzaklaş, çarpmadan sonra topla.</div>`,
      [_ic("star", "i")],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 10</small>Motor onarımı 🔧</h2>
    <p>Makine dairesinde <b>ANA MOTOR</b> → <kbd>E</kbd>. Onarım 4 aşamadır; tamamladığın aşamalar kaydedilir.</p>
    <ol><li><b>Kablolar:</b> renkli kabloları aynı renkteki sokete sürükle.</li>
    <li><b>Sigortalar:</b> kararmış sigortalara tıkla, sonra ana şalteri kaldır. Sağlamlara dokunma!</li>
    <li><b>Basınç:</b> ibre yeşil bölgedeyken KİLİTLE ya da <kbd>Space</kbd>. 3 kez başarman gerekir.</li>
    <li><b>Ateşleme:</b> ışık dizisini izle, aynı sırayla bas.</li></ol>
    <div class="tip">Onarım bitince kalkış kilidi açılır ve görevler seni Dünya'ya yönlendirir.</div>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 11</small>Uyku ve zaman</h2>
    <p>Mars'ta <b>1 gün = 6 dakika</b>. Sol üstteki çubuk günün ilerleyişini, turuncu çizgiler olayları gösterir.</p>
    <ul><li>Uyku kabininde uyursan <b>zaman 2 kat hızlanır</b>, can hızla yenilenir.</li>
    <li>Sabah olunca kendiliğinden uyanırsın. Aç ya da susuz kalırsan erken uyanırsın.</li>
    <li>Uyurken mahsul de 2 kat hızlı büyür.</li></ul>
    <div class="tip">Radyasyon gecesinde ya da uzun bir fırtınada uyumak, tehlikeyi güvenle atlatmanın en kolay yolu.</div>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 12</small>Felaket takvimi</h2>
    <p class="sm">Bugün: <b>Gün {0}</b> · gün bitimine <b>{1}</b> · sonraki fırtına <b>Gün {2}</b></p>
    <table class="cal">{3}</table>
    <p class="sm">Meteorlar takvime girmez: her an düşebilir.</p>`,
      [gameDayNumber(), cal.left, cal.nsd, cal.rows],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 13</small>Dünya ile iletişim 📡</h2>
    <p>Görevin asıl amacı: Mars'ta yaşadıklarını ve topladığın bilgileri <b>Dünya'ya aktarmak</b>. Komuta güvertesinin solundaki <b>İLETİŞİM</b> masasına <kbd>E</kbd>.</p>
    <ul><li><b>Saha günlüğü</b> fırtına, radyasyon, meteor, arıza, numune, tarım ve kritik değerleri <b>otomatik</b> kaydeder.</li>
    <li>Kayıtları seç, kendi notunu yaz (sorunlarını, sorularını), öncelik belirle ve gönder.</li>
    <li>Görev Kontrol <b>~½ sol</b> sonra (ACİL: ~¼ sol) resmî bir yanıt yollar: analiz, talimatlar ve 5 sollük tahmin.</li>
    <li>Kum fırtınası sırasında anten tozla kapanır, <b>gönderim yapılamaz</b>.</li>
    <li><b>🛰️ Yer Birimi</b> sekmesi, raporlarını alan yer istasyonlarını ve görev kontrol merkezlerini gösterir.</li></ul>
    <div class="tip">Görev Kontrol bazen kendiliğinden yazar: hava bültenleri, telemetri uyarıları, rapor talepleri. Sağ üstteki rozet yeni mesajı gösterir.</div>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 14</small>Kıyafet & roket geliştirme 🧬</h2>
    <p>Yaşam güvertesindeki <b>Fabrikasyon Atölyesi</b> <kbd>E</kbd> ile açılır.</p>
    <ul><li><b>Kıyafet setleri</b> (Kaşif → Öncü → Kalkan → ARES Elite) metal numune, yıldız kristali ve nadir taşlarla sırayla üretilir. Her set oksijen tüketimini, yürüme hızını, radyasyon ve fırtına korumasını artırır.</li>
    <li><b>Roket geliştirme</b> meteor kraterlerinin çevresine saçılan <b>altın parçaları</b> ve titanyum cevheriyle yapılır. Fırtına kalkanı 3 seviyedir; son seviyede fırtına motoru bozamaz.</li>
    <li>İlk fırtınadan sonraki her fırtınada motor <b>%60</b> olasılıkla bozulur — kalkan bunu azaltır.</li>
    <li>Altınla rokete yeni boyalar da alabilirsin.</li></ul>
    <div class="tip">Meteor düştükten sonra krater çevresini tara: parıldayan sarı parçalar altındır. Uzak bölgelerde tarayıcının bip sesini takip et: <b>bilinmeyen taşlar</b> (titanyum, olivin, Ares taşı) üst seviye geliştirmeler için şart — çıkarmak için saha kiti gerekir.</div>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 15</small>Acil durum listesi</h2>
    <table class="emg"><tr><td>🫁 Oksijen &lt; %30</td><td>Rokete dön → O₂ tüpleri</td></tr>
    <tr><td>❤ Can düşük</td><td>Medikit (<kbd>G</kbd>), revir ya da uyku</td></tr>
    <tr><td>💧 / 🍽 bitti</td><td>Mutfak ya da yemek kapsülü</td></tr>
    <tr><td>🌪 Turuncu kart</td><td>45 sn içinde rokete gir</td></tr>
    <tr><td>☢ Yeşil kart</td><td>Rokete gir, mümkünse uyu</td></tr>
    <tr><td>☄ Uğultu + gölge</td><td>Gölgeden uzaklaş</td></tr>
    <tr><td>💨 Motordan duman</td><td>Ana motoru onar</td></tr></table>
    <h3>Eve dönüş</h3><p>Sol üstteki görev kartını takip et: numune → kit → tarım → ilk rapor → fırtına → motor onarımı → radyasyon → hasat → Dünya'nın yanıtı → altın → nadir taş → yeni kıyafet → kargo (10). Sonra komuta güvertesinde <b>NAVİGASYON</b> → <b>EVE DÖN</b>.</p>`,
      [],
    ),
  );
  P.push(
    Tf(
      `<h2><small>Bölüm 16</small>Görev mimarisi 📐</h2>
    <p>ARES-1 bir uzay görevinin tüm parçalarıyla tasarlandı. İletişim terminalindeki <b>📐 Görev Mimarisi</b> sekmesi bunları canlı gösterir.</p>
    <ul><li><b>Görev segmentleri:</b> fırlatma, uzay, yer ve kullanıcı segmentleri birlikte çalışır.</li>
    <li><b>Kavram olgunluğu:</b> görev bir fikirle başlar; fizibilite analizi ve ödünleşim çalışmalarından geçerek nokta tasarıma ulaşır.</li>
    <li><b>Alt sistemler:</b> itki, yaşam desteği, ısıl koruma, yapı ve iletişim ayrı ayrı izlenir.</li></ul>
    <div class="tip">ARES-1 kurgusal bir görevdir; oyundaki sayılar oyun için basitleştirilmiştir.</div>`,
      [],
    ),
  );

  return P;
}
/* sayfa içeriği taşarsa (uzun dillerde) içeriği orantılı küçült */
function fitPages(root) {
  (root || $("bookPages")).querySelectorAll(".pg-in").forEach((el) => {
    el.style.transform = "";
    el.style.width = "";
    el.style.height = "";
    const H = el.clientHeight;
    if (!H) return;
    const pb = parseFloat(getComputedStyle(el).paddingBottom) || 0;
    const over = () => {
      let b = 0;
      for (const c of el.children) b = Math.max(b, c.offsetTop + c.offsetHeight);
      return b > el.clientHeight - pb - 16;
    };
    let sc = 1;
    for (let k = 0; k < 14 && over(); k++) {
      sc -= 0.035;
      el.style.transformOrigin = "0 0";
      el.style.transform = `scale(${sc})`;
      el.style.width = `${100 / sc}%`;
      el.style.height = `${100 / sc}%`;
    }
  });
}
function pageHTML(i) {
  if (i < 0 || i >= bookPages.length) return `<div class="pg-end">✦</div>`;
  return `<div class="pg-in">${bookPages[i]}</div>${i > 0 ? `<div class="pg-num">${i + 1}</div>` : ""}`;
}
function renderSpread() {
  $("pgL").innerHTML = pageHTML(bookSpread * 2);
  $("pgR").innerHTML = pageHTML(bookSpread * 2 + 1);
  const last = Math.ceil(bookPages.length / 2) - 1;
  $("bkPrev").disabled = bookSpread <= 0;
  $("bkNext").disabled = bookSpread >= last;
  $("bkInd").textContent =
    bookSpread * 2 + 1 + "–" + Math.min(bookPages.length, bookSpread * 2 + 2) + " / " + bookPages.length;
  document
    .querySelectorAll("#bookScreen [data-go]")
    .forEach((a) => (a.onclick = () => bookGoto(+a.dataset.go)));
  fitPages();
}
function flipSound() {
  noiseBurst(0.22, 0.13, 2600);
  setTimeout(() => noiseBurst(0.08, 0.07, 1800), 120);
}
function openBook() {
  if (mode !== "play" || !game) return;
  bookOpen = true;
  bookPages = buildBookPages();
  bookBusy = false;
  for (const k in keys) keys[k] = false;
  renderSpread();
  $("bookScreen").classList.remove("hidden");
  $("ui").classList.add("book-open");
  layoutBook();
  fitPages();
  flipSound();
}
/* kitabı görev kartının altı ile oksijen barının üstü arasındaki boşluğa yerleştir;
   boşluk dar ise kitap açıkken görev kartı gizlenir ve kitap gün kartının altına oturur */
function layoutBook() {
  const S = $("bookScreen"),
    wrap = S.querySelector(".bk-wrap"),
    bk = S.querySelector(".book");
  const q = $("quest"),
    st = $("stats");
  $("ui").classList.remove("book-noquest");
  const statsTop =
    (st && !st.classList.contains("hidden") ? st.getBoundingClientRect().top : innerHeight) - 24;
  const fit = (topEl) => {
    const top = topEl.getBoundingClientRect().bottom + 22,
      h = statsTop - top;
    return { top, h };
  };
  let L = q && !q.classList.contains("hidden") ? fit(q) : fit($("hud"));
  if (L.h < 330 && q && !q.classList.contains("hidden")) {
    $("ui").classList.add("book-noquest");
    L = fit($("hud"));
  }
  if (L.h < 200) {
    S.style.top = "50%";
    S.style.transform = "translateY(-50%)";
    wrap.style.width = "";
    bk.style.height = "";
    return;
  }
  const w = Math.min(640, innerWidth * 0.5, L.h * 1.5),
    h = Math.min(L.h, w / 1.42);
  S.style.top = L.top + "px";
  S.style.transform = "none";
  wrap.style.width = w + "px";
  bk.style.height = h + "px";
}
addEventListener("resize", () => {
  if (bookOpen) {
    layoutBook();
    fitPages();
  }
});
function closeBook() {
  bookOpen = false;
  $("bookScreen").classList.add("hidden");
  $("ui").classList.remove("book-open", "book-noquest");
  $("bookPages")
    .querySelectorAll(".flip")
    .forEach((f) => f.remove());
  bookBusy = false;
  focusGame();
}
function bookFlip(dir, target) {
  const last = Math.ceil(bookPages.length / 2) - 1,
    s = bookSpread,
    t = target == null ? s + dir : target;
  if (bookBusy || t < 0 || t > last || t === s) return;
  bookBusy = true;
  flipSound();
  const fl = document.createElement("div");
  if (t > s) {
    fl.className = "flip r";
    fl.innerHTML = `<div class="face front page right">${pageHTML(2 * s + 1)}</div><div class="face back page left">${pageHTML(2 * t)}</div>`;
    $("pgR").innerHTML = pageHTML(2 * t + 1);
  } else {
    fl.className = "flip l";
    fl.innerHTML = `<div class="face front page left">${pageHTML(2 * s)}</div><div class="face back page right">${pageHTML(2 * t + 1)}</div>`;
    $("pgL").innerHTML = pageHTML(2 * t);
  }
  $("bookPages").appendChild(fl);
  fitPages();
  requestAnimationFrame(() =>
    requestAnimationFrame(() => {
      fl.classList.add("go");
    }),
  );
  setTimeout(() => {
    bookSpread = t;
    renderSpread();
    fl.remove();
    bookBusy = false;
  }, 760);
}
function bookGoto(page) {
  bookFlip(0, Math.floor(page / 2));
}
$("bkPrev").onclick = () => bookFlip(-1);
$("bkNext").onclick = () => bookFlip(1);
$("bkX").onclick = closeBook;
$("bookPages").addEventListener("click", (e) => {
  if (e.target.closest("a,button")) return;
  const r = $("bookPages").getBoundingClientRect();
  if (e.clientX > r.left + r.width * 0.82) bookFlip(1);
  else if (e.clientX < r.left + r.width * 0.18) bookFlip(-1);
});

/* ============== DÜNYA İLETİŞİM SİSTEMİ ==============
   Komuta güvertesindeki iletişim terminali. Oyunda yaşanan olaylar (fırtına,
   radyasyon, meteor, arıza, numune, tarım, yaşam destek uyarıları) otomatik
   olarak SAHA GÜNLÜĞÜ'ne kaydedilir. Oyuncu bunları + kendi notunu rapor olarak
   Dünya'ya gönderir; Görev Kontrol ~½ sol sonra (ACİL: ~¼ sol) resmî bir yanıt
   yollar. Yanıtlar rapor içeriğine, nota ve o anki araç durumuna göre üretilir. */
const GAME_MIN = (24 * 60) / DAY_SECONDS; // 1 oyun saniyesi = 2,4 Mars dakikası
const SCI_GOAL = 220;
const SIG = {
  fd: ["Elif Arslan", T("Uçuş Direktörü")],
  capcom: ["Kerem Aydın", T("Mürettebat İletişim Sorumlusu")],
  prop: ["Müh. Barış Tunç", T("İtki Sistemleri Şefi")],
  wx: ["Dr. Selin Kaya", T("Uzay Hava Durumu Birimi")],
  sci: ["Prof. Deniz Yalın", T("Gezegen Bilimi Ekibi Lideri")],
  bio: ["Dr. Mert Oral", T("Biyorejeneratif Yaşam Destek")],
  med: ["Dr. Ayşe Demir", T("Uçuş Cerrahı")],
  psy: ["Dr. Nil Erden", T("Davranış Sağlığı Uzmanı")],
  log: ["Ece Korkmaz", T("Lojistik ve Kargo Planlama")],
  ai: ["GDY-1", T("Görev Destek Yapay Zekâsı")],
};
const OBS_DEF = {
  storm: { ic: "🌪", nm: T("Kum fırtınası"), cat: T("Uzay hava durumu"), w: 16, sev: "warn" },
  engine_fail: { ic: "💥", nm: T("Ana motor arızası"), cat: T("Araç sistemleri"), w: 14, sev: "crit" },
  engine_fix: { ic: "🔧", nm: T("Motor onarımı"), cat: T("Araç sistemleri"), w: 10, sev: "ok" },
  radiation: { ic: "☢️", nm: T("Radyasyon dalgası"), cat: T("Uzay hava durumu"), w: 15, sev: "warn" },
  meteor: { ic: "☄️", nm: T("Meteor düşüşü"), cat: T("Gezegen bilimi"), w: 12, sev: "warn" },
  geo: { ic: "🪨", nm: T("Jeolojik numune"), cat: T("Gezegen bilimi"), w: 7, sev: "info" },
  agri: { ic: "🌱", nm: T("Tarım deneyi"), cat: T("Yaşam bilimi"), w: 9, sev: "info" },
  cargo: { ic: "📦", nm: T("Kargo yüklemesi"), cat: T("Lojistik"), w: 4, sev: "info" },
  life: { ic: "🫁", nm: T("Yaşam destek uyarısı"), cat: T("Mürettebat sağlığı"), w: 8, sev: "crit" },
  rare: { ic: "💎", nm: T("Nadir mineral"), cat: T("Gezegen bilimi"), w: 18, sev: "ok" },
  rot: { ic: "🥀", nm: T("Çürüyen hasat"), cat: T("Yaşam bilimi"), w: 14, sev: "warn" },
};
const SEV_BADGE = {
  crit: ["err", T("KRİTİK")],
  warn: ["warn", T("ÖNEMLİ")],
  ok: ["ok", T("OLUMLU")],
  info: ["mute", T("RUTİN")],
};
const LIFE_NM = { o2: T("Oksijen"), thirst: T("Su"), hunger: T("Tokluk"), hp: T("Can"), food: T("Erzak") };

let commOpen = false,
  commTab = "write",
  commSel = null,
  commTx = null,
  commTick = 0;
const commDraft = { note: "", prio: "rutin", off: new Set() };

function commState() {
  if (!game.comms)
    game.comms = {
      log: [],
      sent: [],
      inbox: [],
      seq: { obs: 1, rpr: 1, msg: 1 },
      sci: 0,
      trk: { st: null, rd: null, crit: {} },
      flags: {},
      lastBull: 0,
      lastRpt: 0,
    };
  const C = game.comms;
  C.trk = C.trk || { st: null, rd: null, crit: {} };
  C.trk.crit = C.trk.crit || {};
  C.flags = C.flags || {};
  return C;
}
/* ---------- yardımcılar ---------- */
function rngSeed(seed) {
  let s = seed >>> 0 || 7;
  return () => {
    s ^= s << 13;
    s >>>= 0;
    s ^= s >>> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 4294967296;
  };
}
function hashStr(str) {
  let h = 2166136261;
  for (const c of String(str)) {
    h ^= c.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function escH(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
}
const solOf = (wt) => Math.floor(Math.max(0, wt) / DAY_SECONDS) + 1;
function marsClock(wt) {
  const inDay = ((wt % DAY_SECONDS) + DAY_SECONDS) % DAY_SECONDS,
    mh = (6 + (inDay / DAY_SECONDS) * 24) % 24,
    hh = Math.floor(mh),
    mm = Math.floor((mh - hh) * 60);
  return String(hh).padStart(2, "0") + ":" + String(mm).padStart(2, "0");
}
const solStamp = (wt) => "Sol " + solOf(wt) + " · " + marsClock(wt);
function gDur(gs) {
  const m = Math.max(1, Math.round(gs * GAME_MIN));
  return m >= 60 ? Math.floor(m / 60) + T(" sa ") + (m % 60 ? (m % 60) + T(" dk") : "") : m + T(" dk");
}
const isRadDay = (d) => d >= 3 && d % 3 === 0;
function lightDelay(wt) {
  return 12.6 + 8.1 * Math.sin(solOf(wt) * 0.21 + 0.6);
} // dakika (Mars–Dünya mesafesine göre)
function dsnStation(wt) {
  const h = +marsClock(wt).slice(0, 2);
  return GS_STATIONS[Math.floor(h / 8) % 3].nm;
}
const fmtN = (n, d = 1) =>
  Number(n).toLocaleString(LOCALE, { minimumFractionDigits: d, maximumFractionDigits: d });
const pad3 = (n) => String(n).padStart(3, "0");
function commUnread() {
  return game && game.comms ? game.comms.inbox.filter((m) => !m.read).length : 0;
}
function commPending() {
  return game && game.comms ? game.comms.sent.filter((r) => !r.replied) : [];
}
function commUnsent() {
  return game && game.comms ? game.comms.log.filter((o) => !o.sent) : [];
}

/* ---------- saha günlüğü ---------- */
function obsDetail(o) {
  const d = o.d || {};
  switch (o.type) {
    case "storm":
      return (
        Tf(`{0}. solda ~{1} süren yerel toz fırtınası. Görüş sıfıra yakın, gövde sarsıntısı yüksek. `, [
          o.day,
          gDur(STORM_DUR),
        ]) +
        (d.out > 2
          ? Tf(`Fırtına sırasında araç dışında {0} geçirildi. `, [gDur(d.out)])
          : Tf(`Mürettebat fırtına boyunca araç içinde kaldı. `, [])) +
        (d.broke ? T("Fırtına ana motoru devre dışı bıraktı.") : T("Araçta yeni hasar gözlenmedi."))
      );
    case "engine_fail":
      return Tf(
        `{0}. solda fırtına esnasında itki çekirdeğinde arıza. Makine dairesinde yoğun duman, kalkış kilitli.`,
        [o.day],
      );
    case "engine_fix":
      return Tf(
        `Ana motor 4 aşamalı prosedürle onarıldı (kablolar, sigortalar, basınç, ateşleme). Sistem çevrimiçi.`,
        [],
      );
    case "radiation":
      return (
        Tf(`Güneş kaynaklı parçacık dalgası (~{0}). `, [gDur(RADIATION_DURATION)]) +
        (d.out > 1
          ? Tf(`Dışarıda {0} maruz kalındı, ~{1} can kaybı.`, [gDur(d.out), Math.round(d.dmg || 0)])
          : T("Mürettebat zırhlı gövdede korundu, doz alınmadı."))
      );
    case "meteor":
      return (
        Tf(`{0} meteor çarpması gözlendi`, [d.n || 1]) +
        (d.near != null ? Tf(`, en yakını ~{0} m mesafede.`, [Math.round(d.near / 8)]) : ".") +
        T(" Taze kraterler oluştu.")
      );
    case "geo":
      return Tf(`{0} metal{1} numunesi toplandı.`, [
        d.metal || 0,
        d.star ? Tf(` ve {0} yıldız kristali`, [d.star]) : "",
      ]);
    case "agri":
      return (
        [d.p ? d.p + T(" parsele tohum ekildi") : "", d.h ? d.h + T(" hasat alındı") : ""]
          .filter(Boolean)
          .join(", ") + "."
      );
    case "cargo":
      return Tf(`Kargo bölmesine {0} birim numune yüklendi (toplam {1}/{2}).`, [
        d.pts || 0,
        Math.min(d.tot || 0, CFG.cargoGoal),
        CFG.cargoGoal,
      ]);
    case "rare":
      return (
        Object.keys(d)
          .filter((k) => RARE_DEF[k])
          .map((k) => d[k] + " " + RARE_DEF[k].name)
          .join(", ") + T(" çıkarıldı ve analiz edildi.")
      );
    case "rot":
      return Tf(
        `{0} parselden alınan patates yumruları kararmış ve yumuşamış halde çıktı. Yapraklar hasattan önce solmuştu. Nedeni bilinmiyor.`,
        [d.n || 1],
      );
    case "life":
      return (
        T("Kritik değerler: ") +
        Object.keys(d.f || {})
          .map((k) => (k === "food" ? T("erzak tükendi") : LIFE_NM[k] + " %" + Math.round(d.f[k])))
          .join(", ") +
        "."
      );
  }
  return "";
}
function commsObs(type, data) {
  if (!game || scene === "earth") return;
  const C = commState(),
    day = gameDayNumber();
  let o = C.log.find((x) => !x.sent && x.type === type && x.day === day);
  if (o) {
    const d = o.d;
    for (const k in data) {
      const v = data[k];
      if (k === "near") d.near = d.near == null ? v : Math.min(d.near, v);
      else if (k === "f") {
        d.f = d.f || {};
        for (const q in v) d.f[q] = d.f[q] == null ? v[q] : Math.min(d.f[q], v[q]);
      } else if (typeof v === "number" && k !== "tot") d[k] = (d[k] || 0) + v;
      else d[k] = v;
    }
    o.t = game.worldTime;
  } else {
    o = {
      id: "OBS-" + pad3(C.seq.obs++),
      type,
      day,
      t: game.worldTime,
      d: JSON.parse(JSON.stringify(data || {})),
      sent: false,
    };
    C.log.push(o);
    const big = ["storm", "engine_fail", "radiation", "life"].includes(type);
    if ((big || !C.flags.firstObs) && type !== "rare") {
      // taş için hikâye zaten yol gösteriyor (kargo terminali)
      C.flags.firstObs = true;
      const msg =
        T("📝 Saha günlüğüne eklendi: <b>") +
        OBS_DEF[type].nm +
        T("</b> — komuta güvertesindeki <b>iletişim terminalinden</b> Dünya'ya raporla");
      setTimeout(
        () => {
          if (game && mode === "play") toast(msg);
        },
        type === "engine_fail" ? 3200 : 1200,
      );
    }
  }
  if (C.log.length > 80) C.log.splice(0, C.log.length - 80);
  if (commOpen && commTab === "write" && !commTx) renderComm();
}

/* ---------- her kare: olay takibi + mesaj teslimi ---------- */
function commsTick(simDt, dt) {
  if (!game || mode !== "play") return;
  const C = commState(),
    wt = game.worldTime;
  if (scene !== "earth") {
    // fırtına takibi
    if (stormFx.phase === "active") {
      if (!C.trk.st) C.trk.st = { out: 0, broke: false };
      if (!insideRocket) C.trk.st.out += simDt;
    } else if (C.trk.st) {
      const s = C.trk.st;
      C.trk.st = null;
      commsObs("storm", { out: s.out, broke: !!s.broke });
      if (s.out <= 6) bumpQuest("stormSafe");
    }
    // radyasyon takibi
    if (game.radiationActive) {
      if (!C.trk.rd) C.trk.rd = { out: 0 };
      if (!insideRocket) C.trk.rd.out += simDt;
    } else if (C.trk.rd) {
      const r = C.trk.rd;
      C.trk.rd = null;
      commsObs("radiation", { out: r.out, dmg: r.out * RADIATION_DAMAGE_PER_SECOND });
      if (r.out <= 4) bumpQuest("radSafe");
    }
    // kritik yaşam değerleri (günde bir kez her biri)
    const day = gameDayNumber(),
      f = {};
    if (game.o2 < 20) f.o2 = game.o2;
    if (game.thirst < 15) f.thirst = game.thirst;
    if (game.hunger < 15) f.hunger = game.hunger;
    if (game.hp < 30 && game.hp > 0) f.hp = game.hp;
    if (
      (game.stock.water || 0) + (game.inventory.water || 0) === 0 &&
      (game.stock.potato || 0) + (game.inventory.potato || 0) === 0
    )
      f.food = 0;
    const nf = {};
    for (const k in f) {
      if (C.trk.crit[k] !== day) {
        C.trk.crit[k] = day;
        nf[k] = f[k];
      }
    }
    if (Object.keys(nf).length) commsObs("life", { f: nf });
  }
  // Dünya'dan gelenler
  for (const r of C.sent) {
    if (!r.replied && wt >= r.arriveAt) {
      r.replied = true;
      const m = buildReply(r);
      deliverMsg(m);
    }
  }
  commsBulletins(C, wt);
  commTick += dt || 0;
  if (commTick >= 0.5) {
    commTick = 0;
    updateCommBadge();
    if (commOpen && !commTx) {
      if (commTab === "sent" || commTab === "ground" || commTab === "arch") {
        const sc = $("cmBody").firstElementChild,
          y = sc ? sc.scrollTop : 0;
        renderComm();
        const n = $("cmBody").firstElementChild;
        if (n) n.scrollTop = y;
      } else updateCommChip();
    }
  }
}
function deliverMsg(m) {
  const C = commState();
  C.inbox.unshift(m);
  if (C.inbox.length > 60) C.inbox.length = 60;
  tone(988, 0.12, "sine", 0.1);
  tone(1319, 0.16, "sine", 0.1, 0, 0.13);
  tone(1760, 0.22, "triangle", 0.07, 0, 0.28);
  toast(T("📨 <b>Dünya'dan resmî mesaj:</b> ") + escH(m.subject) + T(" — iletişim terminalinden oku"));
  updateCommBadge();
  if (commOpen && !commTx) renderComm();
}
/* Görev Kontrol'ün kendiliğinden gönderdiği mesajlar */
function commsBulletins(C, wt) {
  if (scene === "earth") return;
  const day = solOf(wt),
    inDay = wt % DAY_SECONDS;
  if (!C.flags.welcome && wt > 18) {
    C.flags.welcome = true;
    deliverMsg(welcomeMsg(wt));
  }
  // uzay hava durumu bülteni: yarın/öbür gün olay varsa, günde en fazla bir kez
  if (C.flags.welcome && C.lastBull < day && inDay >= 60) {
    const ev = [day + 1, day + 2].filter((d) => isStormDay(d) || isRadDay(d));
    if (ev.length) {
      C.lastBull = day;
      deliverMsg(bulletinMsg(wt, ev));
    } else C.lastBull = day;
  }
  // telemetri anomalisi: motor bozuldu ve hâlâ raporlanmadı
  if (
    game.stormBroke &&
    game.repair.state !== "ok" &&
    !C.flags.telem &&
    C.flags.brokeAt != null &&
    wt - C.flags.brokeAt > DAY_SECONDS * 0.35 &&
    !C.sent.some((r) => r.items.some((o) => o.type === "engine_fail"))
  ) {
    C.flags.telem = true;
    deliverMsg(telemetryMsg(wt));
  }
  // uzun sessizlik → rapor talebi
  const quiet = day - (C.lastRpt || 0);
  if (day >= 3 && quiet >= 3 && commUnsent().length >= 2 && (C.flags.nag || 0) <= day - 3 && inDay > 120) {
    C.flags.nag = day;
    deliverMsg(nagMsg(wt, quiet));
  }
  // çürüyen hasat: numune talebi + laboratuvar sonucu
  if (C.flags.anaAt && !C.flags.ana && wt >= C.flags.anaAt) {
    C.flags.ana = true;
    deliverMsg(rotAnalysisMsg(wt));
    storyTrigger("rotReply");
  }
  if (C.flags.rock)
    for (const k in C.flags.rock) {
      const at = C.flags.rock[k];
      if (at > 0 && wt >= at) {
        C.flags.rock[k] = -1;
        ensureRare();
        game.rareKnown[k] = true;
        C.sci = (C.sci || 0) + 12;
        deliverMsg(rockAnalysisMsg(k, wt));
        if (k === "ares") storyTrigger("aresReply");
        else if (game.story && game.story.rk === k) storyTrigger("rockReply");
      }
    }
  if (C.aiQ && C.aiQ.length) {
    const due = C.aiQ.filter((j) => wt >= j.at);
    if (due.length) {
      C.aiQ = C.aiQ.filter((j) => wt < j.at);
      due.forEach((j) => deliverMsg(aiReplyMsg(j, wt)));
    }
  }
  // dönüş penceresi
  if (
    !C.flags.window &&
    game.repair.state === "ok" &&
    game.stormBroke &&
    (game.cargo || 0) >= CFG.cargoGoal
  ) {
    C.flags.window = true;
    deliverMsg(windowMsg(wt));
  }
}

/* ---------- mektup şablonu ---------- */
function letter({ no, wt, ref, subject, prio, body, signers, cc, annex }) {
  const S = signers.map((k) => SIG[k]);
  return Tf(
    `<div class="ltr">
  <div class="ltr-hd"><div class="ltr-seal"><b>ARES</b><span>GK</span></div>
    <div class="ltr-org"><b>ARES-1 GÖREV KONTROL MERKEZİ</b><span>Yer istasyonu ağı üzerinden</span></div>
    <div class="ltr-cls {0}">{1}RESMİ<br><small>MÜRETTEBATA ÖZEL</small></div></div>
  <table class="ltr-meta">
    <tr><td>Belge No</td><td>{2}</td><td>Tarih</td><td>{3} (Mars yerel)</td></tr>
    <tr><td>Kime</td><td>ARES-1 Komutanı</td><td>İlgi</td><td>{4}</td></tr>
    <tr><td>Konu</td><td colspan="3"><b>{5}</b></td></tr></table>
  <div class="ltr-body">{6}</div>
  {7}
  <div class="ltr-sign">{8}</div>
  {9}
  <div class="ltr-ft">Bu ileti {10} dk ışık gecikmesiyle iletilmiştir · Şifreli kanal AES-256 · {11}</div>
</div>`,
    [
      prio === "acil" ? "acil" : "",
      prio === "acil" ? T("ACİL · ") : "",
      no,
      solStamp(wt),
      ref || "—",
      escH(subject),
      body,
      annex || "",
      S.map(
        (s) =>
          `<div><i class="ltr-autog">${s[0].replace(/^(Dr\.|Prof\.|Müh\.)\s*/, "")}</i><b>${s[0]}</b><span>${s[1]}</span></div>`,
      ).join(""),
      cc && cc.length
        ? Tf(`<div class="ltr-cc"><b>Bilgi:</b> {0}</div>`, [
            cc.map((k) => SIG[k][0] + " (" + SIG[k][1] + ")").join(" · "),
          ])
        : "",
      fmtN(lightDelay(wt)),
      dsnStation(wt),
    ],
  );
}
function forecastAnnex(fromSol, n, title) {
  let rows = "";
  for (let d = fromSol; d < fromSol + n; d++) {
    const ev = [];
    if (isRadDay(d))
      ev.push(
        Tf(`<span class="fx rd">☢ Radyasyon · {0}–{1}</span>`, [marsClock(0), marsClock(RADIATION_DURATION)]),
      );
    if (isStormDay(d))
      ev.push(
        Tf(`<span class="fx st">🌪 Kum fırtınası · {0}–{1}</span>`, [
          marsClock(STORM_START),
          marsClock(STORM_START + STORM_DUR),
        ]),
      );
    rows += `<tr><td>Sol ${d}</td><td>${ev.length ? ev.join(" ") : T('<span class="fx ok">Açık · dış görev uygun</span>')}</td></tr>`;
  }
  return Tf(
    `<div class="ltr-annex"><div class="ah">{0}</div><table>{1}</table><div class="an">Meteor düşüşleri öngörülemez; tahmine dahil değildir.</div></div>`,
    [title || T("EK-A · Uzay hava durumu tahmini"), rows],
  );
}
function nextStormSol(fromSol) {
  for (let d = fromSol; d < fromSol + 12; d++) if (isStormDay(d)) return d;
  return fromSol + 5;
}
function nextRadSol(fromSol) {
  for (let d = fromSol; d < fromSol + 4; d++) if (isRadDay(d)) return d;
  return fromSol + 3;
}

function welcomeMsg(wt) {
  const C = commState(),
    no = "GK-" + pad3(C.seq.msg++);
  const body = Tf(
    `<p>Sayın Komutan,</p>
  <p>ARES-1 aracının Mars yüzeyine başarılı inişini tebrik ederiz. Tüm Görev Kontrol ekibi şu an sizi izliyor ve iniş telemetrisini eksiksiz aldık.</p>
  <p>Görevinizin temel amacı, yüzeyde <b>bilimsel veri toplamak</b> ve yaşadığınız her olayı — özellikle tehlikeli olanları — Dünya'ya <b>raporlamaktır</b>. Burada hiçbir insanın daha önce yaşamadığı koşulları yaşayacaksınız; gözlemleriniz gelecekteki mürettebatların hayatını kurtaracak.</p>
  <ol><li>Fırtına, radyasyon, meteor, arıza, numune ve tarım olayları aracın <b>saha günlüğüne</b> otomatik kaydedilir.</li>
  <li>Komuta güvertesindeki <b>İletişim Terminali</b>nden bu kayıtları seçip kendi notunuzu ekleyerek rapor gönderin.</li>
  <li>Raporlar ekiplerimiz tarafından incelenir; resmî yanıtımız yaklaşık <b>½ sol</b> içinde ulaşır. Hayati durumlarda raporu <b>ACİL</b> işaretleyin; yanıt süresi ~¼ sole iner.</li></ol>
  <p>Uydu verilerimiz bölgenizde gelişmekte olan bir toz sistemi gösteriyor. Yoğunluğu hakkında henüz kesin bilgimiz yok; lütfen aracın çevresinden çok uzaklaşmayın.</p>
  <p>Size güveniyoruz. Dünya'dan selamlar.</p>`,
    [],
  );
  return {
    id: no,
    t: wt,
    kind: "brief",
    subject: T("Görev başlangıç brifingi"),
    from: SIG.fd[0],
    read: false,
    html: letter({
      no,
      wt,
      subject: T("Görev başlangıç brifingi"),
      body,
      signers: ["fd"],
      cc: ["capcom", "wx", "sci"],
      annex: forecastAnnex(solOf(wt), 5),
    }),
  };
}
function bulletinMsg(wt, days) {
  const C = commState(),
    no = "GK-" + pad3(C.seq.msg++),
    R = rngSeed(hashStr(no)),
    P = (a) => a[Math.floor(R() * a.length)];
  const items = days
    .map((d) => {
      const s = [];
      if (isStormDay(d))
        s.push(
          Tf(
            `<li><b>Sol {0} · Kum fırtınası:</b> {1} Beklenen başlangıç <b>{2}</b>, süre yaklaşık <b>{3}</b>. Rüzgâr hızı {4} km/sa'e ulaşabilir.</li>`,
            [
              d,
              P([
                T("Yörünge görüntüleri bölgenize doğru ilerleyen bir toz cephesi gösteriyor."),
                T("Basınç modellerimiz yerel bir toz fırtınasının oluşacağını öngörüyor."),
                T("Hellas havzasından yükselen bir toz sistemi konumunuza yaklaşıyor."),
              ]),
              marsClock(STORM_START),
              gDur(STORM_DUR),
              60 + Math.round(R() * 50),
            ],
          ),
        );
      if (isRadDay(d))
        s.push(
          Tf(
            `<li><b>Sol {0} · Radyasyon dalgası:</b> {1} Parçacık akısı <b>{2}–{3}</b> arasında zirve yapacak. Bu sürede <b>araç dışına çıkmayın</b>.</li>`,
            [
              d,
              P([
                T("Güneş yüzeyinde X sınıfı bir patlama kaydedildi."),
                T("SOHO gözlemleri yüksek enerjili bir koronal kütle atımı gösteriyor."),
                T("Güneş rüzgârı parçacık akısında ani artış bekleniyor."),
              ]),
              marsClock(0),
              marsClock(RADIATION_DURATION),
            ],
          ),
        );
      return s.join("");
    })
    .join("");
  const body = Tf(
    `<p>ARES-1 mürettebatına,</p><p>{0}</p>
  <ul class="ltr-ul">{1}</ul>
  <p>{2}</p>`,
    [
      P([
        T("Uzay hava durumu biriminin günlük değerlendirmesi aşağıdadır."),
        T("Önümüzdeki iki sol için risk değerlendirmemiz ekte sunulmuştur."),
        T("Rutin uzay hava durumu bülteni bilgilerinize sunulur."),
      ]),
      items,
      P([
        T("Dış görevlerinizi bu pencerelerin dışına planlamanızı öneriyoruz."),
        T("Numunelerinizi olay öncesinde kargoya yüklemenizi öneriyoruz."),
        T("Olay sırasındaki gözlemlerinizi raporlamanız modellerimizi iyileştirecektir."),
      ]),
    ],
  );
  return {
    id: no,
    t: wt,
    kind: "bulletin",
    subject: T("Uzay hava durumu bülteni · Sol ") + days[0],
    from: SIG.wx[0],
    read: false,
    html: letter({
      no,
      wt,
      subject: T("Uzay hava durumu bülteni"),
      body,
      signers: ["wx"],
      cc: ["fd"],
      annex: forecastAnnex(solOf(wt), 5),
    }),
  };
}
function telemetryMsg(wt) {
  const C = commState(),
    no = "GK-" + pad3(C.seq.msg++);
  const body = Tf(
    `<p>Sayın Komutan,</p>
  <p>Araç telemetrisinde <b>itki sisteminde anomali</b> tespit ettik: ana motor kontrol kartından veri alınamıyor, yakıt hattında basınç dalgalanması görülüyor. Bu tablo, son fırtınada ciddi bir hasar oluştuğuna işaret ediyor.</p>
  <p>Henüz sizden bu konuda bir rapor almadık. Lütfen <b>en kısa sürede durum raporu gönderin</b> ve makine dairesindeki tamir tezgâhından onarım prosedürünü başlatın.</p>
  <div class="ltr-dir"><b>TALİMATLAR</b><ol><li>Makine dairesine inin, ana motora <kbd>E</kbd> ile erişin.</li><li>Prosedürü sırayla uygulayın: kablolar → sigortalar → basınç → ateşleme.</li><li>Duman yoğunsa oksijen seviyenizi kontrol edin.</li></ol></div>`,
    [],
  );
  return {
    id: no,
    t: wt,
    kind: "alert",
    subject: T("Telemetri anomalisi · itki sistemi"),
    from: SIG.prop[0],
    read: false,
    html: letter({
      no,
      wt,
      subject: T("Telemetri anomalisi · itki sistemi"),
      prio: "acil",
      body,
      signers: ["prop", "fd"],
      cc: ["capcom"],
    }),
  };
}
function nagMsg(wt, quiet) {
  const C = commState(),
    no = "GK-" + pad3(C.seq.msg++),
    n = commUnsent().length;
  const body = Tf(
    `<p>Komutan,</p><p>Son <b>{0} soldur</b> sizden rapor alamadık. Telemetri aracın çalıştığını gösteriyor, ancak saha günlüğünüzde <b>{1} gönderilmemiş kayıt</b> birikmiş durumda.</p>
  <p>Bilim ekibimiz ve mürettebat sağlığı birimimiz verilerinizi bekliyor. Kısa da olsa bir durum raporu göndermenizi rica ederiz. Nasıl hissettiğinizi bir iki cümleyle yazmanız da bizim için değerlidir.</p>`,
    [quiet, n],
  );
  return {
    id: no,
    t: wt,
    kind: "alert",
    subject: T("Rapor talebi"),
    from: SIG.capcom[0],
    read: false,
    html: letter({ no, wt, subject: T("Rapor talebi"), body, signers: ["capcom"], cc: ["fd", "psy"] }),
  };
}
function windowMsg(wt) {
  const C = commState(),
    no = "GK-" + pad3(C.seq.msg++);
  const body = Tf(
    `<p>Sayın Komutan,</p><p>Telemetri ana motorun çevrimiçi olduğunu ve kargo bölmesinin <b>{0}/{1}</b> dolduğunu doğruluyor. <b>Dünya'ya dönüş penceresi açılmıştır.</b></p>
  <p>Komuta güvertesindeki navigasyon bilgisayarından dönüş rotasını onaylayabilirsiniz. Kalkıştan önce yaşadıklarınızı içeren son bir rapor göndermeniz, görev arşivi için çok değerli olacaktır.</p><p>Eve hoş geleceksiniz.</p>`,
    [CFG.cargoGoal, CFG.cargoGoal],
  );
  return {
    id: no,
    t: wt,
    kind: "brief",
    subject: T("Dönüş penceresi açıldı"),
    from: SIG.fd[0],
    read: false,
    html: letter({
      no,
      wt,
      subject: T("Dönüş penceresi açıldı"),
      body,
      signers: ["fd"],
      cc: ["prop", "log", "capcom"],
    }),
  };
}

/* ---------- rapor yanıtı: içerik + not + anlık durum ---------- */
const NOTE_RULES = [
  {
    re: /çürü|curu|rotten|\brot\b|rotting|verfault|faul|podrid|pudri/,
    k: "bio",
    t: [
      T("Çürüyen patatesleri biyoloji ekibi inceleyecek. Çürük patatesi kargo terminalinden bize gönderin."),
    ],
  },
  {
    re: /fırtına|firtina|toz|rüzg[aâ]r|ruzgar|storm|dust|wind|sturm|staub|tormenta|polvo|viento/,
    k: "wx",
    t: [
      T(
        "Fırtınalar konusundaki endişenizi anlıyoruz. Fırtınalar her 5 solda bir, sabah saatlerinde başlıyor; uyarı kartı göründüğünde 45 saniyeniz var.",
      ),
      T(
        "Toz fırtınası sırasında aracın gövdesi tasarım sınırları içinde kalıyor; içeride güvendesiniz. Sarsıntı normaldir.",
      ),
    ],
  },
  {
    re: /motor|arıza|ariza|bozul|tamir|onar|duman|itki|engine|smoke|broke|repair|failure|thrust|triebwerk|rauch|defekt|kaputt|reparat|humo|aver[ií]a|averiad|repar/,
    k: "prop",
    t: [
      T(
        "Motor konusunda yazdıklarınızı itki ekibine ilettik. Duman, kontrol kartındaki yanık sigortalardan ve kopan güç kablolarından kaynaklanıyor; onarım prosedürü bu sırayı izliyor.",
      ),
      T(
        "İtki ekibi, onarım sırasında aşamaları atlamamanızı rica ediyor: önce kablolar, sonra sigortalar ve ana şalter, ardından basınç kalibrasyonu ve son olarak ateşleme dizisi.",
      ),
    ],
  },
  {
    re: /oksijen|o2|o₂|nefes|hava|oxygen|breath|sauerstoff|atem|luft|ox[ií]geno|respir|aire/,
    k: "med",
    t: [
      T(
        "Oksijen yönetimi hayati önemde: giysi oksijeni %30'un altına indiğinde dış görevi bitirin. Makine dairesindeki O₂ tüpleri kendini yavaşça yeniliyor; tüp seviyesini de takip edin.",
      ),
    ],
  },
  {
    re: /\bsu\b|susuz|susa|içecek|water|thirst|wasser|durst|\bagua\b|\bsed\b/,
    k: "bio",
    t: [
      T(
        "Su geri dönüştürücü düzenli çalışıyor; stok yavaş da olsa kendiliğinden yenileniyor. Mutfaktan şişe alıp çantanızda taşıyabilirsiniz.",
      ),
    ],
  },
  {
    re: /yemek|\baç\b|açlık|aclik|patates|erzak|yiyecek|stok|food|hungry|hunger|potato|suppl|essen|nahrung|kartoffel|vorr[aä]t|comida|hambre|patata|suministro|v[ií]veres/,
    k: "bio",
    t: [
      T(
        "Erzak durumunuzu yakından izliyoruz. Patates yetiştirmek uzun vadeli tek gıda kaynağınız; her hasat ek tohum da veriyor. Mutfak ve yemek kapsülündeki stoku dengeli kullanın.",
      ),
    ],
  },
  {
    re: /radyasyon|ışın|isin|güneş patla|radiation|solar flare|strahlung|sonneneruption|radiaci[oó]n|erupci[oó]n solar/,
    k: "wx",
    t: [
      T(
        "Radyasyon dalgaları her 3 solda bir, günün ilk saatlerinde geliyor. Aracın gövde zırhı sizi tamamen koruyor; dalga boyunca içeride kalmanız ya da uyumanız yeterli.",
      ),
    ],
  },
  {
    re: /meteor|göktaşı|goktasi|krater|ateş topu|crater|cr[aá]ter|fireball|feuerball|bola de fuego/,
    k: "sci",
    t: [
      T(
        "Meteorlar öngörülemez, ancak düşmeden önce bir uğultu ve yerde büyüyen bir gölge oluşuyor. Gölgeden uzaklaşın; çarpmadan sonra kraterlerde değerli numuneler bulabilirsiniz.",
      ),
    ],
  },
  {
    re: /yalnız|yalniz|kork|stres|moral|üzgün|uzgun|sıkıl|sikil|özle|ozle|ailem|bunal|endişe|endise|uyuyam|lonely|alone|afraid|scared|\bfear|\bsad\b|family|homesick|anxious|can't sleep|einsam|allein|angst|traurig|vermisse|familie|heimweh|\bsol[oa]\b|miedo|triste|echo de menos|familia|ansiedad/,
    k: "psy",
    t: [
      T(
        "Yazdıklarınızı dikkatle okudum. Bu duyguların izole ve yüksek riskli bir ortamda çok doğal olduğunu bilmenizi isterim; zayıflık değil, insan olmanın bir parçası.",
      ),
      T(
        "Günlük bir rutin kurmanızı öneriyorum: düzenli uyku, öğünler ve her sol kısa da olsa bir rapor. Bize yazmak da bir bağ kurmaktır; her mesajınızı okuyoruz. Aileniz iyi ve size selamlarını iletiyorlar.",
      ),
    ],
  },
  {
    re: /yaralı|yarali|hasta|ağrı|agri|\bcan\b|kanam|sakat|yorgun|injur|hurt|sick|pain|health|bleed|tired|verletz|krank|schmerz|gesundheit|müde|herid|enferm|dolor|salud|cansad/,
    k: "med",
    t: [
      T(
        "Sağlık durumunuzu kayda aldık. Can değeriniz düştüğünde revirdeki medikitleri kullanın; uyku da iyileşmeyi belirgin şekilde hızlandırıyor.",
      ),
    ],
  },
  {
    re: /tohum|ekin|ekim|tarla|hasat|bitki|sula|seed|plant|farm|harvest|crop|samen|pflanz|ernte|anbau|gieß|semilla|cultiv|cosech|regar|riego/,
    k: "bio",
    t: [
      T(
        "Tarım denemeniz biyoloji ekibinin en çok takip ettiği konu. Parsellerinizi sulamayı unutmayın; ıslak toprakta büyüme belirgin şekilde hızlanıyor.",
      ),
    ],
  },
  {
    re: /dünya|dunya|dönüş|donus|kalkış|kalkis|eve |evine|geri dön|earth|return|home|launch|erde|rückkehr|heimkehr|zurück|tierra|regres|volver|casa|despeg/,
    k: "fd",
    t: [
      Tf(
        `Dönüş için iki koşul gerekiyor: ana motorun çalışır olması ve kargo bölmesinin {0} birim numuneyle dolması. Bu sağlandığında navigasyon bilgisayarı dönüş rotasını açacak.`,
        [CFG.cargoGoal],
      ),
    ],
  },
  {
    re: /teşekkür|tesekkur|sağ ?ol|sag ?ol|eyvallah|thank|danke|gracias/,
    k: "capcom",
    t: [
      T(
        "Asıl biz teşekkür ederiz. Kontrol odasında her raporunuz okunurken herkes ekranın başına toplanıyor.",
      ),
    ],
  },
  {
    re: /numune|maden|metal|kristal|kaya|taş|sample|crystal|rock|stone|mineral|probe|gestein|stein|muestra|cristal|roca|piedra/,
    k: "sci",
    t: [
      T(
        "Numune toplama çalışmanız bilim ekibinin önceliği. Yıldız kristalleri metal numunelerin iki katı değerinde; kargoya yüklerken bunu göz önünde bulundurun.",
      ),
    ],
  },
];

/* ============== GDY-1: Görev Destek Yapay Zekâsı ==============
   Raporla gönderilen her nota, canlı görev verilerini kullanarak resmî bir yanıt yazar.
   Yanıt, gidiş-dönüş ışık gecikmesi + kısa işlem süresi sonra gelen kutusuna düşer. */
const stripH = (x) =>
  String(x || "")
    .replace(/<[^>]+>/g, "")
    .replace(/\s+/g, " ")
    .trim();
function aiCtx() {
  const g = game,
    S = g.stock || {},
    I = g.inventory || {},
    wt = g.worldTime,
    sol = solOf(wt),
    M = g.radMarks || [];
  const q = QUESTS[Math.min(g.quest, QUESTS.length - 1)];
  return {
    sol,
    clock: marsClock(wt),
    o2: Math.round(g.o2 == null ? 100 : g.o2),
    tank: Math.round((g.o2Tank / o2Max()) * 100),
    hp: Math.round(g.hp),
    hun: Math.round(g.hunger),
    thi: Math.round(g.thirst),
    w: I.water || 0,
    sw: S.water || 0,
    p: I.potato || 0,
    sp: S.potato || 0,
    seed: (I.seed || 0) + (I.tuber || 0) + (S.seed || 0),
    med: (I.medkit || 0) + (S.medkit || 0),
    cargo: Math.min(g.cargo || 0, CFG.cargoGoal),
    goal: CFG.cargoGoal,
    eng: g.repair && g.repair.state === "ok",
    stage: (g.repair && g.repair.stage) || 0,
    ns: nextStormSol(sol),
    nr: nextRadSol(sol),
    ld: fmtN(lightDelay(wt)),
    st: dsnStation(wt),
    marks: M.length,
    green: M.filter((m) => m.u < SOIL_SAFE).length,
    env: Math.round(BIO.env),
    temp: fmtN(BIO.temp, 1),
    rad: fmtN(BIO.rad, 2),
    gold: g.gold || 0,
    rate: fmtN(CFG.waterRecycle / 60, 1),
    qt: q ? stripH(q.t) : "",
    qd: q ? stripH(q.d) : "",
    qh: q ? stripH(q.how) : "",
    done: g.quest >= QUESTS.length,
  };
}
const AI_INTENTS = [
  {
    re: /çürü|curu|rotten|\brot\b|rotting|verfault|faul|podrid|pudr|toprak|soil|boden|suelo|tierra fértil|ölçer|olcer|ölç|meter|messger|medidor|dozimet|dosimet/,
    a: (c) =>
      Tf(
        `Patatesler, ekildikleri toprağın radyasyonu <b>1,0 µSv/h</b> ve üzerindeyse hasatta çürük çıkar. Roketteki <b>alet sandığından</b> radyasyon ölçeri alın ve ekmeden önce toprağı ölçün; ekranda <b>RADYASYON NORMAL</b> görünen yere ekin. Bugüne kadar {0} ölçüm yaptınız, bunların {1} tanesi normal çıktı.`,
        [c.marks, c.green],
      ),
  },
  {
    re: /oksijen|\bo2\b|o₂|nefes|oxygen|breath|sauerstoff|atem|ox[ií]geno|respir/,
    a: (c) =>
      Tf(
        `Giysi oksijeniniz şu anda <b>%{0}</b>, roketteki O₂ tüpü <b>%{1}</b> dolu. Giysi oksijeni %30'un altına düştüğünde rokete dönün ve makine dairesindeki O₂ istasyonundan doldurun. Koşmak tüketimi artırır.`,
        [c.o2, c.tank],
      ),
  },
  {
    re: /\bsu\b|susuz|susa|içecek|water|thirst|wasser|durst|\bagua\b|\bsed\b/,
    a: (c) =>
      Tf(
        `Çantanızda <b>{0}</b>, depoda <b>{1}</b> şişe su var; susuzluk göstergeniz %{2}. Su geri dönüştürücü yaklaşık her {3} dakikada bir şişe üretir. Şişeleri kargo terminalinden ya da mutfaktan alabilirsiniz.`,
        [c.w, c.sw, c.thi, c.rate],
      ),
  },
  {
    re: /yemek|\baç\b|açlık|aclik|patates|erzak|yiyecek|tokluk|food|hungry|hunger|potato|essen|nahrung|kartoffel|comida|hambre|patata/,
    a: (c) =>
      Tf(
        `Tokluğunuz %{0}. Çantanızda <b>{1}</b>, depoda <b>{2}</b> patates ve toplam <b>{3}</b> tohum var. Erzak azalıyorsa radyasyonu normal toprağa patates ekin; düzenli sulama büyümeyi hızlandırır.`,
        [c.hun, c.p, c.sp, c.seed],
      ),
  },
  {
    re: /fırtına|firtina|\btoz\b|rüzg[aâ]r|ruzgar|storm|dust|wind|sturm|staub|tormenta|polvo|viento/,
    a: (c) =>
      Tf(
        `Bir sonraki toz fırtınası <b>Sol {0}</b> için öngörülüyor. Fırtına sırasında anten kapanabilir ve dışarıdaki ana motor arızalanabilir. Uyarı gelince rokete girin ve fırtına geçene kadar dışarı çıkmayın.`,
        [c.ns],
      ),
  },
  {
    re: /radyasyon|ışın|isin|güneş patla|radiation|solar flare|strahlung|radiaci[oó]n/,
    a: (c) =>
      Tf(
        `Bir sonraki güneş kaynaklı radyasyon dalgası <b>Sol {0}</b> için öngörülüyor. Dalga sırasında dışarıda kalmak can kaybettirir; roketin gövdesi koruma sağlar. Şu anki ortam radyasyonu <b>{1} µSv/h</b>.`,
        [c.nr, c.rad],
      ),
  },
  {
    re: /motor|arıza|ariza|bozul|tamir|onar|duman|itki|engine|smoke|broke|repair|thrust|triebwerk|defekt|kaputt|reparat|humo|aver[ií]a|repar/,
    a: (c) =>
      c.eng
        ? Tf(
            `Ana motor şu anda <b>çevrimiçi</b>. Fırtınalarda arızalanabileceği için fırtına uyarısında rokete girmeniz yeterlidir.`,
            [],
          )
        : Tf(
            `Ana motor şu anda <b>devre dışı</b>; onarım {0}/4 aşamada. Makine dairesindeki onarım istasyonuna gidip adımları sırasıyla tamamlayın.`,
            [c.stage],
          ),
  },
  {
    re: /dünya|dunya|dönüş|donus|kalkış|kalkis|eve |geri dön|earth|return|home|launch|erde|rückkehr|zurück|tierra|regres|volver|casa|despeg/,
    a: (c) =>
      Tf(
        `Dünya'ya dönüş için iki koşul gerekiyor: ana motorun çevrimiçi olması (şu an: <b>{0}</b>) ve kargoda en az <b>{1}</b> numune bulunması (şu an: <b>{2}/{3}</b>).`,
        [c.eng ? T("çevrimiçi") : T("devre dışı"), c.goal, c.cargo, c.goal],
      ),
  },
  {
    re: /numune|maden|metal|kristal|kaya|taş|kargo|sample|crystal|rock|stone|mineral|cargo|probe|gestein|stein|fracht|muestra|roca|piedra|carga/,
    a: (c) =>
      Tf(
        `Kargo bölmesinde <b>{0}/{1}</b> numune var. Metal numune 1, yıldız kırıntısı 2 puan sayılır; numuneleri roketin yanında <b>F</b> ile ya da kargo terminalinden yükleyin.`,
        [c.cargo, c.goal],
      ),
  },
  {
    re: /yaralı|yarali|hasta|ağrı|agri|\bcan\b|kanam|medikit|sağlık|saglik|injur|hurt|sick|pain|health|medkit|verletz|krank|schmerz|gesundheit|herid|enferm|dolor|salud/,
    a: (c) =>
      Tf(
        `Canınız <b>%{0}</b>. Toplam <b>{1}</b> medikitiniz var; revirden alıp kullanabilirsiniz. Uyumak da canı yavaşça yeniler.`,
        [c.hp, c.med],
      ),
  },
  {
    re: /uyu|uyku|yorgun|dinlen|sleep|tired|rest|schlaf|müde|dormir|cansad|descans/,
    a: (c) =>
      Tf(
        `Yatakhanedeki ranzada uyuyabilirsiniz. Uyurken zaman hızlanır, can yenilenir; oksijen ve erzak tüketimi devam eder, bu yüzden uyumadan önce stoklarınızı kontrol edin.`,
        [],
      ),
  },
  {
    re: /saat|zaman|gün|kaçıncı|\bsol\b|time|clock|day|uhr|zeit|\btag\b|hora|tiempo|\bdía\b/,
    a: (c) =>
      Tf(
        `Şu an <b>Sol {0}</b>, Mars yerel saati <b>{1}</b>. Bir Mars günü (sol) yaklaşık 24 saat 40 dakika sürer.`,
        [c.sol, c.clock],
      ),
  },
  {
    re: /sıcak|sicak|soğuk|soguk|derece|ısı|üşü|usu|temperat|cold|warm|kalt|frío|frio|calor/,
    a: (c) =>
      Tf(
        `Dış sıcaklık şu anda yaklaşık <b>{0} °C</b>. Giysinizin ısıl kontrolü vücut sıcaklığınızı <b>{1} °C</b> civarında tutuyor; gece sıcaklık −75 °C'ye kadar düşebilir.`,
        [c.env, c.temp],
      ),
  },
  {
    re: /gecikme|mesaj|iletişim|iletisim|sinyal|anten|istasyon|delay|signal|antenna|station|verzöger|funk|retraso|señal|estaci/,
    a: (c) =>
      Tf(
        `Mesajlarınız Mars ile Dünya arasında tek yönde yaklaşık <b>{0} dakikada</b> iletiliyor. Şu an sizi <b>{1}</b> derin uzay anteni izliyor; istasyonlar Dünya döndükçe sırayla devralır.`,
        [c.ld, c.st],
      ),
  },
  {
    re: /meteor|göktaşı|goktasi|krater|crater|fireball|feuerball|bola de fuego/,
    a: (c) =>
      Tf(
        `Meteorlar önceden kesin olarak bilinemez. Düşmeden önce bir uğultu duyulur ve yerde büyüyen bir gölge oluşur; gölgeyi görünce hemen uzaklaşın.`,
        [],
      ),
  },
  {
    re: /altın|altin|geliştir|gelistir|yükselt|gold|upgrade|improve|verbesser|oro|mejor/,
    a: (c) =>
      Tf(
        `Şu anda <b>{0}</b> altınınız var. Roketteki geliştirme istasyonunda altınla roketinizi ve ekipmanınızı güçlendirebilirsiniz.`,
        [c.gold],
      ),
  },
  {
    re: /ne yap|nasıl|nasil|görev|gorev|yardım|yardim|ipucu|sıradaki|siradaki|what (should|do)|how|help|quest|mission|hint|next|was soll|wie|hilfe|aufgabe|qué hago|cómo|ayuda|misión|siguiente/,
    a: (c) =>
      c.done
        ? Tf(`Tüm görevleri tamamladınız. Dönüş penceresi açıksa rokete binip Dünya'ya dönebilirsiniz.`, [])
        : Tf(`Şu anki göreviniz: <b>{0}</b> — {1}. Önerimiz: {2}`, [c.qt, c.qd, c.qh]),
  },
  {
    re: /yalnız|yalniz|kork|stres|moral|üzgün|uzgun|sıkıl|sikil|özle|ozle|endişe|endise|lonely|alone|afraid|scared|\bsad\b|homesick|anxious|einsam|angst|traurig|solo|miedo|triste/,
    a: (c) =>
      Tf(
        `Duygularınızı paylaştığınız için teşekkür ederiz. Uzun görevlerde bu çok doğal. Davranış sağlığı ekibimiz sizi takip ediyor; düzenli uyku, kısa molalar ve hedeflerinizi küçük adımlara bölmek yardımcı olur. Yalnız değilsiniz, her mesajınız burada okunuyor.`,
        [],
      ),
  },
  {
    re: /kimsin|kim\b|sen ne|yapay zek|\bai\b|who are you|wer bist|quién eres/,
    a: (c) =>
      Tf(
        `Ben <b>GDY-1</b>, ARES Görev Kontrol Merkezi'nin görev destek yapay zekâsıyım. Raporlarınızdaki soruları canlı görev verileriyle eşleştirip resmî yanıt hazırlıyorum; ayrıntılı değerlendirmeler uzman ekiplerden ayrıca gelir.`,
        [],
      ),
  },
  {
    re: /merhaba|selam|günaydın|iyi akşam|hello|\bhi\b|hey|hallo|guten|hola|buenos/,
    a: (c) =>
      Tf(
        `Merhaba Komutan. Mesajınız alındı; sinyal kalitesi iyi. Sormak istediğiniz her şeyi raporunuza yazabilirsiniz.`,
        [],
      ),
  },
  {
    re: /teşekkür|tesekkur|sağ ?ol|sag ?ol|thank|danke|gracias/,
    a: (c) => Tf(`Rica ederiz Komutan. Görev Kontrol her an hattadır.`, []),
  },
];
function aiAnswerHTML(note) {
  const c = aiCtx(),
    low = note.toLocaleLowerCase(typeof LOCALE !== "undefined" ? LOCALE : "tr-TR");
  let parts = note
    .split(/(?<=[?.!])\s+|\n+/)
    .map((x) => x.trim())
    .filter((x) => x.length > 1);
  if (!parts.length) parts = [note];
  if (parts.length > 4) parts = parts.slice(0, 4);
  const used = new Set();
  const blocks = parts
    .map((q, i) => {
      const ql = q.toLocaleLowerCase(typeof LOCALE !== "undefined" ? LOCALE : "tr-TR");
      let hit = AI_INTENTS.filter((x) => x.re.test(ql) && !used.has(x));
      if (!hit.length && parts.length === 1) hit = AI_INTENTS.filter((x) => x.re.test(low));
      let ans;
      if (hit.length) {
        const h = hit.slice(0, 1);
        h.forEach((x) => used.add(x));
        ans = h.map((x) => x.a(c)).join(" ");
      } else
        ans = c.done
          ? Tf(
              `Sorunuzu kayda aldım; görev veritabanında doğrudan eşleşen bir konu bulamadım ve uzman ekiplere ilettim.`,
              [],
            )
          : Tf(
              `Sorunuzu kayda aldım; görev veritabanında doğrudan eşleşen bir konu bulamadım ve uzman ekiplere ilettim. Bu arada şu anki göreviniz: <b>{0}</b> — {1}.`,
              [c.qt, c.qd],
            );
      return Tf(
        `<div class="ai-qa"><div class="ai-q"><span>SORU {0}</span>«{1}»</div><div class="ai-a"><span>YANIT</span><p>{2}</p></div></div>`,
        [i + 1, escH(q.length > 200 ? q.slice(0, 200) + "…" : q), ans],
      );
    })
    .join("");
  return blocks;
}
function aiReplyMsg(job, wt) {
  const C = commState(),
    no = "GK-" + pad3(C.seq.msg++),
    c = aiCtx();
  const body = Tf(
    `<p>Sayın Komutan,</p>
  <p><b>{0}</b> numaralı raporunuzdaki not, {1} anteni üzerinden alınarak <b>GDY-1 Görev Destek Yapay Zekâsı</b> tarafından canlı görev verileriyle (Sol {2} · {3}) değerlendirilmiştir. Yanıtlar aşağıdadır.</p>
  {4}
  <p class="ai-ft">Bu yanıt otomatik olarak hazırlanmış ve Görev Kontrol adına resmî bilgilendirme niteliğindedir. Uzman ekiplerin ayrıntılı değerlendirmesi rapor yanıtıyla ayrıca iletilecektir.</p>`,
    [job.rid, escH(job.st), c.sol, c.clock, aiAnswerHTML(job.note)],
  );
  return {
    id: no,
    t: wt,
    kind: "ai",
    subject: T("Sorunuza yanıt · ") + job.rid,
    from: SIG.ai[0],
    read: false,
    html: letter({
      no,
      wt,
      ref: job.rid,
      subject: T("Sorunuza yanıt · ") + job.rid,
      body,
      signers: ["ai"],
      cc: ["fd", "capcom"],
    }),
  };
}
function buildReply(r) {
  const C = commState(),
    wt = game.worldTime,
    sol = solOf(wt);
  const R = rngSeed(hashStr(r.id) + Math.floor(r.t * 13)),
    P = (a) => a[Math.floor(R() * a.length)];
  const no = "GK-" + pad3(C.seq.msg++);
  const team = new Set(["fd"]),
    cc = new Set(["capcom"]);
  const types = {};
  r.items.forEach((o) => {
    (types[o.type] = types[o.type] || []).push(o);
  });
  const order = [
    "engine_fail",
    "life",
    "rot",
    "storm",
    "radiation",
    "meteor",
    "rare",
    "engine_fix",
    "geo",
    "agri",
    "cargo",
  ];
  const secs = [];
  let pts = 0;
  const nextSt = nextStormSol(sol),
    nextRd = nextRadSol(sol);
  const dir = (list) =>
    Tf(`<div class="ltr-dir"><b>TALİMATLAR</b><ol>{0}</ol></div>`, [
      list.map((x) => "<li>" + x + "</li>").join(""),
    ]);
  const pick = (arr, n) => {
    const a = arr.slice(),
      o = [];
    while (a.length && o.length < n) o.push(a.splice(Math.floor(R() * a.length), 1)[0]);
    return o;
  };
  for (const ty of order) {
    const L = types[ty];
    if (!L) continue;
    const D = OBS_DEF[ty];
    pts += D.w * L.length;
    const days = [...new Set(L.map((o) => o.day))].join(", ");
    const sum = (k) => L.reduce((s, o) => s + (o.d[k] || 0), 0);
    let h = `${D.ic} ${D.nm} <small>· Sol ${days}</small>`,
      p = "",
      dl = [];
    if (ty === "storm") {
      team.add("wx");
      const out = sum("out"),
        broke = L.some((o) => o.d.broke),
        tau = fmtN(2.4 + R() * 2.6),
        wind = 70 + Math.round(R() * 55);
      p = P([
        Tf(
          `Sol {0} fırtınasına ait verileriniz Uzay Hava Durumu Birimi tarafından incelendi. Yörünge görüntüleriyle karşılaştırıldığında bölgenizdeki toz yoğunluğunun optik derinlik <b>τ≈{1}</b> seviyesine ulaştığı anlaşılıyor.`,
          [days, tau],
        ),
        Tf(
          `Gönderdiğiniz fırtına gözlemleri, bu enlemde kaydedilen en yoğun yerel toz olaylarından biriyle uyumlu. Rüzgâr hızının anlık olarak <b>{0} km/sa</b>'e çıktığını tahmin ediyoruz.`,
          [wind],
        ),
        Tf(
          `Fırtına süresince toplanan basınç ve görüş verileri modelimizi doğrulamamızı sağladı; tahmin hatamız bu veriyle <b>%{0}</b> azaldı.`,
          [8 + Math.round(R() * 14)],
        ),
      ]);
      p +=
        " " +
        (out > 2
          ? Tf(
              `Kayıtlar fırtına sırasında araç dışında yaklaşık <b>{0}</b> geçirdiğinizi gösteriyor. Bu, EVA güvenlik kuralının (GK-EVA-7) açıkça ihlalidir; lütfen bir daha tekrarlamayın.`,
              [gDur(out)],
            )
          : P([
              T("Fırtına boyunca araç içinde kalmanız prosedüre tam uygundur; teşekkür ederiz."),
              T("Mürettebatın fırtınayı araç içinde geçirmesi doğru karardı."),
            ]));
      if (broke) {
        p += T(" Fırtınanın ana motora verdiği hasar ayrıca itki ekibine iletilmiştir.");
        team.add("prop");
      }
      dl = pick(
        [
          T("Fırtına uyarı kartı göründüğünde <b>45 saniye</b> içinde hava kilidine dönün."),
          Tf(
            `Sonraki fırtına <b>Sol {0}</b>, {1} için öngörülüyor; o sol dış görevleri fırtına öncesine planlayın.`,
            [nextSt, marsClock(STORM_START)],
          ),
          T("Fırtına öncesi çantanızdaki numuneleri kargoya yükleyin."),
          T("Fırtına sırasında komuta güvertesindeki ön camdan görüş gözlemi yapıp raporlayın."),
          T("Fırtına sonrası oksijen tüpü seviyesini kontrol edin; filtreler tozla yüklenmiş olabilir."),
        ],
        3,
      );
    } else if (ty === "engine_fail") {
      team.add("prop");
      p = P([
        T(
          "İtki ekibimiz bildirdiğiniz arızayı telemetriyle eşleştirdi. Toz girişinin yakıt hattı vanasında basınç dalgalanmasına, ardından kontrol kartında aşırı akıma yol açtığı değerlendiriliyor.",
        ),
        T(
          "Arıza raporunuz itki ekibinde öncelikli olarak ele alındı. Ön analiz: fırtına esnasındaki titreşim güç kablolarını soketlerinden kopardı, oluşan kısa devre sigortaları yaktı.",
        ),
        T(
          "Bildirdiğiniz motor arızası, test tesisimizdeki yedek motorda simüle edildi. Aynı belirtileri (duman, kalkış kilidi, kontrol kartı sessizliği) elde ettik; arıza tipi doğrulandı.",
        ),
      ]);
      p +=
        " " +
        (game.repair.state === "ok"
          ? T(
              "<b>Bu yanıt hazırlanırken alınan telemetri motorun yeniden çevrimiçi olduğunu gösteriyor — tebrikler.</b>",
            )
          : Tf(
              `<b>Güncel telemetri motorun hâlâ devre dışı olduğunu gösteriyor</b> (tamamlanan aşama: {0}/4). Onarım bitmeden dönüş penceresi açılmayacaktır.`,
              [game.repair.stage || 0],
            ));
      dl =
        game.repair.state === "ok"
          ? [T("Motor çalışırken makine dairesinde olağandışı ses ya da duman görürseniz derhal raporlayın.")]
          : [
              T("Makine dairesinde ana motora ya da tamir tezgâhına <kbd>E</kbd> ile erişin."),
              T(
                "Prosedür sırası: <b>kablolar → sigortalar + ana şalter → basınç kalibrasyonu → ateşleme</b>. Tamamlanan aşamalar kaydedilir.",
              ),
              T("Basınç aşamasında ibre yeşil bölgedeyken kilitleyin; acele etmeyin."),
              T("Duman yoğunken uzun süre makine dairesinde kalmayın."),
            ];
    } else if (ty === "engine_fix") {
      team.add("prop");
      p = P([
        T(
          "Onarım kayıtlarınızı inceledik: tüm aşamalar nominal değerlerde tamamlanmış. Bu, Mars yüzeyinde mürettebat tarafından yapılan ilk tam itki onarımıdır; tebrikler.",
        ),
        T(
          "Motorun yeniden çevrimiçi olması tüm kontrol odasında alkışla karşılandı. Onarım verileriniz üretici firmaya iletildi; sonraki araç tasarımında toz filtresi revize edilecek.",
        ),
      ]);
      dl = pick(
        [
          T("Sonraki fırtınada motor bölmesinin sızdırmazlığını gözlemleyin."),
          T("Onarım sırasında fark ettiğiniz her şeyi notunuza ekleyin; mühendislerimiz için çok değerli."),
        ],
        1,
      );
    } else if (ty === "radiation") {
      team.add("wx");
      cc.add("med");
      const out = sum("out"),
        dmg = sum("dmg"),
        msv = Math.round(18 + dmg * 9 + R() * 12);
      p = P([
        T(
          "Dozimetre verileriniz Uzay Hava Durumu Birimi ve Uçuş Cerrahı tarafından birlikte değerlendirildi.",
        ),
        T(
          "Parçacık dalgasına ait sensör verileriniz başarıyla işlendi; olay, Güneş'teki bir koronal kütle atımıyla eşleştirildi.",
        ),
      ]);
      p +=
        out > 1
          ? Tf(
              ` Kayıtlara göre dalga sırasında araç dışında <b>{0}</b> kaldınız; tahmini alınan doz <b>~{1} mSv</b>. Bu değer yıllık limitinizin önemli bir kısmıdır. Sağlık kaydınıza işlendi.`,
              [gDur(out), msv],
            )
          : Tf(
              ` Dalga boyunca zırhlı gövde içinde kalmanız sayesinde aldığınız doz ihmal edilebilir düzeyde (<b>&lt;1 mSv</b>). Mükemmel.`,
              [],
            );
      dl = pick(
        [
          Tf(`Sonraki radyasyon dalgası <b>Sol {0}</b>, {1}–{2} arasında bekleniyor.`, [
            nextRd,
            marsClock(0),
            marsClock(RADIATION_DURATION),
          ]),
          T("Dalga sırasında araç içinde kalın; uyumak zamanı güvenle geçirmenin en iyi yolu."),
          T("Doz aldıysanız revirdeki medikiti kullanın."),
          T("Ekran yeşile döndüğünde ve kenarlarda ışıma başladığında derhal rokete dönün."),
        ],
        3,
      );
    } else if (ty === "meteor") {
      team.add("sci");
      const n = sum("n"),
        near = Math.min(...L.map((o) => (o.d.near == null ? 1e9 : o.d.near))),
        m = Math.round(near / 8);
      p = P([
        Tf(
          `Bildirdiğiniz <b>{0}</b> meteor çarpması bilim ekibinde büyük heyecan yarattı. Taze kraterler, Mars yüzeyinin yaşı ve iç yapısı hakkında eşsiz bilgi sağlıyor.`,
          [n],
        ),
        Tf(
          `Gezegen Bilimi Ekibi, raporunuzdaki {0} çarpmayı yörünge sismik verileriyle eşleştirdi. Çarpışma enerjilerinin her biri için birkaç ton TNT eşdeğeri olduğu hesaplanıyor.`,
          [n],
        ),
      ]);
      if (near < 1e8)
        p +=
          m < 25
            ? Tf(
                ` Ancak en yakın çarpmanın yalnızca <b>~{0} m</b> mesafede olması ciddi bir risk; uçuş cerrahımız endişeli.`,
                [m],
              )
            : Tf(` En yakın çarpma ~{0} m mesafede; güvenli sınırlar içinde.`, [m]);
      dl = pick(
        [
          T("Uğultu duyduğunuzda yerdeki <b>büyüyen gölgeyi</b> arayın ve ondan uzaklaşın."),
          T("Taze kraterler bir süre sıcak kalır; tütmesi bitince numune arayın."),
          T("Kraterlerde bulduğunuz yıldız kristallerini öncelikle kargoya yükleyin."),
        ],
        2,
      );
    } else if (ty === "rare") {
      team.add("sci");
      const names = [...new Set(L.flatMap((o) => Object.keys(o.d).filter((k) => RARE_DEF[k])))].map(
        (k) => RARE_DEF[k].name,
      );
      p = P([
        Tf(
          `Bildirdiğiniz <b>{0}</b> bulguları bilim ekibinde olağanüstü bir heyecan yarattı. Bu mineraller yörünge spektrometreleriyle yalnızca dolaylı olarak tespit edilmişti; yerinde analiz ilk kez yapıldı.`,
          [names.join(", ")],
        ),
        Tf(
          `Gezegen Bilimi Ekibi raporladığınız {0} örneklerini inceledi. Kristal yapısı, bölgede geçmişte hidrotermal etkinlik olduğuna işaret ediyor.`,
          [names.join(", ")],
        ),
      ]);
      dl = pick(
        [
          T(
            "Uzak bölgelerde tarayıcı sinyallerini takip etmeye devam edin; ancak oksijen seviyenizi dönüş için yeterli tutun.",
          ),
          T("Titanyum cevherini roket zırhı için, olivin kristallerini EVA giysisi için ayırın."),
          T("Ares taşı son derece nadir; bulduğunuz her parça bilimsel olarak paha biçilemez."),
        ],
        2,
      );
    } else if (ty === "geo") {
      team.add("sci");
      const metal = sum("metal"),
        star = sum("star");
      p = P([
        Tf(
          `Gönderdiğiniz {0} metal{1} numunesinin spektral ön verisi, yüksek demir-nikel oranına işaret ediyor.`,
          [metal, star ? Tf(` ve {0} yıldız kristali`, [star]) : ""],
        ),
        Tf(
          `Numune verileriniz ({0} metal{1}) laboratuvarımızdaki Mars göktaşı koleksiyonuyla karşılaştırılıyor; ilk sonuçlar umut verici.`,
          [metal, star ? Tf(`, {0} kristal`, [star]) : ""],
        ),
      ]);
      if (star)
        p +=
          " " +
          P([
            T(
              "Yıldız kristallerinin kökeni ekibimizde tartışma yarattı; hidratlı mineral olasılığı, geçmişte sıvı su bulunduğuna işaret edebilir.",
            ),
            T(
              "Kristallerin parlaklık spektrumu bilinen hiçbir Mars mineraliyle tam eşleşmiyor. Lütfen toplamaya devam edin.",
            ),
          ]);
      dl = [
        Tf(
          `Kargo hedefi: <b>{0}</b> birim · güncel durum <b>{1}/{2}</b>. Numuneleri komuta güvertesindeki stok terminalinden yükleyin.`,
          [CFG.cargoGoal, Math.min(game.cargo || 0, CFG.cargoGoal), CFG.cargoGoal],
        ),
      ];
    } else if (ty === "rot") {
      team.add("bio");
      p = C.flags.ana
        ? T("Çürümenin nedeni toprağın yüksek radyasyonu. Ekimden önce radyasyon ölçerle toprağı ölçün.")
        : T(
            "Çürüyen hasat bildiriminiz biyoloji ekibine iletildi. Çürük patatesi kargo terminalinden bize gönderin, inceleyip sonucu bildirelim.",
          );
      dl = C.flags.ana
        ? [T("Ekimden önce toprağı ölç: <b>1,0 µSv/h</b> altı güvenli.")]
        : [T("Çürük patates örneğini çantanızda tutun."), T("Aynı parsele yeniden ekim yapmayın.")];
    } else if (ty === "agri") {
      team.add("bio");
      const pl = sum("p"),
        hv = sum("h");
      p = P([
        Tf(
          `Tarım verileriniz ({0} ekim, {1} hasat) Biyorejeneratif Yaşam Destek ekibinin en çok beklediği veriler arasında. Mars regolitinde patates yetiştirmek, uzun süreli görevlerin anahtarı.`,
          [pl, hv],
        ),
        Tf(
          `Biyoloji ekibi raporunuzdaki ekim/hasat oranını ({0}/{1}) Dünya'daki kontrol deneyiyle karşılaştırıyor. Regolitteki perkloratlara rağmen büyümenin sürmesi çok önemli bir bulgu.`,
          [pl, hv],
        ),
      ]);
      dl = pick(
        [
          T("Parselleri düzenli sulayın; ıslak toprakta büyüme hızlanır."),
          T("Her hasattan gelen tohumu yeniden ekerek döngüyü sürdürün."),
          T("Uyurken mahsul de 2 kat hızlı büyür; gece ekim yapmayı düşünün."),
          T("Fırtınadan sonra parselleri kontrol edin."),
        ],
        2,
      );
    } else if (ty === "cargo") {
      team.add("log");
      p =
        Tf(`Lojistik kayıtları güncellendi. Güncel kargo durumu <b>{0}/{1}</b>. `, [
          Math.min(game.cargo || 0, CFG.cargoGoal),
          CFG.cargoGoal,
        ]) +
        ((game.cargo || 0) >= CFG.cargoGoal
          ? T("Kargo hedefi tamamlandı; dönüş için yalnızca araç sistemlerinin hazır olması gerekiyor.")
          : T("Hedefe ulaşmak için numune toplamaya devam edin."));
    } else if (ty === "life") {
      team.add("med");
      cc.add("psy");
      const F = {};
      L.forEach((o) => {
        for (const k in o.d.f || {}) F[k] = F[k] == null ? o.d.f[k] : Math.min(F[k], o.d.f[k]);
      });
      p =
        P([
          T("Mürettebat sağlığı birimi raporunuzdaki kritik değerleri ciddiyetle inceledi."),
          T("Yaşam destek uyarılarınız Uçuş Cerrahı'na öncelikli olarak iletildi."),
        ]) +
        T(" Kayda geçen değerler: ") +
        Object.keys(F)
          .map((k) =>
            k === "food" ? T("<b>erzak tükenmesi</b>") : `<b>${LIFE_NM[k]} %${Math.round(F[k])}</b>`,
          )
          .join(", ") +
        ".";
      const adv = {
        o2: T("Giysi oksijeni %30'un altına inince dış görevi sonlandırın; O₂ tüpleri makine dairesinde."),
        thirst: T("Su seviyeniz için mutfaktan şişe alın ve çantanızda yedek taşıyın."),
        hunger: T("Tokluk düştüğünde mutfakta ya da yemek kapsülünde patates tüketin."),
        hp: T("Can değeriniz düşükken revirde medikit kullanın ve dinlenin."),
        food: T("Erzak tükendi: önceliğiniz tarım olmalı. Su geri dönüştürücü stoku yavaşça yeniliyor."),
      };
      dl = Object.keys(F).map((k) => adv[k]);
    }
    secs.push(`<h4>${secs.length + 1}. ${h}</h4><p>${p}</p>${dl.length ? dir(dl) : ""}`);
  }
  // mürettebat notu
  const note = (r.note || "").trim();
  if (note) {
    const low = note.toLocaleLowerCase(typeof LOCALE !== "undefined" ? LOCALE : "tr-TR"),
      hits = NOTE_RULES.filter((x) => x.re.test(low)).slice(0, 4);
    let q = note.length > 220 ? note.slice(0, 220) + "…" : note;
    let np = `<blockquote>«${escH(q)}»</blockquote>`;
    if (hits.length) {
      hits.forEach((x) => {
        team.add(x.k);
        np += `<p><b>${SIG[x.k][1]}:</b> ${P(x.t)}</p>`;
      });
    } else
      np += `<p>${P([T("Notunuz ilgili birimlere dağıtıldı. Konuyu daha ayrıntılı açıklarsanız uzman ekiplerimiz size daha net yanıt verebilir."), T("Notunuzu kayda aldık ve görev günlüğüne işledik. Ekip toplantımızda ele alınacak.")])}</p>`;
    if (/\?/.test(note))
      np += `<p>${P([T("Sorularınızın tümüne yanıt vermeye çalıştık; eksik kalan bir nokta olursa bir sonraki raporunuzda tekrar sorun."), T("Sorunuzu dikkate aldık. Daha fazla ayrıntı için bir sonraki raporunuzda bize koşullarınızı anlatın.")])}</p>`;
    pts += Math.min(10, Math.round(note.length / 30));
    secs.push(Tf(`<h4>{0}. ✍ Mürettebat notunuz</h4>{1}`, [secs.length + 1, np]));
  }
  // anlık durum değerlendirmesi
  const st = [],
    S = game.stock,
    wa = (S.water || 0) + (game.inventory.water || 0),
    po = (S.potato || 0) + (game.inventory.potato || 0);
  st.push(
    Tf(`<li>Ana motor: {0}</li>`, [
      game.repair.state === "ok"
        ? T('<span class="ok">ÇEVRİMİÇİ</span>')
        : T('<span class="bad">DEVRE DIŞI</span> · onarım ') + (game.repair.stage || 0) + "/4",
    ]),
  );
  st.push(
    Tf(`<li>Erzak: su {0}, patates {1} {2}</li>`, [
      wa,
      po,
      wa + po < 6 ? T('<span class="bad">· KRİTİK</span>') : "",
    ]),
  );
  st.push(
    Tf(`<li>O₂ tüpü: %{0} · kargo: {1}/{2}</li>`, [
      Math.round((game.o2Tank / o2Max()) * 100),
      Math.min(game.cargo || 0, CFG.cargoGoal),
      CFG.cargoGoal,
    ]),
  );
  // bilim puanı
  pts = Math.max(1, Math.round(pts * desSciMul(types)));
  C.sci = (C.sci || 0) + pts;
  const pct = Math.min(100, Math.round((C.sci / SCI_GOAL) * 100));
  const open =
    r.prio === "acil"
      ? P([
          T(
            "ACİL önceliğiyle işaretlenen raporunuz alınır alınmaz görev ekibi toplandı ve tüm birimler raporunuzu öncelikli olarak inceledi.",
          ),
          T("ACİL raporunuz üzerine kontrol odasında olağanüstü vardiya başlatıldı."),
        ])
      : P([
          T("Raporunuz ilgili ekiplerimiz tarafından ayrıntılı olarak incelenmiştir."),
          T("Raporunuz tüm birimlere dağıtılmış ve değerlendirilmiştir."),
          T("Gönderdiğiniz veriler kontrol odasında ekiplerimiz tarafından tek tek ele alındı."),
        ]);
  const body = Tf(
    `<p>{0}</p>
  <p><b>Sol {1}</b> tarihli <b>{2}</b> numaralı raporunuz {3} üzerinden <b>{4} MB</b> olarak eksiksiz alınmıştır. {5}</p>
  {6}
  <h4>{7}. 📊 Görev durumu değerlendirmesi</h4><ul class="ltr-ul">{8}</ul>
  <p>Bilim ekibi bu paketi <b>{9} bilim puanı</b> olarak değerlendirdi. Görev bilim hedefinin <b>%{10}</b>'i tamamlandı.</p>
  <div class="ltr-sci"><i style="width:{11}%"></i></div>
  <p>{12}</p>`,
    [
      P([T("Sayın Komutan,"), T("ARES-1 Komutanına,"), T("Değerli Komutanımız,")]),
      r.sol,
      r.id,
      escH(r.dsn),
      fmtN(r.mb),
      open,
      secs.join(""),
      secs.length + 1,
      st.join(""),
      pts,
      pct,
      pct,
      P([
        T("Çalışmalarınız için tüm ekip adına teşekkür ederiz. Güvende kalın."),
        T("Dünya'da hepimiz sizinle gurur duyuyoruz. Bir sonraki raporunuzu bekliyoruz."),
        T("Unutmayın: yalnız değilsiniz, her adımınızı izliyoruz. Bir sonraki raporunuzu bekliyoruz."),
      ]),
    ],
  );
  const sign = ["fd"],
    main = [...team].filter((k) => k !== "fd");
  if (main.length) sign.unshift(main[0]);
  const ccL = [...new Set([...main.slice(1), ...cc])].filter((k) => !sign.includes(k));
  const names = order.filter((k) => types[k]).map((k) => OBS_DEF[k].nm);
  const subject =
    T("Yanıt: ") +
    r.id +
    " — " +
    (names.length
      ? names.slice(0, 2).join(", ") + (names.length > 2 ? " +" + (names.length - 2) : "")
      : T("Mürettebat notu"));
  return {
    id: no,
    t: wt,
    kind: "reply",
    ref: r.id,
    prio: r.prio,
    subject,
    from: SIG[sign[0]][0],
    read: false,
    html: letter({
      no,
      wt,
      ref: r.id + T(" (Sol ") + r.sol + ")",
      subject,
      prio: r.prio,
      body,
      signers: sign,
      cc: ccL,
      annex: forecastAnnex(sol, 5, T("EK-A · Önümüzdeki 5 sol tahmini")),
    }),
  };
}

/* ---------- gönderim ---------- */
/* ---------- YER BİRİMİ ----------
   İletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları
   ve görev kontrol merkezleri */
const GS_STATIONS = [
  {
    k: "NNO",
    nm: "New Norcia (DSA 1)",
    cc: T("Avustralya"),
    place: T("Batı Avustralya · Perth'in 140 km kuzeyi"),
    lat: "31,05° G",
    lon: "116,19° D",
    alt: "252 m",
    dish: "35 m",
    up: "S · X",
    down: "S · X",
    year: "2002",
  },
  {
    k: "CEB",
    nm: "Cebreros (DSA 2)",
    cc: T("İspanya"),
    place: T("Ávila · Madrid'in 77 km batısı"),
    lat: "40,45° K",
    lon: "4,37° B",
    alt: "794 m",
    dish: "35 m",
    up: "X",
    down: "X · K · Ka",
    year: "2005",
  },
  {
    k: "MLG",
    nm: T("Malargüe (DSA 3)"),
    cc: T("Arjantin"),
    place: T("Mendoza · Malargüe'nin 30 km güneyi"),
    lat: "35,78° G",
    lon: "69,40° B",
    alt: "1.550 m",
    dish: "35 m",
    up: "X · Ka",
    down: "X · K · Ka",
    year: "2012",
  },
];
const GS_CENTERS = [
  {
    nm: T("ARES Görev Kontrol Merkezi"),
    loc: T("Dünya"),
    role: T("GÖREV YÖNETİMİ"),
    li: [
      T("Uçuş direktörü ve iletişim sorumlusuyla görev takibi"),
      T("Raporları inceler, resmî yanıtları ve talimatları yazar"),
      T("Mürettebat sağlığı ve uzay hava durumu değerlendirmesi"),
    ],
  },
  {
    nm: T("Derin Uzay Anten Ağı"),
    loc: T("Avustralya · İspanya · Arjantin"),
    role: T("İLETİŞİM"),
    li: [
      T("Üç 35 m anteni sırayla Mars'a yönlendirir"),
      T("Her ~8 Mars saatinde bir istasyon devri"),
      T("Delta-DOR ile hassas konum ve sinyal kalitesi takibi"),
    ],
  },
  {
    nm: "Bilim Veri Merkezi",
    loc: T("Kullanıcı segmenti"),
    role: T("VERİ ALIMI"),
    li: [
      T("Gelen telemetri ve bilim paketlerinin işlenmesi"),
      T("Numune, hava ve radyasyon verilerinin arşivlenmesi"),
      T("Verilerin bilim ekiplerine dağıtılması"),
    ],
  },
];
function crewCardHTML() {
  return Tf(
    `<div class="np-crew"><div class="gs-mk sm">ARES</div><div><b>Komutan · ARES-1</b><small>ARES-1/CDR · Mars yüzey görevi</small></div></div>`,
    [],
  );
}
/* ---------- GÖREV MİMARİSİ ----------
   görev segmentleri · kavram olgunluğu · alt sistem durumu · zaman çizelgesi */
function archDesignHTML(C) {
  const des = game.design;
  if (!des) return "";
  const D = des.D,
    k = des.calc,
    fx = des.fx,
    sol = gameDayNumber(),
    sent = C.sent.reduce((a, r) => a + (r.mb || 0), 0);
  const cell = (l, v, s, bad) =>
    `<div class="${bad ? "bad" : ""}"><span>${l}</span><b>${v}</b><small>${s}</small></div>`;
  return Tf(
    `<div class="gs-sec">Tasarım kaynakları · canlı</div>
    <div class="ar-kv">{0}
      {1}
      {2}
      {3}
      {4}
      {5}</div>`,
    [
      cell(T("⚖️ Kütle"), fmtN(k.mass) + " / " + k.cap + " t", mdFind(MD_LV, D.lv).nm),
      cell(
        T("⚡ Güç"),
        fmtN(k.puse) + " / " + fmtN(k.pgen) + " kW",
        fx.solar
          ? stormFx.phase === "active"
            ? T("Fırtına: panel üretimi düştü")
            : T("Güneş panelleri")
          : T("RTG · sabit güç"),
        fx.solar && stormFx.phase === "active",
      ),
      cell(
        T("💰 Bütçe"),
        Math.round(k.cost) + (isFinite(k.budget) ? " / " + k.budget : "") + " M$",
        mdFind(MD_DIFF, D.diff).nm,
      ),
      cell(
        T("💾 Veri"),
        k.data + " MB/sol",
        fx.dataFactor < 1
          ? T("Kapasite aşılıyor: bilimin %") + Math.round((1 - fx.dataFactor) * 100) + T("'i kayıp")
          : "Kapasite yeterli",
        fx.dataFactor < 1,
      ),
      cell(T("📡 İletişim"), fx.commsCap + " MB/sol", T("Gönderilen: ") + fmtN(sent) + " MB"),
      cell("⏱️ Zaman", "Sol " + sol + " / " + fx.lifetime, fx.days + T(" gün transfer"), sol > fx.lifetime),
    ],
  );
}
function archHTML(C) {
  const wt = game.worldTime,
    sol = gameDayNumber(),
    L = commLinkState(),
    act = Math.floor(+marsClock(wt).slice(0, 2) / 8) % 3;
  const eng = game.repair.state === "ok",
    A = rkArmor(),
    brk = Math.round((A ? ARMOR[A - 1].chance : BASE_STORM_BREAK) * 100),
    S = curSuit();
  const tank = Math.round((game.o2Tank / o2Max()) * 100),
    sci = Math.min(100, Math.round(((C.sci || 0) / SCI_GOAL) * 100));
  const cargo = Math.min(game.cargo || 0, CFG.cargoGoal),
    qd = Math.min(game.quest, QUESTS.length);
  const water = (game.stock.water || 0) + (game.inventory.water || 0),
    food = (game.stock.potato || 0) + (game.inventory.potato || 0);
  let ns = sol;
  while (!isStormDay(ns)) ns++;
  let nr = sol;
  while (!isRadDay(nr)) nr++;
  const home = game.quest >= QUESTS.length - 1;
  const pill = (ok, txt) =>
    `<span class="ar-pill ${ok === true ? "ok" : ok === false ? "bad" : "mid"}">${txt}</span>`;
  const row = (k, v) => `<div class="ar-row"><span>${k}</span><b>${v}</b></div>`;
  const seg = [
    {
      ic: "🚀",
      t: T("Fırlatma segmenti"),
      d: T("Görevi uzaya taşıyan fırlatma aracı ve fırlatma hizmetleri."),
      st: pill(true, T("TAMAMLANDI")),
      r: [
        row(T("Araç"), T("ARES-1 iniş ve dönüş roketi")),
        row(T("Transfer"), T("≈ 214 gün · 225 milyon km")),
        row(T("Varış"), T("Mars · ekvator ovası")),
      ],
    },
    {
      ic: "🛰️",
      t: T("Uzay segmenti"),
      d: T("Görevi yürüten araç, alet ve ekipman: roket, kıyafet ve numune sistemleri."),
      st: pill(eng, eng ? T("NOMİNAL") : T("ARIZA")),
      r: [
        row(T("Ana motor"), eng ? T("Çalışıyor") : T("Arızalı · ") + (game.repair.stage || 0) + "/4"),
        row(T("Kıyafet"), S.name),
        row(T("Kargo"), cargo + " / " + CFG.cargoGoal),
      ],
    },
    {
      ic: "📡",
      t: T("Yer segmenti"),
      d: T(
        "İletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları ve görev kontrol merkezleri.",
      ),
      st: pill(L.ok, L.ok ? T("BAĞLI") : T("KESİK")),
      r: [
        row("Aktif istasyon", GS_STATIONS[act].nm),
        row(T("Görev kontrol"), "ARES-1"),
        row(T("Işık gecikmesi"), fmtN(lightDelay(wt)) + T(" dk")),
      ],
    },
    {
      ic: "🔬",
      t: T("Kullanıcı segmenti"),
      d: T("Görev verilerini analiz eden ve kullanan bilim insanları ve diğer kullanıcılar."),
      st: pill(sci >= 100 ? true : null, "%" + sci),
      r: [
        row(T("Gönderilen rapor"), C.sent.length),
        row(T("Gönderilen veri"), fmtN(C.sent.reduce((a, r) => a + (r.mb || 0), 0)) + " MB"),
        row(T("Bilim hedefi"), "%" + sci),
      ],
    },
  ]
    .map(
      (g) =>
        `<div class="ar-seg"><div class="ar-sh"><b>${g.t}</b>${g.st}</div><p>${g.d}</p>${g.r.join("")}</div>`,
    )
    .join("");
  const cml =
    [
      ["CML 1", T("İlk görev fikri"), T("Bilim sorusu: Mars'ta insan yaşamı mümkün mü?")],
      ["CML 2", "Fizibilite analizi", T("Tek kişilik mürettebat ve tek araçla görev mümkün mü?")],
      [
        "CML 3",
        T("Ödünleşim çalışmaları"),
        T("Güç, kütle, iletişim ve koruma seçeneklerinin karşılaştırılması"),
      ],
      ["CML 4", T("Nokta tasarım"), T("ARES-1 görev mimarisi")],
    ]
      .map((c) => `<div class="ar-cml done"><em>${c[0]}</em><b>${c[1]}</b><small>${c[2]}</small></div>`)
      .join("") +
    Tf(
      `<div class="ar-cml now"><em>FAZ E</em><b>Operasyon</b><small>Mars yüzey operasyonları · Sol {0}</small></div>`,
      [sol],
    );
  const tl = [
    [T("Kavram"), "CML 1–4", true],
    [T("Fırlatma"), T("Dünya"), true],
    [T("Transfer"), T("214 gün"), true],
    [T("Giriş · İniş"), T("Mars"), true],
    [T("Yüzey"), "Sol " + sol, "now"],
    [T("Dönüş"), home ? T("Rota açık") : T("Kilitli"), home ? "now2" : false],
  ]
    .map(
      (s) =>
        `<div class="ar-tl ${s[2] === true ? "done" : s[2] === "now" ? "now" : s[2] === "now2" ? "now" : ""}"><i></i><b>${s[0]}</b><small>${s[1]}</small></div>`,
    )
    .join("");
  const sub = [
    [T("İtki"), eng ? T("Ana motor çalışıyor") : T("Ana motor arızalı"), eng],
    [
      T("Yaşam desteği"),
      T("O₂ tüpü %") + tank + T(" · su ") + water + T(" · patates ") + food,
      tank > 25 && water + food > 3 ? true : tank > 10 ? null : false,
    ],
    [
      T("Isıl ve radyasyon koruması"),
      S.name + T(" · radyasyon hasarı %") + Math.round(S.st.rad * 100),
      S.st.rad < 1 ? true : null,
    ],
    [
      T("Yapı"),
      T("Fırtına kalkanı ") + (A ? T("Seviye ") + A : T("Yok")) + T(" · arıza riski %") + brk,
      brk <= 15 ? true : brk < 60 ? null : false,
    ],
    [T("İletişim"), L.ok ? GS_STATIONS[act].nm + T(" · bağlı") : T("Bağlantı kesik"), L.ok],
    [T("Görev operasyonları"), T("Görev ") + qd + " / " + QUESTS.length, qd >= QUESTS.length ? true : null],
    [
      T("Risk"),
      T("Sonraki fırtına Sol ") + ns + T(" · radyasyon Sol ") + nr,
      stormFx.phase === "active" || game.radiationActive ? false : null,
    ],
  ]
    .map(
      (s) =>
        `<div class="ar-sub"><span class="d ${s[2] === true ? "ok" : s[2] === false ? "bad" : "mid"}"></span><b>${s[0]}</b><small>${s[1]}</small></div>`,
    )
    .join("");
  return Tf(
    `<div class="gs ar">
    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>ARES-1 GÖREV MİMARİSİ</b>
      <p>ARES-1; fırlatma, uzay, yer ve kullanıcı segmentlerinden oluşur. Kavram, olgunluk seviyeleri boyunca fikirden nokta tasarıma geliştirildi. Alt sistemler mühendislik disiplinlerine göre ayrı ayrı izlenir.</p></div></div>
    <div class="gs-sec">Görev segmentleri</div>
    <div class="ar-segs">{0}</div>
    {1}
    <div class="gs-sec">Görev zaman çizelgesi</div>
    <div class="ar-tls">{2}</div>
    <div class="gs-sec">Kavram olgunluğu</div>
    <div class="ar-cmls">{3}</div>
    <div class="gs-sec">Alt sistem durumu</div>
    <div class="ar-subs">{4}</div>
  </div>`,
    [seg, archDesignHTML(C), tl, cml, sub],
  );
}

/* ---------- ARES-R1 röle uydusu: dairesel alçak Mars yörüngesi, gerçek fizik değerleri ---------- */
const MARS_R = 3389.5,
  MARS_MU = 42828.37,
  MARS_SOL_S = 88775.24;
const SAT = { nm: "ARES-R1", alt: 400, inc: 93, raan0: 0.6, ph0: 1.2 };
const SITE = { nm: "Meridiani Planum", lat: -1.95, lon: -5.53 };
SAT.r = MARS_R + SAT.alt;
SAT.T = 2 * Math.PI * Math.sqrt(SAT.r ** 3 / MARS_MU);
SAT.v = Math.sqrt(MARS_MU / SAT.r);
const marsSec = (wt) => wt * (MARS_SOL_S / DAY_SECONDS);
function satAt(ts) {
  const th = (2 * Math.PI * ts) / SAT.T + SAT.ph0,
    i = (SAT.inc * Math.PI) / 180;
  const lat = Math.asin(Math.sin(i) * Math.sin(th));
  let lon =
    Math.atan2(Math.cos(i) * Math.sin(th), Math.cos(th)) + SAT.raan0 - (2 * Math.PI * ts) / MARS_SOL_S;
  lon = ((((lon + Math.PI) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI)) - Math.PI;
  const sl = (SITE.lat * Math.PI) / 180,
    so = (SITE.lon * Math.PI) / 180;
  const cg = Math.cos(lat) * Math.cos(sl) * Math.cos(lon - so) + Math.sin(lat) * Math.sin(sl);
  const g = Math.acos(Math.max(-1, Math.min(1, cg))),
    k = MARS_R / SAT.r;
  const el = Math.atan2(cg - k, Math.sin(g));
  const rng = Math.sqrt(MARS_R * MARS_R + SAT.r * SAT.r - 2 * MARS_R * SAT.r * cg);
  return {
    lat: (lat * 180) / Math.PI,
    lon: (lon * 180) / Math.PI,
    el: (el * 180) / Math.PI,
    rng,
    vis: el > 0,
  };
}
function satNextPass(ts) {
  // bir sonraki görünürlük başlangıcı ve süresi (Mars saniyesi)
  const now = satAt(ts),
    step = 20;
  let t = ts,
    inPass = now.vis,
    start = null,
    end = null;
  for (let i = 0; i < 9000; i++) {
    t += step;
    const v = satAt(t).vis;
    if (inPass && !v) {
      end = t;
      if (start == null) return { now: true, end };
      break;
    }
    if (!inPass && v && start == null) {
      start = t;
      inPass = true;
    }
    if (start != null && !v) {
      end = t;
      break;
    }
  }
  return { now: false, start, end };
}
const fmtLat = (v) => fmtN(Math.abs(v), 2) + "° " + (v >= 0 ? "K" : "G"),
  fmtLon = (v) => fmtN(Math.abs(v), 2) + "° " + (v >= 0 ? "D" : "B");
const mdur = (s) => {
  s = Math.max(0, Math.round(s / 60));
  const h = Math.floor(s / 60),
    m = s % 60;
  return (h ? h + T(" sa ") : "") + m + T(" dk");
};
function satHTML() {
  const ts = marsSec(game.worldTime),
    S = satAt(ts),
    np = satNextPass(ts),
    ld = lightDelay(game.worldTime);
  // harita: eşdikdörtgen, 360×180
  const X = (lon) => lon + 180,
    Y = (lat) => 90 - lat;
  let past = "",
    fut = "";
  for (let k = -60; k <= 0; k++) {
    const q = satAt(ts + (k * SAT.T) / 120);
    past +=
      (k === -60 ? "M" : Math.abs(q.lon - satAt(ts + ((k - 1) * SAT.T) / 120).lon) > 90 ? "M" : "L") +
      X(q.lon).toFixed(1) +
      "," +
      Y(q.lat).toFixed(1);
  }
  for (let k = 0; k <= 120; k++) {
    const q = satAt(ts + (k * SAT.T) / 120);
    fut +=
      (k === 0 ? "M" : Math.abs(q.lon - satAt(ts + ((k - 1) * SAT.T) / 120).lon) > 90 ? "M" : "L") +
      X(q.lon).toFixed(1) +
      "," +
      Y(q.lat).toFixed(1);
  }
  const grid =
    [...Array(11)]
      .map((_, i) => `<line x1="${(i + 1) * 30}" y1="0" x2="${(i + 1) * 30}" y2="180"/>`)
      .join("") + [30, 60, 90, 120, 150].map((y) => `<line x1="0" y1="${y}" x2="360" y2="${y}"/>`).join("");
  const cov = 26.6; // görüş konisi yarı açısı (400 km)
  const sx = X(SITE.lon),
    sy = Y(SITE.lat),
    px = X(S.lon),
    py = Y(S.lat);
  const satTrk = `<path d="${past}" class="sat-past"/><path d="${fut}" class="sat-fut"/>`,
    satSite = `<g transform="translate(${sx},${sy})"><circle r="3.2" class="sat-site"/><path d="M0,-3 L0,-12 L7,-9.5 L0,-7" class="sat-flag"/></g>`;
  const st = S.vis
    ? Tf(`<b class="sat-on">GÖRÜŞ ALANINDA</b>`, [])
    : Tf(`<b class="sat-off">UFUK ALTINDA</b>`, []);
  const nxt = np.now
    ? Tf(`Geçiş sürüyor · {0} kaldı`, [mdur(np.end - ts)])
    : np.start != null
      ? Tf(`{0} sonra · {1} sürecek`, [mdur(np.start - ts), mdur(np.end - np.start)])
      : "—";
  return Tf(
    `<div class="sat">
    <div class="sat-map">
      <svg viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">
        <defs><linearGradient id="satBg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5a2a1c"/><stop offset=".5" stop-color="#8a3f26"/><stop offset="1" stop-color="#4a2216"/></linearGradient>
          <radialGradient id="satGl"><stop offset="0" stop-color="#7fe7ff" stop-opacity=".9"/><stop offset="1" stop-color="#7fe7ff" stop-opacity="0"/></radialGradient></defs>
        <rect width="360" height="180" fill="url(#satBg)"/>
        <g class="sat-grid">{0}</g>
        <line x1="0" y1="90" x2="360" y2="90" class="sat-eq"/>
        <ellipse cx="{1}" cy="{2}" rx="{3}" ry="{4}" class="sat-cov {5}"/>
        {6}
        {7}
        {8}
        <circle cx="{9}" cy="{10}" r="11" fill="url(#satGl)"/><g transform="translate({11},{12})" class="sat-ic"><rect x="-2.6" y="-2.6" width="5.2" height="5.2" rx="1"/><rect x="-9" y="-1.3" width="5" height="2.6"/><rect x="4" y="-1.3" width="5" height="2.6"/></g>
      </svg>
      <div class="sat-legend"><span><i class="lg-site"></i>ARES-1 · {13}</span><span><i class="lg-sat"></i>{14}</span><span><i class="lg-fut"></i>Sonraki tur</span><span><i class="lg-cov"></i>Görüş alanı</span></div>
    </div>
    <div class="sat-side">
      <div class="sat-hd"><div><small>RÖLE UYDUSU</small><b>{15}</b></div>{16}</div>
      <dl class="sat-dl">
        <dt>Anlık konum</dt><dd>{17} · {18}</dd>
        <dt>ARES-1'e uzaklık</dt><dd>{19} km</dd>
        <dt>Yükseliş açısı</dt><dd>{20}</dd>
        <dt>Sonraki geçiş</dt><dd>{21}</dd>
        <dt>Yörünge</dt><dd>Dairesel · {22} km · eğim {23}°</dd>
        <dt>Periyot · hız</dt><dd>{24} dk · {25} km/s</dd>
        <dt>Bağlantılar</dt><dd>UHF 401 MHz (yüzey) · X-bant (Dünya)</dd>
        <dt>Mars–Dünya</dt><dd>{26} milyon km · {27} dk</dd>
      </dl>
    </div>
  </div>`,
    [
      grid,
      sx,
      sy,
      cov,
      cov,
      S.vis ? "on" : "",
      satTrk,
      S.vis ? `<line x1="${sx}" y1="${sy}" x2="${px}" y2="${py}" class="sat-link"/>` : "",
      satSite,
      px,
      py,
      px,
      py,
      SITE.nm,
      SAT.nm,
      SAT.nm,
      st,
      fmtLat(S.lat),
      fmtLon(S.lon),
      fmtN(S.rng, 0),
      S.vis ? fmtN(S.el, 1) + "°" : T("ufkun altında (") + fmtN(S.el, 0) + "°)",
      nxt,
      SAT.alt,
      fmtN(SAT.inc, 1),
      fmtN(SAT.T / 60, 1),
      fmtN(SAT.v, 2),
      fmtN((ld * 60 * 299792.458) / 1e6, 1),
      fmtN(ld),
    ],
  );
}
function groundSegmentHTML(C) {
  const wt = game.worldTime,
    L = commLinkState(),
    clk = marsClock(wt),
    h = +clk.slice(0, 2),
    mi = +clk.slice(3, 5),
    act = Math.floor(h / 8) % 3;
  const toNext = ((8 - (h % 8)) * 60 - mi) / GAME_MIN;
  const mb = C.sent.reduce((a, r) => a + (r.mb || 0), 0),
    rcv = C.inbox.length,
    ld = lightDelay(wt);
  const st = GS_STATIONS.map((S, i) => {
    const on = i === act;
    const tag = on
      ? L.ok
        ? T('<span class="st on">● MARS\'I İZLİYOR</span>')
        : T('<span class="st err">● SİNYAL YOK</span>')
      : T('<span class="st">BEKLEMEDE</span>');
    const el = on ? Math.round(32 + 26 * Math.sin((((h % 8) * 60 + mi) / 480) * Math.PI)) : null;
    return Tf(
      `<div class="gs-card gs-st {0}">{1}<h5>{2}</h5><div class="loc">📍 {3} · {4}</div>
      <dl class="gs-dl"><dt>Enlem</dt><dd>{5}</dd><dt>Boylam</dt><dd>{6}</dd><dt>Rakım</dt><dd>{7}</dd><dt>Çanak anten</dt><dd>{8} · ışın kılavuzlu</dd>
      <dt>Gönderme</dt><dd>{9} bant</dd><dt>Alma</dt><dd>{10} bant</dd><dt>Hizmete giriş</dt><dd>{11}</dd>
      {12}</dl></div>`,
      [
        on ? "gs-on" : "",
        tag,
        S.nm,
        S.cc,
        S.place,
        S.lat,
        S.lon,
        S.alt,
        S.dish,
        S.up,
        S.down,
        S.year,
        on
          ? Tf(`<dt>Mars yükseliş açısı</dt><dd>{0}°</dd><dt>Veri hızı</dt><dd>{1}</dd>`, [
              el,
              L.ok ? fmtN(desFx().commsCap / 24, 1) + " MB/sa" : "—",
            ])
          : "",
      ],
    );
  }).join("");
  const ctr = GS_CENTERS.map(
    (c) =>
      `<div class="gs-card"><span class="role">${c.role}</span><h5>${c.nm}</h5><div class="loc">📍 ${c.loc}</div><ul>${c.li.map((x) => `<li>${x}</li>`).join("")}</ul></div>`,
  ).join("");
  const node = (ic, nm, sub, cls) =>
    `<div class="gs-node ${cls}"><i>${ic}</i><b>${nm}</b><small>${sub}</small></div>`;
  const arr = (lbl, ok) => `<div class="gs-ar ${ok ? "" : "off"}"><span>${lbl}</span>${ok ? "➜" : "✕"}</div>`;
  return Tf(
    `<div class="gs">
    <div class="gs-hero"><div class="gs-mk">ARES</div><div><b>YER BİRİMİ · ARES-1</b>
      <p>Yer birimi; iletişim, veri alımı ve görev yönetiminden sorumlu yer istasyonları ve görev kontrol merkezlerinden oluşur. ARES-1, boylamda yaklaşık 120° aralıklı üç gerçek 35 m derin uzay anteniyle (New Norcia, Cebreros, Malargüe) Dünya döndükçe kesintisiz izlenir.</p></div></div>
    <div class="gs-sec">Veri yolu</div>
    <div class="gs-path">
      {0}{1}
      {2}{3}
      {4}{5}
      {6}{7}
      {8}
    </div>
    <div class="gs-sec">Röle uydusu · konum ve yörünge</div>
    {9}
    <div class="gs-kv">
      <div><span>Bağlantı</span><b style="color:{10}">{11}</b></div>
      <div><span>Işık gecikmesi</span><b>{12} dk</b></div>
      <div><span>Gönderilen veri</span><b>{13} MB</b></div>
      <div><span>Alınan mesaj</span><b>{14}</b></div></div>
    <div class="gs-sec">Yer istasyonları</div>
    <div class="gs-grid">{15}</div>
    <div class="gs-kv" style="grid-template-columns:repeat(3,1fr)">
      <div><span>Aktif istasyon</span><b>{16}</b></div>
      <div><span>Sonraki devir</span><b>{17} · {18}</b></div>
      <div><span>Veri kapasitesi</span><b>{19} MB/sol</b></div></div>
    <div class="gs-sec">Görev kontrol merkezleri</div>
    <div class="gs-grid">{20}</div>
  </div>`,
    [
      node("🚀", "ARES-1", T("Mars yüzeyi · yüksek kazançlı anten"), "on"),
      arr(T("X-bant"), L.ok),
      node("📡", GS_STATIONS[act].nm, "Yer istasyonu", L.ok ? "on" : "off"),
      arr("", true),
      node("🛰️", T("İstasyon ağı"), T("İletişim operasyonu"), ""),
      arr("", true),
      node("🎛️", T("Görev Kontrol"), T("Görev yönetimi"), ""),
      arr("", true),
      node("🔬", T("Bilim ekipleri"), T("Kullanıcı segmenti"), ""),
      satHTML(),
      L.ok ? "#4ade80" : "#ff8a8a",
      L.ok ? T("AKTİF") : T("KESİK"),
      fmtN(ld),
      fmtN(mb),
      rcv,
      st,
      GS_STATIONS[act].nm,
      GS_STATIONS[(act + 1) % 3].nm,
      gDur(toNext),
      fmtN(desFx().commsCap),
      ctr,
    ],
  );
}
function commLinkState() {
  if (scene === "earth") return { ok: false, cls: "err", txt: T("YEREL AĞ") };
  if (stormFx.phase === "active")
    return desFx().relay
      ? { ok: true, cls: "warn", txt: T("RÖLE UYDUSU") }
      : { ok: false, cls: "err", txt: T("ANTEN TOZLA KAPALI") };
  if (game.radiationActive)
    return { ok: true, cls: "warn", txt: T("PARAZİT · ") + dsnStation(game.worldTime) };
  return {
    ok: true,
    cls: "ok",
    txt: dsnStation(game.worldTime) + " · " + fmtN(lightDelay(game.worldTime)) + T(" dk"),
  };
}
function draftItems() {
  return commUnsent().filter((o) => !commDraft.off.has(o.id));
}
function packetMB(items, note) {
  return 0.35 + items.reduce((s, o) => s + OBS_DEF[o.type].w * 0.21, 0) + note.length * 0.0024;
}
function sendReport() {
  const C = commState(),
    items = draftItems(),
    note = commDraft.note.trim();
  if (!items.length && !note) {
    sfx("error");
    toast(T("Gönderilecek bir şey yok — gözlem seç ya da not yaz"));
    return;
  }
  const L = commLinkState();
  if (!L.ok) {
    sfx("error");
    toast(T("📡 Toz fırtınası yüksek kazançlı anteni kör ediyor — fırtına geçince gönder"));
    return;
  }
  const wt = game.worldTime,
    sols = (commDraft.prio === "acil" ? 0.25 : 0.5) * desFx().replyMul;
  const r = {
    id: "RPR-" + pad3(C.seq.rpr++),
    t: wt,
    sol: solOf(wt),
    prio: commDraft.prio,
    note,
    items: items.map((o) => JSON.parse(JSON.stringify(o))),
    mb: packetMB(items, note) * (game.radiationActive ? 1.15 : 1),
    dsn: dsnStation(wt),
    ackAt: wt + lightDelay(wt) / GAME_MIN,
    arriveAt: wt + sols * DAY_SECONDS * (0.85 + Math.random() * 0.3),
    replied: false,
  };
  C.sent.unshift(r);
  C.lastRpt = solOf(wt);
  bumpQuest("reported");
  if (note) {
    C.aiQ = C.aiQ || [];
    C.aiQ.push({ at: wt + (2 * lightDelay(wt) + 6) / GAME_MIN, rid: r.id, note, st: dsnStation(wt) });
    setTimeout(() => {
      if (game)
        toast(
          T("Notun GDY-1'e iletildi — yanıt ~") +
            gDur((2 * lightDelay(wt) + 6) / GAME_MIN) +
            T(" içinde gelen kutunda"),
        );
    }, 1600);
  }
  if (
    game.qstats.rotSeen > 0 &&
    (items.some((o) => o.type === "rot") ||
      /çürü|curu|rotten|\brot\b|rotting|verfault|faul|podrid|pudri/.test(note.toLocaleLowerCase()))
  ) {
    bumpQuest("rotReport");
  }
  items.forEach((o) => (o.sent = true));
  commDraft.note = "";
  commDraft.off.clear();
  commDraft.prio = "rutin";
  commTx = { r, t0: performance.now(), dur: 4600 };
  sfx("click");
  [0, 0.35, 0.7, 1.05].forEach((d, i) => tone(660 + i * 110, 0.08, "square", 0.04, 0, d));
  noiseBurst(1.6, 0.05, 5200, 0.4);
  renderComm();
  const step = () => {
    if (!commTx) return;
    const k = Math.min(1, (performance.now() - commTx.t0) / commTx.dur);
    const el = $("cmTx");
    if (el) {
      el.querySelector(".cm-txbar i").style.width = k * 100 + "%";
      el.querySelectorAll(".cm-txlog li").forEach((li, i) => li.classList.toggle("on", k >= i / 6));
      el.querySelector(".cm-txpct").textContent = Math.round(k * 100) + "%";
    }
    if (k < 1) requestAnimationFrame(step);
    else {
      tone(1320, 0.18, "sine", 0.09);
      tone(1760, 0.25, "sine", 0.07, 0, 0.16);
      setTimeout(() => {
        const done = commTx;
        commTx = null;
        if (commOpen) {
          commTab = "sent";
          renderComm();
        }
        if (done)
          toast(
            "📡 <b>" +
              done.r.id +
              T("</b> Dünya'ya iletildi · yanıt beklenen: <b>") +
              solStamp(done.r.arriveAt) +
              "</b>",
          );
      }, 700);
    }
  };
  requestAnimationFrame(step);
}

/* ---------- arayüz ---------- */
function openComm() {
  commOpen = true;
  commState();
  commSel = null;
  if (commUnread() > 0) commTab = "inbox";
  $("commScreen").classList.remove("hidden");
  sfx("click");
  tone(520, 0.06, "square", 0.04);
  tone(780, 0.08, "square", 0.04, 0, 0.07);
  renderComm();
}
function closeComm() {
  if (commTx) {
    commTx = null;
  }
  commOpen = false;
  $("commScreen").classList.add("hidden");
  focusGame();
}
function updateCommChip() {
  const L = commLinkState(),
    ch = $("cmChip");
  if (!ch) return;
  ch.className = "con-chip cm-link " + L.cls;
  ch.innerHTML = "<i></i>" + L.txt;
  const u = commUnread();
  $("cmTabIn").innerHTML = T("📥 Gelen kutusu") + (u ? ` <em>${u}</em>` : "");
  const n = commUnsent().length;
  $("cmTabWr").innerHTML = T("📝 Rapor hazırla") + (n ? ` <em class="g">${n}</em>` : "");
  const pn = commPending().length;
  $("cmTabSt").innerHTML = T("📤 Gönderilenler") + (pn ? ` <em class="b">${pn}</em>` : "");
  const sm = $("cmSum");
  if (sm) sm.innerHTML = draftSummary();
  const sb = $("cmSend");
  if (sb) {
    sb.disabled = !L.ok || (!draftItems().length && !commDraft.note.trim());
    sb.textContent = L.ok ? T("📡 Dünya'ya gönder") : T("📡 Anten kapalı — fırtına bekleniyor");
  }
}
function draftSummary() {
  const items = draftItems(),
    note = commDraft.note.trim(),
    wt = game.worldTime,
    sols = (commDraft.prio === "acil" ? 0.25 : 0.5) * desFx().replyMul;
  if (!items.length && !note) return Tf(`<span class="mut">Raporda henüz içerik yok.</span>`, []);
  return Tf(
    `<div><span>İçerik</span><b>{0} gözlem{1}</b></div>
    <div><span>Paket</span><b>{2} MB</b></div>
    <div><span>Işık gecikmesi</span><b>~{3} dk</b></div>
    <div><span>Tahmini yanıt</span><b>Sol {4} civarı</b></div>`,
    [
      items.length,
      note ? T(" + not") : "",
      fmtN(packetMB(items, note)),
      fmtN(lightDelay(wt)),
      solOf(wt + sols * DAY_SECONDS),
    ],
  );
}
function renderComm() {
  const C = commState(),
    body = $("cmBody");
  ["write", "inbox", "sent", "ground", "arch"].forEach((k) =>
    $("cmTab" + { write: "Wr", inbox: "In", sent: "St", ground: "Gs", arch: "Ar" }[k]).classList.toggle(
      "on",
      commTab === k,
    ),
  );
  if (commTx) {
    const r = commTx.r;
    const lines = [
      T("Yüksek kazançlı anten Dünya'ya hizalanıyor…"),
      r.dsn + " kilitlendi",
      T("Paket sıkıştırılıyor ve AES-256 ile şifreleniyor…"),
      r.items.length +
        T(" gözlem kaydı + ") +
        (r.note ? T("mürettebat notu") : T("not yok")) +
        T(" paketlendi"),
      T("X-bandı iletim · ") + fmtN(r.mb) + " MB",
      T("İletim tamamlandı · ışık gecikmesi ~") + fmtN(lightDelay(r.t)) + T(" dk"),
    ];
    body.innerHTML = `<div class="cm-tx" id="cmTx">
      <svg viewBox="0 0 220 120" class="cm-dish"><defs><radialGradient id="cmG" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#5ad1ff" stop-opacity=".5"/><stop offset="1" stop-color="#5ad1ff" stop-opacity="0"/></radialGradient></defs>
        <circle cx="200" cy="20" r="10" fill="#3b82f6"/><circle cx="197" cy="17" r="4" fill="#4ade80"/>
        <g class="cm-waves">${[0, 1, 2, 3].map((i) => `<path d="M${70 + i * 14} ${72 - i * 8} q${10 + i * 3} ${-14 - i * 2} ${26 + i * 6} ${-22 - i * 4}" style="animation-delay:${i * 0.25}s"/>`).join("")}</g>
        <path d="M30 100 L60 70" stroke="#8d94b2" stroke-width="4"/><ellipse cx="62" cy="62" rx="26" ry="11" transform="rotate(-38 62 62)" fill="#c9d2e0" stroke="#5b6178" stroke-width="2"/>
        <circle cx="68" cy="58" r="3" fill="#ff8c42"/><rect x="14" y="100" width="40" height="10" rx="3" fill="#5b6178"/></svg>
      <div class="cm-txh"><b>${r.id}</b> iletiliyor<span class="cm-txpct">0%</span></div>
      <div class="cm-txbar"><i></i></div>
      <ul class="cm-txlog">${lines.map((l) => `<li>${escH(l)}</li>`).join("")}</ul></div>`;
    updateCommChip();
    return;
  }
  if (commTab === "write") {
    const L = commUnsent().slice().reverse();
    const obs = L.length
      ? L.map((o) => {
          const D = OBS_DEF[o.type],
            b = SEV_BADGE[D.sev];
          return `<label class="cm-ob ${commDraft.off.has(o.id) ? "off" : ""}"><input type="checkbox" data-id="${o.id}" ${commDraft.off.has(o.id) ? "" : "checked"}>
        <span class="ic">${D.ic}</span><div class="tx"><b>${D.nm}</b> <em>Sol ${o.day} · ${marsClock(o.t)}</em><small>${obsDetail(o)}</small></div>
        <span class="badge ${b[0]}">${b[1]}</span></label>`;
        }).join("")
      : Tf(
          `<div class="cm-empty">📭 Saha günlüğünde gönderilmemiş kayıt yok.<br><small>Fırtına, radyasyon, meteor, arıza, numune toplama, tarım ve kritik yaşam değerleri burada otomatik kaydedilir.</small></div>`,
          [],
        );
    const quick = [
      ...(game.qstats.rotSeen > 0 ? [T("Patatesler çürüdü, neden olabilir?")] : []),
      T("Motordan duman geliyor, ne yapmalıyım?"),
      T("Erzak azalıyor"),
      T("Fırtınada roket çok sarsıldı"),
      T("Radyasyon sırasında dışarıda kaldım"),
      T("Kendimi yalnız hissediyorum"),
      T("Ne zaman Dünya'ya dönebilirim?"),
    ];
    body.innerHTML = Tf(
      `<div class="cm-cols">
      <div class="cm-col"><div class="con-sec">Saha günlüğü · {0} kayıt</div><div class="cm-obs">{1}</div></div>
      <div class="cm-col"><div class="con-sec">Mürettebat notu</div>
        <textarea id="cmNote" maxlength="500" placeholder="Yaşadığın sorunları, gözlemlerini ya da sorularını yaz…">{2}</textarea>
        <div class="cm-quick">{3}</div>
        <div class="con-sec">Öncelik</div>
        <div class="cm-prio"><button data-p="rutin" class="{4}">RUTİN<small>yanıt ≈ ½ sol</small></button><button data-p="acil" class="acil {5}">ACİL<small>yanıt ≈ ¼ sol</small></button></div>
        <div class="cm-sum" id="cmSum"></div>
        <button class="cbtn pri wide" id="cmSend">📡 Dünya'ya gönder</button></div></div>`,
      [
        L.length,
        obs,
        escH(commDraft.note),
        quick.map((q) => `<button class="chip" data-q="${escH(q)}">+ ${escH(q)}</button>`).join(""),
        commDraft.prio === "rutin" ? "on" : "",
        commDraft.prio === "acil" ? "on" : "",
      ],
    );
    body.querySelectorAll(".cm-ob input").forEach(
      (cb) =>
        (cb.onchange = () => {
          if (cb.checked) commDraft.off.delete(cb.dataset.id);
          else commDraft.off.add(cb.dataset.id);
          cb.closest(".cm-ob").classList.toggle("off", !cb.checked);
          updateCommChip();
        }),
    );
    const ta = $("cmNote");
    ta.oninput = () => {
      commDraft.note = ta.value;
      updateCommChip();
    };
    body.querySelectorAll(".cm-quick .chip").forEach(
      (b) =>
        (b.onclick = () => {
          const q = b.dataset.q;
          commDraft.note = (commDraft.note.trim() ? commDraft.note.trim() + " " : "") + q;
          ta.value = commDraft.note.slice(0, 500);
          commDraft.note = ta.value;
          ta.focus();
          updateCommChip();
          sfx("click");
        }),
    );
    body.querySelectorAll(".cm-prio button").forEach(
      (b) =>
        (b.onclick = () => {
          commDraft.prio = b.dataset.p;
          body.querySelectorAll(".cm-prio button").forEach((x) => x.classList.toggle("on", x === b));
          updateCommChip();
          sfx("click");
        }),
    );
    $("cmSend").onclick = sendReport;
  } else if (commTab === "inbox") {
    const M = C.inbox;
    if (!commSel || !M.some((m) => m.id === commSel))
      commSel = (M.find((m) => !m.read) || M[0] || {}).id || null;
    const cur = M.find((m) => m.id === commSel);
    if (cur && !cur.read) {
      cur.read = true;
      updateCommBadge();
      if (cur.kind === "reply") setTimeout(() => bumpQuest("replyRead"), 300);
    }
    if (cur && cur.kind === "lab") setTimeout(() => unlockMeter(), 400);
    const tag = (m) =>
      ({
        reply: [T("YANIT"), ""],
        bulletin: [T("BÜLTEN"), "st"],
        alert: [T("UYARI"), "al"],
        brief: [T("BRİFİNG"), "br"],
        req: [T("TALEP"), "al"],
        lab: [T("ANALİZ"), "br"],
        rock: [T("ANALİZ"), "br"],
        ai: [T("YZ YANITI"), "ai"],
      })[m.kind] || [T("MESAJ"), ""];
    body.innerHTML = M.length
      ? `<div class="cm-inbox"><div class="cm-list">${M.map((m) => {
          const g = tag(m);
          return `<div class="cm-it ${m.read ? "" : "unread"} ${m.id === commSel ? "sel" : ""}" data-id="${m.id}"><span class="dot"></span>
        <div class="tx"><b>${escH(m.subject)}</b><small>${escH(m.from)} · ${solStamp(m.t)}</small></div><span class="tag ${g[1]} ${m.prio === "acil" ? "al" : ""}">${m.prio === "acil" ? T("ACİL") : g[0]}</span></div>`;
        }).join("")}</div>
      <div class="cm-read" id="cmRead">${cur ? cur.html : ""}</div></div>`
      : Tf(
          `<div class="cm-empty">📭 Gelen kutusu boş.<br><small>Görev Kontrol'ün brifingleri, bültenleri ve raporlarına verdiği yanıtlar burada görünür.</small></div>`,
          [],
        );
    body.querySelectorAll(".cm-it").forEach(
      (it) =>
        (it.onclick = () => {
          commSel = it.dataset.id;
          sfx("click");
          renderComm();
          const rd = $("cmRead");
          if (rd) rd.scrollTop = 0;
        }),
    );
  } else if (commTab === "arch") {
    body.innerHTML = archHTML(C);
  } else if (commTab === "ground") {
    body.innerHTML = groundSegmentHTML(C);
  } else {
    const wt = game.worldTime,
      S = C.sent;
    body.innerHTML = S.length
      ? `<div class="cm-sent">${S.map((r) => {
          const ack = wt >= r.ackAt,
            rev = wt >= r.ackAt + DAY_SECONDS * 0.08,
            done = r.replied;
          const stp = [
            [T("Gönderildi"), true],
            [T("Dünya'ya ulaştı"), ack],
            [T("İnceleniyor"), rev],
            [T("Yanıt geldi"), done],
          ];
          const left = Math.max(0, r.arriveAt - wt);
          return `<div class="cm-rp"><div class="cm-rph"><b>${r.id}</b>${r.prio === "acil" ? T('<span class="badge err">ACİL</span>') : T('<span class="badge mute">RUTİN</span>')}<span class="mut">${solStamp(r.t)} · ${fmtN(r.mb)} MB · ${escH(r.dsn)}</span></div>
        <div class="cm-pipe">${stp.map(([n, on], i) => `<span class="${on ? "on" : ""}">${on ? "✓" : i + 1} ${n}</span>`).join("<i></i>")}</div>
        <div class="cm-rpc">${r.items.map((o) => `<span class="chip">${OBS_DEF[o.type].ic} ${OBS_DEF[o.type].nm}</span>`).join("")}${r.note ? `<span class="chip">✍ “${escH(r.note.length > 48 ? r.note.slice(0, 48) + "…" : r.note)}”</span>` : ""}</div>
        <div class="cm-eta">${done ? T("📨 Yanıt gelen kutunda") : Tf(`⏳ Yanıt bekleniyor · <b>{0}</b> civarı · kalan ~{1} (oyun saati)`, [solStamp(r.arriveAt), gDur(left)])}</div></div>`;
        }).join("")}</div>`
      : Tf(
          `<div class="cm-empty">📤 Henüz rapor göndermedin.<br><small>“Rapor hazırla” sekmesinden saha günlüğünü ve notunu Dünya'ya ilet.</small></div>`,
          [],
        );
  }
  updateCommChip();
}
$("cmTabWr").onclick = () => {
  if (commTx) return;
  commTab = "write";
  sfx("click");
  renderComm();
};
$("cmTabIn").onclick = () => {
  if (commTx) return;
  commTab = "inbox";
  sfx("click");
  renderComm();
};
$("cmTabSt").onclick = () => {
  if (commTx) return;
  commTab = "sent";
  sfx("click");
  renderComm();
};
$("cmTabGs").onclick = () => {
  if (commTx) return;
  commTab = "ground";
  sfx("click");
  renderComm();
};
$("cmTabAr").onclick = () => {
  if (commTx) return;
  commTab = "arch";
  sfx("click");
  renderComm();
};
$("cmX").onclick = () => closeComm();
$("ugX").onclick = () => closeUpg();
document.querySelectorAll("#upgScreen .ug-tabs button").forEach(
  (b) =>
    (b.onclick = () => {
      upgTab = b.dataset.t;
      upgSel = null;
      sfx("click");
      renderUpg();
    }),
);
function updateCommBadge() {
  const b = $("commBadge");
  if (!b) return;
  if (!game || mode !== "play" || scene === "earth") {
    b.classList.add("hidden");
    return;
  }
  const u = commUnread(),
    pn = commPending(),
    un = commUnsent().length;
  let h = "",
    cls = "";
  if (u) {
    h = Tf(
      `<span class="ci">📨</span><div><b>Dünya'dan {0} yeni mesaj</b><small>Komuta güvertesi · iletişim terminali</small></div>`,
      [u],
    );
    cls = "new";
  } else if (pn.length) {
    const nx = pn.reduce((a, r) => Math.min(a, r.arriveAt), 1e12);
    h = Tf(`<span class="ci">📡</span><div><b>Yanıt bekleniyor</b><small>{0} civarı</small></div>`, [
      solStamp(nx),
    ]);
    cls = "wait";
  } else if (un >= 1) {
    h = Tf(
      `<span class="ci">📝</span><div><b>{0} gözlem rapor bekliyor</b><small>İletişim terminalinden gönder</small></div>`,
      [un],
    );
    cls = "log";
  }
  if (!h) {
    b.classList.add("hidden");
    return;
  }
  const MW = mapW();
  b.style.top = 14 + MW + 36 + "px";
  b.style.width = MW + 10 + "px";
  b.className = cls;
  b.innerHTML = h;
}

/* ============== AÇILIŞ SİNEMASI — "ARES-1" ==============
   ARES programı: tek kişilik mürettebat Dünya'dan Mars'a gider,
   görevi Mars'taki yaşam koşullarını inceleyip Dünya'ya aktarmaktır.
   Tamamen kod ile çizilir (canvas) ve WebAudio ile seslendirilir.
   Space/Enter basılı tut ya da "Geç" ile atlanır. */
const INTRO_LEN = 92;
let intro = null;
const IC = {
  // altyazılar
  caps: [
    [0.9, 6.6, "", T("İnsanlık binlerce yıldır gece gökyüzündeki o kızıl noktaya baktı.")],
    [7.3, 11.4, "", T("Şimdi, ilk kez bir insan oraya gidiyor.")],
    [11.8, 15.6, "", T("Tek başına.")],
    [
      16.6,
      21.5,
      T("UÇUŞ DİREKTÖRÜ · GÖREV KONTROL"),
      T("ARES-1 görevi onaylandı. Mürettebat: tek kişi. Komutan sensin."),
    ],
    [
      21.8,
      26.3,
      T("UÇUŞ DİREKTÖRÜ · GÖREV KONTROL"),
      T("Görevin: Mars'a in, oradaki yaşam koşullarını incele ve her bulguyu Dünya'ya aktar."),
    ],
    [
      26.6,
      29.8,
      T("UÇUŞ DİREKTÖRÜ · GÖREV KONTROL"),
      T("Orada yalnız olacaksın. Ama biz seni her an dinliyor olacağız."),
    ],
    [
      31.0,
      35.6,
      T("YER İSTASYONU AĞI"),
      T("A, B ve C istasyonları hazır. Yolculuk boyunca üç istasyon seni sırayla izleyecek."),
    ],
    [40.4, 42.0, T("KALKIŞ KONTROL"), T("Tüm sistemler hazır. Geri sayım başladı.")],
    [54.0, 57.0, T("GÖREV KONTROL"), T("Kalkış! ARES-1 kuleden ayrıldı.")],
    [58.0, 61.7, T("GÖREV KONTROL"), T("Yörüngeye giriş nominal. Mars yolu açık. İyi yolculuklar, Komutan.")],
    [62.6, 65.6, T("KOMUTANIN GÜNLÜĞÜ"), T("Gün 12 — Dünya artık başparmağımın arkasına sığıyor.")],
    [
      65.8,
      68.8,
      T("KOMUTANIN GÜNLÜĞÜ"),
      T("Gün 97 — Buradaki tek ses, Görev Kontrol'den gelen cızırtılı mesajlar."),
    ],
    [
      69.0,
      71.8,
      T("KOMUTANIN GÜNLÜĞÜ"),
      T("Gün 211 — Kızıl gezegen pencereyi dolduruyor. Neredeyse geldim."),
    ],
    [72.6, 75.9, T("GÖREV KONTROL"), T("ARES-1, atmosfere girişe hazırlan. Isı kalkanı devrede.")],
    [76.2, 78.9, T("GÖREV KONTROL"), T("Isı kalkanı 1.600 °C… sinyal… kesil—")],
    [79.3, 82.4, "ARES-1", T("Retro motorlar ateşlendi… 40 metre… 20… 10…")],
    [
      83.4,
      86.8,
      T("GÖREV KONTROL"),
      T(
        "ARES-1, burası Görev Kontrol. A istasyonu sinyalini aldı, inişini doğruluyoruz. Mars'a hoş geldin, Komutan.",
      ),
    ],
  ],
  chapters: [
    [0, "I", T("DÜNYA")],
    [16, "II", T("GÖREV KONTROL")],
    [30, "III", T("GÖREV DOSYASI")],
    [40, "IV", T("KALKIŞ")],
    [62, "V", T("YOLCULUK · 214 GÜN")],
    [72, "VI", T("MARS")],
  ],
};

/* ---------- ultra renk düzenleme (sahneye göre sinematik grade + bloom + anamorfik parlama) ---------- */
const IGRADE = [
  // [bitiş zamanı, üst renk, alt renk, grade gücü, bloom, parlama çizgisi]
  [16, [40, 90, 140], [255, 170, 110], 0.3, 0.55, 0.35], // Dünya: soğuk mavi gölge, sıcak güneş
  [30, [20, 110, 130], [40, 60, 90], 0.26, 0.35, 0.15], // Görev kontrol: camgöbeği monitör ışığı
  [40, [30, 90, 140], [20, 40, 70], 0.24, 0.3, 0.12], // Görev dosyası
  [57, [30, 70, 110], [255, 150, 70], 0.34, 0.7, 0.45], // Kalkış: gece mavisi + motor alevi
  [62, [30, 60, 120], [255, 170, 90], 0.3, 0.6, 0.4], // Yükseliş
  [72, [50, 40, 120], [30, 80, 140], 0.28, 0.5, 0.4], // Yolculuk: derin uzay moru
  [79, [120, 40, 30], [255, 120, 60], 0.34, 0.75, 0.35], // Atmosfere giriş: ısı kalkanı
  [999, [110, 70, 60], [255, 180, 120], 0.3, 0.45, 0.25],
]; // Mars yüzeyi: amber toz
function iPost(t) {
  if (settings.ultra === false) return;
  const cv = ctx.canvas,
    G = IGRADE.find((g) => t < g[0]);
  const P = intro.pp || (intro.pp = { a: mbCanvas(1, 1), b: mbCanvas(1, 1), s: mbCanvas(1, 1) });
  const bw = Math.max(48, Math.round(W / 5)),
    bh = Math.max(28, Math.round(H / 5)),
    sw = Math.max(10, Math.round(W / 40));
  if (P.a.width !== bw || P.a.height !== bh) {
    P.a.width = bw;
    P.a.height = bh;
    P.b.width = Math.max(8, Math.round(bw / 4));
    P.b.height = Math.max(6, Math.round(bh / 4));
    P.s.width = sw;
    P.s.height = bh;
  }
  ctx.save();
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  // 1) renk düzenleme: gölgelere soğuk, ışıklara sıcak ton (soft-light)
  const gr = ctx.createLinearGradient(0, 0, 0, H);
  gr.addColorStop(0, `rgb(${G[1]})`);
  gr.addColorStop(1, `rgb(${G[2]})`);
  ctx.globalCompositeOperation = "soft-light";
  ctx.globalAlpha = G[3];
  ctx.fillStyle = gr;
  ctx.fillRect(0, 0, W, H);
  // 2) parlak alanları ayıkla (x⁴ ile eşik) → bulanıklaştır → ekrana ekle (bloom)
  const a = P.a.getContext("2d");
  a.globalCompositeOperation = "source-over";
  a.globalAlpha = 1;
  a.imageSmoothingQuality = "high";
  a.clearRect(0, 0, bw, bh);
  a.drawImage(cv, 0, 0, bw, bh);
  a.globalCompositeOperation = "multiply";
  a.drawImage(P.a, 0, 0);
  a.drawImage(P.a, 0, 0);
  const b = P.b.getContext("2d");
  b.globalCompositeOperation = "source-over";
  b.clearRect(0, 0, P.b.width, P.b.height);
  b.imageSmoothingQuality = "high";
  b.drawImage(P.a, 0, 0, P.b.width, P.b.height);
  ctx.imageSmoothingEnabled = true;
  ctx.globalCompositeOperation = "screen";
  ctx.globalAlpha = G[4];
  ctx.drawImage(P.b, 0, 0, W, H);
  ctx.globalAlpha = G[4] * 0.6;
  ctx.drawImage(P.a, 0, 0, W, H);
  // 3) anamorfik parlama: parlak noktaları yatayda uzat, maviye boya
  if (G[5] > 0) {
    const s = P.s.getContext("2d");
    s.globalCompositeOperation = "source-over";
    s.globalAlpha = 1;
    s.clearRect(0, 0, sw, bh);
    s.drawImage(P.a, 0, 0, sw, bh);
    s.globalCompositeOperation = "multiply";
    s.fillStyle = "rgb(110,170,255)";
    s.fillRect(0, 0, sw, bh);
    ctx.globalAlpha = G[5];
    ctx.drawImage(P.s, 0, 0, W, H);
  }
  // 4) hafif renk sapması kenar ışığı (kenarlarda kırmızı/mavi saçak hissi)
  ctx.globalCompositeOperation = "source-over";
  ctx.globalAlpha = 1;
  const e = ctx.createRadialGradient(
    W / 2,
    H / 2,
    Math.min(W, H) * 0.45,
    W / 2,
    H / 2,
    Math.max(W, H) * 0.78,
  );
  e.addColorStop(0, "rgba(0,0,0,0)");
  e.addColorStop(1, `rgba(${G[1]},.18)`);
  ctx.fillStyle = e;
  ctx.fillRect(0, 0, W, H);
  ctx.restore();
}
/* ---------- ses ---------- */
function iNow() {
  return AU.ac ? AU.ac.currentTime : 0;
}
function iNoiseBuf() {
  if (!intro.nb) {
    const ac = AU.ac,
      n = ac.sampleRate * 2,
      b = ac.createBuffer(1, n, ac.sampleRate),
      d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    intro.nb = b;
  }
  return intro.nb;
}
function iTone(f, t, dur, o) {
  if (!intro || !intro.mg) return;
  o = o || {};
  const ac = AU.ac,
    os = ac.createOscillator(),
    g = ac.createGain(),
    a = o.a != null ? o.a : 0.01,
    r = o.r != null ? o.r : 0.2,
    v = o.v || 0.1;
  os.type = o.type || "sine";
  os.frequency.setValueAtTime(f, t);
  if (o.to) os.frequency.exponentialRampToValueAtTime(o.to, t + dur);
  if (o.det) os.detune.value = o.det;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(v, t + a);
  g.gain.setValueAtTime(v, t + Math.max(a, dur - r));
  g.gain.linearRampToValueAtTime(0.0001, t + dur);
  let last = os;
  if (o.lp) {
    const fl = ac.createBiquadFilter();
    fl.type = "lowpass";
    fl.frequency.value = o.lp;
    fl.Q.value = o.q || 0.7;
    if (o.lp2) fl.frequency.linearRampToValueAtTime(o.lp2, t + dur * 0.5);
    os.connect(fl);
    last = fl;
  }
  last.connect(g);
  g.connect(o.sfx ? intro.sg : intro.mg);
  os.start(t);
  os.stop(t + dur + 0.05);
}
function iNoise(t, dur, o) {
  if (!intro || !intro.sg) return;
  o = o || {};
  const ac = AU.ac,
    src = ac.createBufferSource(),
    fl = ac.createBiquadFilter(),
    g = ac.createGain(),
    a = o.a != null ? o.a : 0.01,
    r = o.r != null ? o.r : 0.2,
    v = o.v || 0.1;
  src.buffer = iNoiseBuf();
  src.loop = true;
  fl.type = o.type || "lowpass";
  fl.frequency.setValueAtTime(o.f || 800, t);
  if (o.f2) fl.frequency.exponentialRampToValueAtTime(o.f2, t + (o.fd || dur));
  fl.Q.value = o.q || 0.8;
  g.gain.setValueAtTime(0.0001, t);
  g.gain.linearRampToValueAtTime(v, t + a);
  g.gain.setValueAtTime(v, t + Math.max(a, dur - r));
  g.gain.linearRampToValueAtTime(0.0001, t + dur);
  src.connect(fl);
  fl.connect(g);
  g.connect(o.mus ? intro.mg : intro.sg);
  src.start(t, Math.random() * 1.5);
  src.stop(t + dur + 0.05);
}
const iM = (n) => 440 * Math.pow(2, (n - 69) / 12);
function iPad(notes, t, dur, v) {
  notes.forEach((n) => {
    [-8, 7].forEach((d) =>
      iTone(iM(n), t, dur, {
        type: "sawtooth",
        det: d,
        a: Math.min(2.2, dur * 0.35),
        r: Math.min(2.5, dur * 0.4),
        v: v || 0.018,
        lp: 500,
        lp2: 1300,
      }),
    );
  });
}
function iBell(n, t, v) {
  iTone(iM(n), t, 2.6, { a: 0.005, r: 2.5, v: v || 0.05 });
  iTone(iM(n) * 2.01, t, 1.2, { a: 0.005, r: 1.1, v: (v || 0.05) * 0.35, type: "triangle" });
}
function iQuindar(t) {
  iTone(2525, t, 0.24, { a: 0.005, r: 0.02, v: 0.035, sfx: true });
}
function iRadio(t, d) {
  iQuindar(t);
  iNoise(t + 0.25, d || 0.35, { type: "bandpass", f: 1900, q: 1.1, v: 0.05, a: 0.02, r: 0.15 });
}
function iBoom(t, v) {
  iTone(95, t, 1.6, { to: 28, a: 0.005, r: 1.4, v: v || 0.5, sfx: true });
  iNoise(t, 1.4, { f: 500, f2: 80, v: (v || 0.5) * 0.5, a: 0.005, r: 1.2 });
}
function iThud(t) {
  iTone(80, t, 0.5, { to: 38, a: 0.003, r: 0.45, v: 0.35, sfx: true });
  iNoise(t, 0.25, { f: 900, f2: 120, v: 0.18, a: 0.002, r: 0.2 });
}
function iTick(t) {
  iNoise(t, 0.03, { type: "highpass", f: 3500, v: 0.05, a: 0.001, r: 0.02 });
}
function introCues() {
  const C = [];
  // I · Dünya
  C.push([
    0.05,
    (t) => {
      iTone(55, t, 17, { type: "sawtooth", a: 4, r: 4, v: 0.05, lp: 180 });
      iTone(110, t, 17, { a: 5, r: 4, v: 0.03 });
      iPad([57, 60, 64], t + 0.5, 8, 0.016);
    },
  ]);
  C.push([
    5.8,
    (t) => {
      iNoise(t, 3.2, { type: "bandpass", f: 600, f2: 3000, q: 0.6, v: 0.05, a: 2.4, r: 0.5, mus: true });
    },
  ]);
  C.push([
    7.6,
    (t) => {
      iPad([53, 57, 60, 65], t, 8.5, 0.017);
      iBell(76, t + 0.4);
      iBell(81, t + 1.9, 0.04);
      iBell(83, t + 3.4, 0.035);
      iTone(41.2, t, 8, { type: "sine", a: 0.05, r: 6, v: 0.12 });
    },
  ]);
  C.push([
    12,
    (t) => {
      iBell(88, t, 0.03);
      iBell(84, t + 1.2, 0.026);
    },
  ]);
  // II · Görev kontrol
  C.push([
    16.2,
    (t) => {
      iPad([50, 57, 62, 65], t, 7, 0.014);
      for (let i = 0; i < 27; i++)
        iTone(i % 4 ? 660 : 880, t + i * 0.5, 0.05, {
          a: 0.002,
          r: 0.04,
          v: i % 4 ? 0.008 : 0.014,
          type: "square",
          lp: 2200,
        });
    },
  ]);
  C.push([16.5, (t) => iRadio(t)]);
  C.push([21.7, (t) => iRadio(t, 0.2)]);
  C.push([26.5, (t) => iRadio(t, 0.2)]);
  C.push([
    23.2,
    (t) => {
      iPad([45, 52, 57, 60], t, 7, 0.016);
      iTone(55, t, 7, { type: "sawtooth", a: 2, r: 2, v: 0.03, lp: 160 });
    },
  ]);
  C.push([29.8, (t) => iQuindar(t)]);
  // III · Dosya
  C.push([
    30.2,
    (t) => {
      iPad([53, 60, 64, 69], t, 10, 0.015);
      iTone(43.65, t, 10, { a: 2, r: 3, v: 0.07 });
    },
  ]);
  for (let i = 0; i < 46; i++) C.push([31 + i * 0.13, (t) => iTick(t)]);
  C.push([
    37.5,
    (t) => {
      iThud(t);
      iBell(81, t + 0.05, 0.03);
    },
  ]);
  // IV · Kalkış
  C.push([
    40.1,
    (t) => {
      iRadio(t, 0.25);
      iTone(36.7, t, 13, { type: "sawtooth", a: 8, r: 0.4, v: 0.06, lp: 120, lp2: 260 });
      iPad([50, 57, 60, 62], t, 12, 0.012);
    },
  ]);
  for (let i = 0; i < 10; i++)
    C.push([
      42 + i,
      (t) => {
        iTone(i === 9 ? 1320 : 880, t, i === 9 ? 0.5 : 0.13, {
          type: "square",
          a: 0.003,
          r: 0.05,
          v: 0.04,
          lp: 3000,
          sfx: true,
        });
        if (i >= 6) iTone(55, t, 0.4, { to: 40, v: 0.08, sfx: true });
      },
    ]);
  C.push([
    52,
    (t) => {
      iNoise(t, 9, { f: 140, f2: 420, fd: 2.5, v: 0.22, a: 1.2, r: 3, q: 0.5 });
      iNoise(t + 0.4, 8, { type: "bandpass", f: 900, q: 0.4, v: 0.05, a: 1.5, r: 3 });
      iTone(32, t, 8, { v: 0.16, a: 1, r: 3, sfx: true });
    },
  ]);
  C.push([
    53.5,
    (t) => {
      iBoom(t, 0.55);
      iPad([45, 52, 57, 64, 69, 72], t, 7, 0.022);
      iTone(110, t, 6, { type: "sawtooth", a: 1, r: 3, v: 0.035, lp: 600, lp2: 1800 });
    },
  ]);
  C.push([54, (t) => iRadio(t, 0.2)]);
  C.push([
    57,
    (t) => {
      iNoise(t, 5, { f: 300, f2: 120, v: 0.12, a: 0.05, r: 4 });
      iPad([48, 55, 60, 64, 67], t, 6, 0.02);
      iBell(79, t + 0.5, 0.03);
    },
  ]);
  C.push([58, (t) => iRadio(t, 0.2)]);
  C.push([
    60.2,
    (t) => {
      iThud(t);
      iNoise(t, 0.6, { type: "highpass", f: 2000, v: 0.06, r: 0.5 });
    },
  ]);
  // V · Yolculuk
  const prog = [
    [41, 48, 53, 57, 60],
    [48, 55, 60, 64],
    [43, 50, 55, 59, 62],
    [45, 52, 57, 60, 64],
  ];
  prog.forEach((ch, i) =>
    C.push([
      62.2 + i * 2.45,
      (t) => {
        iPad(ch.slice(1), t, 3.4, 0.016);
        iTone(iM(ch[0]), t, 3, { a: 0.3, r: 1, v: 0.06 });
        [0, 1, 2, 3].forEach((j) => {
          if (Math.random() < 0.8) iBell(ch[1 + ((i + j) % (ch.length - 1))] + 24, t + j * 0.6, 0.028);
        });
      },
    ]),
  );
  // VI · Mars
  C.push([
    72.2,
    (t) => {
      iRadio(t, 0.2);
      iTone(41.2, t, 7, { type: "sawtooth", a: 3, r: 1, v: 0.06, lp: 140, lp2: 320 });
      iPad([40, 47, 52, 55], t, 7, 0.016);
    },
  ]);
  C.push([
    73.6,
    (t) => iNoise(t, 5.6, { type: "bandpass", f: 500, f2: 2400, q: 0.7, v: 0.14, a: 2.5, r: 0.3 }),
  ]);
  C.push([
    76.2,
    (t) => {
      iRadio(t, 0.15);
      iNoise(t + 0.8, 2, { type: "bandpass", f: 2200, q: 0.9, v: 0.06, a: 0.1, r: 0.1 });
    },
  ]);
  C.push([
    79,
    (t) => {
      iNoise(t, 3.6, { f: 180, f2: 320, v: 0.2, a: 0.2, r: 0.4, q: 0.5 });
      iTone(34, t, 3.6, { v: 0.12, a: 0.2, r: 0.4, sfx: true });
      iPad([40, 47, 52, 59], t, 4, 0.014);
    },
  ]);
  C.push([
    82.5,
    (t) => {
      iThud(t);
      iNoise(t, 4, { f: 700, f2: 200, v: 0.09, a: 0.05, r: 3.5 });
    },
  ]);
  C.push([83.3, (t) => iRadio(t, 0.25)]);
  C.push([
    86.9,
    (t) => {
      iQuindar(t);
      iPad([45, 52, 57, 61, 64, 69], t, 6, 0.02);
      iTone(55, t, 6, { a: 1, r: 3, v: 0.07 });
      iBell(81, t + 0.3, 0.045);
      iBell(85, t + 1.1, 0.04);
      iBell(88, t + 2, 0.035);
      iBell(93, t + 3.1, 0.025);
    },
  ]);
  return C;
}

/* ---------- başlat / bitir ---------- */
function startIntro() {
  ensureAudio();
  game = newGameState();
  mode = "intro";
  paused = false;
  $("menuScreen").classList.add("hidden");
  $("introSkip").classList.remove("hidden");
  intro = { t: 0, ci: 0, hold: false, hk: 0, parts: [], cues: introCues(), ending: false };
  const R = rng(911);
  intro.stars = Array.from({ length: 320 }, () => ({
    x: R(),
    y: R(),
    s: R() * 1.4 + 0.3,
    tw: R() * 6,
    c: R() < 0.15 ? "#ffd9b3" : R() < 0.3 ? "#bcd4ff" : "#ffffff",
  }));
  intro.cont = [];
  for (let c = 0; c < 9; c++) {
    const lo = [-0.75, 0.05, -1.4][c] != null ? [-0.75, 0.05, -1.4][c] : c * 0.7 + R() * 0.4,
      la = [0.92, 0.62, 0.5][c] != null ? [0.92, 0.62, 0.5][c] : -0.4 + R() * 1.55,
      base = ["#4a7f3a", "#5c8a3f", "#8f7d4c", "#6b8f45", "#a08c5a"][c % 5];
    let x = lo,
      y = la;
    for (let i = 0; i < 26; i++) {
      x += (R() - 0.5) * 0.16;
      y += (R() - 0.5) * 0.12;
      intro.cont.push({
        lon: x,
        lat: y,
        rx: 0.025 + R() * 0.045,
        ry: 0.018 + R() * 0.035,
        col: R() < 0.25 ? "#8f7d4c" : base,
      });
    }
  }
  intro.cloud = Array.from({ length: 90 }, () => ({
    lon: R() * 6.28,
    lat: (R() - 0.5) * 1.9,
    rx: 0.025 + R() * 0.09,
    ry: 0.006 + R() * 0.016,
  }));
  intro.mspot = Array.from({ length: 26 }, () => ({
    lon: R() * 6.28,
    lat: (R() - 0.5) * 1.4,
    rx: 0.05 + R() * 0.16,
    ry: 0.03 + R() * 0.08,
    d: R() < 0.5,
  }));
  intro.crat = Array.from({ length: 40 }, () => ({
    lon: R() * 6.28,
    lat: (R() - 0.5) * 1.7,
    r: 0.008 + R() * 0.03,
  }));
  intro.rocks = Array.from({ length: 26 }, () => ({ x: R(), s: R(), k: R() }));
  // gren dokusu
  const g = document.createElement("canvas");
  g.width = g.height = 160;
  const gc = g.getContext("2d"),
    im = gc.createImageData(160, 160);
  for (let i = 0; i < im.data.length; i += 4) {
    const v = Math.random() * 255;
    im.data[i] = im.data[i + 1] = im.data[i + 2] = v;
    im.data[i + 3] = 255;
  }
  gc.putImageData(im, 0, 0);
  intro.grain = g;
  if (AU.ready) {
    const ac = AU.ac;
    intro.mg = ac.createGain();
    intro.sg = ac.createGain();
    intro.mg.gain.value = 1.4;
    intro.sg.gain.value = 1;
    intro.mg.connect(AU.musicG);
    intro.sg.connect(AU.sfxG);
  }
  try {
    introGLSetup();
  } catch (e) {
    console.warn(e);
  }
}
function endIntro() {
  if (!intro || intro.ending) return;
  intro.ending = true;
  if (intro.mg) {
    const t = iNow();
    [intro.mg, intro.sg].forEach((g) => {
      try {
        g.gain.cancelScheduledValues(t);
        g.gain.setValueAtTime(g.gain.value, t);
        g.gain.linearRampToValueAtTime(0, t + 0.6);
        setTimeout(() => {
          try {
            g.disconnect();
          } catch (e) {}
        }, 900);
      } catch (e) {}
    });
  }
  $("introSkip").classList.add("hidden");
  const wasOutro = intro.outro;
  intro = null;
  if (AU.ac) AU.nextT = AU.ac.currentTime + 1.2; // oyun müziği temiz başlasın
  if (wasOutro) {
    finishOutro();
    return;
  }
  startNewGame();
}
function updateIntro(dt) {
  if (!intro) return;
  intro.t += dt;
  if (intro.hold) {
    intro.hk += dt;
    if (intro.hk >= 0.9) {
      endIntro();
      return;
    }
  } else intro.hk = Math.max(0, intro.hk - dt * 2);
  const r = $("introSkipRing");
  if (r) r.style.strokeDashoffset = String(100 - Math.min(1, intro.hk / 0.9) * 100);
  while (intro.ci < intro.cues.length && intro.cues[intro.ci][0] <= intro.t) {
    const c = intro.cues[intro.ci++];
    if (AU.ready && intro.mg && intro.t - c[0] < 0.5) {
      try {
        c[1](iNow() + 0.02);
      } catch (e) {}
    }
  }
  // parçacıklar
  for (let i = intro.parts.length - 1; i >= 0; i--) {
    const q = intro.parts[i];
    q.l += dt;
    if (q.l > q.m) {
      intro.parts.splice(i, 1);
      continue;
    }
    q.x += q.vx * dt;
    q.y += q.vy * dt;
    q.vx *= 1 - dt * q.dr;
    q.vy *= 1 - dt * q.dr;
    q.vy += (q.g || 0) * dt;
    q.r += q.gr * dt;
  }
  const J = intro.landJob;
  if (J && !J.done && GLX.ok) {
    if (intro.t >= 78.4) {
      while (!J.done) glxTerrainStep(J, 64);
    } else if (intro.t > 1.2) glxTerrainStep(J, Math.max(6, Math.round(J.h / 70)));
  }
  if (intro.t >= (intro.len || INTRO_LEN)) endIntro();
}

/* ============== EVE DÖNÜŞ SİNEMASI (ultra grafik + altyazı) ==============
   Açılış sinemasının motorunu (ses, parçacık, renk düzenleme, WebGL uzay) kullanır.
   Mars kalkışı → yörünge → 180 günlük dönüş → Dünya → atmosfere giriş → paraşütler → okyanusa iniş. */
const OUTRO_LEN = 72;
function outroData() {
  const g = game,
    sol = gameDayNumber(),
    cargo = Math.min(g.cargo || 0, CFG.cargoGoal);
  const C = commState(),
    sci = Math.min(100, Math.round(((C.sci || 0) / SCI_GOAL) * 100));
  const TD = Math.max(120, Math.round((g.design && g.design.fx ? g.design.fx.days : 214) * 0.85));
  const d1 = 3,
    d2 = Math.round(TD * 0.5),
    d3 = TD - 4;
  return {
    sol,
    cargo,
    sci,
    TD,
    caps: [
      [0.8, 4.3, T("GÖREV KONTROL"), T("ARES-1, Dünya'ya dönüş penceresi açık. Kalkış için onay verildi.")],
      [4.5, 8.4, "ARES-1", T("Motorlar ateşlendi… Mars, her şey için teşekkürler.")],
      [8.7, 11.4, T("GÖREV KONTROL"), T("Kalkış başarılı. Hoşça kal, Kızıl Gezegen.")],
      [
        12.0,
        16.1,
        T("ARES-R1 · RÖLE UYDUSU"),
        T("Son bağlantı: yüzey verilerinin tamamı aktarıldı. İyi yolculuklar, ARES-1."),
      ],
      [16.5, 20.6, T("GÖREV KONTROL"), T("Dünya'ya transfer ateşlemesi tamamlandı. Yeni rota: ev.")],
      [
        21.6,
        25.6,
        T("KOMUTANIN GÜNLÜĞÜ"),
        Tf(`Dönüş günü {0} — Mars arkamda küçülüyor. Kargo bölmesinde {1} numune var.`, [d1, cargo]),
      ],
      [
        25.9,
        29.8,
        T("KOMUTANIN GÜNLÜĞÜ"),
        Tf(`Dönüş günü {0} — Ekip her mesajımda Mars'ta öğrendiklerimizi soruyor.`, [d2]),
      ],
      [
        30.1,
        34.2,
        T("KOMUTANIN GÜNLÜĞÜ"),
        Tf(`Dönüş günü {0} — Pencerede mavi bir nokta büyüyor. Evim.`, [d3]),
      ],
      [35.4, 39.4, T("GÖREV KONTROL"), T("ARES-1, Ay'ın yörüngesini geçtin. Kapsül ayrılmasına hazırlan.")],
      [39.7, 43.6, "ARES-1", T("Kapsül ayrıldı. Isı kalkanı Dünya'ya dönük.")],
      [
        44.3,
        48.2,
        T("GÖREV KONTROL"),
        T("Atmosfere giriş. Hız saniyede 11 kilometre. İletişim kesintisi bekleniyor."),
      ],
      [48.5, 51.7, "ARES-1", T("Pencerenin dışı alev alev… dayan…")],
      [52.4, 55.7, T("KURTARMA EKİBİ"), T("Sinyal geri geldi! Paraşütler açıldı, üçü de sağlam.")],
      [56.0, 59.0, T("KURTARMA EKİBİ"), T("Kapsülü görüyoruz. Okyanusa iniş için hazırlan.")],
      [60.3, 64.2, T("GÖREV KONTROL"), T("ARES-1, suya iniş doğrulandı. Kurtarma gemisi yolda.")],
      [64.6, 67.9, T("GÖREV KONTROL"), Tf(`Mars'ta {0} sol geçirdin. Dünya'ya hoş geldin, Komutan.`, [sol])],
    ],
    chapters: [
      [0, "I", T("MARS · KALKIŞ")],
      [11, "II", T("MARS YÖRÜNGESİ")],
      [21, "III", Tf(`EVE DÖNÜŞ · {0} GÜN`, [TD])],
      [35, "IV", T("DÜNYA")],
      [44, "V", T("ATMOSFERE GİRİŞ")],
      [52, "VI", T("OKYANUSA İNİŞ")],
    ],
  };
}
function outroCues() {
  const C = [];
  C.push([
    0.05,
    (t) => {
      iTone(55, t, 11, { type: "sawtooth", a: 3, r: 3, v: 0.045, lp: 170 });
      iPad([57, 60, 64], t + 0.4, 9, 0.015);
    },
  ]);
  C.push([0.7, (t) => iRadio(t)]);
  C.push([8.6, (t) => iRadio(t, 0.2)]);
  [0, 1, 2].forEach((i) =>
    C.push([
      1.0 + i * 0.85,
      (t) => iTone(880, t, 0.12, { a: 0.003, r: 0.1, v: 0.03, type: "square", lp: 2600 }),
    ]),
  );
  C.push([
    3.6,
    (t) => {
      iBoom(t, 0.55);
      iNoise(t, 7.5, { f: 420, f2: 120, v: 0.22, a: 0.3, r: 2.5 });
      iTone(41, t, 7, { type: "sawtooth", a: 0.6, r: 3, v: 0.08, lp: 120 });
    },
  ]);
  C.push([
    11.2,
    (t) => {
      iPad([53, 57, 60, 65], t, 10, 0.016);
      iBell(76, t + 0.6);
      iBell(81, t + 2.2, 0.04);
    },
  ]);
  C.push([11.9, (t) => iRadio(t)]);
  C.push([16.4, (t) => iRadio(t, 0.2)]);
  C.push([
    16.6,
    (t) => {
      iBoom(t, 0.25);
      iNoise(t, 3.5, { f: 900, f2: 200, v: 0.08, a: 0.2, r: 1.2 });
    },
  ]);
  C.push([
    21.2,
    (t) => {
      iPad([50, 57, 62, 66], t, 14, 0.015);
      iTone(43.65, t, 14, { a: 3, r: 4, v: 0.06 });
    },
  ]);
  [22, 26, 30, 33].forEach((s, i) =>
    C.push([
      s,
      (t) => {
        iBell([79, 81, 83, 86][i], t, 0.035);
        iBell([74, 76, 79, 81][i], t + 0.9, 0.025);
      },
    ]),
  );
  C.push([
    35.2,
    (t) => {
      iPad([55, 59, 62, 67], t, 9, 0.017);
      iBell(83, t + 0.4, 0.04);
    },
  ]);
  C.push([35.3, (t) => iRadio(t)]);
  C.push([39.6, (t) => iRadio(t, 0.2)]);
  C.push([
    44.1,
    (t) => {
      iRadio(t);
      iNoise(t + 0.3, 7.6, { f: 300, f2: 1400, v: 0.2, a: 2.5, r: 1 });
      iTone(36, t, 8, { type: "sawtooth", a: 2, r: 1, v: 0.07, lp: 110 });
    },
  ]);
  C.push([
    52.1,
    (t) => {
      iBoom(t, 0.3);
      iRadio(t + 0.25);
      iPad([60, 64, 67, 72], t + 0.4, 7, 0.016);
    },
  ]);
  C.push([55.9, (t) => iRadio(t, 0.2)]);
  C.push([
    59.4,
    (t) => {
      iNoise(t, 1.6, { f: 1800, f2: 300, v: 0.22, a: 0.01, r: 1.4 });
      iThud(t);
    },
  ]);
  C.push([
    60.1,
    (t) => {
      iRadio(t);
      iPad([48, 55, 60, 64, 67], t + 0.3, 12, 0.018);
      iBell(72, t + 0.6, 0.05);
      iBell(76, t + 1.4, 0.045);
      iBell(79, t + 2.2, 0.045);
      iBell(84, t + 3.4, 0.04);
    },
  ]);
  C.push([64.5, (t) => iRadio(t, 0.2)]);
  C.push([
    67.8,
    (t) => {
      iPad([53, 57, 60, 64, 69], t, 5, 0.016);
      iBell(81, t + 0.3, 0.04);
    },
  ]);
  return C;
}
function startOutro() {
  ensureAudio();
  closeRocket();
  document.body.classList.add("cine");
  insideRocket = false;
  game.sleeping = false;
  mode = "intro";
  paused = false;
  $("introSkip").classList.remove("hidden");
  intro = {
    t: 0,
    ci: 0,
    hold: false,
    hk: 0,
    parts: [],
    cues: outroCues(),
    ending: false,
    outro: true,
    len: OUTRO_LEN,
    O: outroData(),
  };
  const R = rng(1207);
  intro.stars = Array.from({ length: 320 }, () => ({
    x: R(),
    y: R(),
    s: R() * 1.4 + 0.3,
    tw: R() * 6,
    c: R() < 0.15 ? "#ffd9b3" : R() < 0.3 ? "#bcd4ff" : "#ffffff",
  }));
  intro.cont = [];
  for (let c = 0; c < 9; c++) {
    const lo = c * 0.7 + R() * 0.4,
      la = -0.4 + R() * 1.55,
      base = ["#4a7f3a", "#5c8a3f", "#8f7d4c", "#6b8f45", "#a08c5a"][c % 5];
    let x = lo,
      y = la;
    for (let i = 0; i < 26; i++) {
      x += (R() - 0.5) * 0.16;
      y += (R() - 0.5) * 0.12;
      intro.cont.push({
        lon: x,
        lat: y,
        rx: 0.025 + R() * 0.045,
        ry: 0.018 + R() * 0.035,
        col: R() < 0.25 ? "#8f7d4c" : base,
      });
    }
  }
  intro.cloud = Array.from({ length: 90 }, () => ({
    lon: R() * 6.28,
    lat: (R() - 0.5) * 1.9,
    rx: 0.025 + R() * 0.09,
    ry: 0.006 + R() * 0.016,
  }));
  intro.mspot = Array.from({ length: 26 }, () => ({
    lon: R() * 6.28,
    lat: (R() - 0.5) * 1.4,
    rx: 0.05 + R() * 0.16,
    ry: 0.03 + R() * 0.08,
    d: R() < 0.5,
  }));
  intro.crat = Array.from({ length: 40 }, () => ({
    lon: R() * 6.28,
    lat: (R() - 0.5) * 1.7,
    r: 0.008 + R() * 0.03,
  }));
  intro.ridge = [0, 1, 2].map((i) =>
    Array.from(
      { length: 64 },
      (_, j) =>
        0.5 + 0.5 * Math.sin(j * 0.37 * (i + 1) + i * 2.1) * Math.cos(j * 0.13 + i) + 0.25 * (R() - 0.5),
    ),
  );
  intro.clouds = Array.from({ length: 22 }, () => ({
    x: R(),
    y: R(),
    w: 0.12 + R() * 0.22,
    h: 0.025 + R() * 0.03,
    z: 0.4 + R() * 0.9,
  }));
  const g = document.createElement("canvas");
  g.width = g.height = 160;
  const gc = g.getContext("2d"),
    im = gc.createImageData(160, 160);
  for (let i = 0; i < im.data.length; i += 4) {
    const v = Math.random() * 255;
    im.data[i] = im.data[i + 1] = im.data[i + 2] = v;
    im.data[i + 3] = 255;
  }
  gc.putImageData(im, 0, 0);
  intro.grain = g;
  if (AU.ready) {
    const ac = AU.ac;
    intro.mg = ac.createGain();
    intro.sg = ac.createGain();
    intro.mg.gain.value = 1.4;
    intro.sg.gain.value = 1;
    intro.mg.connect(AU.musicG);
    intro.sg.connect(AU.sfxG);
  }
  try {
    glxInit();
  } catch (e) {}
}
function finishOutro() {
  mode = "play";
  document.body.classList.remove("cine");
  try {
    enterPlanet("earth", false, true);
  } catch (e) {}
  bumpQuest("traveled");
  showWin();
}
/* ---------- çizim yardımcıları ---------- */
function oCapsule(x, y, rot, s, shield) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  const g = ctx.createLinearGradient(-22, 0, 22, 0);
  g.addColorStop(0, "#9aa3b8");
  g.addColorStop(0.45, "#eef1f7");
  g.addColorStop(1, "#6b7388");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(-24, 14);
  ctx.lineTo(-10, -22);
  ctx.quadraticCurveTo(0, -27, 10, -22);
  ctx.lineTo(24, 14);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "rgba(30,40,60,.6)";
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.fillStyle = "#ff8c42";
  ctx.fillRect(-19, 1, 38, 3);
  ctx.fillStyle = "#1d2b4f";
  ctx.beginPath();
  ctx.ellipse(-6, -8, 3.4, 2.6, 0, 0, 7);
  ctx.ellipse(6, -8, 3.4, 2.6, 0, 0, 7);
  ctx.fill();
  ctx.fillStyle = "rgba(127,231,255,.7)";
  ctx.beginPath();
  ctx.ellipse(-6.6, -8.6, 1.5, 1, 0, 0, 7);
  ctx.ellipse(5.4, -8.6, 1.5, 1, 0, 0, 7);
  ctx.fill();
  const hs = ctx.createLinearGradient(0, 12, 0, 20);
  hs.addColorStop(
    0,
    shield > 0
      ? `rgb(${ilerp(70, 255, shield) | 0},${ilerp(50, 170, shield) | 0},${ilerp(40, 80, shield) | 0})`
      : "#4a3a32",
  );
  hs.addColorStop(1, "#22160f");
  ctx.fillStyle = hs;
  ctx.beginPath();
  ctx.moveTo(-25, 13);
  ctx.quadraticCurveTo(0, 23, 25, 13);
  ctx.lineTo(24, 15);
  ctx.quadraticCurveTo(0, 26, -24, 15);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}
function oMoon(x, y, r, lit) {
  const g = ctx.createRadialGradient(x - r * 0.35 * lit, y - r * 0.3, r * 0.1, x, y, r);
  g.addColorStop(0, "#f1efe9");
  g.addColorStop(0.55, "#b9b5ab");
  g.addColorStop(1, "#3d3b37");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, 7);
  ctx.fill();
  ctx.fillStyle = "rgba(60,58,54,.35)";
  for (const [a, b, c] of [
    [-0.3, -0.2, 0.22],
    [0.25, 0.1, 0.16],
    [-0.05, 0.35, 0.12],
    [0.35, -0.35, 0.1],
    [-0.45, 0.25, 0.08],
  ]) {
    ctx.beginPath();
    ctx.arc(x + a * r, y + b * r, c * r, 0, 7);
    ctx.fill();
  }
  const sh = ctx.createRadialGradient(x + r * 0.6, y + r * 0.2, r * 0.2, x + r * 0.4, y, r * 1.2);
  sh.addColorStop(0, "rgba(0,0,0,.75)");
  sh.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = sh;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, 7);
  ctx.fill();
}
function oChutes(x, y, s, t) {
  const sw = Math.sin(t * 1.3) * 0.06;
  for (const [dx, dy, c] of [
    [-46, -118, 0],
    [0, -132, 1],
    [46, -118, 2],
  ]) {
    const cx = x + (dx + Math.sin(t * 1.1 + c) * 3) * s,
      cy = y + dy * s,
      r = 34 * s;
    ctx.strokeStyle = "rgba(230,230,235,.75)";
    ctx.lineWidth = 1;
    for (let i = -3; i <= 3; i++) {
      ctx.beginPath();
      ctx.moveTo(x, y - 20 * s);
      ctx.lineTo(cx + (i * r) / 3.2, cy + 4 * s);
      ctx.stroke();
    }
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(sw + (c - 1) * 0.08);
    for (let i = 0; i < 8; i++) {
      const a0 = Math.PI + (i / 8) * Math.PI,
        a1 = Math.PI + ((i + 1) / 8) * Math.PI;
      ctx.fillStyle = i % 2 ? "#ff8c42" : "#f5f6fa";
      ctx.beginPath();
      ctx.moveTo(0, 8 * s);
      ctx.arc(0, 8 * s, r, a0, a1);
      ctx.closePath();
      ctx.fill();
    }
    ctx.fillStyle = "rgba(0,0,0,.18)";
    ctx.beginPath();
    ctx.ellipse(0, 8 * s, r, r * 0.18, 0, 0, Math.PI);
    ctx.fill();
    ctx.restore();
  }
}
function oRidges(gy, cols, par) {
  intro.ridge.forEach((R, i) => {
    const amp = [0.07, 0.05, 0.035][i] * H,
      base = gy - [0.06, 0.03, 0.0][i] * H;
    ctx.fillStyle = cols[i];
    ctx.beginPath();
    ctx.moveTo(0, H);
    for (let j = 0; j < R.length; j++) {
      const x = (j / (R.length - 1)) * W * 1.1 - W * 0.05 + par * (i + 1) * 8;
      ctx.lineTo(x, base - R[j] * amp);
    }
    ctx.lineTo(W, H);
    ctx.closePath();
    ctx.fill();
  });
}
/* ---------- sahneler ---------- */
function oLift(t, U) {
  // 0–11: Mars gün batımı, kalkış
  const ign = 3.6,
    up = Math.max(0, t - 4.6),
    lift = Math.pow(up, 2.05) * H * 0.045,
    sh = t > ign && t < 9 ? (1 - iclamp((t - 8) / 1)) * 7 * U : 0;
  ctx.save();
  if (sh) ctx.translate((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, "#0e0a18");
  g.addColorStop(0.45, "#3d2030");
  g.addColorStop(0.72, "#a4573a");
  g.addColorStop(1, "#d9925f");
  ctx.fillStyle = g;
  ctx.fillRect(-20, -20, W + 40, H + 40);
  iStars(0.45, 0, 0, true);
  // Mars'ta gün batımı mavidir
  const sx = W * 0.74,
    sy = H * 0.66,
    bl = ctx.createRadialGradient(sx, sy, 0, sx, sy, H * 0.42);
  bl.addColorStop(0, "rgba(200,230,255,.95)");
  bl.addColorStop(0.06, "rgba(150,200,255,.7)");
  bl.addColorStop(0.3, "rgba(110,160,230,.22)");
  bl.addColorStop(1, "rgba(110,160,230,0)");
  ctx.fillStyle = bl;
  ctx.fillRect(0, 0, W, H);
  // Phobos
  ctx.fillStyle = "#2a1d1a";
  ctx.beginPath();
  ctx.ellipse(W * 0.2, H * 0.18, 6 * U, 4.4 * U, 0.4, 0, 7);
  ctx.fill();
  const gy = H * 0.78;
  oRidges(gy, ["#5a2a20", "#40190f", "#28100a"], -t * 0.2);
  ctx.fillStyle = "#1d0b06";
  ctx.fillRect(0, gy, W, H - gy);
  // yer ışıkları / rampa
  ctx.fillStyle = "#3a2a28";
  ctx.fillRect(W * 0.5 - 70 * U, gy - 4 * U, 140 * U, 6 * U);
  const blink = Math.sin(t * 5) > 0;
  for (const dx of [-64, 64]) {
    ctx.fillStyle = blink ? "#ff5a3c" : "#5a1a10";
    ctx.beginPath();
    ctx.arc(W * 0.5 + dx * U, gy - 6 * U, 2.2 * U, 0, 7);
    ctx.fill();
  }
  const s = U * 1.35,
    rx = W * 0.5,
    ry = gy - 44 * s - lift;
  if (t > ign) {
    // alev + duman
    const pw = iclamp((t - ign) / 1.1);
    if (Math.random() < 0.9)
      iSmoke(rx, gy - 2 * U, up < 2 ? 4 : 2, U, {
        sp: up < 1.5 ? 1.4 : 0.6,
        up: 0.5,
        life: 4,
        c: [190, 140, 110],
        a: 0.55,
      });
    const fl = ctx.createRadialGradient(
      rx,
      ry + 60 * s,
      0,
      rx,
      ry + 60 * s,
      (120 + Math.random() * 30) * U * pw,
    );
    fl.addColorStop(0, "rgba(255,245,210," + 0.9 * pw + ")");
    fl.addColorStop(0.3, "rgba(255,160,70," + 0.6 * pw + ")");
    fl.addColorStop(1, "rgba(255,90,40,0)");
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = fl;
    ctx.fillRect(0, 0, W, H);
    ctx.globalCompositeOperation = "source-over";
    const gl = ctx.createRadialGradient(rx, gy, 0, rx, gy, W * 0.5);
    gl.addColorStop(0, "rgba(255,170,90," + 0.35 * pw * (1 - iclamp(up / 5)) + ")");
    gl.addColorStop(1, "rgba(255,170,90,0)");
    ctx.fillStyle = gl;
    ctx.fillRect(0, gy - H * 0.3, W, H * 0.6);
  }
  iParts2D();
  iRocket(rx, ry, Math.sin(t * 1.7) * 0.01 * (up > 0 ? 1 : 0), s, t > ign ? 1 + 0.2 * Math.sin(t * 30) : 0);
  ctx.restore();
  const cd = Math.max(0, Math.ceil(ign - t));
  iHud(
    [
      [
        T("EVRE"),
        t < ign ? T("GERİ SAYIM") : up <= 0 ? T("ATEŞLEME") : T("MARS KALKIŞI"),
        t < ign ? "#ffd34d" : "#4ade80",
      ],
      ["T", t < ign ? "− " + cd : "+ " + fmtN(t - ign, 1) + " sn"],
      [T("İRTİFA"), fmtN((lift / (H * 0.045)) * 55, 0) + " m"],
      [T("İTKİ"), "%" + Math.round(t > ign ? Math.min(100, (t - ign) * 90) : 0)],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
}
function oOrbit(t, U) {
  // 11–21: Mars uzaklaşır, röle uydusu
  const lt = t - 11,
    k = iease(lt / 10),
    r = Math.max(W, H) * ilerp(0.9, 0.32, k),
    mx = W * ilerp(0.38, 0.24, k),
    my = H * ilerp(1.25, 0.72, k);
  if (GLX.ok)
    ctx.drawImage(
      glxSpace({
        time: t,
        milky: 0.85,
        stars: 1,
        off: [lt * 6, 0],
        p1: [mx, my, r, 1],
        rot1: 0.3 + lt * 0.02,
        tilt1: 1.05,
        l1: [0.7, 0.45, 0.55],
        expo: 1,
      }),
      0,
      0,
      W,
      H,
    );
  else {
    iSpace("#010208", "#06030c");
    iMilky(0.8);
    iStars(1, lt * 6, 0, true);
    iMars(mx, my, r, 0.3 + lt * 0.02, true);
  }
  // röle uydusu
  const sa = iclamp((lt - 0.5) / 1) * (1 - iclamp((lt - 6.5) / 1)),
    sx = W * ilerp(0.95, 0.55, iclamp(lt / 7)),
    sy = H * ilerp(0.3, 0.36, iclamp(lt / 7));
  if (sa > 0) {
    ctx.globalAlpha = sa;
    ctx.save();
    ctx.translate(sx, sy);
    ctx.rotate(-0.2);
    const q = U * 1.1;
    ctx.fillStyle = "#1e3a8a";
    ctx.fillRect(-46 * q, -6 * q, 30 * q, 12 * q);
    ctx.fillRect(16 * q, -6 * q, 30 * q, 12 * q);
    ctx.strokeStyle = "#93c5fd";
    ctx.lineWidth = 0.6;
    for (let i = 1; i < 5; i++) {
      ctx.beginPath();
      ctx.moveTo((-46 + i * 6) * q, -6 * q);
      ctx.lineTo((-46 + i * 6) * q, 6 * q);
      ctx.moveTo((16 + i * 6) * q, -6 * q);
      ctx.lineTo((16 + i * 6) * q, 6 * q);
      ctx.stroke();
    }
    ctx.fillStyle = "#d4a843";
    rrp(-14 * q, -11 * q, 28 * q, 22 * q, 3 * q);
    ctx.fill();
    ctx.fillStyle = "#e8ecf5";
    ctx.beginPath();
    ctx.ellipse(0, -16 * q, 9 * q, 3.5 * q, 0, 0, 7);
    ctx.fill();
    ctx.restore();
    iText("ARES-R1", sx, sy + 30 * U, 10 * U + 3, { al: "center", mono: 1, w: 800, c: "#9fd3ff", ls: 3 });
    if (Math.sin(t * 6) > 0) {
      ctx.strokeStyle = "rgba(127,231,255,.5)";
      ctx.setLineDash([4, 6]);
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(W * 0.62, H * 0.52);
      ctx.stroke();
      ctx.setLineDash([]);
    }
    ctx.globalAlpha = 1;
  }
  // roket: ateşleme 5.5–9.5
  const burn = lt > 5.4 && lt < 9.6,
    rx = W * ilerp(0.5, 0.8, k),
    ry = H * ilerp(0.56, 0.34, k);
  if (burn) {
    const g = ctx.createRadialGradient(rx, ry, 0, rx, ry, 60 * U);
    g.addColorStop(0, "rgba(255,220,160,.5)");
    g.addColorStop(1, "rgba(255,160,90,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(rx, ry, 60 * U, 0, 7);
    ctx.fill();
  }
  iRocket(rx, ry, Math.atan2(-0.22, 0.3) + Math.PI / 2, U * 0.75, burn ? 0.9 + 0.15 * Math.sin(t * 28) : 0);
  iHud(
    [
      [
        T("EVRE"),
        lt < 5.4
          ? T("MARS YÖRÜNGESİ")
          : lt < 9.6
            ? T("DÜNYA'YA TRANSFER ATEŞLEMESİ")
            : T("TRANSFER YÖRÜNGESİ"),
        burn ? "#ffd34d" : "#4ade80",
      ],
      [T("İRTİFA"), fmtN(ilerp(410, 52000, k), 0) + " km"],
      [T("HIZ"), fmtN(ilerp(3.4, 5.9, iclamp((lt - 5.4) / 4)), 1) + " km/s"],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
}
function oCruise(t, U) {
  // 21–35: Mars → Dünya
  const lt = t - 21,
    k = lt / 14,
    O = intro.O;
  const mx = W * 0.15,
    my = H * 0.62,
    mr = H * (0.13 - 0.1 * k),
    ex = W * 0.85,
    ey = H * 0.36,
    er = H * (0.02 + 0.13 * iease(k));
  if (GLX.ok)
    ctx.drawImage(
      glxSpace({
        time: t,
        off: [-lt * 14, 0],
        p1: [ex, ey, er, 0],
        rot1: lt * 0.08,
        l1: [-0.5, 0.35, 0.7],
        p2: [mx, my, mr, 1],
        rot2: lt * 0.04,
        l2: [0.8, 0.3, 0.5],
      }),
      0,
      0,
      W,
      H,
    );
  else {
    iSpace("#010208", "#03061a");
    iMilky(0.9);
    iStars(1, -lt * 14, 0, true);
    iEarth(ex, ey, er, lt * 0.08);
    iMars(mx, my, mr, lt * 0.04);
  }
  const cx = W * 0.5,
    cy = H * 0.08,
    B = (u) => ({
      x: (1 - u) * (1 - u) * mx + 2 * (1 - u) * u * cx + u * u * ex,
      y: (1 - u) * (1 - u) * (my - mr * 1.3) + 2 * (1 - u) * u * cy + u * u * (ey - er * 1.3),
    });
  const u0 = 0.04 + 0.9 * iease(k);
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(127,200,255,.9)";
  ctx.beginPath();
  for (let i = 0; i <= 40; i++) {
    const q = B((i / 40) * u0);
    i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y);
  }
  ctx.stroke();
  ctx.setLineDash([5, 7]);
  ctx.strokeStyle = "rgba(127,200,255,.4)";
  ctx.beginPath();
  for (let i = 0; i <= 40; i++) {
    const q = B(u0 + ((1 - u0) * i) / 40);
    i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y);
  }
  ctx.stroke();
  ctx.setLineDash([]);
  const q = B(u0),
    q2 = B(Math.min(1, u0 + 0.01)),
    ang = Math.atan2(q2.y - q.y, q2.x - q.x);
  const gl = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, 40 * U);
  gl.addColorStop(0, "rgba(160,210,255,.35)");
  gl.addColorStop(1, "rgba(160,210,255,0)");
  ctx.fillStyle = gl;
  ctx.beginPath();
  ctx.arc(q.x, q.y, 40 * U, 0, 7);
  ctx.fill();
  iRocket(q.x, q.y, ang + Math.PI / 2, U * 0.55, 0.2 + 0.08 * Math.sin(t * 20));
  const day = Math.max(1, Math.round(1 + (O.TD - 1) * iease(k)));
  iText(T("DÖNÜŞ GÜNÜ"), W / 2, H * 0.15, 11 * U + 4, { al: "center", mono: 1, w: 800, c: "#8d9cc0", ls: 5 });
  iText(String(day).padStart(3, "0") + " / " + O.TD, W / 2, H * 0.15 + 40 * U, 34 * U + 8, {
    al: "center",
    mono: 1,
    w: 300,
    c: "#fff",
    ls: 4,
  });
  const dist = ilerp(225, 0.4, iease(k)),
    dl = ilerp(12.5, 0.03, iease(k));
  iHud(
    [
      [T("DÜNYA'YA UZAKLIK"), fmtN(dist, 1) + T(" milyon km")],
      [T("SİNYAL GECİKMESİ"), fmtN(dl, 1) + T(" dk")],
      [T("KARGO"), O.cargo + T(" numune")],
      [T("YER İSTASYONU"), GS_STATIONS[Math.floor(day / 9) % 3].nm],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
  iText(T("MARS"), mx, my + mr + 22 * U, 10 * U + 4, { al: "center", mono: 1, w: 800, c: "#ffb38a", ls: 3 });
  iText(T("DÜNYA"), ex, ey + er + 22 * U, 10 * U + 4, { al: "center", mono: 1, w: 800, c: "#9fc9ff", ls: 3 });
}
function oEarth(t, U) {
  // 35–44: Dünya'ya yaklaşma, Ay, kapsül ayrılması
  const lt = t - 35,
    k = iease(lt / 9),
    r = Math.max(W, H) * ilerp(0.28, 0.62, k),
    ex = W * ilerp(0.66, 0.6, k),
    ey = H * ilerp(0.52, 0.78, k);
  // Ay önden geçer
  const mo = W * ilerp(1.1, -0.1, iclamp(lt / 7.5)),
    moy = H * 0.24,
    mr = H * 0.055;
  if (GLX.ok)
    ctx.drawImage(
      glxSpace({
        time: t,
        milky: 0.7,
        stars: 1,
        off: [lt * 8, 0],
        p1: [ex, ey, r, 0],
        rot1: 0.6 + lt * 0.03,
        tilt1: 1.05,
        l1: [-0.55, 0.45, 0.7],
        flare: [W * 0.08, H * 0.15, 0.7],
      }),
      0,
      0,
      W,
      H,
    );
  else {
    iSpace("#010208", "#030a1a");
    iMilky(0.6);
    iStars(1, lt * 8, 0, true);
    iEarth(ex, ey, r, 0.6 + lt * 0.03);
  }
  oMoon(mo, moy, mr, 1);
  // roket gövdesi + kapsül ayrılması (39.6)
  const sep = Math.max(0, lt - 4.6),
    bx = W * ilerp(0.18, 0.34, k),
    by = H * ilerp(0.4, 0.46, k),
    ang = 0.95;
  if (sep <= 0) iRocket(bx, by, ang, U * 0.62, 0.15);
  else {
    ctx.save();
    ctx.translate(bx - sep * 26 * U, by + sep * 10 * U);
    ctx.rotate(ang + sep * 0.25);
    ctx.globalAlpha = Math.max(0, 1 - sep / 4);
    ctx.fillStyle = "#c5ccdf";
    rrp(-12 * U, -10 * U, 24 * U, 70 * U, 6 * U);
    ctx.fill();
    ctx.fillStyle = "#8e2f26";
    ctx.fillRect(-12 * U, 40 * U, 24 * U, 6 * U);
    ctx.restore();
    ctx.globalAlpha = 1;
    if (sep < 0.5) {
      ctx.fillStyle = "rgba(255,240,210," + (1 - sep / 0.5) + ")";
      ctx.beginPath();
      ctx.arc(bx, by, (18 + sep * 90) * U, 0, 7);
      ctx.fill();
    }
    oCapsule(bx + sep * 20 * U, by - sep * 6 * U, ang + Math.PI * 0.05, U * 1.05, 0);
  }
  iHud(
    [
      [T("EVRE"), sep > 0 ? T("KAPSÜL AYRILDI") : T("DÜNYA YAKLAŞMASI"), sep > 0 ? "#ffd34d" : "#4ade80"],
      [T("DÜNYA'YA UZAKLIK"), fmtN(ilerp(380000, 6400, k), 0) + " km"],
      [T("HIZ"), fmtN(ilerp(9.8, 11.1, k), 1) + " km/s"],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
}
function oEntry(t, U) {
  // 44–52: atmosfere giriş
  const lt = t - 44,
    k = lt / 8,
    r = Math.max(W, H) * 1.15,
    cy = H * 0.66 + r - ilerp(0, H * 0.22, iease(k));
  if (GLX.ok)
    ctx.drawImage(
      glxSpace({
        time: t,
        milky: 0.5,
        stars: 1 - iclamp((k - 0.5) * 2),
        p1: [W * 0.5, cy, r, 0],
        rot1: 0.8 + lt * 0.01,
        tilt1: 1.1,
        l1: [0.3, 0.65, 0.7],
      }),
      0,
      0,
      W,
      H,
    );
  else {
    iSpace("#010208", "#040812");
    iStars(1 - iclamp((k - 0.5) * 2), 0, 0, true);
    iEarth(W * 0.5, cy, r, 0.8 + lt * 0.01);
  }
  const atm = ctx.createLinearGradient(0, cy - r - H * 0.1, 0, cy - r + H * 0.06);
  atm.addColorStop(0, "rgba(120,190,255,0)");
  atm.addColorStop(1, "rgba(150,210,255,.4)");
  ctx.fillStyle = atm;
  ctx.fillRect(0, cy - r - H * 0.1, W, H * 0.16);
  const pk = iclamp((lt - 0.8) / 2) * (1 - iclamp((lt - 6.6) / 1.2)),
    sh = pk * 6 * U;
  ctx.save();
  if (sh) ctx.translate((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);
  const rx = W * ilerp(0.24, 0.56, iease(k)),
    ry = H * ilerp(0.14, 0.44, iease(k)),
    ang = Math.atan2(H * 0.3, W * 0.32),
    s = U * 1.5;
  if (pk > 0) {
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < 30; i++) {
      const l = (90 + Math.random() * 220) * U * pk,
        o = (Math.random() - 0.5) * 44 * U;
      ctx.strokeStyle = "rgba(255," + ((140 + Math.random() * 90) | 0) + ",70," + 0.35 * pk + ")";
      ctx.lineWidth = (1 + Math.random() * 3.2) * U;
      ctx.beginPath();
      ctx.moveTo(
        rx + Math.cos(ang) * 22 * s - Math.sin(ang) * o,
        ry + Math.sin(ang) * 22 * s + Math.cos(ang) * o,
      );
      ctx.lineTo(
        rx - Math.cos(ang) * l - Math.sin(ang) * o * 1.8,
        ry - Math.sin(ang) * l + Math.cos(ang) * o * 1.8,
      );
      ctx.stroke();
    }
    const hx = rx + Math.cos(ang) * 26 * s,
      hy = ry + Math.sin(ang) * 26 * s,
      g = ctx.createRadialGradient(hx, hy, 0, hx, hy, 100 * U);
    g.addColorStop(0, "rgba(255,255,235," + pk + ")");
    g.addColorStop(0.3, "rgba(255,170,80," + 0.75 * pk + ")");
    g.addColorStop(1, "rgba(255,90,40,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(hx, hy, 100 * U, 0, 7);
    ctx.fill();
    ctx.globalCompositeOperation = "source-over";
  }
  oCapsule(rx, ry, ang - Math.PI / 2, s, pk);
  ctx.restore();
  if (pk > 0) {
    ctx.fillStyle = "rgba(255,120,60," + 0.12 * pk + ")";
    ctx.fillRect(0, 0, W, H);
  }
  const lost = lt > 3.4 && lt < 7.6;
  iHud(
    [
      [T("EVRE"), T("ATMOSFERE GİRİŞ")],
      [T("HIZ"), fmtN(ilerp(11.1, 0.3, iclamp(lt / 7.5)), 1) + " km/s"],
      [T("ISI KALKANI"), fmtN(ilerp(200, 2700, iclamp(lt / 4)), 0) + " °C", lt > 2.5 ? "#ff8c42" : "#e8f1ff"],
      [T("SİNYAL"), lost ? (Math.sin(t * 8) > 0 ? T("YOK") : "—") : "▮▮▮▯", lost ? "#ff5a5a" : "#4ade80"],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
}
function oChute(t, U) {
  // 52–59: mavi gökyüzü, bulutlar, paraşütler
  const lt = t - 52,
    k = lt / 7;
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, "#2f6fb5");
  g.addColorStop(0.6, "#7fb8e8");
  g.addColorStop(1, "#cfe6f7");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  const sun = ctx.createRadialGradient(W * 0.82, H * 0.18, 0, W * 0.82, H * 0.18, H * 0.35);
  sun.addColorStop(0, "rgba(255,250,230,.95)");
  sun.addColorStop(0.1, "rgba(255,240,200,.6)");
  sun.addColorStop(1, "rgba(255,240,200,0)");
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, W, H);
  for (const c of intro.clouds) {
    const y = ((((c.y * H * 1.4 - lt * H * 0.09 * c.z * 3) % (H * 1.4)) + H * 1.4) % (H * 1.4)) - H * 0.2,
      x = c.x * W;
    ctx.fillStyle = "rgba(255,255,255," + (0.35 + (0.4 * c.z) / 1.3) + ")";
    ctx.beginPath();
    ctx.ellipse(x, y, c.w * W * 0.5 * c.z, c.h * H * c.z, 0, 0, 7);
    ctx.ellipse(x + c.w * W * 0.18, y - c.h * H * 0.5, c.w * W * 0.28 * c.z, c.h * H * 1.1 * c.z, 0, 0, 7);
    ctx.fill();
  }
  // okyanus aşağıdan yükselir
  const sea = H * ilerp(1.25, 0.86, iease(iclamp((lt - 3) / 4)));
  if (sea < H) {
    const sg = ctx.createLinearGradient(0, sea, 0, H);
    sg.addColorStop(0, "#5b8fb8");
    sg.addColorStop(1, "#0f3a63");
    ctx.fillStyle = sg;
    ctx.fillRect(0, sea, W, H - sea);
    ctx.fillStyle = "rgba(255,255,255,.35)";
    ctx.fillRect(0, sea, W, 1.5);
  }
  const open = iclamp((lt - 0.3) / 0.8),
    s = U * 1.25,
    x = W * 0.5 + Math.sin(lt * 1.2) * 12 * U,
    y = H * 0.58 + Math.sin(lt * 1.7) * 5 * U;
  if (lt < 0.5) {
    ctx.fillStyle = "rgba(255,255,255," + (1 - lt / 0.5) * 0.7 + ")";
    ctx.fillRect(0, 0, W, H);
  }
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(1, ilerp(0.2, 1, open));
  ctx.translate(-x, -y);
  oChutes(x, y, s, t);
  ctx.restore();
  oCapsule(x, y, Math.sin(lt * 1.3) * 0.05, s, 0);
  iHud(
    [
      [T("EVRE"), T("PARAŞÜTLER AÇIK"), "#4ade80"],
      [T("İRTİFA"), fmtN(ilerp(3000, 40, k), 0) + " m"],
      [T("İNİŞ HIZI"), fmtN(ilerp(32, 7.5, iclamp(lt / 2)), 1) + " m/s"],
      [T("SİNYAL"), "▮▮▮▮", "#4ade80"],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
}
function oSplash(t, U) {
  // 59–68: gün batımında okyanus
  const lt = t - 59;
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, "#1c2246");
  g.addColorStop(0.35, "#7b3f63");
  g.addColorStop(0.58, "#f08a4b");
  g.addColorStop(0.62, "#ffc27a");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  const hy = H * 0.6,
    sx = W * 0.3;
  const sun = ctx.createRadialGradient(sx, hy - 6 * U, 0, sx, hy, H * 0.4);
  sun.addColorStop(0, "rgba(255,245,210,1)");
  sun.addColorStop(0.07, "rgba(255,215,150,.9)");
  sun.addColorStop(0.3, "rgba(255,150,90,.3)");
  sun.addColorStop(1, "rgba(255,150,90,0)");
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = "rgba(255,240,200,.9)";
  ctx.beginPath();
  ctx.arc(sx, hy - 2 * U, 22 * U, Math.PI, 0);
  ctx.fill();
  const sg = ctx.createLinearGradient(0, hy, 0, H);
  sg.addColorStop(0, "#c76a4f");
  sg.addColorStop(0.25, "#3a3358");
  sg.addColorStop(1, "#0b1022");
  ctx.fillStyle = sg;
  ctx.fillRect(0, hy, W, H - hy);
  // güneş yansıması + dalgalar
  for (let i = 0; i < 70; i++) {
    const yy = hy + Math.pow(i / 70, 1.6) * (H - hy),
      w = (8 + i * 1.6) * U * (0.6 + 0.4 * Math.sin(t * 2 + i)),
      xx = sx + Math.sin(t * 1.3 + i * 1.7) * i * 0.8 * U;
    ctx.fillStyle = "rgba(255,200,140," + 0.55 * (1 - i / 70) + ")";
    ctx.fillRect(xx - w / 2, yy, w, 1.3 * U);
  }
  ctx.strokeStyle = "rgba(255,255,255,.08)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 26; i++) {
    const yy = hy + Math.pow(i / 26, 1.7) * (H - hy);
    ctx.beginPath();
    for (let x = 0; x <= W; x += 24) {
      const y2 = yy + Math.sin(x * 0.02 + t * 1.4 + i) * (1 + i * 0.15) * U;
      x ? ctx.lineTo(x, y2) : ctx.moveTo(x, y2);
    }
    ctx.stroke();
  }
  // kurtarma gemisi
  const shx = W * ilerp(1.08, 0.78, iease(iclamp((lt - 1) / 7))),
    shy = hy + 4 * U;
  ctx.fillStyle = "#141a2c";
  ctx.beginPath();
  ctx.moveTo(shx - 70 * U, shy);
  ctx.lineTo(shx + 66 * U, shy);
  ctx.lineTo(shx + 56 * U, shy + 10 * U);
  ctx.lineTo(shx - 62 * U, shy + 10 * U);
  ctx.closePath();
  ctx.fill();
  ctx.fillRect(shx - 30 * U, shy - 16 * U, 34 * U, 16 * U);
  ctx.fillRect(shx - 20 * U, shy - 28 * U, 12 * U, 12 * U);
  ctx.fillRect(shx + 12 * U, shy - 8 * U, 30 * U, 8 * U);
  ctx.fillStyle = Math.sin(t * 4) > 0 ? "#ff5a3c" : "#5a1a10";
  ctx.beginPath();
  ctx.arc(shx - 14 * U, shy - 30 * U, 2 * U, 0, 7);
  ctx.fill();
  // kapsül: suya iniş
  const drop = iclamp(lt / 0.6),
    cx = W * 0.55,
    cy = ilerp(H * 0.3, hy + 20 * U, iease(drop)) + Math.sin(t * 1.6) * 3 * U * drop;
  if (lt < 0.6) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.globalAlpha = 1 - drop;
    oChutes(0, 0, U * 1.1, t);
    ctx.restore();
    ctx.globalAlpha = 1;
  }
  if (lt > 0.55 && lt < 2.4) {
    const sp = (lt - 0.55) / 1.85;
    for (let i = 0; i < 22; i++) {
      const a = -Math.PI * (i / 21),
        d = sp * 90 * U * (0.6 + 0.4 * Math.sin(i * 7));
      ctx.fillStyle = "rgba(240,248,255," + (1 - sp) * 0.8 + ")";
      ctx.beginPath();
      ctx.arc(cx + Math.cos(a) * d, hy + 20 * U + Math.sin(a) * d * (1.2 - sp), (3 + 3 * (1 - sp)) * U, 0, 7);
      ctx.fill();
    }
    ctx.strokeStyle = "rgba(255,255,255," + (1 - sp) * 0.6 + ")";
    ctx.lineWidth = 2 * U;
    ctx.beginPath();
    ctx.ellipse(cx, hy + 24 * U, sp * 120 * U, sp * 16 * U, 0, 0, 7);
    ctx.stroke();
  }
  oCapsule(cx, cy, Math.sin(t * 1.2) * 0.08 * drop, U * 1.15, 0);
  {
    const wy = cy + 9 * U;
    ctx.fillStyle = sg;
    ctx.beginPath();
    ctx.moveTo(cx - 44 * U, wy + 16 * U); // su kapsülün alt kısmını örter
    for (let x = -44; x <= 44; x += 4) ctx.lineTo(cx + x * U, wy + Math.sin(x * 0.18 + t * 3) * 1.6 * U);
    ctx.lineTo(cx + 44 * U, wy + 16 * U);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "rgba(255,210,170,.5)";
    ctx.lineWidth = 1.2 * U;
    ctx.beginPath();
    for (let x = -44; x <= 44; x += 4) {
      const y = wy + Math.sin(x * 0.18 + t * 3) * 1.6 * U;
      x > -44 ? ctx.lineTo(cx + x * U, y) : ctx.moveTo(cx + x * U, y);
    }
    ctx.stroke();
  }
  if (Math.sin(t * 5) > 0.3 && lt > 1) {
    ctx.fillStyle = "#ff3b3b";
    ctx.beginPath();
    ctx.arc(cx, cy - 26 * U, 2.6 * U, 0, 7);
    ctx.fill();
  }
  iHud(
    [
      [T("EVRE"), T("SUYA İNİŞ"), "#4ade80"],
      [T("KONUM"), T("Pasifik Okyanusu")],
      [T("KURTARMA"), lt < 4 ? T("YOLDA") : T("KAPSÜLE YAKLAŞIYOR")],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
}
function oTitle(t, U) {
  // 68–72
  const lt = t - 68,
    O = intro.O;
  ctx.fillStyle = "#03040a";
  ctx.fillRect(0, 0, W, H);
  iStars(0.5, 0, 0, true);
  const a = iclamp(lt / 0.8);
  ctx.globalAlpha = a;
  iText("ARES-1", W / 2, H * 0.4, 13 * U + 4, { al: "center", mono: 1, w: 800, c: "#ff8c42", ls: 8 });
  iText(T("GÖREV TAMAMLANDI"), W / 2, H * 0.4 + 46 * U, 34 * U + 8, {
    al: "center",
    w: 300,
    c: "#ffffff",
    ls: 10,
  });
  iText(
    Tf(`Mars'ta {0} sol · {1} numune · bilim hedefi %{2}`, [O.sol, O.cargo, O.sci]),
    W / 2,
    H * 0.4 + 86 * U,
    12 * U + 4,
    { al: "center", mono: 1, w: 600, c: "#9fb0d4", ls: 2 },
  );
  ctx.globalAlpha = 1;
}
const OGRADE = [
  [11, 41],
  [21, 60],
  [35, 66],
  [44, 5],
  [52, 75],
  [59, 22],
  [68, 85],
  [99, 85],
];
function drawOutro() {
  const t = intro.t,
    U = Math.min(W, H) / 700,
    O = intro.O;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);
  if (t < 11) oLift(t, U);
  else if (t < 21) oOrbit(t, U);
  else if (t < 35) oCruise(t, U);
  else if (t < 44) oEarth(t, U);
  else if (t < 52) oEntry(t, U);
  else if (t < 59) oChute(t, U);
  else if (t < 68) oSplash(t, U);
  else oTitle(t, U);
  if (t >= 10.9 && t < 11.1) intro.parts.length = 0;
  if (t < 68) iPost(OGRADE.find((g) => t < g[0])[1]);
  const vg = ctx.createRadialGradient(
    W / 2,
    H / 2,
    Math.min(W, H) * 0.35,
    W / 2,
    H / 2,
    Math.max(W, H) * 0.75,
  );
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(0,0,0,.5)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);
  if (intro.grain && settings.grain !== false) {
    ctx.save();
    ctx.globalAlpha = 0.04;
    ctx.globalCompositeOperation = "overlay";
    const pt = ctx.createPattern(intro.grain, "repeat");
    ctx.translate(Math.random() * 160, Math.random() * 160);
    ctx.fillStyle = pt;
    ctx.fillRect(-160, -160, W + 320, H + 320);
    ctx.restore();
  }
  let fb = Math.max(1 - iclamp(t / 1.4), iclamp((t - (OUTRO_LEN - 1.2)) / 1.2));
  for (const b of [11, 21, 35, 44, 68]) fb = Math.max(fb, 1 - Math.min(1, Math.abs(t - b) / 0.55));
  if (fb > 0) {
    ctx.fillStyle = "rgba(0,0,0," + fb + ")";
    ctx.fillRect(0, 0, W, H);
  }
  let fw = 0;
  for (const b of [52, 59.5]) fw = Math.max(fw, 1 - Math.min(1, Math.abs(t - b) / 0.4));
  if (fw > 0) {
    ctx.fillStyle = "rgba(255,250,240," + fw * 0.85 + ")";
    ctx.fillRect(0, 0, W, H);
  }
  const bh = H * 0.085 * iclamp(t / 1.5);
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, bh);
  ctx.fillRect(0, H - bh, W, bh);
  const chp = O.chapters.filter((c) => c[0] <= t).pop();
  if (chp && t < 68) {
    const a = iclamp((t - chp[0] - 0.6) / 0.8) * (1 - iclamp((t - chp[0] - 5.5) / 1));
    if (a > 0) {
      ctx.globalAlpha = a;
      iText(chp[1], W * 0.04, bh * 0.62, 12 * U + 5, { mono: 1, w: 800, c: "#5ad1ff" });
      iText(chp[2], W * 0.04 + 28 * U + 8, bh * 0.62, 11 * U + 4, { mono: 1, w: 700, c: "#c9d3ea", ls: 4 });
      ctx.globalAlpha = 1;
    }
  }
  const cap = O.caps.find((c) => t >= c[0] && t < c[1]);
  if (cap) {
    const a = iclamp((t - cap[0]) * 4) * iclamp((cap[1] - t) * 4),
      n = Math.floor((t - cap[0]) * 42);
    const fs = Math.round((15 * U + 6) * (settings.subs || 1));
    ctx.font = "600 " + fs + "px 'Segoe UI',system-ui,sans-serif";
    const L = iWrap(cap[3], Math.min(W * 0.8, 900));
    let shown = n;
    const baseY = H - bh - fs * 0.9 - (L.length - 1) * fs * 1.35;
    ctx.globalAlpha = a;
    if (cap[2])
      iText(cap[2], W / 2, baseY - fs * 1.25, Math.round(fs * 0.62), {
        al: "center",
        mono: 1,
        w: 800,
        c: "#5ad1ff",
        ls: 3,
      });
    L.forEach((l, i) => {
      const part = l.slice(0, Math.max(0, shown));
      shown -= l.length + 1;
      ctx.save();
      ctx.shadowColor = "rgba(0,0,0,.9)";
      ctx.shadowBlur = 10;
      iText(part, W / 2, baseY + i * fs * 1.35, fs, {
        al: "center",
        w: cap[2] ? 600 : 500,
        c: cap[2] === T("KOMUTANIN GÜNLÜĞÜ") ? "#ffe3c9" : "#ffffff",
      });
      ctx.restore();
    });
    ctx.globalAlpha = 1;
  }
}

/* ---------- çizim yardımcıları ---------- */
const iclamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
const iease = (x) => {
  x = iclamp(x);
  return x < 0.5 ? 2 * x * x : 1 - Math.pow(-2 * x + 2, 2) / 2;
};
const ilerp = (a, b, k) => a + (b - a) * k;
function iStars(a, dx, dy, tw) {
  const t = performance.now() / 1000;
  for (const s of intro.stars) {
    const x = (((s.x * W + dx * s.s) % W) + W) % W,
      y = (((s.y * H + dy * s.s) % H) + H) % H;
    ctx.globalAlpha = a * (tw ? 0.55 + 0.45 * Math.sin(t * 1.7 + s.tw) : 0.9) * (0.4 + s.s * 0.4);
    ctx.fillStyle = s.c;
    ctx.fillRect(x, y, s.s * 1.3, s.s * 1.3);
  }
  ctx.globalAlpha = 1;
}
function iSpace(top, bot) {
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, top || "#02030a");
  g.addColorStop(1, bot || "#070b1c");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
}
function iMilky(a) {
  ctx.save();
  ctx.globalAlpha = a;
  ctx.translate(W * 0.5, H * 0.45);
  ctx.rotate(-0.42);
  const g = ctx.createLinearGradient(0, -H * 0.22, 0, H * 0.22);
  g.addColorStop(0, "rgba(120,110,200,0)");
  g.addColorStop(0.5, "rgba(170,150,230,.12)");
  g.addColorStop(1, "rgba(120,110,200,0)");
  ctx.fillStyle = g;
  ctx.fillRect(-W, -H * 0.22, W * 2, H * 0.44);
  ctx.restore();
}
function iSphereBlobs(list, cx, cy, r, rot, draw) {
  for (const b of list) {
    const a = b.lon + rot,
      cz = Math.cos(a);
    if (cz < -0.05) continue;
    const x = cx + r * Math.sin(a) * Math.cos(b.lat),
      y = cy - r * Math.sin(b.lat) * 0.98,
      k = Math.max(0.08, cz) * Math.cos(b.lat);
    draw(b, x, y, k);
  }
}
function iEarth(cx, cy, r, rot) {
  ctx.save();
  const ag = ctx.createRadialGradient(cx, cy, r * 0.92, cx, cy, r * 1.2);
  ag.addColorStop(0, "rgba(110,180,255,.6)");
  ag.addColorStop(0.35, "rgba(90,160,255,.22)");
  ag.addColorStop(1, "rgba(90,160,255,0)");
  ctx.fillStyle = ag;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 1.2, 0, 7);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, 7);
  ctx.save();
  ctx.clip();
  const og = ctx.createRadialGradient(cx + r * 0.35, cy - r * 0.3, r * 0.1, cx, cy, r);
  og.addColorStop(0, "#3a8fe0");
  og.addColorStop(0.6, "#1d5aa8");
  og.addColorStop(1, "#0b2552");
  ctx.fillStyle = og;
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  ctx.filter = "blur(" + Math.max(0.6, r * 0.004) + "px)";
  iSphereBlobs(intro.cont, cx, cy, r, rot, (b, x, y, k) => {
    ctx.fillStyle = b.col;
    ctx.beginPath();
    ctx.ellipse(x, y, b.rx * r * k, b.ry * r * Math.cos(b.lat) * 0.9 + 1, 0, 0, 7);
    ctx.fill();
  });
  if (r < 260) {
    ctx.fillStyle = "rgba(240,248,255,.9)";
    ctx.beginPath();
    ctx.ellipse(cx, cy - r * 0.97, r * 0.5, r * 0.09, 0, 0, 7);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(cx, cy + r * 0.98, r * 0.45, r * 0.07, 0, 0, 7);
    ctx.fill();
  }
  iSphereBlobs(intro.cloud, cx, cy, r, rot * 1.25 + 1, (b, x, y, k) => {
    ctx.fillStyle = "rgba(255,255,255,.5)";
    ctx.beginPath();
    ctx.ellipse(x, y, b.rx * r * k, b.ry * r, 0, 0, 7);
    ctx.fill();
  });
  ctx.filter = "none";
  // gece tarafı + şehir ışıkları
  const ng = ctx.createLinearGradient(cx - r, 0, cx + r * (r > 260 ? -0.05 : 0.35), 0);
  ng.addColorStop(0, "rgba(1,3,12,.94)");
  ng.addColorStop(0.55, "rgba(1,3,12,.7)");
  ng.addColorStop(1, "rgba(1,3,12,0)");
  ctx.fillStyle = ng;
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  iSphereBlobs(intro.cont, cx, cy, r, rot, (b, x, y, k) => {
    if (x > cx - r * (r > 260 ? 0.45 : 0.15)) return;
    const n = 4;
    for (let i = 0; i < n; i++) {
      const ox = Math.sin(i * 2.3 + b.lon * 9) * b.rx * r * k * 0.8,
        oy = Math.cos(i * 1.7 + b.lat * 7) * b.ry * r * 0.6;
      ctx.fillStyle = "rgba(255,205,120," + (0.5 + 0.3 * Math.sin(i + b.lon)) + ")";
      ctx.fillRect(x + ox, y + oy, 1.6, 1.6);
    }
  });
  const sh = ctx.createRadialGradient(cx + r * 0.5, cy - r * 0.4, 0, cx + r * 0.5, cy - r * 0.4, r * 1.1);
  sh.addColorStop(0, "rgba(255,255,255,.18)");
  sh.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = sh;
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  ctx.restore();
  ctx.strokeStyle = "rgba(150,210,255,.65)";
  ctx.lineWidth = Math.max(1, r * 0.012);
  ctx.beginPath();
  ctx.arc(cx, cy, r, -1.9, 0.7);
  ctx.stroke();
  ctx.restore();
}
function iMars(cx, cy, r, rot, lit) {
  ctx.save();
  const ag = ctx.createRadialGradient(cx, cy, r * 0.96, cx, cy, r * 1.1);
  ag.addColorStop(0, "rgba(255,150,100,.38)");
  ag.addColorStop(1, "rgba(255,150,100,0)");
  ctx.fillStyle = ag;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 1.1, 0, 7);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, 7);
  ctx.save();
  ctx.clip();
  const og = ctx.createRadialGradient(cx + r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r);
  og.addColorStop(0, "#e58a52");
  og.addColorStop(0.55, "#b9552a");
  og.addColorStop(1, "#5a2010");
  ctx.fillStyle = og;
  ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  iSphereBlobs(intro.mspot, cx, cy, r, rot, (b, x, y, k) => {
    ctx.fillStyle = b.d ? "rgba(90,35,18,.42)" : "rgba(240,170,110,.25)";
    ctx.beginPath();
    ctx.ellipse(x, y, b.rx * r * k, b.ry * r, 0, 0, 7);
    ctx.fill();
  });
  iSphereBlobs(intro.crat, cx, cy, r, rot, (b, x, y, k) => {
    ctx.strokeStyle = "rgba(70,25,10,.35)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.ellipse(x, y, b.r * r * k, b.r * r, 0, 0, 7);
    ctx.stroke();
  });
  if (r < 260) {
    ctx.fillStyle = "rgba(255,245,235,.85)";
    ctx.beginPath();
    ctx.ellipse(cx, cy - r * 0.96, r * 0.32, r * 0.08, 0, 0, 7);
    ctx.fill();
  }
  if (lit !== false) {
    const ng = ctx.createLinearGradient(cx - r, 0, cx + r * 0.4, 0);
    ng.addColorStop(0, "rgba(8,2,2,.85)");
    ng.addColorStop(0.6, "rgba(8,2,2,.35)");
    ng.addColorStop(1, "rgba(8,2,2,0)");
    ctx.fillStyle = ng;
    ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
  }
  ctx.restore();
  ctx.restore();
}
function iRocket(x, y, rot, s, flame) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  rocketBody({ flame, broken: false, t: performance.now() / 1000 });
  ctx.restore();
}
function iSmoke(x, y, n, U, o) {
  for (let i = 0; i < n; i++) {
    if (intro.parts.length > 320) return;
    const d = Math.random() < 0.5 ? -1 : 1;
    intro.parts.push({
      x: x + (Math.random() - 0.5) * 20 * U,
      y,
      vx: d * (o.sp || 1) * (60 + Math.random() * 240) * U,
      vy: -(o.up || 1) * (10 + Math.random() * 60) * U,
      r: (12 + Math.random() * 16) * U,
      gr: (26 + Math.random() * 30) * U,
      l: 0,
      m: (o.life || 3) + Math.random() * 2,
      dr: o.dr || 0.7,
      c: o.c || [205, 198, 190],
      a: o.a || 0.5,
    });
  }
}
function iParts2D() {
  for (const q of intro.parts) {
    const k = q.l / q.m;
    ctx.fillStyle = `rgba(${q.c[0]},${q.c[1]},${q.c[2]},${q.a * (1 - k) * Math.min(1, q.l * 4)})`;
    ctx.beginPath();
    ctx.arc(q.x, q.y, q.r, 0, 7);
    ctx.fill();
  }
}
function iText(txt, x, y, size, o) {
  if (intro && game && game.design && game.design.fx.days !== 214)
    txt = String(txt)
      .replace(/\b214\b/g, game.design.fx.days)
      .replace(/\b213\b/g, game.design.fx.days - 1);
  o = o || {};
  ctx.font =
    (o.w || 600) +
    " " +
    size +
    "px " +
    (o.mono ? "ui-monospace,Consolas,monospace" : "'Segoe UI',system-ui,sans-serif");
  ctx.textAlign = o.al || "left";
  ctx.textBaseline = o.bl || "alphabetic";
  if (o.ls && ctx.letterSpacing !== undefined) ctx.letterSpacing = o.ls + "px";
  if (o.glow) {
    ctx.shadowColor = o.glow;
    ctx.shadowBlur = o.gb || 12;
  }
  ctx.fillStyle = o.c || "#e8f1ff";
  ctx.fillText(txt, x, y);
  ctx.shadowBlur = 0;
  if (ctx.letterSpacing !== undefined) ctx.letterSpacing = "0px";
}
function iWrap(txt, maxW) {
  const words = txt.split(" "),
    L = [];
  let cur = "";
  for (const w of words) {
    const tst = cur ? cur + " " + w : w;
    if (ctx.measureText(tst).width > maxW && cur) {
      L.push(cur);
      cur = w;
    } else cur = tst;
  }
  if (cur) L.push(cur);
  return L;
}
function iHud(lines, x, y, U, col) {
  ctx.save();
  const fs = Math.round(12 * U + 3);
  ctx.font = "700 " + fs + "px ui-monospace,Consolas,monospace";
  const w = Math.max(...lines.map((l) => ctx.measureText(l[0] + "  " + l[1]).width)) + 28,
    h = lines.length * fs * 1.65 + 18;
  ctx.fillStyle = "rgba(4,10,24,.55)";
  rrp(x, y, w, h, 8);
  ctx.fill();
  ctx.strokeStyle = col || "rgba(90,209,255,.45)";
  ctx.lineWidth = 1;
  ctx.stroke();
  lines.forEach((l, i) => {
    iText(l[0], x + 14, y + 14 + fs + i * fs * 1.65, fs, { mono: 1, w: 700, c: "#8d9cc0" });
    iText(l[1], x + w - 14, y + 14 + fs + i * fs * 1.65, fs, {
      mono: 1,
      w: 800,
      al: "right",
      c: l[2] || "#e8f1ff",
    });
  });
  ctx.restore();
}

/* ---------- sahneler ---------- */
function sEarth2D(t, U) {
  // 0–16
  iSpace("#010208", "#04071a");
  iMilky(iclamp(t / 4) * 0.9);
  iStars(iclamp(t / 2.5), -t * 6, 0, true);
  // Mars: uzakta kızıl nokta
  const ma = iclamp((t - 8.5) / 2);
  if (ma > 0) {
    const mx = W * 0.78,
      my = H * 0.26,
      pr = 3 * U + 1.5 * Math.sin(t * 3);
    const g = ctx.createRadialGradient(mx, my, 0, mx, my, 26 * U);
    g.addColorStop(0, "rgba(255,120,70," + 0.55 * ma + ")");
    g.addColorStop(1, "rgba(255,120,70,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(mx, my, 26 * U, 0, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,150,100," + ma + ")";
    ctx.beginPath();
    ctx.arc(mx, my, pr, 0, 7);
    ctx.fill();
    ctx.globalAlpha = ma;
    ctx.strokeStyle = "rgba(255,180,140,.6)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(mx, my, 14 * U, 0, 7);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(mx + 14 * U, my - 6 * U);
    ctx.lineTo(mx + 46 * U, my - 24 * U);
    ctx.lineTo(mx + 120 * U, my - 24 * U);
    ctx.stroke();
    iText(T("MARS"), mx + 50 * U, my - 30 * U, 12 * U + 4, { mono: 1, w: 800, c: "#ffb38a", ls: 3 });
    iText(T("225 milyon km"), mx + 50 * U, my - 12 * U, 9 * U + 3, { mono: 1, c: "#c99b84" });
    ctx.globalAlpha = 1;
  }
  // Dünya: alttan yükselir
  const k = iease(t / 9),
    r = Math.max(W, H) * 0.62,
    cy = H + r * 0.98 - ilerp(0, r * 0.42, k);
  iEarth(W * 0.5, cy, r, t * 0.02 + 0.6);
  // gün doğumu parlaması
  const fl = iclamp((t - 4.2) / 2) * (1 - iclamp((t - 12) / 4));
  if (fl > 0) {
    const fx = W * 0.5 + r * 0.42,
      fy = cy - r * 0.9;
    const g = ctx.createRadialGradient(fx, fy, 0, fx, fy, W * 0.35);
    g.addColorStop(0, "rgba(255,250,235," + 0.9 * fl + ")");
    g.addColorStop(0.08, "rgba(255,220,170," + 0.35 * fl + ")");
    g.addColorStop(1, "rgba(255,200,150,0)");
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    ctx.globalCompositeOperation = "source-over";
  }
  // başlık
  const ta = iclamp((t - 1) / 1.5) * (1 - iclamp((t - 5.5) / 1.2));
  if (ta > 0) {
    ctx.globalAlpha = ta;
    iText(T("ARES PROGRAMI"), W / 2, H * 0.36, 13 * U + 4, {
      al: "center",
      w: 800,
      c: "#9fc9ff",
      ls: 6,
      mono: 1,
    });
    iText("2035", W / 2, H * 0.36 + 44 * U, 40 * U + 8, { al: "center", w: 300, c: "#ffffff", ls: 14 });
    ctx.globalAlpha = 1;
  }
}
function sControl(t, U) {
  // 16–30
  const lt = t - 16,
    k = lt / 14;
  ctx.save();
  ctx.translate(W / 2, H * 0.55);
  ctx.scale(1 + k * 0.07, 1 + k * 0.07);
  ctx.translate(-W / 2, -H * 0.55);
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, "#03060f");
  bg.addColorStop(0.6, "#081329");
  bg.addColorStop(1, "#02040a");
  ctx.fillStyle = bg;
  ctx.fillRect(-W * 0.1, -H * 0.1, W * 1.2, H * 1.2);
  // ana ekran
  const sx = W * 0.17,
    sy = H * 0.12,
    sw = W * 0.66,
    sh = H * 0.38;
  const sg = ctx.createRadialGradient(W / 2, sy + sh / 2, 10, W / 2, sy + sh / 2, sw * 0.7);
  sg.addColorStop(0, "rgba(60,140,255,.25)");
  sg.addColorStop(1, "rgba(60,140,255,0)");
  ctx.fillStyle = sg;
  ctx.fillRect(sx - sw * 0.2, sy - sh * 0.3, sw * 1.4, sh * 1.8);
  ctx.fillStyle = "#051028";
  rrp(sx, sy, sw, sh, 6);
  ctx.fill();
  ctx.strokeStyle = "#2b5a9a";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.save();
  rrp(sx, sy, sw, sh, 6);
  ctx.clip();
  ctx.strokeStyle = "rgba(90,160,255,.08)";
  ctx.lineWidth = 1;
  for (let x = sx; x < sx + sw; x += sw / 24) {
    ctx.beginPath();
    ctx.moveTo(x, sy);
    ctx.lineTo(x, sy + sh);
    ctx.stroke();
  }
  for (let y = sy; y < sy + sh; y += sh / 12) {
    ctx.beginPath();
    ctx.moveTo(sx, y);
    ctx.lineTo(sx + sw, y);
    ctx.stroke();
  }
  const ex = sx + sw * 0.2,
    ey = sy + sh * 0.68,
    mx = sx + sw * 0.8,
    my = sy + sh * 0.42;
  iEarth(ex, ey, sh * 0.14, lt * 0.1);
  iMars(mx, my, sh * 0.11, lt * 0.05);
  ctx.strokeStyle = "rgba(255,180,90,.85)";
  ctx.setLineDash([6, 6]);
  ctx.lineDashOffset = -lt * 30;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(ex, ey - sh * 0.16);
  ctx.quadraticCurveTo(sx + sw * 0.5, sy - sh * 0.15, mx, my - sh * 0.13);
  ctx.stroke();
  ctx.setLineDash([]);
  const u = (lt * 0.08) % 1,
    qx = (1 - u) * (1 - u) * ex + 2 * (1 - u) * u * (sx + sw * 0.5) + u * u * mx,
    qy = (1 - u) * (1 - u) * (ey - sh * 0.16) + 2 * (1 - u) * u * (sy - sh * 0.15) + u * u * (my - sh * 0.13);
  ctx.fillStyle = "#fff";
  ctx.beginPath();
  ctx.arc(qx, qy, 3, 0, 7);
  ctx.fill();
  const fs = Math.round(11 * U + 3);
  iText(T("ARES-1 · GÖREV PROFİLİ"), sx + 14, sy + fs + 10, fs, { mono: 1, w: 800, c: "#9fc9ff", ls: 2 });
  iText(T("TRANSFER YÖRÜNGESİ · 214 GÜN"), sx + 14, sy + fs * 2 + 16, fs * 0.9, { mono: 1, c: "#6f8ab8" });
  iText(T("MÜRETTEBAT: 1"), sx + sw - 14, sy + fs + 10, fs, { mono: 1, w: 800, c: "#ffd34d", al: "right" });
  if (Math.sin(lt * 4) > -0.2)
    iText(T("● GÖREV ONAYLANDI"), sx + sw - 14, sy + fs * 2 + 16, fs * 0.9, {
      mono: 1,
      w: 800,
      c: "#4ade80",
      al: "right",
    });
  ctx.restore();
  // yan ekranlar
  for (const [x0, col] of [
    [W * 0.02, "#4ade80"],
    [W * 0.86, "#ffb347"],
  ]) {
    ctx.fillStyle = "#04101f";
    rrp(x0, H * 0.16, W * 0.12, H * 0.24, 5);
    ctx.fill();
    ctx.strokeStyle = "rgba(90,160,255,.35)";
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.strokeStyle = col;
    ctx.lineWidth = 1.2;
    for (let r = 0; r < 3; r++) {
      ctx.beginPath();
      for (let i = 0; i <= 40; i++) {
        const x = x0 + 6 + (i * (W * 0.12 - 12)) / 40,
          y = H * 0.2 + r * H * 0.07 + Math.sin(i * 0.5 + lt * (3 + r) + r) * H * 0.012 * (1 + r * 0.4);
        i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
      }
      ctx.stroke();
    }
  }
  // konsol sıraları + insan siluetleri
  const rows = [
    [H * 0.6, 0.62],
    [H * 0.73, 0.8],
    [H * 0.9, 1.05],
  ];
  rows.forEach(([ry, sc], ri) => {
    const n = ri === 2 ? 5 : 7,
      sp = W / (n + 0.3);
    ctx.fillStyle = "#0a1428";
    ctx.fillRect(0, ry, W, H * 0.05 * sc);
    ctx.fillStyle = "#132443";
    ctx.fillRect(0, ry, W, 3 * sc);
    for (let i = 0; i < n; i++) {
      const cx = sp * (i + 0.65) + (ri % 2 ? sp * 0.3 : 0),
        mw = 44 * U * sc,
        mh = 28 * U * sc;
      const hx = cx + Math.sin(lt * 0.8 + i * 2 + ri) * 3 * sc,
        hy = ry - mh - 16 * U * sc;
      // kişi
      ctx.fillStyle = "#010309";
      ctx.beginPath();
      ctx.arc(hx, hy, 11 * U * sc, 0, 7);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(hx, ry - 4 * sc, 24 * U * sc, 18 * U * sc, 0, Math.PI, 0);
      ctx.fill();
      ctx.strokeStyle = "rgba(90,170,255,.45)";
      ctx.lineWidth = 1.2 * sc;
      ctx.beginPath();
      ctx.arc(hx, hy, 11 * U * sc, -1.2, 0.5);
      ctx.stroke();
      if ((i + ri) % 3 === 0) {
        ctx.strokeStyle = "#0a0f1c";
        ctx.lineWidth = 2 * sc;
        ctx.beginPath();
        ctx.arc(hx, hy, 13 * U * sc, Math.PI * 1.1, -0.1 * Math.PI);
        ctx.stroke();
      } // kulaklık
      // monitörler
      for (const off of [-1, 1]) {
        const mx = cx + off * (mw * 0.75),
          my = ry - mh - 4 * sc,
          c = ["#1d6fd8", "#14a36b", "#d98a1d", "#1d6fd8"][(i + ri + (off > 0 ? 1 : 0)) % 4];
        ctx.fillStyle = "#020611";
        rrp(mx - mw / 2, my, mw, mh, 3 * sc);
        ctx.fill();
        ctx.fillStyle = c;
        ctx.globalAlpha = 0.55 + 0.15 * Math.sin(lt * 2 + i + off);
        rrp(mx - mw / 2 + 2 * sc, my + 2 * sc, mw - 4 * sc, mh - 4 * sc, 2 * sc);
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.fillStyle = "rgba(255,255,255,.55)";
        for (let l = 0; l < 3; l++)
          ctx.fillRect(
            mx - mw / 2 + 5 * sc,
            my + 6 * sc + l * 6 * sc,
            (mw - 14 * sc) * (0.4 + 0.5 * Math.abs(Math.sin(i * 3 + l + off + Math.floor(lt * 2)))),
            1.5 * sc,
          );
      }
    }
  });
  ctx.restore();
  const v = ctx.createLinearGradient(0, H * 0.5, 0, H);
  v.addColorStop(0, "rgba(0,0,0,0)");
  v.addColorStop(1, "rgba(0,0,0,.55)");
  ctx.fillStyle = v;
  ctx.fillRect(0, 0, W, H);
}
function sDossier(t, U) {
  // 30–40
  const lt = t - 30;
  iSpace("#03060f", "#0a1226");
  ctx.strokeStyle = "rgba(90,209,255,.05)";
  ctx.lineWidth = 1;
  for (let x = 0; x < W; x += 40) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, H);
    ctx.stroke();
  }
  for (let y = 0; y < H; y += 40) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
    ctx.stroke();
  }
  const cw = Math.min(W * 0.84, 980),
    ch = Math.min(H * 0.66, 470),
    x0 = W / 2 - cw / 2,
    y0 = H / 2 - ch / 2 - H * 0.02,
    ap = iease(lt / 0.7);
  ctx.save();
  ctx.globalAlpha = ap;
  ctx.translate(0, (1 - ap) * 30);
  ctx.shadowColor = "rgba(90,209,255,.35)";
  ctx.shadowBlur = 40;
  ctx.fillStyle = "rgba(10,18,40,.94)";
  rrp(x0, y0, cw, ch, 14);
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = "rgba(90,209,255,.4)";
  ctx.lineWidth = 1.2;
  ctx.stroke();
  const fs = iclamp(ch * 0.038, 11, 17),
    hh = fs * 2.6;
  ctx.fillStyle = "rgba(90,209,255,.1)";
  rrp(x0, y0, cw, hh, 14);
  ctx.fill();
  iText(T("ARES PROGRAMI — GÖREV DOSYASI"), x0 + 20, y0 + hh * 0.62, fs, {
    mono: 1,
    w: 800,
    c: "#9fc9ff",
    ls: 2,
  });
  iText(T("GİZLİLİK: ÜST DÜZEY"), x0 + cw - 20, y0 + hh * 0.62, fs * 0.85, {
    mono: 1,
    w: 800,
    c: "#ff8c42",
    al: "right",
    ls: 1,
  });
  // portre
  const pw = Math.min(cw * 0.3, ch * 0.62),
    ph = ch - hh - 30,
    px = x0 + 18,
    py = y0 + hh + 14;
  const pg = ctx.createLinearGradient(0, py, 0, py + ph);
  pg.addColorStop(0, "#16264d");
  pg.addColorStop(1, "#0a1226");
  ctx.fillStyle = pg;
  rrp(px, py, pw, ph, 10);
  ctx.fill();
  ctx.strokeStyle = "rgba(90,209,255,.3)";
  ctx.stroke();
  ctx.save();
  rrp(px, py, pw, ph, 10);
  ctx.clip();
  const sc = Math.min(pw / 70, ph / 120);
  ctx.save();
  ctx.translate(px + pw / 2, py + ph * 0.62);
  ctx.scale(sc, sc);
  try {
    p.walk = 0;
    p.dir = 1;
    p.sx = p.sy = 1;
    astronaut(0, 0, false, null, 0);
  } catch (e) {}
  ctx.restore();
  const scan = py + ((lt * 0.35) % 1) * ph;
  ctx.fillStyle = "rgba(90,209,255,.22)";
  ctx.fillRect(px, scan, pw, 2);
  ctx.fillStyle = "rgba(90,209,255,.06)";
  for (let y = py; y < py + ph; y += 4) ctx.fillRect(px, y, pw, 1);
  ctx.restore();
  iText(T("KOMUTAN — SEN"), px + pw / 2, py + ph - fs * 1.9, fs * 0.95, {
    al: "center",
    w: 800,
    c: "#fff",
    ls: 1,
  });
  iText(T("KİMLİK ARES-1/CDR"), px + pw / 2, py + ph - fs * 0.7, fs * 0.75, {
    al: "center",
    mono: 1,
    c: "#8d9cc0",
  });
  // bilgiler
  const ix = px + pw + 26,
    iw = x0 + cw - ix - 22;
  let y = py + fs * 1.2;
  const rows = [
    [T("GÖREV"), T("ARES-1 · Mars yüzey keşfi")],
    [T("MÜRETTEBAT"), T("1 kişi — Komutan (sen)")],
    [T("ARAÇ"), T("ARES-1 iniş ve dönüş roketi · 3 güverte")],
    [T("YOLCULUK"), T("≈ 214 gün · 225 milyon km")],
    [T("HEDEF"), T("Mars · ekvator ovası")],
    [T("YER BİRİMİ"), T("Görev Kontrol · 3 yer istasyonu")],
  ];
  const goals = [
    T("Atmosferi, toprağı ve radyasyonu ölç, verileri topla"),
    T("Su, oksijen ve tarımla yaşam koşullarını test et"),
    T("Fırtına, radyasyon ve meteor gibi tehlikeleri raporla"),
    T("Tüm bulguları iletişim terminalinden Dünya'ya aktar"),
  ];
  const show = (i, k) => iclamp((lt - 0.8 - i * 0.55) * k);
  rows.forEach((r, i) => {
    const a = show(i, 3);
    if (a <= 0) return;
    ctx.globalAlpha = ap * a;
    iText(r[0], ix, y, fs * 0.78, { mono: 1, w: 800, c: "#5ad1ff", ls: 1 });
    const full = r[1],
      n = Math.floor(full.length * iclamp((lt - 0.8 - i * 0.55) * 2.2));
    iText(full.slice(0, n), ix + iw * 0.3, y, fs, { w: 600, c: "#fff" });
    ctx.fillStyle = "rgba(141,156,192,.18)";
    ctx.fillRect(ix, y + fs * 0.6, iw, 1);
    y += fs * 1.85;
  });
  y += fs * 0.5;
  const ga = show(6, 3);
  if (ga > 0) {
    ctx.globalAlpha = ap * ga;
    iText(T("GÖREV AMAÇLARI"), ix, y, fs * 0.78, { mono: 1, w: 800, c: "#ff8c42", ls: 2 });
    y += fs * 1.6;
    goals.forEach((g, i) => {
      const a = show(6.6 + i * 0.75, 2.5);
      if (a <= 0) return;
      ctx.globalAlpha = ap * a;
      iText("▸", ix, y, fs, { c: "#ff8c42", w: 800 });
      ctx.font = "600 " + fs + "px 'Segoe UI',system-ui,sans-serif";
      const L = iWrap(g, iw - fs * 1.6);
      L.forEach((l, j) => iText(l, ix + fs * 1.4, y + j * fs * 1.3, fs, { c: "#dfe7f8" }));
      y += fs * 1.3 * L.length + fs * 0.45;
    });
  }
  ctx.globalAlpha = ap;
  // mühür
  const st = lt - 7.5;
  if (st > 0) {
    const s = Math.max(1, 2.4 - st * 9),
      a = iclamp(st * 8);
    ctx.save();
    ctx.translate(x0 + cw - cw * 0.17, y0 + ch - ch * 0.2);
    ctx.rotate(-0.2);
    ctx.scale(s, s);
    ctx.globalAlpha = a * ap * 0.92;
    ctx.strokeStyle = "#ff4d4d";
    ctx.lineWidth = 3.5;
    rrp(-fs * 6, -fs * 1.5, fs * 12, fs * 3, 6);
    ctx.stroke();
    ctx.lineWidth = 1.2;
    rrp(-fs * 5.6, -fs * 1.15, fs * 11.2, fs * 2.3, 4);
    ctx.stroke();
    iText(T("ONAYLANDI"), 0, fs * 0.55, fs * 1.55, { al: "center", w: 900, c: "#ff4d4d", ls: 4 });
    ctx.restore();
  }
  ctx.restore();
  ctx.globalAlpha = 1;
}
function sLaunch(t, U) {
  // 40–57
  const lt = t - 40,
    G = H * 0.8,
    s = U * 2.25,
    ig = t >= 52,
    lift = t >= 53.5,
    lu = t - 53.5;
  const shake = ig ? Math.min(1, (t - 52) / 1.5) * (lift ? Math.max(0.3, 1 - lu / 4) : 1) * 7 * U : 0;
  ctx.save();
  if (shake) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
  const sky = ctx.createLinearGradient(0, 0, 0, G);
  sky.addColorStop(0, "#060d24");
  sky.addColorStop(0.45, "#1f3466");
  sky.addColorStop(0.8, "#b5694f");
  sky.addColorStop(1, "#f6a466");
  ctx.fillStyle = sky;
  ctx.fillRect(-20, -20, W + 40, G + 20);
  iStars(0.5 * (1 - iclamp(lt / 10)), 0, 0, true);
  const sun = ctx.createRadialGradient(W * 0.82, G, 0, W * 0.82, G, H * 0.5);
  sun.addColorStop(0, "rgba(255,230,180,.85)");
  sun.addColorStop(0.15, "rgba(255,170,100,.35)");
  sun.addColorStop(1, "rgba(255,140,90,0)");
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, W, G);
  // uzak kıyı
  ctx.fillStyle = "#1b1c33";
  ctx.beginPath();
  ctx.moveTo(-20, G);
  for (let x = 0; x <= W + 20; x += W / 16)
    ctx.lineTo(x, G - H * 0.03 - Math.abs(Math.sin(x * 0.013)) * H * 0.025);
  ctx.lineTo(W + 20, G);
  ctx.closePath();
  ctx.fill();
  const gr = ctx.createLinearGradient(0, G, 0, H);
  gr.addColorStop(0, "#272a3e");
  gr.addColorStop(1, "#0d0e18");
  ctx.fillStyle = gr;
  ctx.fillRect(-20, G, W + 40, H - G + 20);
  const rx = W * 0.5,
    ry = G - 46 * s - (lift ? lu * lu * H * 0.085 + lu * 12 * U : 0);
  // kule
  const tx = rx - 62 * s,
    tw = 22 * s,
    th = 170 * s;
  ctx.strokeStyle = "#3a3f5c";
  ctx.lineWidth = 2;
  ctx.strokeRect(tx - tw / 2, G - th, tw, th);
  ctx.beginPath();
  for (let y = G; y > G - th; y -= tw) {
    ctx.moveTo(tx - tw / 2, y);
    ctx.lineTo(tx + tw / 2, y - tw);
    ctx.moveTo(tx + tw / 2, y);
    ctx.lineTo(tx - tw / 2, y - tw);
  }
  ctx.stroke();
  ctx.fillStyle = "#ff5a5a";
  if (Math.sin(t * 4) > 0) {
    ctx.beginPath();
    ctx.arc(tx, G - th - 4, 3, 0, 7);
    ctx.fill();
  }
  const arm = iclamp((t - 50.5) / 1.4);
  ctx.fillStyle = "#4b5070";
  ctx.save();
  ctx.translate(tx + tw / 2, G - th * 0.68);
  ctx.rotate(-arm * 1.1);
  ctx.fillRect(0, -3 * s, rx - tx - tw / 2 - 24 * s, 6 * s);
  ctx.restore();
  // rampa
  ctx.fillStyle = "#3a3e57";
  ctx.beginPath();
  ctx.moveTo(rx - 70 * s, G);
  ctx.lineTo(rx - 50 * s, G - 10 * s);
  ctx.lineTo(rx + 50 * s, G - 10 * s);
  ctx.lineTo(rx + 70 * s, G);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#14151f";
  ctx.fillRect(rx - 24 * s, G - 10 * s, 48 * s, 10 * s);
  // duman
  if (ig && Math.random() < 0.95) {
    iSmoke(rx, G - 6 * s, lift ? 3 : 5, U, { sp: lift ? 0.7 : 1.2, up: 0.6, life: 3.5 });
    if (lift && lu < 3) iSmoke(rx, ry + 60 * s, 2, U, { sp: 0.25, up: -0.2, life: 2.5, a: 0.4 });
  }
  // roket + alev
  const fl = ig ? Math.min(1.15, (t - 52) * 0.6 + (lift ? 0.4 : 0)) : 0;
  if (fl > 0) {
    const gx = rx,
      gy = ry + 70 * s,
      R = (70 + fl * 70) * U;
    const g = ctx.createRadialGradient(gx, gy, 0, gx, gy, R * 2.2);
    g.addColorStop(0, "rgba(255,240,200," + 0.8 * Math.min(1, fl) + ")");
    g.addColorStop(0.2, "rgba(255,160,80,.45)");
    g.addColorStop(1, "rgba(255,120,60,0)");
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = g;
    ctx.fillRect(gx - R * 2.2, gy - R * 2.2, R * 4.4, R * 4.4);
    ctx.globalCompositeOperation = "source-over";
  }
  iRocket(rx, ry, 0, s, fl);
  iParts();
  // ışık parlaması
  if (ig) {
    ctx.fillStyle = "rgba(255,190,120," + 0.18 * Math.min(1, fl) + ")";
    ctx.fillRect(-20, -20, W + 40, H + 40);
  }
  ctx.restore();
  // geri sayım
  if (t >= 42 && t < 53.5) {
    const n = 10 - Math.floor(t - 42),
      k = (t - 42) % 1;
    ctx.save();
    if (n >= 1) {
      const sz = (76 + Math.max(0, 0.25 - k) * 120) * U;
      ctx.globalAlpha = 1 - Math.max(0, k - 0.75) * 3;
      iText(T("KALKIŞA"), W / 2, H * 0.2, 12 * U + 4, { al: "center", mono: 1, w: 800, c: "#ffb38a", ls: 6 });
      iText("T–" + String(n).padStart(2, "0"), W / 2, H * 0.2 + sz * 0.95, sz, {
        al: "center",
        w: 300,
        c: "#ffffff",
        ls: 6,
        glow: "rgba(255,140,80,.8)",
        gb: 20,
        mono: 1,
      });
    } else {
      ctx.globalAlpha = Math.min(1, (t - 52) * 4);
      iText(T("ATEŞLEME"), W / 2, H * 0.28, 44 * U + 6, {
        al: "center",
        w: 800,
        c: "#ffd34d",
        ls: 12,
        glow: "#ff8c42",
        gb: 24,
      });
    }
    ctx.restore();
  }
  if (lift && lu < 2.6) {
    ctx.globalAlpha = Math.min(1, lu * 3) * (1 - iclamp((lu - 2) / 0.6));
    iText(T("KALKIŞ"), W / 2, H * 0.28, 44 * U + 6, {
      al: "center",
      w: 800,
      c: "#fff",
      ls: 14,
      glow: "#5ad1ff",
      gb: 24,
    });
    ctx.globalAlpha = 1;
  }
  if (t >= 42 && t < 53.5)
    iHud(
      [
        [T("ARAÇ"), "ARES-1"],
        [T("YAKIT"), "%100", "#4ade80"],
        [T("RÜZGÂR"), T("6 km/sa")],
        [T("DURUM"), t < 52 ? T("HAZIR") : T("ATEŞLEME"), t < 52 ? "#4ade80" : "#ffd34d"],
      ],
      W * 0.04,
      H * 0.14,
      U,
    );
}
function sAscent(t, U) {
  // 57–62
  const lt = t - 57,
    k = lt / 5;
  const top = [ilerp(40, 2, k), ilerp(110, 4, k), ilerp(210, 14, k)],
    bot = [ilerp(150, 8, k), ilerp(205, 12, k), ilerp(255, 30, k)];
  const g = ctx.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, `rgb(${top.map(Math.round)})`);
  g.addColorStop(1, `rgb(${bot.map(Math.round)})`);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H);
  iStars(iclamp((k - 0.45) * 2), 0, lt * 40, false);
  if (GLX.ok && k > 0.5) {
    ctx.globalAlpha = iclamp((k - 0.5) * 2.5);
    const er = Math.max(W, H) * 1.6;
    ctx.drawImage(
      glxSpace({
        time: t,
        milky: 0.4,
        stars: 0.8,
        p1: [W * 0.5, H * 0.98 + er - ilerp(0, H * 0.42, iease((k - 0.5) * 2)), er, 0],
        rot1: 0.9 + lt * 0.01,
        tilt1: 1.2,
        l1: [0.5, 0.55, 0.65],
      }),
      0,
      0,
      W,
      H,
    );
    ctx.globalAlpha = 1;
  }
  // bulutlar aşağı akar
  const ca = 1 - iclamp((k - 0.35) * 2.5);
  if (ca > 0) {
    for (let i = 0; i < 14; i++) {
      const y = ((i * 137 + lt * H * 1.1) % (H * 1.4)) - H * 0.2,
        x = (i * 311) % W;
      ctx.fillStyle = "rgba(255,255,255," + 0.5 * ca + ")";
      ctx.beginPath();
      ctx.ellipse(x, y, (90 + (i % 4) * 40) * U, (14 + (i % 3) * 6) * U, 0, 0, 7);
      ctx.fill();
    }
  }
  // hız çizgileri
  ctx.strokeStyle = "rgba(255,255,255,.25)";
  ctx.lineWidth = 1;
  for (let i = 0; i < 24; i++) {
    const x = (i * 97) % W,
      y = (i * 53 + lt * H * 2.4) % H;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x, y - 40 * U);
    ctx.stroke();
  }
  const s = U * 1.7,
    rx = W * 0.5 + Math.sin(lt * 2) * 3,
    ry = H * 0.5,
    rot = 0.12 + k * 0.18;
  // kademe ayrılması
  if (lt > 3.1) {
    const d = lt - 3.1;
    ctx.save();
    ctx.translate(rx - d * 30 * U, ry + 90 * s * 0.6 + d * d * H * 0.12);
    ctx.rotate(-d * 1.4);
    ctx.fillStyle = "#c5ccdf";
    rrp(-14 * s, -20 * s, 28 * s, 40 * s, 4 * s);
    ctx.fill();
    ctx.fillStyle = "#8e2f26";
    ctx.fillRect(-14 * s, 10 * s, 28 * s, 6 * s);
    ctx.restore();
    if (d < 0.4) {
      ctx.fillStyle = "rgba(255,240,210," + (1 - d / 0.4) + ")";
      ctx.beginPath();
      ctx.arc(rx, ry + 60 * s, (30 + d * 120) * U, 0, 7);
      ctx.fill();
    }
  }
  iRocket(rx, ry, rot, s, 1.1);
  iHud(
    [
      [T("İRTİFA"), fmtN(Math.pow(k, 1.5) * 410, 0) + " km"],
      [T("HIZ"), fmtN(0.4 + k * 7.4, 1) + " km/s"],
      [
        T("EVRE"),
        lt < 1.4 ? "MAX-Q" : lt < 3.1 ? T("YÜKSELİŞ") : lt < 3.9 ? T("KADEME AYRILMASI") : T("YÖRÜNGE"),
        lt >= 3.1 && lt < 3.9 ? "#ffd34d" : "#4ade80",
      ],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
}
function sCruise(t, U) {
  // 62–72
  const lt = t - 62,
    k = lt / 10;
  const ex = W * 0.15,
    ey = H * 0.66,
    er = H * (0.15 - 0.11 * k),
    mx = W * 0.85,
    my = H * 0.36,
    mr = H * (0.025 + 0.12 * iease(k));
  if (GLX.ok)
    ctx.drawImage(
      glxSpace({
        time: t,
        off: [lt * 14, 0],
        p1: [ex, ey, er, 0],
        rot1: lt * 0.08,
        l1: [0.8, 0.3, 0.5],
        p2: [mx, my, mr, 1],
        rot2: lt * 0.04 + 1.2,
        l2: [-0.6, 0.3, 0.72],
      }),
      0,
      0,
      W,
      H,
    );
  else {
    iSpace("#010208", "#03061a");
    iMilky(0.9);
    iStars(1, -lt * 14, 0, true);
    iEarth(ex, ey, er, lt * 0.08);
    iMars(mx, my, mr, lt * 0.04);
  }
  const cx = W * 0.5,
    cy = H * 0.06,
    B = (u) => ({
      x: (1 - u) * (1 - u) * ex + 2 * (1 - u) * u * cx + u * u * mx,
      y: (1 - u) * (1 - u) * (ey - er * 1.2) + 2 * (1 - u) * u * cy + u * u * (my - mr * 1.4),
    });
  const u0 = 0.04 + 0.9 * iease(k);
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(255,180,90,.9)";
  ctx.beginPath();
  for (let i = 0; i <= 40; i++) {
    const q = B((i / 40) * u0);
    i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y);
  }
  ctx.stroke();
  ctx.setLineDash([5, 7]);
  ctx.strokeStyle = "rgba(255,180,90,.4)";
  ctx.beginPath();
  for (let i = 0; i <= 40; i++) {
    const q = B(u0 + ((1 - u0) * i) / 40);
    i ? ctx.lineTo(q.x, q.y) : ctx.moveTo(q.x, q.y);
  }
  ctx.stroke();
  ctx.setLineDash([]);
  const q = B(u0),
    q2 = B(Math.min(1, u0 + 0.01)),
    ang = Math.atan2(q2.y - q.y, q2.x - q.x);
  const gl = ctx.createRadialGradient(q.x, q.y, 0, q.x, q.y, 40 * U);
  gl.addColorStop(0, "rgba(255,200,140,.35)");
  gl.addColorStop(1, "rgba(255,200,140,0)");
  ctx.fillStyle = gl;
  ctx.beginPath();
  ctx.arc(q.x, q.y, 40 * U, 0, 7);
  ctx.fill();
  iRocket(q.x, q.y, ang + Math.PI / 2, U * 0.55, 0.25 + 0.1 * Math.sin(t * 20));
  const TD = game && game.design ? game.design.fx.days : 214,
    day = Math.max(1, Math.round(1 + (TD - 1) * iease(k)));
  iText(T("GÖREV GÜNÜ"), W / 2, H * 0.15, 11 * U + 4, { al: "center", mono: 1, w: 800, c: "#8d9cc0", ls: 5 });
  iText(String(day).padStart(3, "0") + " / 214", W / 2, H * 0.15 + 40 * U, 34 * U + 8, {
    al: "center",
    mono: 1,
    w: 300,
    c: "#fff",
    ls: 4,
  });
  const dist = ilerp(0.4, 225, iease(k)),
    dl = ilerp(0.02, 12.5, iease(k));
  iHud(
    [
      [T("DÜNYA'YA UZAKLIK"), fmtN(dist, 1) + T(" milyon km")],
      [T("SİNYAL GECİKMESİ"), fmtN(dl, 1) + T(" dk")],
      [T("HIZ"), "24,1 km/s"],
      [T("YER İSTASYONU"), ["A", "B", "C"][Math.floor(day / 9) % 3]],
    ],
    W * 0.04,
    H * 0.14,
    U,
  );
  iText(T("DÜNYA"), ex, ey + er + 22 * U, 10 * U + 4, { al: "center", mono: 1, w: 800, c: "#9fc9ff", ls: 3 });
  iText(T("MARS"), mx, my + mr + 22 * U, 10 * U + 4, { al: "center", mono: 1, w: 800, c: "#ffb38a", ls: 3 });
}
function sEntry(t, U) {
  // 72–79
  const lt = t - 72,
    k = lt / 7;
  const r = Math.max(W, H) * 1.15,
    cy = H * 0.62 + r - ilerp(0, H * 0.25, iease(k));
  if (GLX.ok)
    ctx.drawImage(
      glxSpace({
        time: t,
        milky: 0.6,
        stars: 1 - iclamp((k - 0.5) * 2),
        p1: [W * 0.55, cy, r, 1],
        rot1: 0.4 + lt * 0.01,
        tilt1: 1.1,
        l1: [0.35, 0.6, 0.72],
      }),
      0,
      0,
      W,
      H,
    );
  else {
    iSpace("#010208", "#0a0408");
    iStars(1 - iclamp((k - 0.5) * 2), 0, 0, true);
    iMars(W * 0.55, cy, r, 0.4 + lt * 0.01, false);
  }
  if (!GLX.ok) {
    const atm = ctx.createLinearGradient(0, cy - r - H * 0.12, 0, cy - r + H * 0.05);
    atm.addColorStop(0, "rgba(255,150,100,0)");
    atm.addColorStop(1, "rgba(255,170,120,.35)");
    ctx.fillStyle = atm;
    ctx.fillRect(0, cy - r - H * 0.12, W, H * 0.17);
  }
  const pk = iclamp((lt - 1.4) / 2) * (1 - iclamp((lt - 6) / 1)),
    sh = pk * 5 * U;
  ctx.save();
  if (sh) ctx.translate((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);
  const rx = W * ilerp(0.18, 0.56, iease(k)),
    ry = H * ilerp(0.1, 0.42, iease(k)),
    ang = Math.atan2(H * 0.32, W * 0.38),
    s = U * 1.15;
  if (pk > 0) {
    // plazma kılıfı
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < 26; i++) {
      const l = (80 + Math.random() * 200) * U * pk,
        o = (Math.random() - 0.5) * 36 * U;
      ctx.strokeStyle = "rgba(255," + ((130 + Math.random() * 90) | 0) + ",60," + 0.35 * pk + ")";
      ctx.lineWidth = (1 + Math.random() * 3) * U;
      ctx.beginPath();
      ctx.moveTo(
        rx + Math.cos(ang) * 40 * s - Math.sin(ang) * o,
        ry + Math.sin(ang) * 40 * s + Math.cos(ang) * o,
      );
      ctx.lineTo(
        rx - Math.cos(ang) * l - Math.sin(ang) * o * 1.8,
        ry - Math.sin(ang) * l + Math.cos(ang) * o * 1.8,
      );
      ctx.stroke();
    }
    const g = ctx.createRadialGradient(
      rx + Math.cos(ang) * 70 * s,
      ry + Math.sin(ang) * 70 * s,
      0,
      rx + Math.cos(ang) * 70 * s,
      ry + Math.sin(ang) * 70 * s,
      90 * U,
    );
    g.addColorStop(0, "rgba(255,255,230," + pk + ")");
    g.addColorStop(0.3, "rgba(255,170,80," + 0.7 * pk + ")");
    g.addColorStop(1, "rgba(255,90,40,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(rx + Math.cos(ang) * 70 * s, ry + Math.sin(ang) * 70 * s, 90 * U, 0, 7);
    ctx.fill();
    ctx.globalCompositeOperation = "source-over";
  }
  iRocket(rx, ry, ang + Math.PI / 2, s, 0);
  ctx.restore();
  if (pk > 0) {
    ctx.fillStyle = "rgba(255,120,60," + 0.12 * pk + ")";
    ctx.fillRect(0, 0, W, H);
  }
  const lost = lt > 4.6;
  iHud(
    [
      [T("EVRE"), T("ATMOSFERE GİRİŞ")],
      [T("HIZ"), fmtN(ilerp(5.8, 1.2, k), 1) + " km/s"],
      [T("ISI KALKANI"), fmtN(ilerp(200, 1600, iclamp(lt / 4.5)), 0) + " °C", lt > 3 ? "#ff8c42" : "#e8f1ff"],
      [T("SİNYAL"), lost ? (Math.sin(t * 8) > 0 ? T("YOK") : "—") : "▮▮▮▯", lost ? "#ff5a5a" : "#4ade80"],
    ],
    W * 0.04,
    H * 0.14,
    U,
    lost ? "rgba(255,90,90,.6)" : null,
  );
}
function sLand2D(t, U) {
  // 79–92
  const lt = t - 79,
    G = H * 0.78;
  const sky = ctx.createLinearGradient(0, 0, 0, G);
  sky.addColorStop(0, "#5e3a2c");
  sky.addColorStop(0.6, "#c48a62");
  sky.addColorStop(1, "#e8bf94");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, W, G);
  const sun = ctx.createRadialGradient(W * 0.2, H * 0.2, 0, W * 0.2, H * 0.2, H * 0.3);
  sun.addColorStop(0, "rgba(255,245,230,.9)");
  sun.addColorStop(0.06, "rgba(255,235,210,.5)");
  sun.addColorStop(1, "rgba(255,220,190,0)");
  ctx.fillStyle = sun;
  ctx.fillRect(0, 0, W, G);
  ctx.fillStyle = "#a35a38";
  ctx.beginPath();
  ctx.moveTo(0, G);
  for (let x = 0; x <= W; x += W / 20)
    ctx.lineTo(
      x,
      G - H * 0.07 - Math.abs(Math.sin(x * 0.008 + 1)) * H * 0.06 - Math.sin(x * 0.03) * H * 0.01,
    );
  ctx.lineTo(W, G);
  ctx.fill();
  ctx.fillStyle = "#8a4426";
  ctx.beginPath();
  ctx.moveTo(0, G);
  for (let x = 0; x <= W; x += W / 24)
    ctx.lineTo(x, G - H * 0.025 - Math.abs(Math.sin(x * 0.017 + 3)) * H * 0.03);
  ctx.lineTo(W, G);
  ctx.fill();
  const gg = ctx.createLinearGradient(0, G, 0, H);
  gg.addColorStop(0, "#b8673a");
  gg.addColorStop(1, "#6e3218");
  ctx.fillStyle = gg;
  ctx.fillRect(0, G, W, H - G);
  for (const r of intro.rocks) {
    const x = r.x * W,
      y = G + 8 + r.k * (H - G - 8),
      sz = (3 + r.s * 9) * U * (0.5 + r.k);
    ctx.fillStyle = "#5e2a14";
    ctx.beginPath();
    ctx.ellipse(x, y, sz * 1.4, sz * 0.7, 0, 0, 7);
    ctx.fill();
    ctx.fillStyle = "rgba(255,200,160,.25)";
    ctx.beginPath();
    ctx.ellipse(x - sz * 0.3, y - sz * 0.25, sz * 0.6, sz * 0.25, 0, 0, 7);
    ctx.fill();
  }
  const s = U * 2,
    TD = 3.5,
    u = iclamp(lt / TD),
    rest = G - 34 * s - 8 * U,
    ry = ilerp(-H * 0.25, rest, 1 - Math.pow(1 - u, 2.2)),
    rx = W * 0.52;
  const fl = lt < TD ? 0.95 : Math.max(0, 0.95 - (lt - TD) * 1.2);
  if (lt > 1.8 && lt < TD + 0.6)
    iSmoke(rx, G, lt > TD - 0.4 ? 6 : 2, U, {
      sp: 1.6,
      up: 0.35,
      life: 3,
      c: [200, 130, 90],
      a: 0.45,
      dr: 0.9,
    });
  if (!intro.td && lt >= TD) {
    intro.td = true;
    iSmoke(rx, G, 50, U, { sp: 2.2, up: 0.6, life: 4.5, c: [190, 120, 80], a: 0.55, dr: 1 });
  }
  const sh = lt > TD - 0.3 && lt < TD + 0.8 ? 6 * U : 0;
  ctx.save();
  if (sh) ctx.translate((Math.random() - 0.5) * sh, (Math.random() - 0.5) * sh);
  ctx.fillStyle = "rgba(40,15,5," + 0.35 * u + ")";
  ctx.beginPath();
  ctx.ellipse(rx, G + 4 * U, (30 + 40 * u) * s * 0.6, 8 * U, 0, 0, 7);
  ctx.fill();
  if (fl > 0) {
    const g = ctx.createRadialGradient(rx, G, 0, rx, G, 120 * U);
    g.addColorStop(0, "rgba(255,220,160," + 0.6 * fl + ")");
    g.addColorStop(1, "rgba(255,160,90,0)");
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = g;
    ctx.fillRect(rx - 120 * U, G - 120 * U, 240 * U, 240 * U);
    ctx.globalCompositeOperation = "source-over";
  }
  iRocket(rx, ry, 0, s, fl);
  iParts();
  ctx.restore();
  const haze = lt > TD ? Math.max(0, 0.45 - (lt - TD) * 0.07) : 0;
  if (haze > 0) {
    ctx.fillStyle = "rgba(200,140,100," + haze + ")";
    ctx.fillRect(0, 0, W, H);
  }
  if (lt < TD + 2.6) {
    const alt = Math.max(0, Math.round(ilerp(140, 0, 1 - Math.pow(1 - u, 2.2))));
    iHud(
      lt < TD
        ? [
            [T("EVRE"), T("GÜÇLÜ İNİŞ")],
            [T("İRTİFA"), alt + " m"],
            [T("DİKEY HIZ"), fmtN(Math.max(0, (1 - u) * 24), 1) + " m/s"],
          ]
        : [
            [T("EVRE"), T("TEMAS")],
            [T("İNİŞ"), T("BAŞARILI"), "#4ade80"],
            [T("KONUM"), T("Mars · ekvator ovası")],
            [T("SİNYAL"), T("İSTASYON A · ALINDI"), "#4ade80"],
          ],
      W * 0.04,
      H * 0.14,
      U,
      lt >= TD ? "rgba(74,222,128,.6)" : null,
    );
  }
  // başlık kartı
  iTitleCard(t, U);
}
/* ---------- ana çizim ---------- */
function drawIntro() {
  if (!intro) return;
  if (intro.outro) {
    drawOutro();
    return;
  }
  const t = intro.t,
    U = Math.min(W, H) / 700;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = "source-over";
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, H);
  if (t < 16) sEarth(t, U);
  else if (t < 30) sControl(t, U);
  else if (t < 40) sDossier(t, U);
  else if (t < 57) sLaunch(t, U);
  else if (t < 62) sAscent(t, U);
  else if (t < 72) sCruise(t, U);
  else if (t < 79) sEntry(t, U);
  else sLand(t, U);
  if ((t >= 56.4 && t < 57) || (t >= 62 && t < 62.05)) intro.parts.length = 0;
  iPost(t);
  // vinyet
  const vg = ctx.createRadialGradient(
    W / 2,
    H / 2,
    Math.min(W, H) * 0.35,
    W / 2,
    H / 2,
    Math.max(W, H) * 0.75,
  );
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(0,0,0,.55)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);
  // gren
  if (intro.grain && settings.grain !== false) {
    ctx.save();
    ctx.globalAlpha = 0.045;
    ctx.globalCompositeOperation = "overlay";
    const pt = ctx.createPattern(intro.grain, "repeat");
    ctx.translate(Math.random() * 160, Math.random() * 160);
    ctx.fillStyle = pt;
    ctx.fillRect(-160, -160, W + 320, H + 320);
    ctx.restore();
  }
  // geçişler
  let fb = Math.max(1 - iclamp(t / 1.6), iclamp((t - (INTRO_LEN - 1.2)) / 1.2));
  for (const b of [16, 30, 40, 62, 72]) fb = Math.max(fb, 1 - Math.min(1, Math.abs(t - b) / 0.55));
  if (fb > 0) {
    ctx.fillStyle = "rgba(0,0,0," + fb + ")";
    ctx.fillRect(0, 0, W, H);
  }
  let fw = 0;
  for (const b of [57, 79]) fw = Math.max(fw, 1 - Math.min(1, Math.abs(t - b) / 0.4));
  if (fw > 0) {
    ctx.fillStyle = "rgba(255,248,236," + fw + ")";
    ctx.fillRect(0, 0, W, H);
  }
  // sinema şeritleri
  const bh = H * 0.085 * iclamp(t / 1.5);
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, W, bh);
  ctx.fillRect(0, H - bh, W, bh);
  // bölüm etiketi
  const chp = IC.chapters.filter((c) => c[0] <= t).pop();
  if (chp) {
    const a = iclamp((t - chp[0] - 0.6) / 0.8) * (1 - iclamp((t - chp[0] - 5.5) / 1));
    if (a > 0) {
      ctx.globalAlpha = a;
      iText(chp[1], W * 0.04, bh * 0.62, 12 * U + 5, { mono: 1, w: 800, c: "#ff8c42" });
      iText(chp[2], W * 0.04 + 28 * U + 8, bh * 0.62, 11 * U + 4, { mono: 1, w: 700, c: "#c9d3ea", ls: 4 });
      ctx.globalAlpha = 1;
    }
  }
  // altyazı
  const cap = IC.caps.find((c) => t >= c[0] && t < c[1]);
  if (cap) {
    const a = iclamp((t - cap[0]) * 4) * iclamp((cap[1] - t) * 4),
      n = Math.floor((t - cap[0]) * 42),
      txt = cap[3].slice(0, n);
    const fs = Math.round((15 * U + 6) * (settings.subs || 1));
    ctx.font = "600 " + fs + "px 'Segoe UI',system-ui,sans-serif";
    const L = iWrap(cap[3], Math.min(W * 0.8, 900));
    let shown = n;
    const baseY = H - bh - fs * 0.9 - (L.length - 1) * fs * 1.35;
    ctx.globalAlpha = a;
    if (cap[2])
      iText(cap[2], W / 2, baseY - fs * 1.25, Math.round(fs * 0.62), {
        al: "center",
        mono: 1,
        w: 800,
        c: "#5ad1ff",
        ls: 3,
      });
    L.forEach((l, i) => {
      const part = l.slice(0, Math.max(0, shown));
      shown -= l.length + 1;
      ctx.save();
      ctx.shadowColor = "rgba(0,0,0,.9)";
      ctx.shadowBlur = 10;
      iText(part, W / 2, baseY + i * fs * 1.35, fs, {
        al: "center",
        w: cap[2] ? 600 : 500,
        c: cap[2] === T("KOMUTANIN GÜNLÜĞÜ") ? "#ffe3c9" : "#ffffff",
      });
      ctx.restore();
    });
    ctx.globalAlpha = 1;
    void txt;
  }
}

/* ============== ANA MENÜ — gerçekçi Mars manzarası ==============
   Arazi bir kez prosedürel olarak (piksel piksel gürültü + ışıklandırma)
   ayrı katmanlara pişirilir; her karede sadece katmanlar paralaksla
   çizilir, üstüne canlı öğeler (güneş halesi, Phobos, toz, toz şeytanı,
   roketin işaret ışığı) eklenir. */
const MB = { baked: null, bakeT: 0, mx: 0, my: 0, tx: 0, ty: 0, motes: [] };
function mbHash(i, j, s) {
  let n = (i * 374761393 + j * 668265263 + s * 982451653) | 0;
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}
function mbNoise(x, y, s, P) {
  const xi = Math.floor(x),
    yi = Math.floor(y),
    u = x - xi,
    v = y - yi,
    fu = u * u * (3 - 2 * u),
    fv = v * v * (3 - 2 * v);
  const w = P ? (a) => ((a % P) + P) % P : (a) => a;
  const a = mbHash(w(xi), w(yi), s),
    b = mbHash(w(xi + 1), w(yi), s),
    c = mbHash(w(xi), w(yi + 1), s),
    d = mbHash(w(xi + 1), w(yi + 1), s);
  return a + (b - a) * fu + (c - a) * fv + (a - b - c + d) * fu * fv;
}
function mbFbm(x, y, o, s, P) {
  let t = 0,
    a = 0.5,
    f = 1;
  for (let i = 0; i < o; i++) {
    t += a * mbNoise(x * f, y * f, s + i * 17, P ? P * f : 0);
    a *= 0.5;
    f *= 2;
  }
  return t / (1 - Math.pow(0.5, o));
}
function mbRidge(x, y, o, s) {
  let t = 0,
    a = 0.5,
    f = 1;
  for (let i = 0; i < o; i++) {
    t += a * (1 - Math.abs(2 * mbNoise(x * f, y * f, s + i * 31) - 1));
    a *= 0.5;
    f *= 2;
  }
  return t / (1 - Math.pow(0.5, o));
}
const mbMix = (a, b, k) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const mbC = (x) => Math.max(0, Math.min(1, x));
function mbCanvas(w, h) {
  const c = document.createElement("canvas");
  c.width = Math.max(1, w | 0);
  c.height = Math.max(1, h | 0);
  return c;
}

function bakeMenu() {
  const q = Math.min(1, 1000 / Math.max(W, 1)),
    M = 26,
    w = Math.round((W + M * 2) * q),
    h = Math.round((H + M * 2) * q);
  const HY = Math.round(h * 0.6),
    SX = Math.round(w * 0.83),
    SY = HY - Math.round(h * 0.07);
  const sky = [
      [13, 17, 30],
      [42, 34, 40],
      [118, 78, 58],
      [196, 146, 108],
    ],
    HAZE = [198, 150, 112];
  const B = { q, M, w, h, HY, SX, SY };
  /* --- gökyüzü (düşük çözünürlük, yumuşak) --- */
  {
    const sw = Math.ceil(w / 3),
      sh = Math.ceil(HY / 3) + 2,
      c = mbCanvas(sw, sh),
      g = c.getContext("2d"),
      im = g.createImageData(sw, sh),
      D = im.data;
    for (let y = 0; y < sh; y++) {
      const k = y / (sh - 1);
      const base =
        k < 0.45
          ? mbMix(sky[0], sky[1], k / 0.45)
          : k < 0.8
            ? mbMix(sky[1], sky[2], (k - 0.45) / 0.35)
            : mbMix(sky[2], sky[3], (k - 0.8) / 0.2);
      for (let x = 0; x < sw; x++) {
        const dx = (x * 3 - SX) / w,
          dy = (y * 3 - SY) / h,
          dist = Math.sqrt(dx * dx * 1.2 + dy * dy * 2.2);
        const blue = Math.exp(-dist * 7.5) * 0.75,
          warm = Math.exp(-dist * 2.6) * 0.35; // Mars gün batımı: güneş çevresi mavi hale
        const band = (mbFbm((x / sw) * 6, (y / sh) * 14, 4, 3) - 0.5) * 0.1 * k; // ince toz katmanları
        let c0 = mbMix(base, [214, 170, 128], warm);
        c0 = mbMix(c0, [150, 190, 228], blue);
        const i = (y * sw + x) * 4;
        D[i] = c0[0] * (1 + band);
        D[i + 1] = c0[1] * (1 + band);
        D[i + 2] = c0[2] * (1 + band);
        D[i + 3] = 255;
      }
    }
    g.putImageData(im, 0, 0);
    B.sky = c;
  }
  /* --- uzak sıradağ (krater kenarı) --- */
  const profFar = new Float32Array(w),
    profMid = new Float32Array(w);
  for (let x = 0; x < w; x++) {
    const xn = x / w;
    const big =
      Math.exp(-Math.pow((xn - 0.3) / 0.16, 2)) * 0.09 + Math.exp(-Math.pow((xn - 0.93) / 0.1, 2)) * 0.05; // geniş volkan omuzları
    profFar[x] =
      HY -
      h *
        (0.03 +
          big +
          0.07 * Math.pow(mbFbm(xn * 2.1 + 7, 0.5, 5, 11), 1.8) +
          0.03 * mbRidge(xn * 6 + 2, 0.3, 4, 13));
    const pl = mbFbm(xn * 3.3 + 40, 1.5, 5, 21);
    const mesa = mbC((mbFbm(xn * 2.6 + 3, 2.2, 3, 27) - 0.5) * 9) * 0.035;
    profMid[x] =
      HY -
      h * (0.006 + mesa + 0.04 * Math.pow(mbC((pl - 0.32) * 1.6), 1.3) + 0.01 * mbRidge(xn * 11, 0.7, 3, 23));
  }
  const layer = (prof, seed, col, dark, hazeK, bottom) => {
    const c = mbCanvas(w, bottom + 2),
      g = c.getContext("2d"),
      im = g.createImageData(w, bottom + 2),
      D = im.data;
    for (let x = 0; x < w; x++) {
      const top = Math.floor(prof[x]),
        sl = (prof[Math.min(w - 1, x + 2)] - prof[Math.max(0, x - 2)]) / 4; // eğim: + → sağa iniyor (güneşe bakan)
      for (let y = Math.max(0, top); y <= bottom; y++) {
        const n = mbFbm((x / w) * 38, (y / h) * 30, 4, seed),
          gul = mbRidge((x / w) * 60, (y / h) * 12, 3, seed + 5);
        const depth = (y - top) / Math.max(8, bottom - top);
        let lit = 0.62 + sl * 2.2 + (n - 0.5) * 0.55 - gul * 0.18 + (1 - depth) * 0.08;
        lit = Math.max(0.25, Math.min(1.25, lit));
        let c0 = mbMix(dark, col, mbC(lit - 0.2));
        c0 = [c0[0] * lit, c0[1] * lit, c0[2] * lit];
        const hz =
          hazeK * (1 - mbC((HY - y) / (h * 0.12)) * 0.25) +
          (y > HY - h * 0.012 ? mbC((y - (HY - h * 0.012)) / (h * 0.012)) * 0.5 : 0);
        c0 = mbMix(c0, HAZE, mbC(hz));
        const i = (y * w + x) * 4,
          edge = y === top ? mbC(prof[x] - top === 0 ? 1 : 1 - (prof[x] - top)) : 1;
        D[i] = c0[0];
        D[i + 1] = c0[1];
        D[i + 2] = c0[2];
        D[i + 3] = 255 * edge;
      }
    }
    g.putImageData(im, 0, 0);
    return c;
  };
  B.far = layer(profFar, 31, [176, 112, 82], [96, 56, 44], 0.55, HY);
  B.mid = layer(profMid, 41, [150, 78, 44], [66, 30, 20], 0.22, HY);
  /* --- zemin: perspektifli doku + kum dalgaları + ışıklandırma --- */
  {
    const gh = h - HY,
      c = mbCanvas(w, gh),
      g = c.getContext("2d"),
      im = g.createImageData(w, gh),
      D = im.data;
    const height = (u, v) => {
      const b = mbFbm(u * 0.55, v * 0.55, 5, 51),
        dn = Math.sin((u * 1.3 + v * 0.45) * 5.2 + mbFbm(u * 0.25, v * 0.25, 3, 57) * 7);
      return b * 0.9 + 0.16 * dn * mbC(mbFbm(u * 0.18 + 3, v * 0.18, 3, 59) * 1.8 - 0.55);
    };
    for (let y = 0; y < gh; y++) {
      const d = (y + 0.5) / gh,
        z = 1 / (d + 0.035),
        fog = Math.pow(mbC(1 - d * 3.2), 1.5) * 0.85;
      for (let x = 0; x < w; x++) {
        const u = (x / w - 0.5) * z * 2.1,
          v = z * 0.9,
          e = 0.035 * Math.max(0.4, z * 0.12);
        const h0 = height(u, v),
          hx = (height(u + e, v) - h0) / e,
          hz = (height(u, v + e) - h0) / e;
        let lit = 0.86 - hx * 0.16 - hz * 0.22;
        lit = Math.max(0.35, Math.min(1.35, lit));
        const n = mbFbm(u * 2.2, v * 2.2, 4, 61),
          bas = mbC((mbFbm(u * 0.35 + 9, v * 0.35, 4, 67) - 0.56) * 5);
        let c0 = mbMix([181, 98, 52], [132, 62, 32], n);
        c0 = mbMix(c0, [78, 46, 36], bas * 0.75);
        const sunSide = 0.9 + 0.25 * mbC((x / w - 0.35) * 1.4) * (1 - d);
        c0 = [c0[0] * lit * sunSide, c0[1] * lit * sunSide, c0[2] * lit * sunSide];
        c0 = mbMix(c0, HAZE, fog);
        c0 = mbMix(c0, [30, 14, 10], Math.pow(d, 2.2) * 0.45); // ön plan kararır
        const i = (y * w + x) * 4;
        D[i] = c0[0];
        D[i + 1] = c0[1];
        D[i + 2] = c0[2];
        D[i + 3] = 255;
      }
    }
    g.putImageData(im, 0, 0);
    // kayalar (uzaktan yakına), uzun gün batımı gölgeleriyle
    const R = rng(77),
      rocks = [];
    for (let i = 0; i < 300; i++) {
      const d = Math.pow(R(), 0.7);
      rocks.push({ x: R() * w, d, s: R(), k: R(), id: i });
    }
    rocks.sort((a, b) => a.d - b.d);
    for (const r of rocks) {
      const y = r.d * gh,
        sz = (1 + Math.pow(r.d, 1.5) * h * 0.05) * (0.18 + Math.pow(r.s, 3) * 1.5);
      if (sz < 0.8) continue;
      const rx = sz * (1.1 + r.k * 0.8),
        ry = sz * (0.55 + r.k * 0.35),
        n = 11,
        pts = [];
      for (let j = 0; j < n; j++) {
        const a = (j / n) * Math.PI * 2,
          jr = 0.62 + 0.5 * mbHash(r.id, j, 5);
        let py = Math.sin(a) * ry * jr;
        if (py > 0) py *= 0.28; // alt kısım gömülü
        pts.push([r.x + Math.cos(a) * rx * jr, y + py]);
      }
      // gün batımı gölgesi (sola uzanır)
      g.fillStyle = "rgba(22,8,6," + (0.3 + 0.22 * r.d) + ")";
      g.beginPath();
      g.moveTo(r.x + rx * 0.2, y + ry * 0.12);
      g.quadraticCurveTo(r.x - rx * 2.2, y + ry * 0.5, r.x - rx * 3.2 * (0.6 + r.k), y + ry * 0.18);
      g.quadraticCurveTo(r.x - rx * 1.5, y - ry * 0.05, r.x - rx * 0.6, y);
      g.closePath();
      g.fill();
      const poly = () => {
        g.beginPath();
        pts.forEach((p, k) => (k ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])));
        g.closePath();
      };
      const gr = g.createLinearGradient(r.x + rx * 0.8, y - ry, r.x - rx * 0.7, y + ry * 0.2);
      const tone = r.k < 0.3 ? [110, 72, 60] : [170, 94, 58];
      gr.addColorStop(0, `rgb(${tone[0] + 50},${tone[1] + 40},${tone[2] + 30})`);
      gr.addColorStop(0.4, `rgb(${tone[0]},${tone[1]},${tone[2]})`);
      gr.addColorStop(1, "rgb(40,18,12)");
      poly();
      g.fillStyle = gr;
      g.fill();
      if (sz > 4) {
        // yüzey faseti + çatlak
        g.save();
        poly();
        g.clip();
        g.fillStyle = "rgba(30,12,8,.32)";
        g.beginPath();
        g.moveTo(r.x - rx, y - ry);
        g.lineTo(r.x - rx * 0.05 + mbHash(r.id, 1, 9) * rx * 0.3, y - ry * 1.1);
        g.lineTo(r.x - rx * 0.2, y + ry);
        g.lineTo(r.x - rx * 1.2, y + ry);
        g.fill();
        g.strokeStyle = "rgba(25,10,6,.45)";
        g.lineWidth = Math.max(0.5, sz * 0.04);
        g.beginPath();
        g.moveTo(r.x + rx * 0.3, y - ry * 0.6);
        g.lineTo(r.x + rx * 0.1, y - ry * 0.1);
        g.lineTo(r.x + rx * 0.35, y + ry * 0.1);
        g.stroke();
        for (let k = 0; k < 6; k++) {
          g.fillStyle = "rgba(255,210,170," + (0.08 + 0.1 * mbHash(r.id, k, 3)) + ")";
          g.fillRect(
            r.x + (mbHash(r.id, k, 4) - 0.3) * rx,
            y - ry * mbHash(r.id, k, 6) * 0.8,
            sz * 0.08,
            sz * 0.06,
          );
        }
        g.restore();
      }
      // kumun kayayı kısmen örtmesi
      g.fillStyle = "rgba(150,78,44," + (0.5 + 0.2 * r.k) + ")";
      g.beginPath();
      g.ellipse(r.x, y + ry * 0.08, rx * 1.05, ry * 0.2, 0, 0, 7);
      g.fill();
      const fogk = Math.pow(mbC(1 - r.d * 3.2), 1.5) * 0.8;
      if (fogk > 0.02) {
        g.fillStyle = "rgba(198,150,112," + fogk + ")";
        poly();
        g.fill();
      }
    }
    // çakıllar
    for (let i = 0; i < 900; i++) {
      const d = Math.pow(R(), 0.6),
        y = d * gh,
        x = R() * w,
        s = 0.4 + d * d * 2.4;
      g.fillStyle = "rgba(" + (R() < 0.5 ? "60,28,18" : "200,130,90") + "," + (0.25 + d * 0.4) + ")";
      g.fillRect(x, y, s * 1.4, s * 0.7);
    }
    B.ground = c;
  }
  /* --- toz dokusu (döşenebilir) --- */
  {
    const S = 256,
      c = mbCanvas(S * 2, S),
      g = c.getContext("2d"),
      im = g.createImageData(S * 2, S),
      D = im.data;
    for (let y = 0; y < S; y++)
      for (let x = 0; x < S * 2; x++) {
        const n = mbFbm((x / S) * 2, (y / S) * 2, 5, 71, 4),
          a = mbC((n - 0.42) * 2.4);
        const i = (y * S * 2 + x) * 4;
        D[i] = 214;
        D[i + 1] = 150;
        D[i + 2] = 104;
        D[i + 3] = a * 120;
      }
    g.putImageData(im, 0, 0);
    B.dust = c;
  }
  /* --- roket (oyunun kendi modeli) --- */
  {
    const rs = Math.max(0.35, h * 0.00105),
      rw = Math.ceil(90 * rs),
      rh = Math.ceil(150 * rs),
      c = mbCanvas(rw * 2, rh * 2),
      g = c.getContext("2d");
    bakeRocketInto(g, 2, rw / 2, 84 * rs, rs);
    B.rocket = c;
    B.rs = rs;
    B.rw = rw;
    B.rh = rh;
  }
  B.W = W;
  B.H = H;
  return B;
}
function i0(r) {
  return Math.floor(r.x * 7 + r.s * 1000);
}

function drawMenuBg2D() {
  const c = mctx,
    t = performance.now() / 1000;
  if (!MB.baked || MB.baked.W !== W || MB.baked.H !== H) {
    if (!MB.baked || performance.now() - MB.bakeT > 250) {
      MB.baked = bakeMenu();
      MB.bakeT = performance.now();
    }
  }
  const B = MB.baked,
    s = 1 / B.q,
    M = B.M;
  MB.tx += (MB.mx - MB.tx) * 0.04;
  MB.ty += (MB.my - MB.ty) * 0.04;
  const par = (k) => [-M + MB.tx * k - 0, -M + MB.ty * k * 0.5];
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.globalCompositeOperation = "source-over";
  c.imageSmoothingEnabled = true;
  // gökyüzü
  let [ox, oy] = par(3);
  c.drawImage(B.sky, ox, oy, B.w * s, (B.HY + 6) * s);
  // yıldızlar (üst bölge)
  for (const st of stars) {
    if (st.y > 0.32) continue;
    const a = (0.15 + st.h * 0.6) * (1 - st.y / 0.32) * (0.6 + 0.4 * Math.sin(t * 1.3 + st.h * 50));
    c.fillStyle = "rgba(255,240,230," + a + ")";
    const z = 0.6 + st.h * 1.3;
    c.fillRect(st.x * W + ox * 0.3, st.y * H, z, z);
  }
  // güneş + hale
  const sx = B.SX * s + ox,
    sy = B.SY * s + oy;
  c.globalCompositeOperation = "lighter";
  let g = c.createRadialGradient(sx, sy, 0, sx, sy, H * 0.5);
  g.addColorStop(0, "rgba(200,225,255,.55)");
  g.addColorStop(0.05, "rgba(150,190,235,.28)");
  g.addColorStop(0.35, "rgba(120,150,200,.06)");
  g.addColorStop(1, "rgba(0,0,0,0)");
  c.fillStyle = g;
  c.fillRect(sx - H * 0.5, sy - H * 0.5, H, H);
  g = c.createRadialGradient(sx, sy, 0, sx, sy, 8 + H * 0.008);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.6, "rgba(235,245,255,.9)");
  g.addColorStop(1, "rgba(200,225,255,0)");
  c.fillStyle = g;
  c.beginPath();
  c.arc(sx, sy, 8 + H * 0.008, 0, 7);
  c.fill();
  c.globalCompositeOperation = "source-over";
  // Phobos: yavaşça geçer
  {
    const k = (t % 120) / 120,
      px = W * (1.08 - 1.2 * k),
      py = H * 0.13 + Math.sin(k * Math.PI) * -H * 0.03,
      pr = Math.max(5, H * 0.011);
    c.save();
    c.translate(px, py);
    c.rotate(0.4);
    const pg = c.createRadialGradient(pr * 0.5, -pr * 0.3, pr * 0.1, 0, 0, pr * 1.4);
    pg.addColorStop(0, "#d9c3b0");
    pg.addColorStop(1, "#3a2c27");
    c.fillStyle = pg;
    c.beginPath();
    c.ellipse(0, 0, pr * 1.35, pr, 0, 0, 7);
    c.fill();
    c.fillStyle = "rgba(40,28,24,.5)";
    c.beginPath();
    c.arc(-pr * 0.4, pr * 0.2, pr * 0.3, 0, 7);
    c.fill();
    c.restore();
  }
  // uzak dağlar
  [ox, oy] = par(6);
  c.drawImage(B.far, ox, oy, B.w * s, B.far.height * s);
  // uzak toz perdesi
  const dw = B.dust.width;
  c.save();
  c.globalAlpha = 0.35;
  const pat = c.createPattern(B.dust, "repeat");
  c.translate(-(t * 6) % dw, 0);
  c.fillStyle = pat;
  c.fillRect(0, B.HY * s - H * 0.16 + oy, W + dw, H * 0.18);
  c.restore();
  // toz şeytanı (uzakta dönen kum hortumu)
  {
    const k = (t * 0.006) % 1.4,
      dx = W * (0.15 + k * 0.75),
      base = B.HY * s + oy + H * 0.012,
      hh = H * 0.15;
    if (k < 1.2) {
      c.save();
      for (let i = 0; i < 26; i++) {
        const f = i / 25,
          y = base - f * hh,
          r = ((3 + f * f * 26) * H) / 900,
          sw = Math.sin(t * 3 + f * 6) * 6 * f;
        c.fillStyle = "rgba(206,150,108," + 0.1 * (1 - f * 0.6) + ")";
        c.beginPath();
        c.ellipse(dx + sw + f * f * 14, y, r * 1.6, r * 0.55, 0, 0, 7);
        c.fill();
      }
      const top = c.createRadialGradient(dx + 16, base - hh, 0, dx + 16, base - hh, hh * 0.4);
      top.addColorStop(0, "rgba(206,150,108,.12)");
      top.addColorStop(1, "rgba(206,150,108,0)");
      c.fillStyle = top;
      c.fillRect(dx - hh * 0.4, base - hh * 1.4, hh * 0.9, hh * 0.8);
      c.restore();
    }
  }
  // orta tepeler
  [ox, oy] = par(10);
  c.drawImage(B.mid, ox, oy, B.w * s, B.mid.height * s);
  // zemin
  const gx = ox * 1.6,
    gy = oy * 1.2;
  c.drawImage(B.ground, gx - M * 0.6, B.HY * s + gy, B.w * s, (B.h - B.HY) * s);
  // roket — iniş alanında, sağ tarafta
  {
    const rx = W * 0.64 + gx * 0.6,
      ry = B.HY * s + gy + (B.h - B.HY) * s * 0.16,
      rw = B.rw * s,
      rh = B.rh * s;
    c.fillStyle = "rgba(20,8,6,.45)";
    c.beginPath();
    c.ellipse(rx - rw * 0.9, ry + 2, rw * 1.3, rh * 0.04, 0, 0, 7);
    c.fill();
    c.drawImage(B.rocket, rx - rw / 2, ry - rh * 0.79, rw, rh);
    // işaret ışığı + pencere parlaması
    const bl = Math.max(0, Math.sin(t * 2.2)) ** 8;
    if (bl > 0.02) {
      const by = ry - rh * 0.79 + rh * 0.03;
      g = c.createRadialGradient(rx, by, 0, rx, by, 12);
      g.addColorStop(0, "rgba(255,90,80," + bl + ")");
      g.addColorStop(1, "rgba(255,90,80,0)");
      c.globalCompositeOperation = "lighter";
      c.fillStyle = g;
      c.fillRect(rx - 30, by - 30, 60, 60);
      c.globalCompositeOperation = "source-over";
    }
    const wy = ry - rh * 0.79 + rh * 0.42;
    g = c.createRadialGradient(rx, wy, 0, rx, wy, rw * 0.6);
    g.addColorStop(0, "rgba(140,210,255,.28)");
    g.addColorStop(1, "rgba(140,210,255,0)");
    c.globalCompositeOperation = "lighter";
    c.fillStyle = g;
    c.fillRect(rx - rw, wy - rw, rw * 2, rw * 2);
    c.globalCompositeOperation = "source-over";
  }
  // yakın toz perdesi
  c.save();
  c.globalAlpha = 0.16;
  c.translate(-(t * 22) % dw, 0);
  c.fillStyle = pat;
  c.fillRect(0, H * 0.62, W + dw, H * 0.4);
  c.restore();
  // uçuşan toz zerreleri
  if (!MB.motes.length) {
    const R = rng(31);
    for (let i = 0; i < 110; i++) MB.motes.push({ x: R(), y: R(), z: R() });
  }
  for (const m of MB.motes) {
    const sp = 0.006 + m.z * 0.03;
    m.x += sp / 60;
    m.y += Math.sin(t * 0.7 + m.z * 30) * 0.00012;
    if (m.x > 1.02) {
      m.x = -0.02;
      m.y = Math.random();
    }
    const x = m.x * W,
      y = (0.25 + m.y * 0.75) * H,
      r = 0.5 + m.z * m.z * 2.6;
    c.fillStyle = "rgba(240,200,160," + (0.12 + m.z * 0.35) + ")";
    c.beginPath();
    c.arc(x, y, r, 0, 7);
    c.fill();
  }
  // sinematik renk + okunurluk
  g = c.createLinearGradient(0, 0, W * 0.55, 0);
  g.addColorStop(0, "rgba(10,5,5,.82)");
  g.addColorStop(0.6, "rgba(10,5,5,.38)");
  g.addColorStop(1, "rgba(10,5,5,0)");
  c.fillStyle = g;
  c.fillRect(0, 0, W, H);
  g = c.createRadialGradient(W * 0.6, H * 0.5, Math.min(W, H) * 0.3, W * 0.6, H * 0.5, Math.max(W, H) * 0.8);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,.6)");
  c.fillStyle = g;
  c.fillRect(0, 0, W, H);
  g = c.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, "rgba(0,0,0,.35)");
  g.addColorStop(0.18, "rgba(0,0,0,0)");
  g.addColorStop(0.85, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,.45)");
  c.fillStyle = g;
  c.fillRect(0, 0, W, H);
}
addEventListener("pointermove", (e) => {
  if (mode !== "menu") return;
  MB.mx = (e.clientX / W - 0.5) * -2 * 9;
  MB.my = (e.clientY / H - 0.5) * -2 * 9;
});
/* canlı telemetri satırı */
function menuTele() {
  const el = $("mnTele");
  if (!el || mode !== "menu") return;
  const d = new Date(),
    mh = (d.getHours() * 60 + d.getMinutes() + d.getSeconds() / 60) * 1.0275,
    hh = Math.floor(mh / 60) % 24,
    mm = Math.floor(mh % 60);
  const temp = -63 + Math.round(Math.sin(d.getTime() / 9e5) * 6),
    wind = 14 + Math.round(Math.abs(Math.sin(d.getTime() / 4e4)) * 9),
    dl = (12.6 + Math.sin(d.getTime() / 8e6) * 0.4).toFixed(1).replace(".", ",");
  el.innerHTML = Tf(
    `<span><i class="dot"></i>CANLI</span><span>MARS YEREL <b>{0}:{1}</b></span><span>SICAKLIK <b>{2} °C</b></span><span>RÜZGÂR <b>{3} km/sa</b></span><span>BASINÇ <b>6,1 mbar</b></span><span>IŞIK GECİKMESİ <b>{4} dk</b></span>`,
    [String(hh).padStart(2, "0"), String(mm).padStart(2, "0"), temp, wind, dl],
  );
}
setInterval(menuTele, 1000);

/* ============== GLX — WebGL "ultra" grafik motoru ==============
   • space   : yıldız alanı + Samanyolu + 2 gezegen (Dünya/Mars) + mercek parlaması
   • terrain : ışın yürütmeli (raymarch) Mars arazisi, yumuşak gölge, sis, gün batımı göğü
   Arazi pahalıdır: FBO'ya satır satır (kare başına birkaç şerit) işlenir, bitince
   2D tuvale kopyalanır. WebGL yoksa oyun eski 2D çizimlere döner. */
const GLX = { ok: false, c: null, gl: null, P: {} };
const GLSL_COMMON = `
precision highp float;
float h21(vec2 p){vec3 p3=fract(vec3(p.xyx)*.1031);p3+=dot(p3,p3.yzx+33.33);return fract((p3.x+p3.y)*p3.z);}
float h31(vec3 p3){p3=fract(p3*.1031);p3+=dot(p3,p3.zyx+31.32);return fract((p3.x+p3.y)*p3.z);}
float n2(vec2 p){vec2 i=floor(p),f=fract(p),u=f*f*(3.-2.*f);
  return mix(mix(h21(i),h21(i+vec2(1.,0.)),u.x),mix(h21(i+vec2(0.,1.)),h21(i+vec2(1.,1.)),u.x),u.y);}
float n3(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);
  return mix(mix(mix(h31(i),h31(i+vec3(1.,0.,0.)),f.x),mix(h31(i+vec3(0.,1.,0.)),h31(i+vec3(1.,1.,0.)),f.x),f.y),
             mix(mix(h31(i+vec3(0.,0.,1.)),h31(i+vec3(1.,0.,1.)),f.x),mix(h31(i+vec3(0.,1.,1.)),h31(i+vec3(1.,1.,1.)),f.x),f.y),f.z);}
float fbm3(vec3 p,int o){float a=.5,s=0.,t=0.;for(int i=0;i<7;i++){if(i>=o)break;s+=a*n3(p);t+=a;p=p*2.03+vec3(1.7,9.2,3.1);a*=.5;}return s/t;}
vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
`;
const FS_SPACE =
  GLSL_COMMON +
  `
uniform vec2 uRes;uniform float uTime,uMilky,uStars,uExpo;
uniform vec4 uP1,uP2;uniform vec2 uRot,uTilt;uniform vec3 uL1,uL2,uFlare;uniform vec2 uOff;
vec3 rotY(vec3 p,float a){float c=cos(a),s=sin(a);return vec3(c*p.x+s*p.z,p.y,-s*p.x+c*p.z);}
vec3 stars(vec2 fc){
  vec3 c=vec3(0.);
  for(int l=0;l<3;l++){
    float cs=6.+float(l)*5.,thr=.93-float(l)*.025;
    vec2 g=(fc+uOff*(.4+float(l)*.5))/cs,id=floor(g);
    float h=h21(id+float(l)*17.31);
    if(h>thr){
      vec2 o=vec2(h21(id+3.7),h21(id+9.1));
      float d=length((fract(g)-o)*cs);
      float b=pow((h-thr)/(1.-thr),2.2)*(1.4+float(l));
      float tw=.7+.3*sin(uTime*(1.+h*4.)+h*40.);
      vec3 tint=mix(vec3(1.,.82,.66),vec3(.72,.82,1.),h21(id+5.3));
      c+=tint*b*tw*exp(-d*d*(1.6-float(l)*.35));
    }
  }
  return c;
}
vec3 milky(vec2 fc){
  vec2 uv=fc/uRes.y;vec2 dir=normalize(vec2(1.,.55));vec2 nrm=vec2(-dir.y,dir.x);
  float b=dot(uv-vec2(.9*uRes.x/uRes.y,.45),nrm);
  float band=exp(-b*b*9.);
  float cl=fbm3(vec3(uv*2.6,1.3),6),lane=smoothstep(.45,.7,fbm3(vec3(uv*5.,7.1),5));
  vec3 col=mix(vec3(.10,.08,.16),vec3(.26,.19,.14),smoothstep(.4,.8,cl))*band*(.35+cl)*(1.-lane*.75*band);
  float neb=smoothstep(.55,.85,fbm3(vec3(uv*1.4,4.4),5));
  col+=vec3(.12,.04,.08)*neb*.5+vec3(.02,.05,.12)*smoothstep(.5,.9,fbm3(vec3(uv*1.1+3.,2.),4))*.6;
  return col*.55;
}
vec4 planet(vec2 fc,vec4 P,float rot,vec3 L,float tilt){
  if(P.z<1.)return vec4(0.);
  vec2 d=(fc-P.xy)/P.z;float r2=dot(d,d),r=sqrt(r2);
  bool earth=P.w<.5;
  vec3 atmC=earth?vec3(.30,.56,1.):vec3(1.,.52,.32);
  vec3 dir3=normalize(vec3(d/max(r,1e-4),.08));
  float hh=max(r-1.,0.);vec3 glow=atmC*exp(-hh*(earth?40.:60.))*(earth?.75:.4)*smoothstep(-.45,.45,dot(dir3,L));
  if(r>1.)return vec4(glow,0.);
  float big=smoothstep(450.,1500.,P.z);vec2 dd=d*mix(1.,.55,big);
  float rim=exp(-(1.-r)*P.z/(5.+P.z*.018));
  vec3 n=vec3(dd,sqrt(max(0.,1.-dot(dd,dd))));float ct=cos(tilt),st=sin(tilt);vec3 nt=vec3(n.x,ct*n.y-st*n.z,st*n.y+ct*n.z);vec3 p=rotY(nt,rot);
  float ndl=dot(n,L);vec3 col;
  if(earth){
    vec3 q=p*1.7;float w=fbm3(q*1.3+vec3(1.,7.,3.),4);
    float h=fbm3(q+w*.55,6);
    float land=smoothstep(.505,.52,h),lat=abs(p.y);
    float ice=smoothstep(.80,.86,lat+(fbm3(p*6.,3)-.5)*.12);
    float desert=smoothstep(.55,.68,fbm3(p*2.3+5.,4))*(1.-smoothstep(.45,.6,lat))*smoothstep(.1,.28,lat);
    vec3 lc=mix(mix(vec3(.05,.10,.035),vec3(.025,.06,.02),smoothstep(.5,.7,fbm3(p*8.,3))),vec3(.34,.24,.12),desert);
    lc=mix(lc,vec3(.16,.13,.10),smoothstep(.62,.74,h));
    vec3 oc=mix(vec3(.004,.018,.065),vec3(.012,.075,.15),smoothstep(.43,.505,h));
    vec3 surf=mix(mix(oc,lc,land),vec3(.86,.9,.95),ice);
    float cl=fbm3(p*2.4+vec3(uTime*.004,0.,0.)+w*.9,6);
    float clouds=smoothstep(.47,.7,cl)*.88;
    float day=smoothstep(-.12,.28,ndl);
    vec3 hv=normalize(L+vec3(0.,0.,1.));
    float spec=pow(max(dot(n,hv),0.),80.)*(1.-land)*(1.-ice)*(1.-clouds)*1.4;
    col=surf*day*1.05+spec*vec3(1.,.86,.66)*day;
    col=mix(col,vec3(.82)*day+vec3(.012,.02,.04),clouds*.92);
    float city=smoothstep(.55,.78,n3(p*58.))*smoothstep(.42,.7,n3(p*11.))*land*(1.-ice)*(1.-clouds*.85);
    col+=city*vec3(1.,.6,.26)*2.2*smoothstep(.06,-.25,ndl);
    col+=vec3(1.,.32,.08)*exp(-abs(ndl)*12.)*.12*(1.-clouds*.5);
    float fr=max(rim,pow(1.-n.z,3.)*.5);
    col=mix(col,atmC*.35*smoothstep(-.25,.6,ndl),fr*.45);
    col+=atmC*fr*smoothstep(-.35,.5,ndl)*.6;
  }else{
    vec3 q=p*1.5;float w=fbm3(q*1.2+vec3(3.,1.,8.),4);
    float a=fbm3(q+w*.5,6);
    float dk=smoothstep(.47,.62,fbm3(p*1.1+vec3(9.,2.,4.),5));
    vec3 c=mix(vec3(.52,.18,.065),vec3(.30,.10,.04),a);c=mix(c,vec3(.11,.045,.028),dk*.78);
    float can=exp(-pow((p.y+.12+(n3(p*5.)-.5)*.05)*30.,2.))*smoothstep(-.75,-.25,p.x)*smoothstep(.65,.15,p.x)*step(0.,p.z);
    c*=1.-can*.6;
    float cap=smoothstep(.86,.9,p.y+(n3(p*7.)-.5)*.06);c=mix(c,vec3(.92,.86,.8),cap);
    float e=.01;vec3 qq=q*3.2;float f0=fbm3(qq,5);
    vec3 g=vec3(fbm3(qq+vec3(e,0.,0.),5)-f0,fbm3(qq+vec3(0.,e,0.),5)-f0,fbm3(qq+vec3(0.,0.,e),5)-f0)/e;
    vec3 gt=rotY(g,-rot);vec3 gn=vec3(gt.x,ct*gt.y+st*gt.z,-st*gt.y+ct*gt.z);vec3 nb=normalize(n-(gn-dot(gn,n)*n)*.045);
    float day=smoothstep(-.05,.35,dot(nb,L))*.85+smoothstep(-.1,.4,ndl)*.15;
    col=c*day*.9;
    float fr=max(rim,pow(1.-n.z,3.)*.5);col+=atmC*fr*.35*smoothstep(-.25,.55,ndl);
  }
  float aa=smoothstep(1.,1.-1.6/P.z,r);
  return vec4(col*aa+glow*(1.-aa*(1.-rim*.5)),aa);
}
void main(){
  vec2 fc=gl_FragCoord.xy;
  vec3 col=vec3(.0012,.0016,.004)+milky(fc)*uMilky+stars(fc)*uStars;
  vec4 a=planet(fc,uP2,uRot.y,uL2,uTilt.y);col=col*(1.-a.a)+a.rgb;
  vec4 b=planet(fc,uP1,uRot.x,uL1,uTilt.x);col=col*(1.-b.a)+b.rgb;
  if(uFlare.z>0.){vec2 fd=fc-uFlare.xy;float dd=length(fd)/uRes.y*900.;
    col+=uFlare.z*(vec3(1.,.95,.86)*exp(-dd*.045)*3.+vec3(1.,.78,.55)*exp(-dd*.007)*.35+vec3(.85,.8,1.)*exp(-abs(fd.y/uRes.y*900.)*.35)*exp(-abs(dd)*.002)*.7);}
  col*=uExpo;
  col=aces(col);col=pow(col,vec3(1./2.2));
  col+=(h21(fc+fract(uTime)*91.)-.5)/255.;
  gl_FragColor=vec4(col,1.);
}`;
const FS_TERRAIN =
  GLSL_COMMON +
  `
uniform vec2 uRes;uniform vec3 uCam,uTgt,uSun;uniform vec4 uPad;uniform float uFl,uMood,uExpo;
const mat2 M2=mat2(.8,-.6,.6,.8);
float fbm2(vec2 p,int o){float a=.5,s=0.,t=0.;for(int i=0;i<7;i++){if(i>=o)break;s+=a*n2(p);t+=a;p=M2*p*2.02;a*=.5;}return s/t;}
float rdg(vec2 p,int o){float a=.5,s=0.,t=0.;for(int i=0;i<6;i++){if(i>=o)break;float n=1.-abs(n2(p)*2.-1.);s+=a*n*n;t+=a;p=M2*p*2.03;a*=.5;}return s/t;}
float terr(vec2 p,int lod){
  float d=length(p-uCam.xz);
  float h=(fbm2(p*.0035,4)-.5)*70.;
  h+=(pow(rdg(p*.0021+vec2(4.1,7.3),lod>0?5:4),1.7)*95.+pow(fbm2(p*.0013+vec2(2.,5.),4),2.2)*190.)*smoothstep(420.,1150.,d);
  h+=(fbm2(p*.018+vec2(9.,2.),lod>0?5:3)-.5)*24.;
  if(lod>1){h+=(fbm2(p*.13,4)-.5)*2.6;h+=sin(dot(p,vec2(.33,.11))+n2(p*.05)*6.)*.22*smoothstep(.45,.6,fbm2(p*.01,2));}
  float pd=length(p-uPad.xz);h=mix(uPad.y,h,smoothstep(uPad.w,uPad.w*3.,pd));
  float cd=length(p-uCam.xz);h=min(h,mix(uCam.y-1.6,h,smoothstep(6.,40.,cd)));
  return h;
}
float march(vec3 ro,vec3 rd){
  float t=.5;
  for(int i=0;i<170;i++){vec3 p=ro+rd*t;int l=t<160.?2:(t<800.?1:0);float h=p.y-terr(p.xz,l);
    if(h<.0015*t||t>3000.)break;t+=max(h*.42,.004*t+.03);}
  return t;
}
vec3 nrm(vec3 p,float t){float e=.015*t+.03;int l=t<160.?2:1;
  return normalize(vec3(terr(p.xz-vec2(e,0.),l)-terr(p.xz+vec2(e,0.),l),2.*e,terr(p.xz-vec2(0.,e),l)-terr(p.xz+vec2(0.,e),l)));}
float shad(vec3 p,float t0){float res=1.,t=t0;
  for(int i=0;i<36;i++){vec3 q=p+uSun*t;float h=q.y-terr(q.xz,1);res=min(res,10.*h/t);if(res<0.||t>1400.)break;t+=clamp(h*.6,.8,60.);}
  return clamp(res,0.,1.);}
vec3 sky(vec3 rd,float disc){
  float sd=max(dot(rd,uSun),0.),y=max(rd.y,0.);
  vec3 zen=mix(vec3(.05,.035,.035),vec3(.0025,.003,.008),uMood);
  vec3 hor=mix(vec3(.62,.34,.17),vec3(.20,.075,.03),uMood);
  vec3 c=mix(hor,zen,pow(y,mix(.42,.32,uMood)));
  c+=vec3(.9,.42,.16)*pow(sd,6.)*exp(-y*7.)*mix(.12,.32,uMood);
  c+=vec3(.14,.30,.68)*pow(sd,70.)*mix(.6,.9,uMood)*(.35+.65*disc);
  c+=vec3(.6,.8,1.)*pow(sd,500.)*2.5*disc;
  c+=vec3(1.,.97,.92)*smoothstep(.99955,.99985,sd)*14.*disc;
  c=mix(c,hor*1.05,exp(-y*16.)*.55);
  return c;
}
void main(){
  vec2 uv=(gl_FragCoord.xy-.5*uRes)/uRes.y;
  vec3 fw=normalize(uTgt-uCam),rt=normalize(cross(vec3(0.,1.,0.),fw)),up=cross(fw,rt);
  vec3 rd=normalize(uv.x*rt+uv.y*up+uFl*fw);
  vec3 col;float t=march(uCam,rd);
  vec3 fogc=sky(normalize(vec3(rd.x,.02,rd.z)),0.);
  if(t>3000.){col=sky(rd,1.);
    if(rd.y>.08){vec2 sg=rd.xz/rd.y*180.;vec2 id=floor(sg);float h=h21(id);if(h>.985){float d=length(fract(sg)-vec2(h21(id+3.),h21(id+7.)));col+=vec3(1.,.92,.85)*exp(-d*d*60.)*(h-.985)*60.*uMood*smoothstep(.08,.3,rd.y);}}
  }else{
    vec3 p=uCam+rd*t,n=nrm(p,t);
    float pd=length(p.xz-uPad.xz);
    float m1=fbm2(p.xz*.045,4),m2=fbm2(p.xz*.6,3);
    vec3 alb=mix(vec3(.40,.15,.065),vec3(.20,.075,.035),smoothstep(.35,.7,m1));
    alb=mix(alb,vec3(.10,.05,.035),smoothstep(.62,.75,fbm2(p.xz*.012+3.,4))*.8);
    alb=mix(alb,vec3(.55,.24,.10),smoothstep(.86,.98,n.y)*.45);
    alb*=.75+.5*m2;
    if(t<180.)alb*=mix(.55,1.,smoothstep(.22,.34,n2(p.xz*1.9)));
    alb*=mix(.35,1.,smoothstep(uPad.w*.35,uPad.w*1.9,pd));
    float dif=clamp(dot(n,uSun),0.,1.);
    float sh=dif>.001?shad(p+n*.3,1.):0.;
    float amb=.55+.45*n.y;
    vec3 sunc=mix(vec3(1.,.72,.48),vec3(1.,.55,.32),uMood)*mix(3.6,2.2,uMood);
    vec3 lin=dif*sh*sunc+amb*mix(vec3(.30,.17,.11),vec3(.10,.07,.07),uMood)*.65+clamp(-n.y*.3+.2,0.,1.)*vec3(.12,.05,.02)*.2;
    col=alb*lin;
    float fo=1.-exp(-t*mix(.0007,.00085,uMood));
    float hf=exp(-max(p.y-uCam.y+20.,0.)*.035)*(1.-exp(-t*.004))*.55*uMood;
    col=mix(col,fogc*.92,clamp(fo+hf,0.,1.));
  }
  float sd=max(dot(rd,uSun),0.);col+=vec3(.35,.5,.85)*pow(sd,24.)*.1;
  col*=uExpo;col=aces(col);col=pow(col,vec3(1./2.2));
  vec2 q=gl_FragCoord.xy/uRes;col*=.55+.45*pow(16.*q.x*q.y*(1.-q.x)*(1.-q.y),.18);
  col+=(h21(gl_FragCoord.xy)-.5)/255.;
  gl_FragColor=vec4(col,1.);
}`;
function glxInit() {
  if (GLX.tried) return GLX.ok;
  GLX.tried = true;
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl", {
      antialias: false,
      alpha: false,
      depth: false,
      stencil: false,
      preserveDrawingBuffer: true,
      powerPreference: "high-performance",
    });
    if (!gl) return false;
    const hp = gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT);
    if (!hp || hp.precision < 20) return false;
    GLX.c = c;
    GLX.gl = gl;
    const b = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, b);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    c.addEventListener("webglcontextlost", (e) => {
      e.preventDefault();
      GLX.ok = false;
    });
    GLX.ok = !!glxProg("space", FS_SPACE) && !!glxProg("terrain", FS_TERRAIN);
  } catch (e) {
    GLX.ok = false;
  }
  return GLX.ok;
}
function glxProg(name, src) {
  const gl = GLX.gl,
    mk = (t, s) => {
      const sh = gl.createShader(t);
      gl.shaderSource(sh, s);
      gl.compileShader(sh);
      if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
        console.warn("GLX", name, gl.getShaderInfoLog(sh));
        return null;
      }
      return sh;
    };
  const vs = mk(gl.VERTEX_SHADER, "attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}"),
    fs = mk(gl.FRAGMENT_SHADER, src);
  if (!vs || !fs) return null;
  const p = gl.createProgram();
  gl.attachShader(p, vs);
  gl.attachShader(p, fs);
  gl.bindAttribLocation(p, 0, "a");
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
    console.warn("GLX link", gl.getProgramInfoLog(p));
    return null;
  }
  return (GLX.P[name] = { p, u: {} });
}
function glxSet(name, U) {
  const gl = GLX.gl,
    P = GLX.P[name];
  gl.useProgram(P.p);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  for (const k in U) {
    let l = P.u[k];
    if (l === undefined) l = P.u[k] = gl.getUniformLocation(P.p, k);
    if (l === null) continue;
    const v = U[k];
    if (typeof v === "number") gl.uniform1f(l, v);
    else if (v.length === 2) gl.uniform2f(l, v[0], v[1]);
    else if (v.length === 3) gl.uniform3f(l, v[0], v[1], v[2]);
    else gl.uniform4f(l, v[0], v[1], v[2], v[3]);
  }
}
/* tam kare uzay sahnesi: W×H css piksel koordinatlarıyla gezegenleri verir */
function glxSpace(o) {
  const gl = GLX.gl,
    sc = Math.min(1, 1100 / Math.max(1, W)),
    w = Math.round(W * sc),
    h = Math.round(H * sc),
    c = GLX.c;
  if (c.width !== w || c.height !== h) {
    c.width = w;
    c.height = h;
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  gl.viewport(0, 0, w, h);
  const pl = (P) => (P ? [P[0] * sc, h - P[1] * sc, P[2] * sc, P[3]] : [0, 0, 0, 0]);
  const nl = (v) => {
    const l = Math.hypot(v[0], v[1], v[2]) || 1;
    return [v[0] / l, v[1] / l, v[2] / l];
  };
  glxSet("space", {
    uRes: [w, h],
    uTime: o.time || 0,
    uMilky: o.milky == null ? 1 : o.milky,
    uStars: o.stars == null ? 1 : o.stars,
    uExpo: o.expo || 1,
    uP1: pl(o.p1),
    uP2: pl(o.p2),
    uRot: [o.rot1 || 0, o.rot2 || 0],
    uTilt: [o.tilt1 || 0.25, o.tilt2 || 0.25],
    uL1: nl(o.l1 || [0.6, 0.4, 0.7]),
    uL2: nl(o.l2 || [0.6, 0.4, 0.7]),
    uFlare: o.flare ? [o.flare[0] * sc, h - o.flare[1] * sc, o.flare[2]] : [0, 0, 0],
    uOff: [(o.off || [0, 0])[0] * sc, (o.off || [0, 0])[1] * sc],
  });
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  return c;
}
/* arazi işi: FBO'ya şerit şerit; bitince 2D tuval */
function glxTerrainJob(w, h, U) {
  const gl = GLX.gl,
    tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  const fb = gl.createFramebuffer();
  gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
  gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  return { w, h, U, y: 0, tex, fb, done: false, canvas: null };
}
function glxTerrainStep(job, rows) {
  if (!job || job.done || !GLX.ok) return job && job.done;
  const gl = GLX.gl;
  gl.bindFramebuffer(gl.FRAMEBUFFER, job.fb);
  gl.viewport(0, 0, job.w, job.h);
  glxSet("terrain", Object.assign({ uRes: [job.w, job.h] }, job.U));
  gl.enable(gl.SCISSOR_TEST);
  gl.scissor(0, job.y, job.w, rows);
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  gl.disable(gl.SCISSOR_TEST);
  job.y += rows;
  if (job.y >= job.h) {
    const px = new Uint8Array(job.w * job.h * 4);
    gl.readPixels(0, 0, job.w, job.h, gl.RGBA, gl.UNSIGNED_BYTE, px);
    const c = document.createElement("canvas");
    c.width = job.w;
    c.height = job.h;
    const g = c.getContext("2d"),
      im = g.createImageData(job.w, job.h),
      row = job.w * 4;
    for (let y = 0; y < job.h; y++)
      im.data.set(px.subarray((job.h - 1 - y) * row, (job.h - y) * row), y * row);
    g.putImageData(im, 0, 0);
    job.canvas = c;
    job.done = true;
    gl.deleteFramebuffer(job.fb);
    gl.deleteTexture(job.tex);
  }
  gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  return job.done;
}
/* --- arazi yüksekliği JS kopyası (kamera/rampa yerleşimi için) --- */
const tj = {
  fr: (x) => x - Math.floor(x),
  h21(x, y) {
    let a = tj.fr(x * 0.1031),
      b = tj.fr(y * 0.1031),
      c = tj.fr(x * 0.1031);
    const d = a * (b + 33.33) + b * (c + 33.33) + c * (a + 33.33);
    a += d;
    b += d;
    c += d;
    return tj.fr((a + b) * c);
  },
  n2(x, y) {
    const ix = Math.floor(x),
      iy = Math.floor(y),
      fx = x - ix,
      fy = y - iy,
      ux = fx * fx * (3 - 2 * fx),
      uy = fy * fy * (3 - 2 * fy);
    const a = tj.h21(ix, iy),
      b = tj.h21(ix + 1, iy),
      c = tj.h21(ix, iy + 1),
      d = tj.h21(ix + 1, iy + 1);
    return a + (b - a) * ux + (c + (d - c) * ux - (a + (b - a) * ux)) * uy;
  },
  fbm(x, y, o) {
    let a = 0.5,
      s = 0,
      t = 0;
    for (let i = 0; i < o; i++) {
      s += a * tj.n2(x, y);
      t += a;
      const nx = (0.8 * x + 0.6 * y) * 2.02,
        ny = (-0.6 * x + 0.8 * y) * 2.02;
      x = nx;
      y = ny;
      a *= 0.5;
    }
    return s / t;
  },
  rdg(x, y, o) {
    let a = 0.5,
      s = 0,
      t = 0;
    for (let i = 0; i < o; i++) {
      const n = 1 - Math.abs(tj.n2(x, y) * 2 - 1);
      s += a * n * n;
      t += a;
      const nx = (0.8 * x + 0.6 * y) * 2.03,
        ny = (-0.6 * x + 0.8 * y) * 2.03;
      x = nx;
      y = ny;
      a *= 0.5;
    }
    return s / t;
  },
  ss: (a, b, x) => {
    const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
    return t * t * (3 - 2 * t);
  },
  h(x, z, cam) {
    const d = Math.hypot(x - cam[0], z - cam[2]);
    let h = (tj.fbm(x * 0.0035, z * 0.0035, 4) - 0.5) * 70;
    h +=
      (Math.pow(tj.rdg(x * 0.0021 + 4.1, z * 0.0021 + 7.3, 5), 1.7) * 95 +
        Math.pow(tj.fbm(x * 0.0013 + 2, z * 0.0013 + 5, 4), 2.2) * 190) *
      tj.ss(420, 1150, d);
    h += (tj.fbm(x * 0.018 + 9, z * 0.018 + 2, 5) - 0.5) * 24;
    return h;
  },
};
/* GLSL mat2(.8,-.6,.6,.8) sütun-öncelikli: M2*p = (.8x+.6y, -.6x+.8y) — JS ile aynı */
function glxProject(P, U, W_, H_) {
  // dünya noktası → css piksel
  const c = U.uCam,
    t = U.uTgt;
  let fw = [t[0] - c[0], t[1] - c[1], t[2] - c[2]];
  const fl = Math.hypot(...fw);
  fw = fw.map((v) => v / fl);
  let rt = [fw[2], 0, -fw[0]];
  const rl = Math.hypot(...rt);
  rt = rt.map((v) => v / rl);
  const up = [fw[1] * rt[2] - fw[2] * rt[1], fw[2] * rt[0] - fw[0] * rt[2], fw[0] * rt[1] - fw[1] * rt[0]];
  const v = [P[0] - c[0], P[1] - c[1], P[2] - c[2]],
    x = v[0] * rt[0] + v[1] * rt[1] + v[2] * rt[2],
    y = v[0] * up[0] + v[1] * up[1] + v[2] * up[2],
    z = v[0] * fw[0] + v[1] * fw[1] + v[2] * fw[2];
  return { x: W_ / 2 + (x / z) * U.uFl * H_, y: H_ / 2 - (y / z) * U.uFl * H_, s: (U.uFl * H_) / z };
}
/* yumuşak duman/toz sprite'ı (renge göre önbellekli) */
const _puff = {};
function puffSprite(rgb) {
  const k = rgb.join(",");
  if (_puff[k]) return _puff[k];
  const S = 128,
    c = document.createElement("canvas");
  c.width = c.height = S;
  const g = c.getContext("2d"),
    im = g.createImageData(S, S),
    D = im.data;
  for (let y = 0; y < S; y++)
    for (let x = 0; x < S; x++) {
      const dx = (x - S / 2) / (S / 2),
        dy = (y - S / 2) / (S / 2),
        r = Math.sqrt(dx * dx + dy * dy);
      const n = mbFbm((x / S) * 4, (y / S) * 4, 4, (rgb[0] * 7) | 0),
        a = Math.max(0, 1 - r) * Math.max(0, 1 - r) * (0.35 + n * 0.9);
      const lit = 0.78 + 0.35 * (-dy * 0.5 - dx * 0.2) + n * 0.15,
        i = (y * S + x) * 4;
      D[i] = Math.min(255, rgb[0] * lit);
      D[i + 1] = Math.min(255, rgb[1] * lit);
      D[i + 2] = Math.min(255, rgb[2] * lit);
      D[i + 3] = Math.min(255, a * 255);
    }
  g.putImageData(im, 0, 0);
  return (_puff[k] = c);
}

/* roket modelini doğrudan verilen bağlama çizer (ana tuvalin boyutuna/durumuna bağlı değil) */
function bakeRocketInto(g, k, ox, oy, rs) {
  const old = ctx;
  let ok = true;
  try {
    ctx = g;
    g.save();
    g.setTransform(k, 0, 0, k, 0, 0);
    g.translate(ox, oy);
    g.scale(rs, rs);
    rocketBody({ flame: 0, broken: false, t: 0 });
    g.restore();
  } catch (e) {
    ok = false;
    try {
      g.restore();
    } catch (_) {}
  } finally {
    ctx = old;
  }
  return ok;
}
/* ============== ULTRA SAHNELER (WebGL) ============== */
function mkRocketSprite(rs, filter) {
  // oyunun roket modelini (vektör) bir sprite'a pişirir; zemin = sprite tepesinden 128*rs
  const rw = Math.ceil(110 * rs),
    rh = Math.ceil(150 * rs),
    c = document.createElement("canvas");
  c.width = rw;
  c.height = rh;
  const g = c.getContext("2d");
  const tmp = document.createElement("canvas");
  tmp.width = rw;
  tmp.height = rh;
  const ok = bakeRocketInto(tmp.getContext("2d"), 1, rw / 2, 84 * rs, rs);
  if (filter) g.filter = filter;
  g.drawImage(tmp, 0, 0);
  g.filter = "none";
  return { c, rs, rw, rh, ok };
}
/* kamera / rampa yerleşimi: manzarayı gören, önü kapalı olmayan nokta */
function glxFindView(o) {
  let best = null;
  for (let gx = -7; gx <= 7; gx++)
    for (let gz = -7; gz <= 7; gz++) {
      const cx = gx * 90 + o.ox,
        cz = gz * 90,
        cam0 = [cx, 0, cz],
        g = tj.h(cx, cz, cam0),
        eye = g + o.eye;
      let ahead = 0,
        block = false;
      for (let i = 1; i <= 10; i++) {
        const d = i * i * 7,
          h = tj.h(cx + d * o.dx, cz + d, cam0);
        ahead += h;
        if (h > eye - d * o.slope) block = true;
      }
      ahead /= 10;
      const score = (g - ahead) * o.over - (block ? 1e5 : 0) - Math.abs(g - ahead - o.want) * 0.3;
      if (!best || score > best.score) best = { score, cx, cz, g };
    }
  const cam = [best.cx, best.g + o.eye, best.cz];
  // rampa: görüş hattı açık, düzlüğe yakın
  let pad = null;
  for (const d of o.padD)
    for (const a of o.padA) {
      const px = cam[0] + Math.sin(a) * d,
        pz = cam[2] + Math.cos(a) * d,
        py = tj.h(px, pz, cam);
      const s1 =
        Math.abs(tj.h(px + 8, pz, cam) - tj.h(px - 8, pz, cam)) +
        Math.abs(tj.h(px, pz + 8, cam) - tj.h(px, pz - 8, cam));
      let vis = true;
      for (let i = 1; i < 20; i++) {
        const k = i / 20,
          x = cam[0] + (px - cam[0]) * k,
          z = cam[2] + (pz - cam[2]) * k,
          y = cam[1] + (py + o.padTop - cam[1]) * k;
        if (tj.h(x, z, cam) > y - 0.5) {
          vis = false;
          break;
        }
      }
      if (vis && s1 < o.flat && (!pad || s1 < pad.s1)) {
        pad = { x: px, y: py, z: pz, s1 };
        if (s1 < o.flat * 0.4) break;
      }
    }
  if (!pad) {
    const px = cam[0] + Math.sin(o.padA[0]) * o.padD[0],
      pz = cam[2] + Math.cos(o.padA[0]) * o.padD[0];
    pad = { x: px, y: tj.h(px, pz, cam), z: pz };
  }
  return { cam, pad };
}
function glxSun(az, el) {
  return [Math.sin(az) * Math.cos(el), Math.sin(el), Math.cos(az) * Math.cos(el)];
}

/* ---------------- ANA MENÜ ---------------- */
const MG = { job: null, key: "", doneT: 0, U: null, rocket: null, far: null, motes: [], shoot: 0 };
function menuGLSetup() {
  const v = glxFindView({
    ox: 0,
    eye: 9,
    dx: 0.12,
    slope: 0.012,
    over: 1,
    want: 40,
    padD: [150, 190, 230, 120, 270],
    padA: [0.2, 0.24, 0.16, 0.28, 0.12],
    padTop: 12,
    flat: 6,
  });
  const cam = v.cam,
    yaw = 0.12;
  const U = {
    uCam: cam,
    uTgt: [cam[0] + Math.sin(yaw) * 100, cam[1] - 5.5, cam[2] + Math.cos(yaw) * 100],
    uSun: glxSun(yaw + 0.34, 0.028),
    uPad: [v.pad.x, v.pad.y, v.pad.z, 13],
    uFl: 1.55,
    uMood: 0.9,
    uExpo: 1.15,
  };
  // uzak, gizemli ışık: sol tarafta uzak bir sırtta
  const fa = yaw - 0.42,
    fd = 1350,
    fx = cam[0] + Math.sin(fa) * fd,
    fz = cam[2] + Math.cos(fa) * fd;
  MG.far = [fx, tj.h(fx, fz, cam) + 3, fz];
  return U;
}
function drawMenuBg() {
  const haveImg = !!((MG.job && MG.job.done && MG.job.canvas) || MG.prev);
  const glOk = settings.ultra !== false && glxInit();
  if (settings.ultra === false || (!glOk && !haveImg)) return drawMenuBg2D();
  const c = mctx,
    t = performance.now() / 1000;
  // küçük boyut değişimlerinde (kaydırma çubuğu, tarayıcı çubukları) yeniden işleme yok: mevcut görüntü ölçeklenir
  const key = W + "x" + H,
    [kw, kh] = (MG.key || "0x0").split("x").map(Number);
  const bigChange =
    !MG.key || Math.abs(W - kw) / Math.max(1, kw) > 0.12 || Math.abs(H - kh) / Math.max(1, kh) > 0.12;
  if (MG.key !== key && !bigChange && haveImg) MG.key = key;
  if (MG.key !== key && glOk) {
    if (!MG.pendT) MG.pendT = performance.now();
    if (!MG.job || performance.now() - MG.pendT > 300) {
      MG.pendT = 0;
      MG.key = key;
      MG.U = MG.U || menuGLSetup();
      const sc = Math.min(1.25, 1700 / Math.max(1, W)) * Math.min(dpr, 1.5),
        w = Math.round(W * Math.min(sc, dpr)),
        h = Math.round(H * Math.min(sc, dpr));
      const old = MG.job && MG.job.done ? MG.job.canvas : MG.prev;
      MG.prev = old;
      MG.job = glxTerrainJob(w, h, MG.U);
      MG.doneT = 0;
    }
  }
  if (glOk && MG.job && !MG.job.done) {
    glxTerrainStep(MG.job, Math.max(8, Math.round(MG.job.h / 36)));
    if (MG.job.done) MG.doneT = t;
  }
  if (!MG.rocket || !MG.rocket.ok)
    MG.rocket = mkRocketSprite(1.6, "brightness(.34) saturate(.55) contrast(1.15)");
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.globalCompositeOperation = "source-over";
  c.globalAlpha = 1;
  c.fillStyle = "#050304";
  c.fillRect(0, 0, W, H);
  const img = MG.job && MG.job.done ? MG.job.canvas : MG.prev;
  if (!img) {
    // ilk işleme sürerken: zarif bekleme
    const g = c.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, "#07050a");
    g.addColorStop(0.62, "#1d0f0b");
    g.addColorStop(1, "#070404");
    c.fillStyle = g;
    c.fillRect(0, 0, W, H);
    const p = MG.job ? MG.job.y / MG.job.h : 0;
    c.fillStyle = "rgba(255,140,80,.5)";
    c.fillRect(W * 0.5 - 60, H - 28, 120 * p, 1.5);
    menuOverlay(c, t, null);
    return;
  }
  // yeni görüntü hazır olunca eskisinin ÜSTÜNE yumuşakça geçer (siyaha düşmez)
  const fadeIn = MG.job && MG.job.done && MG.prev && MG.prev !== img ? Math.min(1, (t - MG.doneT) / 1.6) : 1;
  const fade = 1;
  // yavaş sinematik itme (Ken Burns)
  const z = 1.035 + 0.025 * Math.sin(t * 0.045),
    cx = W * 0.62,
    cy = H * 0.55;
  c.save();
  c.translate(cx, cy);
  c.scale(z, z);
  c.translate(-cx, -cy);
  if (fadeIn < 1 && MG.prev) c.drawImage(MG.prev, 0, 0, W, H);
  c.globalAlpha = fadeIn;
  c.drawImage(img, 0, 0, W, H);
  c.globalAlpha = 1;
  if (fadeIn >= 1 && MG.prev && MG.prev !== img) MG.prev = null;
  const U = MG.U;
  // roket (gün batımında siluet) + ışıkları
  {
    const b = glxProject([U.uPad[0], U.uPad[1], U.uPad[2]], U, W, H);
    if (b.s > 0) {
      const ppu = (b.s * 17) / 124,
        R = MG.rocket,
        sw = (R.rw * ppu) / R.rs,
        sh = (R.rh * ppu) / R.rs,
        top = b.y - 128 * ppu;
      c.globalAlpha = fade;
      c.fillStyle = "rgba(8,3,2,.55)";
      c.beginPath();
      c.ellipse(b.x - sw * 0.1, b.y, sw * 0.9, sh * 0.03, 0, 0, 7);
      c.fill();
      c.drawImage(R.c, b.x - sw / 2, top, sw, sh);
      // gün batımı kenar ışığı (sağdan)
      c.globalCompositeOperation = "lighter";
      const rim = c.createLinearGradient(b.x + sw * 0.25, 0, b.x, 0);
      rim.addColorStop(0, "rgba(255,130,70,.0)");
      rim.addColorStop(1, "rgba(255,130,70,0)");
      // pencere ışığı
      const wy = top + sh * 0.36,
        wl = c.createRadialGradient(b.x, wy, 0, b.x, wy, sw * 0.55);
      wl.addColorStop(0, "rgba(120,200,255,.55)");
      wl.addColorStop(0.25, "rgba(90,170,255,.18)");
      wl.addColorStop(1, "rgba(90,170,255,0)");
      c.fillStyle = wl;
      c.fillRect(b.x - sw, wy - sw, sw * 2, sw * 2);
      const bl = Math.pow(Math.max(0, Math.sin(t * 2.1)), 10),
        by = top + sh * 0.03;
      if (bl > 0.02) {
        const g = c.createRadialGradient(b.x, by, 0, b.x, by, 5 + sw * 0.1);
        g.addColorStop(0, "rgba(255,70,60," + bl + ")");
        g.addColorStop(1, "rgba(255,70,60,0)");
        c.fillStyle = g;
        c.fillRect(b.x - 40, by - 40, 80, 80);
      }
      // zemindeki çalışma lambası halesi
      const gl = c.createRadialGradient(b.x, b.y, 0, b.x, b.y, sw * 1.6);
      gl.addColorStop(0, "rgba(255,190,130,.16)");
      gl.addColorStop(1, "rgba(255,190,130,0)");
      c.fillStyle = gl;
      c.fillRect(b.x - sw * 2, b.y - sw, sw * 4, sw * 2);
      c.globalCompositeOperation = "source-over";
      c.globalAlpha = 1;
    }
  }
  // uzakta gizemli ışık (yavaş nabız)
  {
    const f = glxProject(MG.far, U, W, H);
    if (f.s > 0 && f.x > 0 && f.x < W) {
      const pu = 0.35 + 0.65 * Math.pow(0.5 + 0.5 * Math.sin(t * 0.9), 3);
      c.globalCompositeOperation = "lighter";
      const g = c.createRadialGradient(f.x, f.y, 0, f.x, f.y, 22);
      g.addColorStop(0, "rgba(150,210,255," + 0.85 * pu * fade + ")");
      g.addColorStop(0.15, "rgba(110,180,255," + 0.25 * pu * fade + ")");
      g.addColorStop(1, "rgba(110,180,255,0)");
      c.fillStyle = g;
      c.fillRect(f.x - 24, f.y - 24, 48, 48);
      c.fillStyle = "rgba(200,235,255," + 0.18 * pu * fade + ")";
      c.fillRect(f.x - 26, f.y - 0.5, 52, 1);
      c.globalCompositeOperation = "source-over";
    }
  }
  c.restore();
  menuOverlay(c, t, U);
}
function menuOverlay(c, t, U) {
  // Phobos (yüksekte yavaş geçer)
  {
    const k = (t % 150) / 150,
      px = W * (1.1 - 1.25 * k),
      py = H * 0.1 + Math.sin(k * Math.PI) * -H * 0.03,
      pr = Math.max(4, H * 0.008);
    c.save();
    c.translate(px, py);
    c.rotate(0.4);
    const pg = c.createRadialGradient(pr * 0.6, -pr * 0.2, pr * 0.1, 0, 0, pr * 1.3);
    pg.addColorStop(0, "#bfa48f");
    pg.addColorStop(1, "#1d1512");
    c.fillStyle = pg;
    c.beginPath();
    c.ellipse(0, 0, pr * 1.35, pr, 0, 0, 7);
    c.fill();
    c.restore();
  }
  // kayan yıldız (ara sıra)
  {
    const p = (t % 13) / 13;
    if (p < 0.05) {
      const q = p / 0.05,
        x0 = W * 0.35,
        y0 = H * 0.04,
        x1 = W * 0.62,
        y1 = H * 0.2,
        x = x0 + (x1 - x0) * q,
        y = y0 + (y1 - y0) * q;
      const g = c.createLinearGradient(x - (x1 - x0) * 0.25, y - (y1 - y0) * 0.25, x, y);
      g.addColorStop(0, "rgba(255,240,220,0)");
      g.addColorStop(1, "rgba(255,240,220," + 0.8 * (1 - q) + ")");
      c.strokeStyle = g;
      c.lineWidth = 1.4;
      c.beginPath();
      c.moveTo(x - (x1 - x0) * 0.25, y - (y1 - y0) * 0.25);
      c.lineTo(x, y);
      c.stroke();
    }
  }
  // yerden süzülen toz sisi
  const sp = puffSprite([150, 92, 64]);
  if (!MG.motes.length) {
    const R = rng(41);
    for (let i = 0; i < 34; i++) MG.motes.push({ x: R(), y: R(), s: R(), v: R() });
  }
  for (const m of MG.motes) {
    const x = (((m.x + t * (0.004 + m.v * 0.006)) % 1.2) - 0.1) * W,
      y = H * (0.62 + m.y * 0.4),
      s = ((120 + m.s * 260) * H) / 900;
    c.globalAlpha = 0.05 + m.s * 0.06;
    c.drawImage(sp, x - s, y - s * 0.35, s * 2, s * 0.7);
  }
  c.globalAlpha = 1;
  // zerreler
  for (let i = 0; i < 70; i++) {
    const h = (i * 0.618) % 1,
      x = (h * W + t * (14 + h * 30) * (1 + (i % 3))) % W,
      y = H * (0.3 + ((i * 0.371) % 1) * 0.7) + Math.sin(t * 0.6 + i) * 6,
      r = 0.5 + h * h * 2;
    c.fillStyle = "rgba(235,200,170," + (0.08 + h * 0.22) + ")";
    c.fillRect(x, y, r, r);
  }
  // okunurluk + sinematik ton
  let g = c.createLinearGradient(0, 0, W * 0.58, 0);
  g.addColorStop(0, "rgba(6,3,3,.86)");
  g.addColorStop(0.55, "rgba(6,3,3,.42)");
  g.addColorStop(1, "rgba(6,3,3,0)");
  c.fillStyle = g;
  c.fillRect(0, 0, W, H);
  g = c.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0, "rgba(0,0,0,.45)");
  g.addColorStop(0.16, "rgba(0,0,0,0)");
  g.addColorStop(0.82, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,.6)");
  c.fillStyle = g;
  c.fillRect(0, 0, W, H);
  // gren
  if (!MG.grain) {
    const gc = document.createElement("canvas");
    gc.width = gc.height = 160;
    const x = gc.getContext("2d"),
      im = x.createImageData(160, 160);
    for (let i = 0; i < im.data.length; i += 4) {
      const v = Math.random() * 255;
      im.data[i] = im.data[i + 1] = im.data[i + 2] = v;
      im.data[i + 3] = 255;
    }
    x.putImageData(im, 0, 0);
    MG.grain = gc;
  }
  if (settings.grain !== false) {
    c.save();
    c.globalAlpha = 0.04;
    c.globalCompositeOperation = "overlay";
    c.translate(Math.random() * 160, Math.random() * 160);
    c.fillStyle = c.createPattern(MG.grain, "repeat");
    c.fillRect(-160, -160, W + 320, H + 320);
    c.restore();
  }
}

/* ---------------- HİKÂYE SAHNELERİ ---------------- */
function introGLSetup() {
  if (settings.ultra === false || !glxInit()) return;
  const v = glxFindView({
    ox: 1800,
    eye: 2.2,
    dx: 0,
    slope: 0.0,
    over: 0.15,
    want: 5,
    padD: [90, 80, 105, 70],
    padA: [0.06, 0.02, 0.1, -0.04],
    padTop: 20,
    flat: 5,
  });
  const cam = v.cam,
    p = v.pad;
  const U = {
    uCam: cam,
    uTgt: [p.x * 0.7 + cam[0] * 0.3, p.y + 16, p.z],
    uSun: glxSun(-0.9, 0.42),
    uPad: [p.x, p.y, p.z, 13],
    uFl: 1.42,
    uMood: 0.1,
    uExpo: 1.0,
  };
  const sc = Math.min(1, 1400 / Math.max(1, W)) * Math.min(dpr, 1.25);
  intro.landJob = glxTerrainJob(Math.round(W * sc), Math.round(H * sc), U);
}
function iParts() {
  for (const q of intro.parts) {
    const k = q.l / q.m,
      a = q.a * (1 - k) * Math.min(1, q.l * 4);
    if (a <= 0.003) continue;
    const sp = puffSprite(q.c);
    ctx.globalAlpha = Math.min(1, a * 1.25);
    const r = q.r * 1.5;
    ctx.drawImage(sp, q.x - r, q.y - r, r * 2, r * 2);
  }
  ctx.globalAlpha = 1;
}
function sEarth(t, U) {
  if (!GLX.ok) return sEarth2D(t, U);
  const k = iease(t / 9),
    r = Math.max(W, H) * 0.62,
    cy = H + r * 0.98 - ilerp(0, r * 0.42, k),
    ma = iclamp((t - 8.5) / 2);
  const sw = iclamp((t - 3) / 10),
    L = [ilerp(0.42, 0.6, sw), ilerp(0.5, 0.45, sw), ilerp(-0.82, 0.28, iease(sw))];
  const ll = Math.hypot(L[0], L[1]) || 1,
    fl = iclamp(-L[2] * 1.5) * iclamp((t - 1.5) / 2.5);
  ctx.drawImage(
    glxSpace({
      time: t,
      milky: iclamp(t / 4),
      stars: iclamp(t / 2.5),
      off: [t * 5, 0],
      p1: [W * 0.5, cy, r, 0],
      rot1: t * 0.018 + 0.6,
      tilt1: 1.05,
      l1: L,
      p2: ma > 0 ? [W * 0.78, H * 0.26, Math.max(2.5, 3.4 * U), 1] : null,
      l2: [-0.4, 0.3, 0.85],
      flare: fl > 0 ? [W * 0.5 + (r * L[0]) / ll, cy - (r * L[1]) / ll, fl * 1.3] : null,
      expo: iclamp(t / 1.2),
    }),
    0,
    0,
    W,
    H,
  );
  if (ma > 0) {
    const mx = W * 0.78,
      my = H * 0.26;
    ctx.globalAlpha = ma;
    ctx.strokeStyle = "rgba(255,180,140,.6)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(mx, my, 14 * U, 0, 7);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(mx + 14 * U, my - 6 * U);
    ctx.lineTo(mx + 46 * U, my - 24 * U);
    ctx.lineTo(mx + 120 * U, my - 24 * U);
    ctx.stroke();
    iText(T("MARS"), mx + 50 * U, my - 30 * U, 12 * U + 4, { mono: 1, w: 800, c: "#ffb38a", ls: 3 });
    iText(T("225 milyon km"), mx + 50 * U, my - 12 * U, 9 * U + 3, { mono: 1, c: "#c99b84" });
    ctx.globalAlpha = 1;
  }
  const ta = iclamp((t - 1) / 1.5) * (1 - iclamp((t - 5.5) / 1.2));
  if (ta > 0) {
    ctx.globalAlpha = ta;
    iText(T("ARES PROGRAMI"), W / 2, H * 0.36, 13 * U + 4, {
      al: "center",
      w: 800,
      c: "#9fc9ff",
      ls: 6,
      mono: 1,
    });
    iText("2035", W / 2, H * 0.36 + 44 * U, 40 * U + 8, { al: "center", w: 300, c: "#ffffff", ls: 14 });
    ctx.globalAlpha = 1;
  }
}
function sLand(t, U) {
  const J = intro.landJob;
  if (!GLX.ok || !J || !J.done) return sLand2D(t, U);
  const lt = t - 79,
    TD = 3.5,
    u = iclamp(lt / TD),
    LU = J.U,
    P = LU.uPad;
  const shk = lt > TD - 0.3 && lt < TD + 0.8 ? 5 * U : 0;
  ctx.save();
  if (shk) ctx.translate((Math.random() - 0.5) * shk, (Math.random() - 0.5) * shk);
  const z = 1.02 + lt * 0.004,
    cx = W / 2,
    cy = H * 0.6;
  ctx.translate(cx, cy);
  ctx.scale(z, z);
  ctx.translate(-cx, -cy);
  ctx.drawImage(J.canvas, 0, 0, W, H);
  const alt = ilerp(150, 0, 1 - Math.pow(1 - u, 2.2)),
    b = glxProject([P[0], P[1], P[2]], LU, W, H),
    r = glxProject([P[0], P[1] + alt, P[2]], LU, W, H);
  const s = (b.s * 16) / 124,
    fl = lt < TD ? 0.95 : Math.max(0, 0.95 - (lt - TD) * 1.2);
  // gölge
  ctx.fillStyle = "rgba(10,4,2," + 0.55 * u + ")";
  ctx.beginPath();
  ctx.ellipse(b.x + s * 20, b.y + 2, (26 + 30 * u) * s, 6 * s, 0, 0, 7);
  ctx.fill();
  // alevin zemine vurduğu ışık
  if (fl > 0) {
    ctx.globalCompositeOperation = "lighter";
    const g = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, 90 * s * (1.3 - u * 0.5));
    g.addColorStop(0, "rgba(255,200,140," + 0.45 * fl * u + ")");
    g.addColorStop(1, "rgba(255,140,80,0)");
    ctx.fillStyle = g;
    ctx.fillRect(b.x - 120 * s, b.y - 120 * s, 240 * s, 240 * s);
    ctx.globalCompositeOperation = "source-over";
  }
  if (lt > 1.6 && lt < TD + 0.6)
    iSmoke(b.x, b.y, lt > TD - 0.5 ? 5 : 2, s * 0.9, {
      sp: 1.5,
      up: 0.35,
      life: 3.2,
      c: [176, 104, 66],
      a: 0.5,
      dr: 0.9,
    });
  if (!intro.td && lt >= TD) {
    intro.td = true;
    iSmoke(b.x, b.y, 46, s * 0.9, { sp: 2.1, up: 0.55, life: 4.6, c: [170, 100, 62], a: 0.55, dr: 1 });
  }
  iRocket(r.x, r.y - 40 * s, 0, s, fl);
  iParts();
  ctx.restore();
  const haze = lt > TD ? Math.max(0, 0.4 - (lt - TD) * 0.065) : 0;
  if (haze > 0) {
    ctx.fillStyle = "rgba(170,110,75," + haze + ")";
    ctx.fillRect(0, 0, W, H);
  }
  if (lt < TD + 2.6) {
    const a = Math.max(0, Math.round(alt));
    iHud(
      lt < TD
        ? [
            [T("EVRE"), T("GÜÇLÜ İNİŞ")],
            [T("İRTİFA"), a + " m"],
            [T("DİKEY HIZ"), fmtN(Math.max(0, (1 - u) * 24), 1) + " m/s"],
          ]
        : [
            [T("EVRE"), T("TEMAS")],
            [T("İNİŞ"), T("BAŞARILI"), "#4ade80"],
            [T("KONUM"), T("Mars · ekvator ovası")],
            [T("SİNYAL"), T("İSTASYON A · ALINDI"), "#4ade80"],
          ],
      W * 0.04,
      H * 0.14,
      U,
      lt >= TD ? "rgba(74,222,128,.6)" : null,
    );
  }
  iTitleCard(t, U);
}
function iTitleCard(t, U) {
  const ta = iclamp((t - 87.2) / 1.2);
  if (ta > 0) {
    ctx.fillStyle = "rgba(4,3,10," + 0.62 * ta + ")";
    ctx.fillRect(0, 0, W, H);
    ctx.globalAlpha = ta;
    iText("ARES-1 · SOL 1", W / 2, H * 0.38, 12 * U + 4, {
      al: "center",
      mono: 1,
      w: 800,
      c: "#ffb38a",
      ls: 8,
    });
    iText("SOL ZERO", W / 2, H * 0.38 + 56 * U, Math.min(W * 0.06, 54 * U + 10), {
      al: "center",
      w: 800,
      c: "#ffffff",
      ls: Math.round(8 * U),
      glow: "rgba(255,140,80,.55)",
      gb: 26,
    });
    const lw = W * 0.24 * iease((t - 87.4) / 1.4);
    ctx.fillStyle = "#ff8c42";
    ctx.fillRect(W / 2 - lw / 2, H * 0.38 + 76 * U, lw, 2);
    iText(
      T("Görev başlıyor: Mars'ı incele, hayatta kal ve her şeyi Dünya'ya aktar."),
      W / 2,
      H * 0.38 + 108 * U,
      14 * U + 5,
      { al: "center", w: 500, c: "#e9d6c8" },
    );
    ctx.globalAlpha = 1;
  }
}

/* ============== GELİŞTİRME İSTASYONU — kıyafet setleri + roket ==============
   Kıyafetler metal numune (+ yıldız kristali) ile üretilir; roket geliştirmeleri
   meteor kraterlerinden toplanan altın parçalarıyla yapılır. */
function withCtx(c2, fn) {
  const o = ctx;
  ctx = c2;
  try {
    fn();
  } finally {
    ctx = o;
  }
}
const SUITS = [
  {
    id: "std",
    name: T("ARES Standart"),
    tier: T("BAŞLANGIÇ"),
    tag: T("Dengeli"),
    cost: { stone: 0, star: 0 },
    desc: T(
      "Görevin standart EVA giysisi. Beyaz çok katmanlı kumaş, temel yaşam desteği. Kısa dış görevler için yeterli, uzun maruziyette yetersiz.",
    ),
    pal: {
      white: "#f6f7fc",
      light: "#e3e7f3",
      shade: "#c4cbde",
      dark: "#98a1bd",
      line: "#5f6886",
      orange: "#ff8c42",
      orangeD: "#c75d1e",
      navy: "#232b4d",
      steel: "#7f879f",
      glove: "#ff9a52",
      visor: ["#b9ecff", "#3f8fd8", "#17406f", "#0a1d3a"],
      trim: "rgba(255,211,77,.8)",
    },
    st: { o2: 1, spd: 1, rad: 1, storm: 1, grav: 0 },
    deco: 0,
    glow: "#ff8c42",
  },
  {
    id: "kasif",
    name: T("Kaşif Mk-I"),
    tier: "SET I",
    tag: T("Hafif · Çevik"),
    cost: { stone: 4, star: 0 },
    desc: T(
      "Kum rengi hafif kompozit dış katman ve geliştirilmiş CO₂ geri dönüştürücü. Uzun yürüyüşlerde daha az oksijen harcar, daha çevik hareket eder.",
    ),
    pal: {
      white: "#f6eddc",
      light: "#e4d3b3",
      shade: "#c2a982",
      dark: "#9c855f",
      line: "#6b5a3e",
      orange: "#26b5a4",
      orangeD: "#177a6f",
      navy: "#203332",
      steel: "#8f8a7a",
      glove: "#2fc2b0",
      visor: ["#d9fff8", "#38c9b5", "#156b63", "#0a2b28"],
      trim: "rgba(43,190,170,.95)",
    },
    st: { o2: 0.82, spd: 1.08, rad: 0.8, storm: 0.82, grav: 0.25 },
    gf: T("Ağırlıklı botlar"),
    deco: 1,
    glow: "#2fc2b0",
  },
  {
    id: "oncu",
    name: T("Öncü Mk-II"),
    tier: "SET II",
    tag: T("Karbon · Işık şeritli"),
    cost: { stone: 8, star: 1, olivin: 2 },
    desc: T(
      "Karbon-grafit gövde, ışık şeritli eklemler ve toz contalı bağlantılar. Fırtınada rüzgâra karşı daha sağlam, radyasyona karşı ara katmanlı.",
    ),
    pal: {
      white: "#6a7285",
      light: "#4b5263",
      shade: "#363c4a",
      dark: "#252a34",
      line: "#14171e",
      orange: "#38bdf8",
      orangeD: "#0e7fb5",
      navy: "#0c1220",
      steel: "#758099",
      glove: "#2b3240",
      visor: ["#e0f6ff", "#5ad1ff", "#145a8c", "#04121f"],
      trim: "rgba(90,209,255,.95)",
    },
    st: { o2: 0.66, spd: 1.16, rad: 0.6, storm: 0.6, grav: 0.5 },
    gf: T("Manyetik botlar"),
    deco: 2,
    glow: "#38bdf8",
  },
  {
    id: "kalkan",
    name: T("Kalkan Mk-III"),
    tier: "SET III",
    tag: T("Zırhlı · Radyasyon kalkanı"),
    cost: { stone: 12, star: 3, olivin: 4, titan: 2 },
    desc: T(
      "Kurşun katkılı zırh plakaları, manyetik radyasyon kalkanı ve güçlendirilmiş motor destekli eklemler. Radyasyon dalgasında çok daha uzun dayanır.",
    ),
    pal: {
      white: "#d5dbb6",
      light: "#a3ab80",
      shade: "#7d865e",
      dark: "#5d6444",
      line: "#383d28",
      orange: "#ffd23a",
      orangeD: "#b58f0a",
      navy: "#1f2416",
      steel: "#757b64",
      glove: "#3d4231",
      visor: ["#fff6c9", "#e8c547", "#6b5a12", "#1d1804"],
      trim: "rgba(255,210,58,.95)",
    },
    st: { o2: 0.52, spd: 1.23, rad: 0.38, storm: 0.4, grav: 0.7 },
    gf: T("Jiroskop dengeleyici"),
    deco: 3,
    glow: "#ffd23a",
  },
  {
    id: "elite",
    name: "ARES Elite",
    tier: "SET IV",
    tag: T("Prototip · Altın vizör"),
    cost: { stone: 16, star: 5, olivin: 5, ares: 3 },
    desc: T(
      "Görev Kontrol'ün gizli prototipi. Altın kaplı vizör, plazma çekirdekli yaşam desteği, tam fırtına zırhı ve güçlendirilmiş dış iskelet.",
    ),
    pal: {
      white: "#43434d",
      light: "#2a2a31",
      shade: "#1a1a20",
      dark: "#0f0f13",
      line: "#000000",
      orange: "#f5c042",
      orangeD: "#a87a12",
      navy: "#0b0b0f",
      steel: "#c9a34a",
      glove: "#1c1c22",
      visor: ["#fff3c4", "#f5c042", "#9a6a0a", "#2b1a00"],
      trim: "rgba(255,226,140,1)",
    },
    st: { o2: 0.38, spd: 1.3, rad: 0.2, storm: 0.2, grav: 0.88 },
    gf: T("Aktif yerçekimi dengeleyici"),
    deco: 4,
    glow: "#f5c042",
  },
];
const ROCKET_SKINS = [
  {
    id: "classic",
    name: T("Klasik ARES"),
    cost: 0,
    desc: T("Beyaz gövde, turuncu burun — görevin orijinal boyası."),
    hull: ["#ffffff", "#eef1fb", "#c5ccdf", "#8d94b2"],
    nose: ["#ffb37a", "#ff7a3a", "#b7471c"],
    band: "#ff5a4a",
    fin: ["#ff6a55", "#b7291f"],
    finLine: "#6e1a14",
    cfin: "#8e2f26",
    text: "#3b4260",
    line: "#6f7698",
    deco: "",
  },
  {
    id: "polar",
    name: T("Kutup Mavisi"),
    cost: 8,
    desc: T("Buz beyazı gövde, lacivert burun, camgöbeği kanatlar ve ince hız şeritleri."),
    hull: ["#ffffff", "#eaf6ff", "#bcdcf2", "#7aa7c9"],
    nose: ["#7fd4ff", "#1f7fd0", "#0b3a6e"],
    band: "#38bdf8",
    fin: ["#5ad1ff", "#0b5fa8"],
    finLine: "#06305a",
    cfin: "#0b3a6e",
    text: "#0b3a6e",
    line: "#5b86a8",
    deco: "stripes",
  },
  {
    id: "camo",
    name: T("Mars Kamuflajı"),
    cost: 10,
    desc: T("Pas ve kum tonlarında desen, zeytin yeşili kanatlar. Mars'ta neredeyse görünmez."),
    hull: ["#e2c093", "#c99a63", "#9e6c3f", "#6b4526"],
    nose: ["#8a9752", "#5b6631", "#2f3618"],
    band: "#5b6631",
    fin: ["#8a9752", "#3c4420"],
    finLine: "#20250f",
    cfin: "#3c4420",
    text: "#2f2414",
    line: "#5a3d22",
    deco: "camo",
  },
  {
    id: "raven",
    name: T("Gece Kuzgunu"),
    cost: 12,
    desc: T("Mat siyah gövde, kızıl burun ve kanatlar, parlayan kırmızı çizgiler."),
    hull: ["#5a5d68", "#353741", "#202229", "#0f1014"],
    nose: ["#ff6b6b", "#d61f2c", "#6e0b12"],
    band: "#d61f2c",
    fin: ["#e0313c", "#5e0a10"],
    finLine: "#2a0508",
    cfin: "#5e0a10",
    text: "#e6e8ef",
    line: "#0a0b0e",
    deco: "raven",
  },
  {
    id: "gold",
    name: T("Altın Çağ"),
    cost: 26,
    desc: T("Krom-altın kaplama, siyah burun ve şeritler, güneşte parıldayan yansımalar."),
    hull: ["#fff6d2", "#f2cf6b", "#c79a2c", "#7a5a12"],
    nose: ["#4a4a52", "#1d1d22", "#000000"],
    band: "#1d1d22",
    fin: ["#f5c042", "#8a6410"],
    finLine: "#4a3405",
    cfin: "#1d1d22",
    text: "#3a2a05",
    line: "#6b4e0e",
    deco: "gold",
  },
];
const ARMOR = [
  {
    lv: 1,
    name: T("Titanyum Plakalar"),
    cost: 10,
    c: { gold: 10, titan: 3 },
    chance: 0.35,
    desc: T("Alt gövdeye perçinli titanyum plakalar. Fırtınada motor arızası olasılığı %60 → %35."),
  },
  {
    lv: 2,
    name: T("Kanat & Burun Zırhı"),
    cost: 18,
    c: { gold: 18, titan: 5 },
    chance: 0.15,
    desc: T(
      "Kanat kenar koruyucuları ve güçlendirilmiş burun başlığı. Arıza olasılığı %15'e iner, gövde daha az sarsılır.",
    ),
  },
  {
    lv: 3,
    name: T("Deflektör Kalkanı"),
    cost: 30,
    c: { gold: 30, titan: 6, ares: 3 },
    chance: 0,
    desc: T("Manyetik toz deflektörü roketi enerji kalkanıyla sarar. Fırtına artık motoru bozamaz."),
  },
];
const BASE_STORM_BREAK = 0.6;
let SUITX = { deco: 0, visor: SUITS[0].pal.visor, trim: SUITS[0].pal.trim };
let RSK = ROCKET_SKINS[0],
  RKV = { armor: 0 };
function curSuit() {
  return SUITS.find((s) => s.id === (game && game.suit)) || SUITS[0];
}
function suitSt() {
  return curSuit().st;
}
function rkArmor() {
  return game && game.rk ? game.rk.armor || 0 : 0;
}
function ensureUpg() {
  if (!game) return;
  ensureRare();
  if (!game.suit) game.suit = "std";
  if (!Array.isArray(game.suitsOwned)) game.suitsOwned = ["std"];
  if (game.gold == null) game.gold = 0;
  if (!game.rk) game.rk = { armor: 0, skin: "classic", owned: ["classic"] };
}
function applySuit(s) {
  s = s || curSuit();
  Object.assign(SUIT, s.pal);
  SUITX = { deco: s.deco, visor: s.pal.visor, trim: s.pal.trim };
}
function applyRocketSkin() {
  RSK = ROCKET_SKINS.find((s) => s.id === (game && game.rk && game.rk.skin)) || ROCKET_SKINS[0];
  RKV = { armor: rkArmor() };
}
function syncLooks() {
  if (game) ensureUpg();
  const k = game ? game.suit + "|" + game.rk.skin + "|" + game.rk.armor : "std|classic|0";
  if (syncLooks.k !== k) {
    syncLooks.k = k;
    applySuit();
    applyRocketSkin();
  }
}
/* --- önizleme sprite'ları (önbellekli) --- */
const _suitPrev = {},
  _rkPrev = {};
function suitSprite(s, scale) {
  const key = s.id + "@" + scale;
  if (_suitPrev[key]) return _suitPrev[key];
  const c = document.createElement("canvas"),
    w = Math.ceil(80 * scale),
    h = Math.ceil(120 * scale);
  c.width = w;
  c.height = h;
  const g = c.getContext("2d");
  const save = { walk: p.walk, t: p.t, dir: p.dir, sx: p.sx, sy: p.sy },
    sv = { ...SUIT },
    sx = SUITX,
    kc = game && game.kitCarried,
    sI = stormFx.I,
    ra = game && game.radiationActive,
    ir = insideRocket;
  try {
    p.walk = 0;
    p.t = 0;
    p.dir = 1;
    p.sx = 1;
    p.sy = 1;
    stormFx.I = 0;
    insideRocket = true;
    if (game) {
      game.kitCarried = false;
    }
    applySuit(s);
    withCtx(g, () => {
      ctx.save();
      ctx.translate(w / 2 - 2 * scale, h * 0.66);
      ctx.scale(scale, scale);
      astronaut(0, 0, false, null, 0);
      ctx.restore();
    });
  } catch (e) {
  } finally {
    Object.assign(p, save);
    Object.assign(SUIT, sv);
    SUITX = sx;
    stormFx.I = sI;
    insideRocket = ir;
    if (game) game.kitCarried = kc;
  }
  return (_suitPrev[key] = c);
}
function rocketSprite(sk, armor, scale) {
  const key = sk.id + "@" + armor + "@" + scale;
  if (_rkPrev[key]) return _rkPrev[key];
  const c = document.createElement("canvas"),
    w = Math.ceil(110 * scale),
    h = Math.ceil(150 * scale);
  c.width = w;
  c.height = h;
  const g = c.getContext("2d");
  const o1 = RSK,
    o2 = RKV;
  try {
    RSK = sk;
    RKV = { armor };
    withCtx(g, () => {
      ctx.save();
      ctx.translate(w / 2, 84 * scale);
      ctx.scale(scale, scale);
      rocketBody({ flame: 0, broken: false, t: 1.2 });
      ctx.restore();
    });
  } catch (e) {
  } finally {
    RSK = o1;
    RKV = o2;
  }
  return (_rkPrev[key] = c);
}
/* --- astronot süslemeleri (set seviyesine göre) --- */
function suitDecoTorso(t) {
  const d = SUITX.deco;
  if (!d) return;
  if (d === 1) {
    // Kaşif: camgöbeği biyeler + göğüs yaması
    ctx.strokeStyle = SUIT.orange;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(-15, -20);
    ctx.quadraticCurveTo(-8, -2, -14, 10);
    ctx.moveTo(15, -20);
    ctx.quadraticCurveTo(8, -2, 14, 10);
    ctx.stroke();
    ctx.fillStyle = SUIT.orange;
    rrp(8, 4, 8, 5, 1.5);
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.fillRect(9, 6, 6, 1);
  } else if (d === 2) {
    // Öncü: ışık şeritleri
    ctx.save();
    ctx.shadowColor = SUIT.orange;
    ctx.shadowBlur = 6;
    ctx.strokeStyle = SUIT.orange;
    ctx.lineWidth = 1.4;
    ctx.globalAlpha = 0.75 + 0.25 * Math.sin(t * 3);
    ctx.beginPath();
    ctx.moveTo(-14, -18);
    ctx.lineTo(-14, 8);
    ctx.moveTo(14, -18);
    ctx.lineTo(14, 8);
    ctx.moveTo(-16, 14);
    ctx.lineTo(16, 14);
    ctx.stroke();
    ctx.restore();
  } else if (d === 3) {
    // Kalkan: göğüs zırhı + tehlike bandı + radyasyon simgesi
    const cg = ctx.createLinearGradient(-14, -22, 14, 8);
    cg.addColorStop(0, SUIT.light);
    cg.addColorStop(1, SUIT.dark);
    ctx.fillStyle = cg;
    rrp(-15, -22, 30, 10, 4);
    ctx.fill();
    ctx.strokeStyle = SUIT.line;
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.save();
    rrp(-18, 15, 36, 4, 1);
    ctx.clip();
    ctx.fillStyle = "#1f2416";
    ctx.fillRect(-18, 15, 36, 4);
    ctx.fillStyle = SUIT.orange;
    for (let x = -18; x < 18; x += 6) {
      ctx.beginPath();
      ctx.moveTo(x, 19);
      ctx.lineTo(x + 3, 19);
      ctx.lineTo(x + 6, 15);
      ctx.lineTo(x + 3, 15);
      ctx.fill();
    }
    ctx.restore();
    ctx.fillStyle = SUIT.orange;
    ctx.beginPath();
    ctx.arc(-9, 4, 4, 0, 7);
    ctx.fill();
    ctx.fillStyle = "#1f2416";
    for (let i = 0; i < 3; i++) {
      const a = (i * Math.PI * 2) / 3 - Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(-9, 4);
      ctx.arc(-9, 4, 3.4, a - 0.45, a + 0.45);
      ctx.fill();
    }
    ctx.fillStyle = SUIT.orange;
    ctx.beginPath();
    ctx.arc(-9, 4, 0.9, 0, 7);
    ctx.fill();
  } else if (d === 4) {
    // Elite: plazma çekirdeği + altın hatlar
    ctx.strokeStyle = SUIT.orange;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(-16, -16);
    ctx.lineTo(-6, -6);
    ctx.lineTo(-6, 10);
    ctx.moveTo(16, -16);
    ctx.lineTo(6, -6);
    ctx.lineTo(6, 10);
    ctx.stroke();
    const pu = 0.7 + 0.3 * Math.sin(t * 4);
    ctx.save();
    ctx.shadowColor = "#ffb02e";
    ctx.shadowBlur = 12 * pu;
    const rg = ctx.createRadialGradient(0, 2, 0, 0, 2, 5.5);
    rg.addColorStop(0, "#fffbe6");
    rg.addColorStop(0.4, "#ffd34d");
    rg.addColorStop(1, "rgba(255,140,30,0)");
    ctx.fillStyle = rg;
    ctx.beginPath();
    ctx.arc(0, 2, 5.5, 0, 7);
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = SUIT.orange;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(0, 2, 4, 0, 7);
    ctx.stroke();
  }
}
function suitDecoShoulders() {
  const d = SUITX.deco;
  if (d < 3) return;
  for (const s of [-1, 1]) {
    const g = ctx.createLinearGradient(s * 8, -26, s * 20, -12);
    g.addColorStop(0, d === 4 ? "#f8d77a" : SUIT.light);
    g.addColorStop(1, d === 4 ? "#8a6410" : SUIT.dark);
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(s * 14, -18, 9, 6.5, s * 0.25, 0, 7);
    ctx.fill();
    ctx.strokeStyle = SUIT.line;
    ctx.lineWidth = 1.1;
    ctx.stroke();
    ctx.fillStyle = "rgba(255,255,255,.35)";
    ctx.beginPath();
    ctx.ellipse(s * 13, -20.5, 4, 1.6, s * 0.25, 0, 7);
    ctx.fill();
  }
}
function suitDecoHelmet(t) {
  const d = SUITX.deco;
  if (!d) return;
  if (d === 1) {
    ctx.strokeStyle = SUIT.orange;
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.arc(0, 0, 17.5, Math.PI * 1.12, Math.PI * 1.62);
    ctx.stroke();
  }
  if (d === 2) {
    ctx.save();
    ctx.shadowColor = SUIT.orange;
    ctx.shadowBlur = 8;
    ctx.strokeStyle = SUIT.orange;
    ctx.lineWidth = 1.3;
    ctx.globalAlpha = 0.8 + 0.2 * Math.sin(t * 3);
    ctx.beginPath();
    ctx.arc(0, 0, 18.5, Math.PI * 0.95, Math.PI * 1.55);
    ctx.stroke();
    ctx.restore();
  }
  if (d === 3) {
    ctx.fillStyle = SUIT.dark;
    rrp(-21, -6, 6, 12, 2);
    ctx.fill();
    ctx.fillStyle = SUIT.orange;
    ctx.fillRect(-20, -4, 4, 1.6);
    ctx.fillRect(-20, 0, 4, 1.6);
  }
  if (d === 4) {
    // tepe yüzgeci
    const g = ctx.createLinearGradient(-10, -30, 8, -16);
    g.addColorStop(0, "#ffe9a0");
    g.addColorStop(1, "#8a6410");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(-10, -16);
    ctx.quadraticCurveTo(-8, -27, 6, -25);
    ctx.lineTo(4, -18);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#4a3405";
    ctx.lineWidth = 1;
    ctx.stroke();
  }
}
/* --- roket boyası/zırh süsleri (gövde kırpması içinde çağrılır) --- */
function rocketDecoInside(t) {
  const d = RSK.deco;
  if (d === "stripes") {
    ctx.fillStyle = "rgba(56,189,248,.55)";
    for (const y of [-36, -32]) ctx.fillRect(-26, y, 52, 2);
    ctx.fillStyle = "rgba(11,58,110,.6)";
    ctx.fillRect(-26, 26, 52, 2.5);
  }
  if (d === "camo") {
    const R = rng(9);
    for (let i = 0; i < 22; i++) {
      ctx.fillStyle = ["rgba(91,102,49,.55)", "rgba(107,69,38,.55)", "rgba(226,192,147,.5)"][i % 3];
      ctx.beginPath();
      ctx.ellipse(-24 + R() * 48, -60 + R() * 92, 4 + R() * 7, 3 + R() * 5, R() * 3, 0, 7);
      ctx.fill();
    }
  }
  if (d === "raven") {
    ctx.save();
    ctx.shadowColor = "#ff2a3a";
    ctx.shadowBlur = 6;
    ctx.strokeStyle = "rgba(255,60,70,.9)";
    ctx.lineWidth = 1;
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(s * 6, -50);
      ctx.quadraticCurveTo(s * 20, -10, s * 19, 30);
      ctx.stroke();
    }
    ctx.restore();
  }
  if (d === "gold") {
    ctx.fillStyle = "rgba(20,20,24,.85)";
    for (const y of [-44, 24]) {
      ctx.beginPath();
      ctx.moveTo(-26, y);
      ctx.lineTo(0, y + 5);
      ctx.lineTo(26, y);
      ctx.lineTo(26, y + 3);
      ctx.lineTo(0, y + 8);
      ctx.lineTo(-26, y + 3);
      ctx.closePath();
      ctx.fill();
    }
    const sx = Math.sin(t * 1.3) * 18;
    const g = ctx.createLinearGradient(sx - 10, 0, sx + 10, 0);
    g.addColorStop(0, "rgba(255,255,255,0)");
    g.addColorStop(0.5, "rgba(255,255,255,.55)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(-26, -80, 52, 116);
  }
  const a = RKV.armor || 0;
  if (a >= 1) {
    // perçinli plakalar
    for (const [x0, x1] of [
      [-24, -2],
      [2, 24],
    ]) {
      const g = ctx.createLinearGradient(0, 4, 0, 22);
      g.addColorStop(0, "rgba(120,128,150,.85)");
      g.addColorStop(1, "rgba(60,66,88,.9)");
      ctx.fillStyle = g;
      rrp(x0, 4, x1 - x0, 17, 2);
      ctx.fill();
      ctx.strokeStyle = "rgba(20,24,36,.8)";
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.fillStyle = "rgba(230,235,245,.8)";
      for (let x = x0 + 3; x < x1 - 1; x += 5) {
        ctx.beginPath();
        ctx.arc(x, 7, 0.8, 0, 7);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(x, 18, 0.8, 0, 7);
        ctx.fill();
      }
    }
  }
}
function rocketDecoOutside(t) {
  const a = RKV.armor || 0;
  if (a >= 2) {
    // kanat kenar koruyucuları + burun başlığı
    ctx.strokeStyle = "#c3c9dc";
    ctx.lineWidth = 2.6;
    ctx.lineCap = "round";
    for (const sx of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(sx * 23, 6);
      ctx.lineTo(sx * 44, 42);
      ctx.stroke();
    }
    ctx.strokeStyle = "rgba(30,34,50,.8)";
    ctx.lineWidth = 1;
    for (const sx of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(sx * 23, 6);
      ctx.lineTo(sx * 44, 42);
      ctx.stroke();
    }
    const g = ctx.createLinearGradient(-6, -82, 6, -70);
    g.addColorStop(0, "#eef1fb");
    g.addColorStop(1, "#5b6178");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.moveTo(0, -82);
    ctx.quadraticCurveTo(6, -76, 6.5, -70);
    ctx.lineTo(-6.5, -70);
    ctx.quadraticCurveTo(-6, -76, 0, -82);
    ctx.fill();
  }
  if (a >= 3) {
    // deflektör kalkanı
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < 2; i++) {
      const y = -14 + i * 30,
        ph = t * 2 + i;
      ctx.strokeStyle = "rgba(90,200,255," + (0.35 + 0.25 * Math.sin(ph)) + ")";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(0, y, 34, 6, 0, 0, 7);
      ctx.stroke();
    }
    const g = ctx.createRadialGradient(0, -20, 10, 0, -20, 70);
    g.addColorStop(0, "rgba(90,200,255,0)");
    g.addColorStop(0.8, "rgba(90,200,255," + (0.08 + 0.04 * Math.sin(t * 3)) + ")");
    g.addColorStop(1, "rgba(90,200,255,0)");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.ellipse(0, -20, 52, 78, 0, 0, 7);
    ctx.fill();
    ctx.restore();
  }
}
/* --- altın parçası (zeminde) --- */
function drawGoldNugget(x, y, t, seed) {
  ctx.save();
  ctx.translate(x, y);
  const pu = 0.6 + 0.4 * Math.sin(t * 3 + seed);
  const gl = ctx.createRadialGradient(0, 0, 0, 0, 0, 26);
  gl.addColorStop(0, "rgba(255,210,90," + 0.35 * pu + ")");
  gl.addColorStop(1, "rgba(255,210,90,0)");
  ctx.fillStyle = gl;
  ctx.beginPath();
  ctx.arc(0, 0, 26, 0, 7);
  ctx.fill();
  ctx.fillStyle = "rgba(0,0,0,.3)";
  ctx.beginPath();
  ctx.ellipse(2, 9, 11, 3.5, 0, 0, 7);
  ctx.fill();
  const R = rng(Math.floor(seed * 1000) + 3);
  ctx.beginPath();
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * 6.283,
      r = 7 + R() * 4;
    ctx.lineTo(Math.cos(a) * r * 1.25, Math.sin(a) * r * 0.85);
  }
  ctx.closePath();
  const g = ctx.createLinearGradient(-9, -8, 9, 8);
  g.addColorStop(0, "#fff4c2");
  g.addColorStop(0.35, "#f5c542");
  g.addColorStop(0.75, "#b9861a");
  g.addColorStop(1, "#6b4a08");
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = "#5a3d06";
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.fillStyle = "rgba(255,255,255,.75)";
  ctx.beginPath();
  ctx.ellipse(-3, -3, 3, 1.4, -0.5, 0, 7);
  ctx.fill();
  const sp = (t * 1.4 + seed) % 1;
  if (sp < 0.3) {
    const a = 1 - sp / 0.3;
    ctx.strokeStyle = "rgba(255,255,255," + a + ")";
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(5, -9);
    ctx.lineTo(5, -3);
    ctx.moveTo(2, -6);
    ctx.lineTo(8, -6);
    ctx.stroke();
  }
  ctx.restore();
}
/* --- roket içi: geliştirme istasyonu (cam kapsül + manken) --- */
let upgOpen = false,
  upgTab = "suit",
  upgSel = null,
  upgAnim = 0;
function drawSuitPod(x, F, C, t) {
  upgAnim += ((upgOpen ? 1 : 0) - upgAnim) * 0.12;
  const top = C + 18,
    w = 40;
  // gövde: mühendislik ünitesi
  const bg = ctx.createLinearGradient(x - w / 2, 0, x + w / 2, 0);
  bg.addColorStop(0, "#3b4160");
  bg.addColorStop(0.5, "#59617f");
  bg.addColorStop(1, "#2d3246");
  ctx.fillStyle = bg;
  rrp(x - w / 2, top, w, F - top, 6);
  ctx.fill();
  ctx.strokeStyle = "#1b1e2e";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  // üst: holografik projeksiyon (kıyafet ↔ roket dönüşümlü)
  const cyc = (t * 0.22) % 2,
    isS = cyc < 1,
    k = cyc % 1,
    fade = Math.min(1, Math.min(k, 1 - k) * 6);
  const hx = x,
    hy = top + 36,
    gc = isS ? curSuit().glow : "#5ad1ff";
  ctx.fillStyle = "#0a0f22";
  rrp(x - w / 2 + 3, top + 3, w - 6, 62, 5);
  ctx.fill();
  ctx.save();
  rrp(x - w / 2 + 3, top + 3, w - 6, 62, 5);
  ctx.clip();
  ctx.strokeStyle = "rgba(90,209,255,.08)";
  ctx.lineWidth = 1;
  for (let yy = top + 5; yy < top + 66; yy += 3) {
    ctx.beginPath();
    ctx.moveTo(x - w / 2, yy);
    ctx.lineTo(x + w / 2, yy);
    ctx.stroke();
  }
  ctx.globalAlpha = 0.85 * fade;
  ctx.globalCompositeOperation = "lighter";
  const img = isS ? suitSprite(curSuit(), 0.42) : rocketSprite(RSK, RKV.armor, 0.36);
  const sx = Math.cos(t * 1.4);
  ctx.save();
  ctx.translate(hx, hy);
  ctx.scale(Math.max(0.25, Math.abs(sx)) * (sx < 0 ? -1 : 1), 1);
  ctx.drawImage(img, -img.width / 2, -img.height / 2 + (isS ? -2 : 6));
  ctx.restore();
  ctx.globalCompositeOperation = "source-over";
  ctx.globalAlpha = 1;
  const hl = ctx.createLinearGradient(0, top + 3, 0, top + 65);
  hl.addColorStop(0, "rgba(0,0,0,0)");
  hl.addColorStop(1, gc + "33");
  ctx.fillStyle = hl;
  ctx.fillRect(x - w / 2, top + 3, w, 62);
  ctx.restore();
  ctx.fillStyle = gc;
  ctx.fillRect(x - 12, top + 64, 24, 1.6);
  // orta: üretim haznesi + robot kol
  const cy = top + 72,
    ch = F - cy - 24;
  ctx.fillStyle = "#141a2e";
  rrp(x - w / 2 + 3, cy, w - 6, ch, 4);
  ctx.fill();
  const cg = ctx.createLinearGradient(0, cy, 0, cy + ch);
  cg.addColorStop(0, "rgba(255,170,90,.18)");
  cg.addColorStop(1, "rgba(255,120,60,.05)");
  ctx.fillStyle = cg;
  rrp(x - w / 2 + 3, cy, w - 6, ch, 4);
  ctx.fill();
  const ax = x + Math.sin(t * 1.7) * 9,
    ay = cy + ch - 12 + Math.sin(t * 3.1) * 2;
  ctx.strokeStyle = "#c9d0e2";
  ctx.lineWidth = 2.4;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x - w / 2 + 6, cy + 5);
  ctx.lineTo(x - 4, cy + ch * 0.45);
  ctx.lineTo(ax, ay);
  ctx.stroke();
  ctx.fillStyle = "#ff8c42";
  ctx.beginPath();
  ctx.arc(x - 4, cy + ch * 0.45, 2.2, 0, 7);
  ctx.fill();
  ctx.fillStyle = "#6b7390";
  rrp(x - 12, cy + ch - 6, 24, 5, 2);
  ctx.fill(); // üretim tablası
  if (Math.sin(t * 9) > 0.2) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    const sg = ctx.createRadialGradient(ax, ay, 0, ax, ay, 9);
    sg.addColorStop(0, "rgba(255,240,200,.95)");
    sg.addColorStop(1, "rgba(255,160,80,0)");
    ctx.fillStyle = sg;
    ctx.beginPath();
    ctx.arc(ax, ay, 9, 0, 7);
    ctx.fill();
    for (let i = 0; i < 4; i++) {
      const a = Math.random() * 3.14 + 3.14,
        l = 3 + Math.random() * 7;
      ctx.strokeStyle = "rgba(255,210,140,.9)";
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(ax + Math.cos(a) * l, ay + Math.sin(a) * l);
      ctx.stroke();
    }
    ctx.restore();
  }
  // cam
  ctx.fillStyle = "rgba(180,220,255,.07)";
  rrp(x - w / 2 + 3, cy, w - 6, ch, 4);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.25)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x - w / 2 + 6, cy + 4);
  ctx.lineTo(x - w / 2 + 6, cy + ch - 4);
  ctx.stroke();
  // alt: malzeme yuvaları (metal / altın / nadir)
  const by = F - 20;
  ctx.fillStyle = "#1d2234";
  rrp(x - w / 2 + 2, by, w - 4, 16, 3);
  ctx.fill();
  const slots = [
    ["#c9d2e0", (game.inventory.stone || 0) > 0],
    ["#f5c542", (game.gold || 0) > 0],
    ["#b6f04a", game.rare && (game.rare.olivin || 0) > 0],
    ["#9fd3ff", game.rare && (game.rare.titan || 0) > 0],
  ];
  slots.forEach(([c, on], i) => {
    const sx2 = x - 14 + i * 9.3;
    ctx.fillStyle = on ? c : "#2a3048";
    ctx.beginPath();
    ctx.arc(sx2, by + 8, 2.6, 0, 7);
    ctx.fill();
    if (on) {
      ctx.fillStyle = c + "55";
      ctx.beginPath();
      ctx.arc(sx2, by + 8, 5, 0, 7);
      ctx.fill();
    }
  });
  // etiket
  ctx.fillStyle = "#0a1024";
  rrp(x - 20, top - 13, 40, 10, 2);
  ctx.fill();
  ctx.fillStyle = gc;
  ctx.font = "700 6.5px monospace";
  ctx.textAlign = "center";
  ctx.fillText(T("ATÖLYE"), x, top - 5.5);
}
/* --- arayüz --- */
function upgRes() {
  ensureRare();
  return {
    stone: game.inventory.stone || 0,
    star: game.inventory.star || 0,
    gold: game.gold || 0,
    titan: game.rare.titan || 0,
    olivin: game.rare.olivin || 0,
    ares: game.rare.ares || 0,
  };
}
function openUpg(tab) {
  ensureUpg();
  upgOpen = true;
  if (tab) upgTab = tab;
  upgSel = null;
  $("upgScreen").classList.remove("hidden");
  sfx("click");
  tone(440, 0.08, "triangle", 0.05);
  tone(660, 0.1, "triangle", 0.05, 0, 0.08);
  renderUpg();
}
function closeUpg() {
  upgOpen = false;
  $("upgScreen").classList.add("hidden");
  focusGame();
}
const pct = (v) => Math.round(v * 100);
function statRows(st, cmp) {
  const rows = [
    [T("Oksijen tüketimi"), 1 / st.o2, 1 / (cmp || st).o2, "o2", "%" + pct(1 - st.o2) + T(" daha az")],
    [T("Yürüme hızı"), st.spd, (cmp || st).spd, "spd", "+%" + pct(st.spd - 1)],
    [
      T("Radyasyon koruması"),
      1 - st.rad,
      1 - (cmp || st).rad,
      "rad",
      "%" + pct(1 - st.rad) + T(" daha az hasar"),
    ],
    [
      T("Fırtına direnci"),
      1 - st.storm,
      1 - (cmp || st).storm,
      "storm",
      "%" + pct(1 - st.storm) + T(" daha az etki"),
    ],
    [
      T("Yerçekimi dengesi"),
      st.grav || 0,
      (cmp || st).grav || 0,
      "grav",
      "%" + pct((st.grav || 0) * 0.85) + T(" daha az sekme"),
    ],
  ];
  const norm = {
    o2: (v) => (v - 1) / 1.7,
    spd: (v) => (v - 1) / 0.3,
    rad: (v) => v / 0.8,
    storm: (v) => v / 0.8,
    grav: (v) => v / 0.9,
  };
  return rows
    .map(([n, v, c, k, txt]) => {
      const a = Math.max(0.04, Math.min(1, norm[k](v))),
        b = Math.max(0.04, Math.min(1, norm[k](c)));
      const up = a > b + 0.001,
        dn = a < b - 0.001;
      return `<div class="ug-st"><div class="ug-stn"><span>${n}</span><b class="${up ? "up" : dn ? "dn" : ""}">${txt === "+%0" || txt.startsWith("%0 ") ? T("standart") : txt}</b></div>
      <div class="ug-bar"><i class="cur" style="width:${b * 100}%"></i><i class="new ${up ? "up" : dn ? "dn" : ""}" style="width:${a * 100}%"></i></div></div>`;
    })
    .join("");
}
function costChips(c) {
  const R = upgRes(),
    out = [];
  if (c.stone)
    out.push(
      `<span class="ug-cost ${R.stone >= c.stone ? "ok" : "no"}"><img src="${itemIconURL("stone")}">${R.stone}/${c.stone}</span>`,
    );
  if (c.star)
    out.push(
      `<span class="ug-cost ${R.star >= c.star ? "ok" : "no"}"><img src="${itemIconURL("star")}">${R.star}/${c.star}</span>`,
    );
  if (c.gold)
    out.push(
      `<span class="ug-cost gold ${R.gold >= c.gold ? "ok" : "no"}"><i class="ug-au"></i>${R.gold}/${c.gold}</span>`,
    );
  for (const k of RARE_KEYS)
    if (c[k])
      out.push(
        `<span class="ug-cost ${R[k] >= c[k] ? "ok" : "no"}" title="${RARE_DEF[k].name}"><img src="${rareIconURL(k)}">${game.rareKnown[k] ? RARE_DEF[k].name.split(" ")[0] : "???"} ${R[k]}/${c[k]}</span>`,
      );
  return out.join("") || T('<span class="ug-cost ok">Ücretsiz</span>');
}
function canPay(c) {
  const R = upgRes();
  return ["stone", "star", "gold", ...RARE_KEYS].every((k) => R[k] >= (c[k] || 0));
}
function pay(c) {
  game.inventory.stone -= c.stone || 0;
  game.inventory.star -= c.star || 0;
  game.gold -= c.gold || 0;
  for (const k of RARE_KEYS) game.rare[k] -= c[k] || 0;
  updateInv();
}
function upgFanfare(col) {
  tone(523, 0.12, "triangle", 0.07);
  tone(659, 0.12, "triangle", 0.07, 0, 0.1);
  tone(784, 0.16, "triangle", 0.07, 0, 0.2);
  tone(1047, 0.35, "sine", 0.06, 0, 0.32);
  const el = $("ugFlash");
  if (el) {
    el.style.background = `radial-gradient(circle at 50% 45%,${col}55,transparent 60%)`;
    el.classList.remove("go");
    void el.offsetWidth;
    el.classList.add("go");
  }
}
function renderUpg() {
  const R = upgRes();
  $("ugRes").innerHTML =
    Tf(
      `<span><img src="{0}">Metal <b>{1}</b></span><span><img src="{2}">Kristal <b>{3}</b></span><span><i class="ug-au"></i>Altın <b>{4}</b></span>`,
      [itemIconURL("stone"), R.stone, itemIconURL("star"), R.star, R.gold],
    ) +
    RARE_KEYS.map(
      (k) =>
        `<span title="${RARE_DEF[k].name}"><img src="${rareIconURL(k)}">${game.rareKnown[k] ? RARE_DEF[k].name.split(" ")[0] : "???"} <b>${R[k]}</b></span>`,
    ).join("");
  document
    .querySelectorAll("#upgScreen .ug-tabs button")
    .forEach((b) => b.classList.toggle("on", b.dataset.t === upgTab));
  const B = $("ugBody");
  if (upgTab === "suit") {
    const cur = curSuit();
    const sel = SUITS.find((s) => s.id === upgSel) || cur;
    upgSel = sel.id;
    const owned = game.suitsOwned.includes(sel.id),
      worn = game.suit === sel.id,
      idx = SUITS.indexOf(sel),
      prevOwned = idx === 0 || game.suitsOwned.includes(SUITS[idx - 1].id);
    B.innerHTML = `<div class="ug-grid">
      <div class="ug-list">${SUITS.map((s) => {
        const o = game.suitsOwned.includes(s.id),
          wn = game.suit === s.id;
        return `<button class="ug-card ${s.id === sel.id ? "sel" : ""} ${o ? "own" : ""}" data-id="${s.id}" style="--g:${s.glow}">
          <div class="ug-thumb"><img src="${suitSprite(s, 0.7).toDataURL()}"></div>
          <div class="ug-ct"><small>${s.tier}</small><b>${s.name}</b><em>${s.tag}</em></div>
          <span class="ug-badge ${wn ? "on" : o ? "own" : ""}">${wn ? T("GİYİLİ") : o ? T("SAHİP") : T("KİLİTLİ")}</span></button>`;
      }).join("")}</div>
      <div class="ug-detail" style="--g:${sel.glow}">
        <div class="ug-stage"><div class="ug-ring"></div><img class="ug-hero" src="${suitSprite(sel, 2.1).toDataURL()}"><div class="ug-floor"></div></div>
        <div class="ug-info"><small>${sel.tier}</small><h3>${sel.name}</h3><p>${sel.desc}</p>
          ${sel.gf ? Tf(`<div class="ug-feat">⚙ {0} · dışarıda yerçekiminden daha az etkilenirsin</div>`, [sel.gf]) : ""}<div class="ug-stats">${statRows(sel.st, cur.st)}</div>
          <div class="ug-buy">${owned ? "" : `<div class="ug-costs">${costChips(sel.cost)}</div>`}
            <button class="cbtn pri wide" id="ugAct" ${worn ? "disabled" : ""}>${worn ? T("✓ Şu an giyili") : owned ? T("Giy") : !prevOwned ? T("Önce ") + SUITS[idx - 1].name : T("Üret ve giy")}</button></div></div>
      </div></div>`;
    B.querySelectorAll(".ug-card").forEach(
      (c) =>
        (c.onclick = () => {
          upgSel = c.dataset.id;
          sfx("click");
          renderUpg();
        }),
    );
    $("ugAct").onclick = () => {
      if (worn) return;
      if (!owned) {
        if (!prevOwned) {
          sfx("error");
          toast(T("Önce bir önceki seti üretmelisin"));
          return;
        }
        if (!canPay(sel.cost)) {
          sfx("error");
          toast(T("Malzeme yetersiz — metal, yıldız kristali ve uzak bölgelerdeki nadir taşları topla"));
          return;
        }
        pay(sel.cost);
        game.suitsOwned.push(sel.id);
        setTimeout(() => {
          bumpQuest("suit");
          if (sel.st.rad <= 0.6) bumpQuest("radSuit");
        }, 900);
      }
      game.suit = sel.id;
      syncLooks();
      upgFanfare(sel.glow);
      toast("🧑‍🚀 <b>" + sel.name + T("</b> giyildi — ") + sel.tag);
      renderUpg();
    };
  } else {
    const A = rkArmor(),
      sk = ROCKET_SKINS.find((s) => s.id === upgSel) || ROCKET_SKINS.find((s) => s.id === game.rk.skin);
    upgSel = sk.id;
    const ownedSk = game.rk.owned.includes(sk.id),
      appl = game.rk.skin === sk.id;
    const chanceNow = A ? ARMOR[A - 1].chance : BASE_STORM_BREAK;
    B.innerHTML = Tf(
      `<div class="ug-rk">
      <div class="ug-rkstage" style="--g:#5ad1ff"><div class="ug-ring"></div><img class="ug-hero rk" src="{0}"><div class="ug-floor"></div>
        <div class="ug-rkcap"><small>BOYA</small><b>{1}</b><p>{2}</p></div></div>
      <div class="ug-rkside">
        <div class="ug-sec">🛡️ FIRTINA KALKANI <span>Arıza olasılığı: <b>%{3}</b></span></div>
        <div class="ug-armor">{4}</div>
        <div class="ug-sec">🎨 GÖRÜNÜM <span>Altın parçalarıyla boya</span></div>
        <div class="ug-skins">{5}</div>
        <div class="ug-buy">{6}
          <button class="cbtn pri wide" id="ugSk" {7}>{8}</button></div>
      </div></div>`,
      [
        rocketSprite(sk, A, 2.2).toDataURL(),
        sk.name,
        sk.desc,
        Math.round(chanceNow * 100),
        ARMOR.map((a) => {
          const done = A >= a.lv,
            next = A === a.lv - 1;
          return `<div class="ug-al ${done ? "done" : next ? "next" : "lock"}"><div class="ug-alv">${done ? "✓" : a.lv}</div><div class="ug-alt"><b>${a.name}</b><p>${a.desc}</p>${next ? `<div class="ug-costs">${costChips(a.c)}</div>` : ""}</div>
            ${next ? Tf(`<button class="cbtn pri" data-armor="{0}">Kur</button>`, [a.lv]) : done ? T('<span class="ug-badge on">KURULU</span>') : T('<span class="ug-badge">KİLİTLİ</span>')}</div>`;
        }).join(""),
        ROCKET_SKINS.map((s) => {
          const o = game.rk.owned.includes(s.id),
            on = game.rk.skin === s.id;
          return `<button class="ug-sk ${s.id === sk.id ? "sel" : ""}" data-id="${s.id}"><img src="${rocketSprite(s, A, 0.62).toDataURL()}"><b>${s.name}</b>
            <span class="ug-badge ${on ? "on" : o ? "own" : ""}">${on ? T("AKTİF") : o ? T("SAHİP") : `<i class="ug-au"></i>${s.cost}`}</span></button>`;
        }).join(""),
        ownedSk ? "" : `<div class="ug-costs">${costChips({ gold: sk.cost })}</div>`,
        appl ? "disabled" : "",
        appl ? T("✓ Uygulandı") : ownedSk ? T("Boyayı uygula") : T("Satın al ve uygula"),
      ],
    );
    B.querySelectorAll(".ug-sk").forEach(
      (c) =>
        (c.onclick = () => {
          upgSel = c.dataset.id;
          sfx("click");
          renderUpg();
        }),
    );
    B.querySelectorAll("[data-armor]").forEach(
      (b) =>
        (b.onclick = () => {
          const a = ARMOR[+b.dataset.armor - 1];
          if (!canPay(a.c)) {
            sfx("error");
            toast(
              T("Malzeme yetersiz — altın (meteor kraterleri) ve titanyum cevheri (uzak bölgeler) topla"),
            );
            return;
          }
          pay(a.c);
          game.rk.armor = a.lv;
          syncLooks();
          setTimeout(() => bumpQuest("armor"), 900);
          upgFanfare("#5ad1ff");
          noiseBurst(0.6, 0.12, 1800);
          toast(
            "🛡️ <b>" + a.name + T("</b> kuruldu — fırtınada arıza olasılığı %") + Math.round(a.chance * 100),
          );
          renderUpg();
        }),
    );
    $("ugSk").onclick = () => {
      if (appl) return;
      if (!ownedSk) {
        if (!canPay({ gold: sk.cost })) {
          sfx("error");
          toast(T("Yeterli altın yok — meteor kraterlerinden altın parçası topla"));
          return;
        }
        pay({ gold: sk.cost });
        game.rk.owned.push(sk.id);
      }
      game.rk.skin = sk.id;
      syncLooks();
      upgFanfare("#f5c042");
      toast(T("🎨 Roket boyandı: <b>") + sk.name + "</b>");
      renderUpg();
    };
  }
}

/* ============== KEŞİF: nadir taşlar, yer şekilleri, atmosfer ============== */
const RARE_DEF = {
  titan: {
    name: T("Titanyum cevheri"),
    col: ["#f2f7ff", "#a9bddf", "#4a5d82"],
    glow: "#9fd3ff",
    use: T("Roket zırhı · fırtına kalkanı"),
  },
  olivin: {
    name: T("Olivin kristali"),
    col: ["#f1ffc4", "#97d43f", "#3c6b12"],
    glow: "#b6f04a",
    use: T("Kıyafet setleri · Öncü, Kalkan, Elite"),
  },
  ares: {
    name: T("Ares taşı"),
    col: ["#ffe0f5", "#e04ab0", "#5a0f4a"],
    glow: "#ff5ad1",
    use: T("En üst seviye · ARES Elite + Deflektör kalkanı"),
  },
  hematit: {
    name: T("Hematit küreleri"),
    col: ["#e8e3ea", "#6f6a78", "#2a2730"],
    glow: "#c9c3d6",
    use: T("Bilim numunesi · geçmişte su izi"),
  },
  jips: {
    name: T("Jips kristali"),
    col: ["#ffffff", "#e9e1cf", "#9c8f72"],
    glow: "#fff6dc",
    use: T("Bilim numunesi · kristal suyu içerir"),
  },
  perklorat: {
    name: T("Perklorat tuzu"),
    col: ["#fffbd6", "#e8d94a", "#7a6a10"],
    glow: "#f2e85a",
    use: T("Bilim numunesi · zehirli, dikkatle taşı"),
  },
  meteorit: {
    name: T("Demir-nikel meteorit"),
    col: ["#e6e9ef", "#8b93a3", "#353a45"],
    glow: "#d8dee9",
    use: T("Bilim numunesi · uzaydan gelen göktaşı"),
  },
};
const RARE_KEYS = ["titan", "olivin", "ares"];
const RARE_ALL = ["titan", "olivin", "ares", "hematit", "jips", "perklorat", "meteorit"];
/* Dünya laboratuvarının numune analizleri (gerçek mineral verileri; Ares taşı kurgusaldır) */
const MINERAL = {
  titan: {
    cls: T("Oksit minerali · ilmenit"),
    f: "FeTiO₃",
    comp: [
      ["TiO₂", 52.6, "#9fd3ff"],
      ["FeO", 46.0, "#7a8299"],
      ["MnO + MgO", 1.4, "#c9d2e0"],
    ],
    mohs: "5 – 6",
    rho: "4,7 g/cm³",
    rad: T("Doğal radyoaktivite yok"),
    hz: "ok",
    hzT: T("Tehlikesiz. Kesip öğütürken çıkan tozu solumayın."),
    sci: T(
      "Mars bazaltlarında yaygın titanyum kaynağıdır. Titanyum hafif ve çok dayanıklı olduğu için roket zırhı ve ısıl kalkan için en değerli yerel malzemelerden biridir.",
    ),
  },
  olivin: {
    cls: T("Silikat minerali · forsterit–fayalit serisi"),
    f: "(Mg,Fe)₂SiO₄",
    comp: [
      ["MgO", 45.2, "#97d43f"],
      ["SiO₂", 40.1, "#e9e1cf"],
      ["FeO", 14.0, "#7a8299"],
      [T("Diğer"), 0.7, "#c9d2e0"],
    ],
    mohs: "6,5 – 7",
    rho: "3,3 g/cm³",
    rad: T("Doğal radyoaktivite yok"),
    hz: "ok",
    hzT: "Tehlikesiz. Kristaller keskin olabilir; eldivenle tutun.",
    sci: T(
      "Olivin suyla temas edince kolayca ayrışır. Bu kadar taze olivin bulunması, bölgenin çok uzun süredir kuru kaldığını gösteriyor. Sert ve ısıya dayanıklı yapısıyla kıyafet katmanlarında kullanılabilir.",
    ),
  },
  ares: {
    cls: T("Tanımlanamayan kristal yapı (Mars'a özgü)"),
    f: T("Si–Fe–O + nadir toprak elementleri"),
    comp: [
      ["SiO₂", 58.0, "#e04ab0"],
      ["Fe₂O₃", 24.5, "#7a3a2a"],
      ["Al₂O₃", 11.3, "#c9d2e0"],
      ["Ce · La · Nd", 3.2, "#ff5ad1"],
      [T("Diğer"), 3.0, "#8b93a3"],
    ],
    mohs: "8",
    rho: "4,1 g/cm³",
    rad: T("Zayıf radyoaktivite (doğal arka planın ~3 katı)"),
    hz: "wa",
    hzT: T(
      "Dikkat. Uzun süre çıplak elle tutmayın ve yatakhanede saklamayın. Kargo bölmesinde korumalı taşınabilir.",
    ),
    sci: T(
      "Dünya'da eşi bilinmeyen bir kristal örgü. Nadir toprak elementleri ve çok yüksek sertlik, onu kalkan sistemleri için eşsiz kılıyor. Ekiplerimiz kökenini araştırmayı sürdürüyor.",
    ),
  },
  hematit: {
    cls: T("Demir oksit · küresel konkresyon"),
    f: "Fe₂O₃",
    comp: [
      ["Fe₂O₃", 94.0, "#6f6a78"],
      ["SiO₂", 3.5, "#e9e1cf"],
      [T("Diğer"), 2.5, "#c9d2e0"],
    ],
    mohs: "5,5 – 6,5",
    rho: "5,3 g/cm³",
    rad: T("Doğal radyoaktivite yok"),
    hz: "ok",
    hzT: T("Tehlikesiz."),
    sci: T(
      "Bu küçük demir oksit küreleri, kayaçların içinden geçen yeraltı suyunda yavaş yavaş oluşur. Yani bu bölgede çok uzun zaman önce sıvı su vardı. Meridiani Planum'da bulunan ünlü kürelerle aynı türden.",
    ),
  },
  jips: {
    cls: T("Sülfat minerali · kalsiyum sülfat dihidrat"),
    f: "CaSO₄·2H₂O",
    comp: [
      ["SO₃", 46.5, "#e8d94a"],
      ["CaO", 32.6, "#ffffff"],
      [T("H₂O (kristal suyu)"), 20.9, "#38bdf8"],
    ],
    mohs: "2",
    rho: "2,3 g/cm³",
    rad: T("Doğal radyoaktivite yok"),
    hz: "ok",
    hzT: T("Tehlikesiz. Çok yumuşaktır, kolay kırılır."),
    sci: T(
      "Jips, su buharlaşırken oluşan bir mineraldir ve yapısında %21 oranında su tutar. Isıtıldığında bu suyu bırakır; ileride Mars'ta su elde etmek için önemli bir kaynak olabilir.",
    ),
  },
  perklorat: {
    cls: T("Klor tuzu · magnezyum/kalsiyum perklorat"),
    f: "Mg(ClO₄)₂ · Ca(ClO₄)₂",
    comp: [
      [T("ClO₄⁻ (perklorat)"), 62.0, "#f2e85a"],
      ["Mg²⁺", 14.5, "#97d43f"],
      ["Ca²⁺", 9.5, "#ffffff"],
      [T("Toprak + su"), 14.0, "#8a5a3c"],
    ],
    mohs: "1 – 2",
    rho: "2,2 g/cm³",
    rad: T("Doğal radyoaktivite yok"),
    hz: "dg",
    hzT: T(
      "TEHLİKELİ. Perklorat insan için zehirlidir; tiroid bezinin çalışmasını bozar. Çıplak elle dokunmayın, tozunu solumayın, kabine sokmayın. Giysiyi kabine girmeden önce temizleyin.",
    ),
    sci: T(
      "Perkloratlar Mars toprağında yaygındır (yaklaşık %0,5–1). Zehirli olsalar da parçalandıklarında oksijen açığa çıkardıkları için gelecekte oksijen üretiminde kullanılabilirler.",
    ),
  },
  meteorit: {
    cls: T("Demir meteorit · kamasit–tenit"),
    f: T("Fe–Ni alaşımı"),
    comp: [
      ["Fe", 91.8, "#8b93a3"],
      ["Ni", 7.2, "#d8dee9"],
      ["Co", 0.5, "#9fd3ff"],
      ["P · S · C", 0.5, "#c9a26a"],
    ],
    mohs: "4 – 5",
    rho: "7,8 g/cm³",
    rad: T("Kozmik ışınla oluşmuş izotop izleri (zararsız)"),
    hz: "ok",
    hzT: T("Tehlikesiz. Çok ağırdır; taşırken dikkat edin."),
    sci: T(
      "Bu taş Mars'a uzaydan düşmüş bir göktaşı. Kesilip parlatıldığında çok yavaş soğumanın izi olan çapraz desenler görülür. Mars yüzeyinde bulunan demir meteoritler, atmosferin geçmişteki kalınlığı hakkında ipucu verir.",
    ),
  },
};
let rareNodes = [];
function ensureRare() {
  if (!game) return;
  if (!game.rare) game.rare = { titan: 0, olivin: 0, ares: 0 };
  for (const k of RARE_ALL) if (game.rare[k] == null) game.rare[k] = 0;
  if (!game.rareKnown) game.rareKnown = {};
  if (!Array.isArray(game.rareTaken)) game.rareTaken = [];
}
function genRare() {
  const R = rng(4242),
    out = [],
    spec = [
      ["titan", 28, 1300, 6400],
      ["olivin", 23, 1700, 7200],
      ["ares", 10, 2700, 7800],
      ["hematit", 22, 800, 6200],
      ["jips", 20, 1000, 6800],
      ["perklorat", 16, 1200, 7400],
      ["meteorit", 11, 2000, 7800],
    ];
  for (const [k, n, d0, d1] of spec) {
    let made = 0,
      guard = 0;
    while (made < n && guard++ < 4000) {
      const a = R() * 6.283,
        d = d0 + R() * (d1 - d0),
        x = ROCKET.x + Math.cos(a) * d,
        y = ROCKET.y + Math.sin(a) * d;
      if (Math.abs(x) > CFG.worldHalf - 160 || Math.abs(y) > CFG.worldHalf - 160) continue;
      if (out.some((o) => Math.hypot(o.x - x, o.y - y) < 320)) continue;
      out.push({
        id: k + made,
        kind: k,
        x,
        y,
        n: k === "titan" && R() < 0.4 ? 2 : 1,
        seed: R() * 100,
        taken: false,
      });
      made++;
    }
  }
  return out;
}
function spawnRare(sc) {
  ensureRare();
  rareNodes = sc === "mars" ? genRare().filter((n) => !game.rareTaken.includes(n.id)) : [];
}
function rareLabel(k) {
  return game && game.rareKnown && game.rareKnown[k] ? RARE_DEF[k].name : T("Bilinmeyen taş");
}
/* --- çizim: büyük, ayrıntılı nadir taş (kaya gövdesi + jeot kristalleri + çatlaklar + kırılma) --- */
const RARE_SCALE = 1.45;
function hslHex(h, s, l) {
  h = ((h % 360) + 360) % 360;
  s /= 100;
  l /= 100;
  const k = (n) => (n + h / 30) % 12,
    a = s * Math.min(l, 1 - l),
    f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return (
    "#" +
    [f(0), f(8), f(4)]
      .map((x) =>
        Math.round(x * 255)
          .toString(16)
          .padStart(2, "0"),
      )
      .join("")
  );
}
function rarePal(n, t) {
  const known = game && game.rareKnown && game.rareKnown[n.kind],
    D = RARE_DEF[n.kind];
  if (known) return { col: D.col, gl: D.glow, unk: false };
  const h = 200 + (((t || 0) * 24 + (n.seed || 0) * 90) % 160); // gizemli, renk değiştiren (yanardöner) kristal
  return {
    col: [hslHex(h, 90, 93), hslHex(h + 35, 72, 64), hslHex(h + 70, 62, 24)],
    gl: hslHex(h + 20, 95, 72),
    unk: true,
  };
}
function rareShape(n) {
  // kaya silüeti (sabit, tohumdan)
  if (n._sh) return n._sh;
  const R = rng(Math.floor(n.seed * 1000) + 7),
    pts = [];
  for (let i = 0; i < 14; i++) {
    const a = Math.PI + (i / 13) * Math.PI,
      r = 30 + R() * 9;
    pts.push([Math.cos(a) * r * 1.25, Math.sin(a) * r * 0.95 - 2]);
  }
  pts.push([34, 6], [22, 12], [0, 14], [-22, 12], [-35, 6]);
  const cr = [];
  const nC = 6 + Math.floor(R() * 3);
  for (let i = 0; i < nC; i++)
    cr.push({
      x: (R() - 0.5) * 30,
      y: -6 + (R() - 0.5) * 6,
      h: 18 + R() * 24,
      w: 4 + R() * 4.5,
      a: (R() - 0.5) * 0.95,
    });
  cr.sort((a, b) => b.h - a.h);
  const sh = [];
  for (let i = 0; i < 5; i++) {
    const a = R() * 6.283;
    sh.push({
      x: Math.cos(a) * (44 + R() * 16),
      y: 8 + Math.sin(a) * 10,
      h: 5 + R() * 7,
      a: (R() - 0.5) * 1.2,
    });
  }
  const sp = [];
  for (let i = 0; i < 26; i++) sp.push([(R() - 0.5) * 66, -30 + R() * 36, R()]);
  return (n._sh = { pts, cr, sh, sp });
}
function rareCrystal(c, x, y, h, w, a, col, gl, pu) {
  c.save();
  c.translate(x, y);
  c.rotate(a);
  c.shadowColor = gl;
  c.shadowBlur = 12 * pu;
  const cg = c.createLinearGradient(-w, 0, w, 0);
  cg.addColorStop(0, col[2]);
  cg.addColorStop(0.35, col[1]);
  cg.addColorStop(0.55, col[0]);
  cg.addColorStop(1, col[2]);
  c.fillStyle = cg;
  c.beginPath();
  c.moveTo(-w, 0);
  c.lineTo(-w * 0.85, -h * 0.72);
  c.lineTo(0, -h);
  c.lineTo(w * 0.85, -h * 0.72);
  c.lineTo(w, 0);
  c.closePath();
  c.fill();
  c.shadowBlur = 0;
  const ig = c.createLinearGradient(0, 0, 0, -h);
  ig.addColorStop(0, "rgba(255,255,255,0)");
  ig.addColorStop(0.6, gl + "66");
  ig.addColorStop(1, "rgba(255,255,255,.9)");
  c.fillStyle = ig;
  c.beginPath();
  c.moveTo(-w * 0.25, -h * 0.1);
  c.lineTo(-w * 0.3, -h * 0.7);
  c.lineTo(0, -h * 0.96);
  c.lineTo(w * 0.1, -h * 0.7);
  c.lineTo(w * 0.05, -h * 0.1);
  c.closePath();
  c.fill();
  c.strokeStyle = "rgba(255,255,255,.55)";
  c.lineWidth = 0.8;
  c.beginPath();
  c.moveTo(-w * 0.85, -h * 0.72);
  c.lineTo(0, -h);
  c.lineTo(w * 0.85, -h * 0.72);
  c.stroke();
  c.restore();
}
function drawRareBody(c, n, t, o) {
  o = o || {};
  const P = rarePal(n, t),
    col = P.col,
    gl = P.gl,
    S = rareShape(n),
    pu = 0.6 + 0.4 * Math.sin(t * 2.2 + n.seed);
  const now = performance.now() / 1000,
    wob = n.hitT ? Math.max(0, 1 - (now - n.hitT) / 0.35) : 0;
  const hits = n.hits || 0,
    split = n.split ? Math.min(1, (now - n.split) / 0.55) : 0;
  // zemin: koyu iz + nabız gibi atan ışık + yere düşen kristal ışığı
  if (!o.icon) {
    c.fillStyle = "rgba(10,4,2,.35)";
    c.beginPath();
    c.ellipse(0, 10, 62, 17, 0, 0, 7);
    c.fill();
    const g0 = c.createRadialGradient(0, 2, 4, 0, 2, 92);
    g0.addColorStop(0, gl + "66");
    g0.addColorStop(0.5, gl + "22");
    g0.addColorStop(1, gl + "00");
    c.globalAlpha = 0.55 + 0.45 * pu;
    c.fillStyle = g0;
    c.beginPath();
    c.ellipse(0, 4, 92, 46, 0, 0, 7);
    c.fill();
    c.globalAlpha = 1;
    // yörüngedeki toz zerreleri
    for (let i = 0; i < 7; i++) {
      const a = t * 0.6 + i * 0.9 + n.seed,
        r = 46 + 12 * Math.sin(t + i);
      c.fillStyle = gl;
      c.globalAlpha = 0.35 + 0.35 * Math.sin(t * 3 + i);
      c.beginPath();
      c.arc(Math.cos(a) * r, -14 + Math.sin(a) * r * 0.32, 1.3, 0, 7);
      c.fill();
    }
    c.globalAlpha = 1;
  }
  // etraftaki küçük kristal kırıntıları
  for (const s of S.sh) rareCrystal(c, s.x, s.y, s.h, 2.2, s.a, col, gl, pu * 0.7);
  const half = (side) => {
    // ana kaya: üç tonlu yüzeyler + kenar ışığı
    c.beginPath();
    S.pts.forEach((q, i) => (i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])));
    c.closePath();
    const rg = c.createLinearGradient(-30, -34, 24, 16);
    rg.addColorStop(0, "#8a6253");
    rg.addColorStop(0.35, "#5a382c");
    rg.addColorStop(0.75, "#2e1a13");
    rg.addColorStop(1, "#170c08");
    c.fillStyle = rg;
    c.fill();
    c.save();
    c.clip();
    c.fillStyle = "rgba(255,210,180,.10)";
    c.beginPath();
    c.moveTo(-40, -40);
    c.lineTo(10, -40);
    c.lineTo(-6, -10);
    c.lineTo(-40, -4);
    c.closePath();
    c.fill(); // üst yüzey
    c.fillStyle = "rgba(0,0,0,.22)";
    c.beginPath();
    c.moveTo(12, -36);
    c.lineTo(44, -20);
    c.lineTo(44, 20);
    c.lineTo(6, 20);
    c.closePath();
    c.fill(); // gölgeli yan
    for (const q of S.sp) {
      c.fillStyle = q[2] < 0.5 ? "rgba(255,220,200,.10)" : "rgba(0,0,0,.18)";
      c.fillRect(q[0], q[1], 1.4, 1.4);
    }
    // jeot ağzı: kayanın içinden ışık sızar
    const gg = c.createRadialGradient(0, -8, 2, 0, -8, 26);
    gg.addColorStop(0, gl + "cc");
    gg.addColorStop(0.5, gl + "44");
    gg.addColorStop(1, gl + "00");
    c.globalAlpha = 0.55 + 0.35 * pu;
    c.fillStyle = gg;
    c.beginPath();
    c.ellipse(0, -8, 26, 14, 0, 0, 7);
    c.fill();
    c.globalAlpha = 1;
    c.restore();
    c.strokeStyle = "rgba(15,6,3,.75)";
    c.lineWidth = 1.6;
    c.beginPath();
    S.pts.forEach((q, i) => (i ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])));
    c.closePath();
    c.stroke();
    c.strokeStyle = "rgba(255,190,150,.35)";
    c.lineWidth = 1.2;
    c.beginPath();
    for (let i = 1; i < 9; i++) {
      const q = S.pts[i];
      i === 1 ? c.moveTo(q[0], q[1]) : c.lineTo(q[0], q[1]);
    }
    c.stroke(); // kenar ışığı
    // kristal kümesi
    for (const k of S.cr) rareCrystal(c, k.x, k.y, k.h, k.w, k.a, col, gl, pu);
    // bilinmeyen taş: yüzeyde nabız gibi atan ışık damarları
    if (P.unk && !hits) {
      c.save();
      c.shadowColor = gl;
      c.shadowBlur = 6;
      c.strokeStyle = gl;
      c.globalAlpha = 0.25 + 0.45 * (0.5 + 0.5 * Math.sin(t * 2.6 + n.seed * 3));
      c.lineWidth = 1.1;
      c.lineCap = "round";
      for (const V of [
        [
          [-34, -6],
          [-22, -12],
          [-14, -6],
          [-6, -14],
        ],
        [
          [30, -4],
          [20, -10],
          [12, -6],
        ],
        [
          [-26, 6],
          [-12, 4],
          [-2, 8],
        ],
      ]) {
        c.beginPath();
        V.forEach((q, j) => (j ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])));
        c.stroke();
      }
      c.restore();
    }
    // vuruş çatlakları: içinden ışık sızar
    if (hits > 0) {
      c.save();
      c.shadowColor = gl;
      c.shadowBlur = 8;
      c.strokeStyle = gl;
      c.lineWidth = 1.6;
      c.lineCap = "round";
      const cracks = [
        [
          [-4, -30],
          [2, -18],
          [-3, -8],
          [4, 4],
          [0, 12],
        ],
        [
          [2, -18],
          [14, -14],
          [22, -4],
        ],
        [
          [-3, -8],
          [-16, -4],
          [-26, 4],
        ],
        [
          [4, 4],
          [16, 8],
        ],
      ];
      for (let i = 0; i < Math.min(cracks.length, hits + 1); i++) {
        const L = cracks[i];
        c.beginPath();
        L.forEach((q, j) => (j ? c.lineTo(q[0], q[1]) : c.moveTo(q[0], q[1])));
        c.stroke();
      }
      c.restore();
    }
  };
  c.save();
  if (wob > 0) {
    c.translate(Math.sin(now * 70) * 2.2 * wob, 0);
    c.rotate(Math.sin(now * 55) * 0.03 * wob);
  }
  if (split <= 0) half(0);
  else {
    // kırıldı: iki yarı ayrılır, ortada çekirdek kalır
    const e = 1 - Math.pow(1 - split, 3),
      fade = n.fadeEnd ? Math.max(0, Math.min(1, (n.fadeEnd - now) / 1.2)) : 1;
    c.globalAlpha = fade;
    for (const sd of [-1, 1]) {
      c.save();
      c.translate(sd * e * 20, e * 5);
      c.rotate(sd * e * 0.32);
      c.beginPath();
      if (sd < 0) {
        c.moveTo(-80, -80);
        c.lineTo(-4, -80);
        c.lineTo(2, -18);
        c.lineTo(-3, -8);
        c.lineTo(4, 4);
        c.lineTo(0, 30);
        c.lineTo(-80, 30);
      } else {
        c.moveTo(80, -80);
        c.lineTo(-4, -80);
        c.lineTo(2, -18);
        c.lineTo(-3, -8);
        c.lineTo(4, 4);
        c.lineTo(0, 30);
        c.lineTo(80, 30);
      }
      c.closePath();
      c.clip();
      half(sd);
      c.restore();
    }
    c.globalAlpha = 1;
  }
  c.restore();
  // parıltı
  const sp = (t * 0.9 + n.seed) % 1;
  if (sp < 0.25 && !split) {
    const a = 1 - sp / 0.25,
      sx = Math.sin(n.seed * 7) * 14,
      sy = -40;
    c.strokeStyle = "rgba(255,255,255," + a + ")";
    c.lineWidth = 1.4;
    c.beginPath();
    c.moveTo(sx, sy - 8);
    c.lineTo(sx, sy + 8);
    c.moveTo(sx - 8, sy);
    c.lineTo(sx + 8, sy);
    c.stroke();
  }
}
function drawRareCore(n, now) {
  // kırılınca açığa çıkan parlayan çekirdek
  if (!n.split) return;
  const k = Math.min(1, (now - n.split) / 0.8),
    P = rarePal(n),
    fly = n.flyT ? Math.min(1, (now - n.flyT) / 0.35) : 0;
  if (fly >= 1) return;
  let x = n.x,
    y = n.y - 14 * RARE_SCALE - 34 * (1 - Math.pow(1 - k, 3)) + Math.sin(now * 4) * 2;
  if (fly > 0) {
    const tx = p.x + p.dir * 14,
      ty = p.y - 6,
      e = fly * fly;
    x += (tx - x) * e;
    y += (ty - y) * e - 26 * Math.sin(Math.PI * fly);
  }
  const s = (0.6 + 0.4 * k) * (1 - fly * 0.5);
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.globalCompositeOperation = "lighter";
  const g = ctx.createRadialGradient(0, 0, 2, 0, 0, 46);
  g.addColorStop(0, "rgba(255,255,255,.9)");
  g.addColorStop(0.25, P.gl + "aa");
  g.addColorStop(1, P.gl + "00");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(0, 0, 46, 0, 7);
  ctx.fill();
  ctx.strokeStyle = P.gl + "88";
  ctx.lineWidth = 1.5;
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * 6.283 + now * 0.8,
      r1 = 14,
      r2 = 28 + 8 * Math.sin(now * 6 + i);
    ctx.beginPath();
    ctx.moveTo(Math.cos(a) * r1, Math.sin(a) * r1);
    ctx.lineTo(Math.cos(a) * r2, Math.sin(a) * r2);
    ctx.stroke();
  }
  ctx.globalCompositeOperation = "source-over";
  ctx.rotate(Math.sin(now * 2) * 0.2);
  rareCrystal(ctx, 0, 9, 22, 7, 0, P.col, P.gl, 1);
  rareCrystal(ctx, -6, 9, 14, 4, -0.45, P.col, P.gl, 1);
  rareCrystal(ctx, 6, 9, 15, 4, 0.45, P.col, P.gl, 1);
  ctx.restore();
}
function drawRare(n, t) {
  const known = game.rareKnown[n.kind],
    D = RARE_DEF[n.kind],
    P = rarePal(n, t),
    gl = P.gl;
  const d = Math.hypot(p.x - n.x, p.y - n.y);
  ctx.save();
  ctx.translate(n.x, n.y);
  ctx.scale(RARE_SCALE, RARE_SCALE);
  drawRareBody(ctx, n, t);
  ctx.restore();
  if (n.split || n.taken) return;
  // tarayıcı işareti: dönen holografik halka + etiket
  if (d < 340) {
    const a = Math.min(1, (340 - d) / 120);
    ctx.save();
    ctx.translate(n.x, n.y);
    ctx.globalAlpha = a;
    ctx.strokeStyle = gl;
    ctx.lineWidth = 1.6;
    ctx.setLineDash([6, 6]);
    ctx.lineDashOffset = -t * 22;
    ctx.beginPath();
    ctx.ellipse(0, 8, 82, 30, 0, 0, 7);
    ctx.stroke();
    ctx.setLineDash([]);
    const ly = -112 + Math.sin(t * 2) * 3;
    if (!known) {
      // holografik tarayıcı: ışık hüzmesi + iki katlı dönen halka + titreşen "?"
      const hy = ly - 30;
      const bm = ctx.createLinearGradient(0, hy, 0, -30);
      bm.addColorStop(0, gl + "55");
      bm.addColorStop(1, gl + "00");
      ctx.fillStyle = bm;
      ctx.beginPath();
      ctx.moveTo(-6, hy + 8);
      ctx.lineTo(6, hy + 8);
      ctx.lineTo(46, -26);
      ctx.lineTo(-46, -26);
      ctx.closePath();
      ctx.fill();
      for (let i = 0; i < 3; i++) {
        const yy = hy + 10 + ((t * 40 + i * 24) % 70);
        ctx.strokeStyle = gl;
        ctx.globalAlpha = a * (1 - ((t * 40 + i * 24) % 70) / 70) * 0.7;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.ellipse(0, yy, 8 + (yy - hy) * 0.55, 2 + (yy - hy) * 0.12, 0, 0, 7);
        ctx.stroke();
      }
      ctx.globalAlpha = a;
      ctx.save();
      ctx.translate(0, hy);
      ctx.shadowColor = gl;
      ctx.shadowBlur = 16;
      ctx.strokeStyle = gl;
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const an = (i / 6) * 6.283 + t * 0.9;
        ctx.lineTo(Math.cos(an) * 17, Math.sin(an) * 17);
      }
      ctx.closePath();
      ctx.stroke();
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 4]);
      ctx.beginPath();
      ctx.arc(0, 0, 23, -t * 1.4, -t * 1.4 + 5.2);
      ctx.stroke();
      ctx.setLineDash([]);
      for (let i = 0; i < 4; i++) {
        const an = (i * Math.PI) / 2 - t * 1.4;
        ctx.beginPath();
        ctx.moveTo(Math.cos(an) * 26, Math.sin(an) * 26);
        ctx.lineTo(Math.cos(an) * 30, Math.sin(an) * 30);
        ctx.stroke();
      }
      const gx = Math.random() < 0.06 ? (Math.random() - 0.5) * 4 : 0;
      ctx.fillStyle = gl;
      ctx.globalAlpha = a * 0.6;
      ctx.font = "900 21px Inter,system-ui,sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("?", gx + 1.5, 1);
      ctx.globalAlpha = a;
      ctx.fillStyle = "#fff";
      ctx.fillText("?", gx, 0);
      ctx.restore();
    }
    ctx.fillStyle = "rgba(8,10,24,.8)";
    const tx = known ? D.name : T("BİLİNMEYEN TAŞ") + ".".repeat(1 + (Math.floor(t * 2.5) % 3));
    ctx.font = "800 11px ui-monospace,monospace";
    const tw = ctx.measureText(tx).width + 18;
    rrp(-tw / 2, ly - 13, tw, 20, 10);
    ctx.fill();
    ctx.strokeStyle = gl;
    ctx.lineWidth = 1;
    ctx.stroke();
    ctx.fillStyle = known ? "#fff" : gl;
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillText(tx, 0, ly + 1);
    ctx.strokeStyle = gl;
    ctx.beginPath();
    ctx.moveTo(0, ly + 7);
    ctx.lineTo(0, -62);
    ctx.stroke();
    ctx.restore();
  }
}
const _rareIc = {};
function rareIconURL(k) {
  if (_rareIc[k]) return _rareIc[k];
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d"),
    D = RARE_DEF[k];
  g.translate(32, 40);
  g.fillStyle = "#3a241c";
  g.beginPath();
  g.ellipse(0, 6, 22, 9, 0, 0, 7);
  g.fill();
  for (const [bx, h, w, a] of [
    [-10, 26, 6, -0.35],
    [0, 34, 7, 0],
    [10, 24, 6, 0.35],
    [-4, 18, 5, -0.15],
    [6, 20, 5, 0.2],
  ]) {
    g.save();
    g.translate(bx, 4);
    g.rotate(a);
    g.shadowColor = D.glow;
    g.shadowBlur = 8;
    const cg = g.createLinearGradient(-w, 0, w, 0);
    cg.addColorStop(0, D.col[1]);
    cg.addColorStop(0.45, D.col[0]);
    cg.addColorStop(1, D.col[2]);
    g.fillStyle = cg;
    g.beginPath();
    g.moveTo(-w, 0);
    g.lineTo(-w * 0.8, -h * 0.75);
    g.lineTo(0, -h);
    g.lineTo(w * 0.8, -h * 0.75);
    g.lineTo(w, 0);
    g.closePath();
    g.fill();
    g.restore();
  }
  return (_rareIc[k] = c.toDataURL());
}
/* --- tarayıcı: yakındaki bilinmeyen sinyal --- */
let _scanT = 0;
function rareScan(dt) {
  if (scene !== "mars" || insideRocket || !rareNodes.length) return;
  let best = null,
    bd = 700 * desFx().scanMul;
  for (const n of rareNodes) {
    if (n.taken) continue;
    const d = Math.hypot(p.x - n.x, p.y - n.y);
    if (d < bd) {
      bd = d;
      best = n;
    }
  }
  if (!best) return;
  _scanT -= dt;
  if (_scanT <= 0) {
    _scanT = 0.5 + (bd / 700) * 2.2;
    tone(900 + (700 - bd) * 1.4, 0.05, "sine", 0.025);
    if (!best.pinged) {
      best.pinged = true;
      toast(
        T("📡 Tarayıcı: yakında ") +
          (game.rareKnown[best.kind]
            ? "<b>" + RARE_DEF[best.kind].name + "</b>"
            : T("<b>bilinmeyen bir mineral</b>")) +
          T(" sinyali — haritadaki işarete git"),
      );
    }
  }
}
function pickRare(n) {
  ensureRare();
  n.taken = true;
  game.rareTaken.push(n.id);
  if (n.kind === "ares") setTimeout(() => storyTrigger("ares"), 700);
  else if (!storySeen("firstRock") && !storySeen("ares")) {
    storyState().rk = n.kind;
    setTimeout(() => storyTrigger("firstRock"), 700);
  }
  game.rare[n.kind] = (game.rare[n.kind] || 0) + n.n;
  setTimeout(() => bumpQuest("rare"), 1200);
  const D = RARE_DEF[n.kind];
  sfx("star");
  tone(1320, 0.18, "sine", 0.06);
  tone(1760, 0.25, "sine", 0.05, 0, 0.12);
  updateInv();
  addFloat(n.x, n.y - 50, "+" + n.n + " " + (game.rareKnown[n.kind] ? D.name : T("Bilinmeyen taş")), D.glow);
  if (!game.rareKnown[n.kind]) {
    toast(
      T(
        "<b>Bilinmeyen taş</b> çantana alındı. Ne olduğunu ve tehlikeli olup olmadığını öğrenmek için roketteki <b>kargo terminalinden</b> analize gönder.",
      ),
    );
    commsObs("rare", { [n.kind]: n.n });
  } else {
    toast("💎 +" + n.n + " <b>" + D.name + T("</b> (toplam ") + game.rare[n.kind] + ")");
    commsObs("rare", { [n.kind]: n.n });
  }
}

/* ---------- taş analizi: kargoyla Dünya'ya gönder → laboratuvar raporu ---------- */
function sendRockSample(k) {
  ensureRare();
  const C = commState();
  C.flags.rock = C.flags.rock || {};
  if ((game.rare[k] || 0) < 1) {
    sfx("error");
    return;
  }
  if (C.flags.rock[k]) {
    sfx("error");
    toast(T("Bu taş zaten analizde"));
    return;
  }
  game.rare[k]--;
  C.flags.rock[k] = game.worldTime + DAY_SECONDS * 0.05;
  bumpQuest("rockSent");
  tone(523, 0.1, "triangle", 0.07);
  tone(659, 0.1, "triangle", 0.07, 0, 0.09);
  tone(880, 0.16, "triangle", 0.07, 0, 0.18);
  noiseBurst(0.35, 0.08, 1400, 0.12);
  toast(T("Taş numunesi <b>analiz için</b> Dünya'ya gönderildi. Laboratuvar sonucu birazdan gelen kutunda."));
  updateInv();
  if (marketOpen) openMarket();
}
function rockAnalysisMsg(k, wt) {
  const C = commState(),
    no = "GK-" + pad3(C.seq.msg++),
    D = RARE_DEF[k],
    M = MINERAL[k];
  const tot = M.comp.reduce((a, c) => a + c[1], 0);
  const bar = `<div class="mn-bar">${M.comp.map((c) => `<span style="width:${((c[1] / tot) * 100).toFixed(1)}%;background:${c[2]}"></span>`).join("")}</div>
    <div class="mn-leg">${M.comp.map((c) => `<span><i style="background:${c[2]}"></i>${c[0]} %${fmtN(c[1], 1)}</span>`).join("")}</div>`;
  const hzL = { ok: T("GÜVENLİ"), wa: T("DİKKAT"), dg: T("TEHLİKELİ") }[M.hz];
  const body = Tf(
    `<p>Sayın Komutan,</p>
  <p><b>Analiz için</b> gönderdiğiniz bilinmeyen taş numunesi laboratuvarımızda incelendi. Taşın adı ve özellikleri aşağıdadır.</p>
  <div class="ltr-annex"><div class="ah">NUMUNE ANALİZ RAPORU · {0}</div>
  <table class="mn-tbl">
    <tr><td>Tanım</td><td><b>{1}</b></td></tr>
    <tr><td>Mineral sınıfı</td><td>{2}</td></tr>
    <tr><td>Kimyasal formül</td><td><b>{3}</b></td></tr>
    <tr><td>Sertlik (Mohs)</td><td>{4}</td></tr>
    <tr><td>Yoğunluk</td><td>{5}</td></tr>
    <tr><td>Radyoaktivite</td><td>{6}</td></tr></table>
  <b style="font-size:12px">Bileşim (ağırlıkça)</b>{7}
  <div class="an">Yöntem: X-ışını kırınımı (XRD) · X-ışını floresansı (XRF) · gama spektrometrisi</div></div>
  <div class="mn-hz {8}"><b>{9}</b><span>{10}</span></div>
  <h4>Bilimsel değerlendirme</h4><p>{11}</p>
  <p><b>Oyundaki kullanımı:</b> {12}.</p>`,
    [
      escH(D.name).toLocaleUpperCase(LOCALE),
      D.name,
      M.cls,
      M.f,
      M.mohs,
      M.rho,
      M.rad,
      bar,
      M.hz,
      hzL,
      M.hzT,
      M.sci,
      D.use,
    ],
  );
  return {
    id: no,
    t: wt,
    kind: "rock",
    rk: k,
    subject: T("Numune analizi · ") + D.name,
    from: SIG.sci[0],
    read: false,
    html: letter({
      no,
      wt,
      subject: T("Numune analizi · ") + D.name,
      body,
      signers: ["sci"],
      cc: ["med", "fd"],
    }),
  };
}
/* --- yer şekilleri: kum tepesi alanları, bazalt düzlükleri, kırağı, kuru dere yatakları --- */
let landmarks = null;
function genLandmarks() {
  const R = rng(9001),
    L = [],
    B = CFG.worldHalf - 300;
  const add = (type, n, r0, r1) => {
    let m = 0,
      g = 0;
    while (m < n && g++ < 2000) {
      const x = (R() * 2 - 1) * B,
        y = (R() * 2 - 1) * B,
        r = r0 + R() * (r1 - r0);
      if (Math.hypot(x - ROCKET.x, y - ROCKET.y) < r + 380) continue;
      if (L.some((o) => Math.hypot(o.x - x, o.y - y) < o.r + r)) continue;
      L.push({ type, x, y, r, seed: R() * 1000, ang: R() * 3.14 });
      m++;
    }
  };
  add("dunes", 42, 280, 560);
  add("basalt", 30, 220, 440);
  add("frost", 21, 140, 280);
  add("river", 18, 380, 680);
  add("layers", 24, 200, 380);
  return L;
}
function lmCanvas(l) {
  if (l.c) return l.c;
  const S = Math.ceil(l.r * 2 + 40),
    c = document.createElement("canvas");
  c.width = c.height = S;
  const g = c.getContext("2d"),
    R = rng(Math.floor(l.seed) + 1),
    cx = S / 2,
    cy = S / 2;
  g.save();
  g.translate(cx, cy);
  g.rotate(l.ang);
  const mask = (a) => {
    const gr = g.createRadialGradient(0, 0, l.r * 0.2, 0, 0, l.r);
    gr.addColorStop(0, "rgba(0,0,0," + a + ")");
    gr.addColorStop(1, "rgba(0,0,0,0)");
    return gr;
  };
  if (l.type === "dunes") {
    for (let i = -l.r; i < l.r; i += 14 + R() * 6) {
      const ph = R() * 6;
      g.beginPath();
      for (let x = -l.r; x <= l.r; x += 10) {
        const y = i + Math.sin(x * 0.012 + ph) * 18 + Math.sin(x * 0.035) * 5;
        x === -l.r ? g.moveTo(x, y) : g.lineTo(x, y);
      }
      g.strokeStyle = "rgba(255,214,170,.20)";
      g.lineWidth = 3;
      g.stroke();
      g.translate(0, 4);
      g.strokeStyle = "rgba(70,20,6,.20)";
      g.lineWidth = 3;
      g.stroke();
      g.translate(0, -4);
    }
  } else if (l.type === "basalt") {
    const s1 = R() * 6,
      s2 = R() * 6;
    g.filter = "blur(5px)";
    g.beginPath();
    for (let i = 0; i < 64; i++) {
      const a = (i / 64) * 6.283,
        r = l.r * (0.74 + 0.13 * Math.sin(3 * a + s1) + 0.08 * Math.sin(5 * a + s2));
      g.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.75);
    }
    g.closePath();
    g.fillStyle = "rgba(40,14,8,.32)";
    g.fill();
    g.filter = "none";
    g.strokeStyle = "rgba(20,6,2,.4)";
    g.lineWidth = 1.5;
    for (let i = 0; i < 40; i++) {
      let x = (R() - 0.5) * l.r * 1.2,
        y = (R() - 0.5) * l.r * 0.9;
      g.beginPath();
      g.moveTo(x, y);
      for (let k = 0; k < 4; k++) {
        x += (R() - 0.5) * 40;
        y += (R() - 0.5) * 30;
        g.lineTo(x, y);
      }
      g.stroke();
    }
    for (let i = 0; i < 60; i++) {
      g.fillStyle = "rgba(15,5,2,.5)";
      g.beginPath();
      g.arc((R() - 0.5) * l.r * 1.3, (R() - 0.5) * l.r * 0.9, 1 + R() * 3, 0, 7);
      g.fill();
    }
  } else if (l.type === "frost") {
    const s1 = R() * 6,
      s2 = R() * 6;
    g.filter = "blur(6px)";
    g.beginPath();
    for (let i = 0; i < 64; i++) {
      const a = (i / 64) * 6.283,
        r = l.r * (0.72 + 0.15 * Math.sin(3 * a + s1) + 0.08 * Math.sin(7 * a + s2));
      g.lineTo(Math.cos(a) * r, Math.sin(a) * r * 0.7);
    }
    g.closePath();
    const fg = g.createRadialGradient(0, 0, 0, 0, 0, l.r);
    fg.addColorStop(0, "rgba(230,240,255,.42)");
    fg.addColorStop(0.7, "rgba(190,210,240,.22)");
    fg.addColorStop(1, "rgba(190,210,240,0)");
    g.fillStyle = fg;
    g.fill();
    g.filter = "none";
    g.strokeStyle = "rgba(255,255,255,.3)";
    g.lineWidth = 1;
    for (let i = 0; i < 26; i++) {
      const x = (R() - 0.5) * l.r,
        y = (R() - 0.5) * l.r * 0.6,
        s = 4 + R() * 8;
      g.beginPath();
      g.moveTo(x - s, y);
      g.lineTo(x + s, y);
      g.moveTo(x, y - s * 0.6);
      g.lineTo(x, y + s * 0.6);
      g.stroke();
    }
  } else if (l.type === "river") {
    const pts = [];
    let x = -l.r,
      y = (R() - 0.5) * l.r * 0.4;
    for (let i = 0; i <= 20; i++) {
      pts.push([x, y]);
      x += (l.r * 2) / 20;
      y += (R() - 0.5) * 50;
    }
    const path = () => {
      g.beginPath();
      pts.forEach(([a, b], i) => (i ? g.lineTo(a, b) : g.moveTo(a, b)));
    };
    g.lineCap = "round";
    g.lineJoin = "round";
    path();
    g.strokeStyle = "rgba(255,206,160,.16)";
    g.lineWidth = 90;
    g.stroke();
    path();
    g.strokeStyle = "rgba(60,18,6,.28)";
    g.lineWidth = 58;
    g.stroke();
    path();
    g.strokeStyle = "rgba(30,8,2,.25)";
    g.lineWidth = 26;
    g.stroke();
    for (let i = 0; i < 50; i++) {
      const [a, b] = pts[Math.floor(R() * pts.length)];
      g.fillStyle = "rgba(200,150,110,.35)";
      g.beginPath();
      g.arc(a + (R() - 0.5) * 40, b + (R() - 0.5) * 20, 1.5 + R() * 3, 0, 7);
      g.fill();
    }
  } else if (l.type === "layers") {
    for (let i = 0; i < 9; i++) {
      const rr = l.r * (1 - i * 0.1);
      g.beginPath();
      for (let k = 0; k <= 40; k++) {
        const a = (k / 40) * 6.283,
          w = rr * (1 + 0.08 * Math.sin(a * 3 + i));
        g.lineTo(Math.cos(a) * w, Math.sin(a) * w * 0.6);
      }
      g.closePath();
      g.fillStyle = i % 2 ? "rgba(255,200,150,.07)" : "rgba(70,20,6,.09)";
      g.fill();
    }
  }
  g.restore();
  g.globalCompositeOperation = "destination-in";
  g.fillStyle = mask(1);
  g.translate(cx, cy);
  g.fillRect(-cx, -cy, S, S);
  return (l.c = c);
}
function drawLandmarks(vis) {
  if (scene !== "mars") return;
  if (!landmarks) landmarks = genLandmarks();
  for (const l of landmarks) {
    if (Math.abs(l.x - p.x) > l.r + 1400 || Math.abs(l.y - p.y) > l.r + 1100) continue;
    const c = lmCanvas(l);
    ctx.drawImage(c, l.x - c.width / 2, l.y - c.height / 2);
  }
}
/* --- toz şeytanları (dolaşan kum hortumları) --- */
const devils = [];
function updateAmbient(dt) {
  if (scene !== "mars" || !game) {
    devils.length = 0;
    return;
  }
  while (devils.length < 4) {
    const a = Math.random() * 6.283,
      d = 900 + Math.random() * 900;
    devils.push({
      x: p.x + Math.cos(a) * d,
      y: p.y + Math.sin(a) * d,
      vx: (Math.random() - 0.5) * 60,
      vy: (Math.random() - 0.5) * 40,
      ph: Math.random() * 6,
      life: 40 + Math.random() * 60,
    });
  }
  for (let i = devils.length - 1; i >= 0; i--) {
    const v = devils[i];
    v.life -= dt;
    v.ph += dt * 6;
    v.vx += (Math.random() - 0.5) * 30 * dt;
    v.vy += (Math.random() - 0.5) * 30 * dt;
    v.vx = Math.max(-90, Math.min(90, v.vx));
    v.vy = Math.max(-70, Math.min(70, v.vy));
    v.x += v.vx * dt;
    v.y += v.vy * dt;
    const d = Math.hypot(p.x - v.x, p.y - v.y);
    if (d > 2400 || v.life <= 0) {
      devils.splice(i, 1);
      continue;
    }
    if (!insideRocket && d < 90) {
      const k = (1 - d / 90) * SUIT_STORM() * dt;
      p.x += ((p.y - v.y) / (d || 1)) * 160 * k + ((p.x - v.x) / (d || 1)) * 90 * k;
      p.y += (-(p.x - v.x) / (d || 1)) * 160 * k + ((p.y - v.y) / (d || 1)) * 90 * k;
      game.o2 = Math.max(0, game.o2 - 1.2 * k);
      shake = Math.max(shake, 3);
      if (!v.hit) {
        v.hit = true;
        toast(T("🌀 Toz şeytanına yakalandın — uzaklaş!"));
        sfx("hurt");
      }
    }
  }
}
function SUIT_STORM() {
  return typeof suitSt === "function" ? suitSt().storm : 1;
}
function drawDevils(t) {
  if (scene !== "mars") return;
  const sp = puffSprite([196, 132, 92]);
  for (const v of devils) {
    if (Math.abs(v.x - p.x) > 1400 || Math.abs(v.y - p.y) > 1000) continue;
    const fade = Math.min(1, v.life / 4);
    ctx.save();
    ctx.translate(v.x, v.y);
    ctx.globalAlpha = 0.32 * fade;
    ctx.drawImage(sp, -70, -22, 140, 44);
    for (let i = 0; i < 22; i++) {
      const f = i / 21,
        y = -f * 190,
        r = 12 + f * f * 55,
        sw = Math.sin(v.ph + f * 5) * 10 * f;
      ctx.globalAlpha = (0.16 - f * 0.08) * fade;
      ctx.drawImage(sp, sw - r, y - r * 0.35, r * 2, r * 0.7);
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }
}
/* --- ekran atmosferi (sakin havada da canlı Mars) --- */
const AMB = { wisps: null, motes: null };
function drawAtmosphere() {
  if (scene !== "mars" || settings.atmos === false) return;
  const t = performance.now() / 1000,
    calm = 1 - Math.min(1, stormFx.I * 1.5);
  if (calm <= 0) return;
  // ufuk pusu (üst kenar)
  let g = ctx.createLinearGradient(0, 0, 0, H * 0.45);
  g.addColorStop(0, "rgba(255,170,120," + 0.16 * calm + ")");
  g.addColorStop(1, "rgba(255,170,120,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, W, H * 0.45);
  // bulut/toz gölgeleri yerde kayar
  const sp = puffSprite([40, 12, 6]);
  for (let i = 0; i < 4; i++) {
    const s = Math.max(W, H) * (0.55 + i * 0.12),
      x = (((i * 0.37 + t * 0.006) % 1.6) - 0.3) * W - ((p.x * 0.02) % W),
      y = ((i * 0.29) % 1) * H * 0.9 - ((p.y * 0.02) % H) + Math.sin(t * 0.05 + i) * 40;
    ctx.globalAlpha = 0.1 * calm;
    ctx.drawImage(sp, x - s / 2, y - s / 3, s, s * 0.66);
  }
  ctx.globalAlpha = 1;
  // süzülen toz perdeleri
  const dw = puffSprite([222, 160, 118]);
  if (!AMB.wisps) {
    AMB.wisps = [];
    for (let i = 0; i < 12; i++)
      AMB.wisps.push({
        x: Math.random(),
        y: Math.random(),
        s: Math.random(),
        v: 0.008 + Math.random() * 0.014,
      });
  }
  for (const w of AMB.wisps) {
    const x = (((w.x + t * w.v) % 1.3) - 0.15) * W - ((((p.x * 0.15) % W) + W) % W) * 0,
      y = w.y * H + Math.sin(t * 0.4 + w.s * 9) * 14,
      sx = 280 + w.s * 420,
      sy = sx * 0.18;
    ctx.globalAlpha = (0.045 + w.s * 0.05) * calm;
    ctx.drawImage(dw, x - sx / 2, y - sy / 2, sx, sy);
  }
  ctx.globalAlpha = 1;
  // zerreler
  for (let i = 0; i < 60; i++) {
    const h = (i * 0.618) % 1,
      x = (((h * W + t * (10 + h * 26) - p.x * 0.3 * (0.3 + h)) % W) + W) % W,
      y = (((i * 0.377) % 1) * H + Math.sin(t * 0.7 + i) * 8 - ((p.y * 0.3 * (0.3 + h)) % H) + H) % H,
      r = 0.6 + h * h * 2.2;
    ctx.fillStyle = "rgba(255,225,190," + (0.1 + h * 0.25) * calm + ")";
    ctx.fillRect(x, y, r, r);
  }
  // sıcak hava titreşimi hissi: hafif sıcak ton nabzı
  ctx.fillStyle = "rgba(255,140,80," + 0.025 * calm * (0.5 + 0.5 * Math.sin(t * 0.3)) + ")";
  ctx.fillRect(0, 0, W, H);
}

/* ============== SAHNE GİRİŞİ / HUD ============== */
function enterPlanet(k, fromLoad, silent) {
  scene = k;
  mode = "play";
  paused = false;
  rocketOpen = false;
  marketOpen = false;
  ev.meteors = [];
  if (scene === "earth" || scene === START_PLANET) {
    ev.type = null;
  }
  warp = silent ? 0 : 1;
  if (!fromLoad) {
    p.x = 170;
    p.y = 120;
  }
  game.planet = k;
  if (!game.visited.includes(k)) game.visited.push(k);
  stones = spawnStones(k);
  farmArr();
  spawnRare(k);
  showPlayUI();
  if (!fromLoad && !silent) {
    sfx("travel");
    toast(PLANETS[k].name + T("'e varıldı"));
  }
  if (!fromLoad && !silent) bumpQuest("traveled");
}
function showPlayUI() {
  $("menuScreen").classList.add("hidden");
  $("hud").classList.remove("hidden");
  $("inv").classList.remove("hidden");
  $("stats").classList.remove("hidden");
  updateHud(true);
  updateInv();
  updateStats();
  updateQuest();
  focusGame();
}
let hudSec = -1;
function updateHud(force) {
  const sec = Math.floor((game.worldTime || 0) * 2);
  if (!force && sec === hudSec) return;
  hudSec = sec;
  const wt = Math.max(0, Number(game.worldTime) || 0),
    day = Math.floor(wt / DAY_SECONDS) + 1,
    inDay = wt % DAY_SECONDS,
    frac = inDay / DAY_SECONDS;
  const mh = (6 + frac * 24) % 24,
    hh = Math.floor(mh),
    mm = Math.floor((mh - hh) * 60),
    isDay = hh >= 6 && hh < 18;
  const clock = String(hh).padStart(2, "0") + ":" + String(mm).padStart(2, "0");
  // olay çipleri
  const S = scene === "earth" ? { phase: "none" } : stormInfo();
  let ev = "";
  if (scene !== "earth") {
    if (S.phase === "active") ev += T('<span class="st on">🌪 FIRTINA</span>');
    else if (S.phase === "warn") ev += '<span class="st on">🌪 ' + mmss(S.tTo) + "</span>";
    else {
      const ns = nextStormIn();
      if (isFinite(ns)) {
        const d2 = Math.floor((wt + ns) / DAY_SECONDS) + 1;
        ev += T('<span class="st" title="Sonraki kum fırtınası">🌪 Gün ') + d2 + "</span>";
      }
    }
    if (game.radiationActive) ev += T('<span class="rd on">☢ AKTİF</span>');
    else {
      const rd = Math.ceil(day / 3) * 3 === day ? day + 3 : Math.ceil(day / 3) * 3;
      ev += T('<span class="rd" title="Sonraki radyasyon dalgası">☢ Gün ') + rd + "</span>";
    }
  }
  // gün çubuğunda olay işaretleri
  let marks = "";
  if (scene !== "earth" && isStormDay(day))
    marks += '<i style="left:' + (STORM_START / DAY_SECONDS) * 100 + '%"></i>';
  if (scene !== "earth" && day % 3 === 0) marks += '<i class="rad" style="left:0%"></i>';
  $("hud").innerHTML = Tf(
    `<div class="hd-top"><span class="hd-planet" style="{0}"></span>
      <div class="hd-tt"><b>{1}</b><span>GÜN {2}</span></div>
      <div class="hd-clock">{3} {4}</div></div>
    <div class="hd-bar">{5}<em style="left:{6}%"></em></div>
    <div class="hd-foot"><span>⏳ {7}</span><span class="hd-ev">{8}</span></div>`,
    [
      scene === "earth"
        ? "background:radial-gradient(circle at 34% 30%,#d6f0ff 0,#3b82f6 30%,#1e3a8a 70%,#0b1638 100%)"
        : "",
      PLANETS[scene].name.toLocaleUpperCase("tr-TR"),
      day,
      isDay ? "☀" : "☾",
      clock,
      marks,
      (frac * 100).toFixed(2),
      mmss(DAY_SECONDS - inDay),
      ev,
    ],
  );
}
function setStat(id, val) {
  $(id + "Fill").style.width = Math.max(0, val) + "%";
  $(id + "Val").textContent = Math.max(0, Math.round(val));
  $(id + "Stat").classList.toggle("low", val < 25);
}
/* kendi bilgilerimiz: vücut ısısı, nabız, ortam sıcaklığı, ortam radyasyonu (hafif simülasyon) */
const BIO = { temp: 36.8, pulse: 72, env: -58, rad: 0.45, ex: 0, acc: 0 };
function updateBio(dt) {
  if (!game || scene === "earth") return;
  const out = !insideRocket,
    ra = !!game.radiationActive && out,
    lowO2 = (game.o2 == null ? 100 : game.o2) < 25,
    lowHp = game.hp < 30;
  const k = 1 - Math.exp(-dt * 0.6);
  const inDay = ((game.worldTime % DAY_SECONDS) + DAY_SECONDS) % DAY_SECONDS,
    hr = (6 + (inDay / DAY_SECONDS) * 24) % 24;
  const sun = Math.max(0, Math.sin((Math.PI * (hr - 6)) / 12));
  const envT = out ? -78 + 56 * sun + (stormFx.I > 0.25 ? 6 : 0) : 21;
  const radT = out ? (ra ? 8.6 : 0.42 + 0.08 * Math.sin(game.worldTime * 0.05)) : 0.08;
  const tempT =
    36.6 + BIO.ex * 0.7 + (lowHp ? 0.5 : 0) + (out && sun < 0.1 ? -0.15 : 0) + (game.sleeping ? -0.3 : 0);
  const pulseT =
    (game.sleeping ? 56 : 66) +
    BIO.ex * 48 +
    (lowO2 ? 28 : 0) +
    (lowHp ? 16 : 0) +
    (ra ? 12 : 0) +
    (stormFx.I > 0.25 && out ? 8 : 0);
  BIO.temp += (tempT - BIO.temp) * k * 0.6;
  BIO.pulse += (pulseT - BIO.pulse) * k * 1.6;
  BIO.env += (envT - BIO.env) * k * 1.4;
  BIO.rad += (radT - BIO.rad) * Math.min(1, dt * 2);
  BIO.acc += dt;
  if (BIO.acc < 0.25) return;
  BIO.acc = 0;
  const set = (id, v, cls) => {
    const e = $(id);
    e.querySelector("b").innerHTML = v;
    e.classList.toggle("warn", cls === "warn");
    e.classList.toggle("crit", cls === "crit");
  };
  set("bioTemp", fmtN(BIO.temp, 1) + "<em>°C</em>", BIO.temp > 37.6 ? "warn" : BIO.temp < 36 ? "warn" : "");
  const bpm = Math.round(BIO.pulse + Math.sin(performance.now() / 700) * 1.5);
  set("bioPulse", bpm + "<em>bpm</em>", bpm > 120 ? "crit" : bpm > 100 ? "warn" : "");
  $("bioPulse").style.setProperty("--beat", (60 / Math.max(40, bpm)).toFixed(2) + "s");
  $("bioEnvL").textContent = out ? T("DIŞARI") : T("KABİN");
  set("bioEnv", Math.round(BIO.env) + "<em>°C</em>", "");
  set("bioRad", fmtN(BIO.rad, 2) + "<em>µSv/h</em>", BIO.rad > 4 ? "crit" : BIO.rad > 1 ? "warn" : "");
}
function updateStats() {
  setStat("oxy", game.o2 == null ? 100 : game.o2);
  setStat("hp", game.hp);
  setStat("hunger", game.hunger);
  setStat("thirst", game.thirst);
}
/* --- hotbar: alttaki 1-6 slot seçimi --- */
const SLOT_KEYS = [
  "kit",
  "pick",
  "radmeter",
  "water",
  "potato",
  "medkit",
  "seed",
  "tuber",
  "ceramic",
  "stone",
  "star",
  "rotten",
];
const SLOT_NAMES = [
  T("Çapa"),
  T("Jeolog kazması"),
  T("DZ-7 radyasyon ölçer"),
  T("💧 Su"),
  T("🥔 Patates"),
  T("💊 Medikit"),
  T("🌱 Tohum"),
  T("🥔 Tohumluk patates"),
  T("🛡️ Seramik kalkan"),
  T("🔩 Metal numune"),
  T("⭐ Yıldız kırıntısı (2 numune)"),
  T("Çürük patates (numune)"),
];
const SLOT_GROUP = {
  kit: 0,
  pick: 0,
  radmeter: 0,
  water: 1,
  potato: 1,
  medkit: 1,
  seed: 1,
  tuber: 1,
  ceramic: 1,
  stone: 2,
  star: 2,
  rotten: 2,
};
let selSlot = 0;
function useSelected() {
  if (
    mode !== "play" ||
    paused ||
    rocketOpen ||
    marketOpen ||
    repairOpen ||
    capOpen ||
    commOpen ||
    upgOpen ||
    o2Fill ||
    bookOpen ||
    !game
  )
    return;
  const order = game.slotOrder || [];
  const k = order[selSlot];
  if (!k) {
    sfx("error");
    toast(T("Bu numarada henüz eşya yok — önce topla"));
    return;
  }
  if (k === "kit") {
    sfx("click");
    toast(T("Çapa elinde — yakındaki yere <b>sol tıkla</b>, toprağı kaz"));
    return;
  }
  const n = game.inventory[k] || 0;
  const nm = SLOT_NAMES[SLOT_KEYS.indexOf(k)] || k;
  if (n <= 0) {
    sfx("error");
    toast(T("Bu slot boş — (") + (selSlot + 1) + ") " + nm);
    return;
  }
  if (k === "water") {
    if (game.thirst >= 100) {
      sfx("full");
      toast(T("Susuzluğun zaten dolu"));
      return;
    }
    game.inventory.water--;
    game.thirst = Math.min(100, game.thirst + CFG.drinkThirst);
    startAct("drink", 1.8);
    burst(p.x, p.y - 30, 10, "#38bdf8", { sp: 70, life: 0.5, size: 3 });
    sfx("drink");
    toast(T("Su içildi (+") + CFG.drinkThirst + T(" susuzluk)"));
    updateInv();
    updateStats();
    bumpQuest("drunk");
    return;
  }
  if (k === "potato") {
    if (game.hunger >= 100) {
      sfx("full");
      toast(T("Açlığın zaten dolu"));
      return;
    }
    game.inventory.potato--;
    game.hunger = Math.min(100, game.hunger + CFG.eatHunger);
    startAct("eat", 2.0);
    sfx("eat");
    toast(T("Patates yendi (+") + CFG.eatHunger + T(" açlık)"));
    updateInv();
    updateStats();
    return;
  }
  if (k === "medkit") {
    pressG();
    return;
  }
  if (k === "radmeter") {
    if (insideRocket) {
      sfx("click");
      toast(T("Radyasyon ölçer dışarıda, toprak üzerinde kullanılır"));
      return;
    }
    startMeasure(p.x + p.dir * 80, p.y + 26);
    return;
  }
  if (k === "rotten") {
    sfx("error");
    toast(T("Çürük patates yenmez — roketteki kargo terminalinden Dünya'ya gönder"));
    return;
  }
  if (isSeedKey(k)) {
    const pl = nearestPlot();
    if (!pl) {
      sfx("error");
      toast(T("Tarla parselinin yakınına git"));
      return;
    }
    const fa = farmArr(),
      g = fa[pl.i];
    if (g && g.g > 0) {
      sfx("error");
      toast(T("Parsel dolu — önce hasat et (F)"));
      return;
    }
    if (g && g.cov && g.shut) {
      sfx("error");
      toast(T("🔒 Kalkan kapalı — tohum ekmek için önce <b>Q</b> ile aç"));
      return;
    }
    game.inventory[k]--;
    Object.assign(fa[pl.i], { g: 0.1, wet: 0, idle: 0, fill: 0 });
    updateInv();
    burst(pl.pl.x, pl.pl.y, 14, "#8a6a3c", { sp: 90, life: 0.6, size: 4 });
    addFloat(pl.pl.x, pl.pl.y - 30, T("🌱 Ekildi"), "#7fe0ff");
    sfx("plant");
    bumpQuest("planted");
    return;
  }
  if (k === "ceramic") {
    if (insideRocket) {
      sfx("click");
      toast(T("Seramik kalkan dışarıda, ekili parselin üstüne takılır"));
      return;
    }
    const pl = nearestPlot();
    if (!pl) {
      sfx("error");
      toast(T("Bir parselin yakınına git"));
      return;
    }
    coverPlot(farmArr()[pl.i]);
    return;
  }
  if (k === "stone" || k === "star") {
    if (nearRocket() || (insideRocket && nearStation() && nearStation().key === "trade")) {
      depositSamples();
      return;
    }
    sfx("click");
    toast(T("Numuneler roketin kargo bölmesine yüklenir — rokete götür (F)"));
    return;
  }
}
function slotCount(k) {
  return k === "kit" ? (game.kitCarried ? 1 : 0) : game.inventory[k] || 0;
}
function updateInv() {
  if (!game) return;
  if (!Array.isArray(game.slotOrder)) game.slotOrder = [];
  const prevKey = game.slotOrder[selSlot];
  // düzenli yerleşim: aletler | tüketim | numuneler (her eşyanın sabit yeri var)
  game.slotOrder = SLOT_KEYS.filter((k) => slotCount(k) > 0);
  if (prevKey && game.slotOrder.includes(prevKey)) selSlot = game.slotOrder.indexOf(prevKey);
  else if (prevKey) selSlot = -1; // elindeki bitti → eller boş
  if (selSlot >= game.slotOrder.length) selSlot = -1;
  const nameOf = (k) => SLOT_NAMES[SLOT_KEYS.indexOf(k)] || k;
  let h = `<div class="slot bookslot" data-book="1" title="Rehber kitap (R)"><span class="num">R</span><img class="ic" src="${itemIconURL("book")}" alt=""></div><div class="slot-sep"></div>`;
  game.slotOrder.forEach((key, i) => {
    const n = slotCount(key);
    if (i > 0 && SLOT_GROUP[key] !== SLOT_GROUP[game.slotOrder[i - 1]]) h += `<div class="slot-sep"></div>`;
    h += `<div class="slot on${i === selSlot ? " sel" : ""}" data-i="${i}" title="${i + 1} · ${nameOf(key)}">
      <span class="num">${i + 1}</span><img class="ic" src="${itemIconURL(key)}" alt="">${key !== "kit" && n > 0 ? `<b>${n}</b>` : ""}</div>`;
  });
  $("inv").innerHTML = h;
}
function equip(k) {
  const i = (game.slotOrder || []).indexOf(k);
  if (i < 0) return false;
  selSlot = i;
  updateInv();
  sfx("click");
  return true;
}
$("inv").addEventListener("click", (e) => {
  const s = e.target.closest(".slot");
  if (!s || !game) return;
  if (s.dataset.book) {
    openBook();
    return;
  }
  const i = +s.dataset.i;
  if (i === selSlot) useSelected();
  else {
    selSlot = i;
    updateInv();
    const k = (game.slotOrder || [])[i];
    if (k) {
      sfx("click");
      toast(T("Slot ") + (i + 1) + ": " + (SLOT_NAMES[SLOT_KEYS.indexOf(k)] || k));
    } else sfx("error");
  }
});

/* ============== GÖREV / HEDEF UI ============== */
const QUEST_REWARD = (QUESTS_NOOP = null); // görevler artık ödül vermez
function bumpQuest(key, amount) {
  if (!game || !game.qstats) return;
  game.qstats[key] = (game.qstats[key] || 0) + (amount == null ? 1 : amount);
  if (key === "planted") commsObs("agri", { p: 1 });
  else if (key === "harvested") commsObs("agri", { h: 1 });
  else if (key === "repaired") commsObs("engine_fix", {});
  else if (key === "loaded") commsObs("cargo", { pts: amount || 1, tot: game.cargo || 0 });
  const q0 = game.quest;
  checkQuest();
  if (game.quest === q0) updateQuest(); // kısmi ilerleme (1/5, 2/5…) kartta hemen görünsün
}
function checkQuest() {
  if (!game) return;
  if (game.story && game.story.goal) return; // hikâye görevi sürerken normal görev bekler
  let guard = 0;
  while (game.quest < QUESTS.length && guard++ < 25) {
    const qi = game.quest,
      q = QUESTS[qi];
    if ((game.qstats[q.k] || 0) < q.n) break;
    game.quest++;
    /* Dünya: görevlerin sonuna gelince açılır
       (son "Kaşif" görevi roket yolculuğu sırasında tamamlanır) */
    const earthOpen = game.quest >= QUESTS.length - 1;
    game.progIdx = earthOpen ? PROG_ORDER.length - 1 : 0;
    updateInv();
    updateQuest(true);
    showQuestDone(q, QUESTS[game.quest]);
    if (earthOpen) setTimeout(() => storyTrigger("home"), 3800);
    if (earthOpen)
      setTimeout(() => {
        sfx("star");
        toast(T("🔓 Dünya rotası açıldı! Komuta güvertesindeki navigasyondan eve dön"));
      }, 1800);
  }
}
/* görev bitti: ekranın ortasında kutlama kartı + fanfar + konfeti */
function showQuestDone(q, next) {
  const el = $("qDone");
  clearTimeout(showQuestDone._t);
  clearTimeout(showQuestDone._t2);
  el.className = "";
  el.innerHTML = Tf(
    `<div class="qd-ck">✓</div><div class="qd-k">GÖREV TAMAMLANDI</div><div class="qd-t">{0} {1}</div>
{2}`,
    [
      q.ic || "",
      q.t,
      next
        ? Tf(`<div class="qd-n">Sıradaki görev: <b>{0} {1}</b></div>`, [next.ic || "", next.t])
        : Tf(`<div class="qd-n"><b>Tüm görevler bitti!</b></div>`, []),
    ],
  );
  void el.offsetWidth;
  [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.16, "triangle", 0.2, null, i * 0.11));
  const cx = insideRocket ? null : p.x,
    cy = insideRocket ? null : p.y;
  if (cx != null) {
    burst(cx, cy - 40, 26, "#4ade80", { sp: 220, life: 1, size: 5, up: 120 });
    burst(cx, cy - 40, 18, "#ffd34d", { sp: 200, life: 1.1, size: 4, up: 140 });
  }
  showQuestDone._t = setTimeout(() => {
    el.classList.add("out");
  }, 3000);
  showQuestDone._t2 = setTimeout(() => {
    el.className = "hidden";
  }, 3500);
}
/* ---------- görev kartı görseli: gidilecek/toplanacak cismin oyundaki gerçek görüntüsü ---------- */
const _qIcon = {};
function bakeIcon(key, fn) {
  if (_qIcon[key]) return _qIcon[key];
  const cv = document.createElement("canvas");
  cv.width = cv.height = 96;
  const g = cv.getContext("2d");
  const old = ctx;
  ctx = g;
  try {
    g.translate(48, 52);
    fn(g);
  } finally {
    ctx = old;
  }
  return (_qIcon[key] = cv.toDataURL());
}
const QUEST_ART = {
  covered: "ceramic",
  domeCycle: "ceramic",
  shieldSaved: "ceramic",
  kit: "kit",
  mined: "stone",
  planted: "seed",
  drunk: "water",
  harvested: "potato",
  cleanHarvest: "potato",
  rotSample: "rotten",
  measured: "radmeter",
  loaded: "star",
};
function questIconURL(q) {
  if (QUEST_ART[q.k]) return itemIconURL(QUEST_ART[q.k]);
  if (q.k === "gold")
    return bakeIcon("gold", () => {
      ctx.scale(1.6, 1.6);
      drawGoldNugget(0, 0, 0, 3);
    });
  if (q.k === "rare" || q.k === "rockSent")
    return bakeIcon("rare", (g) => {
      g.translate(0, 8);
      g.scale(0.95, 0.95);
      drawRareBody(g, { kind: "titan", seed: 3.7 }, 1.2, { icon: true });
    });
  if (q.k === "suit" || q.k === "radSuit")
    return bakeIcon("suit", () => {
      const pd = p.dir,
        ps = p.sx,
        py = p.sy,
        pw = p.walk;
      p.dir = 1;
      p.sx = p.sy = 1;
      p.walk = 0;
      ctx.translate(0, -2);
      ctx.scale(0.7, 0.7);
      astronaut(0, -10, false, null, 0);
      p.dir = pd;
      p.sx = ps;
      p.sy = py;
      p.walk = pw;
    });
  return null;
}
function setQuestIcon(el, q) {
  const u = questIconURL(q);
  if (u) el.innerHTML = '<img src="' + u + '" alt="">';
  else el.textContent = q.ic || "📋";
}
function updateQuest(pop) {
  const el = $("quest");
  if (!game || mode !== "play" || game.quest >= QUESTS.length) {
    el.classList.add("hidden");
    return;
  }
  el.classList.remove("hidden");
  const q = QUESTS[game.quest],
    cur = Math.min(q.n, game.qstats[q.k] || 0);
  $("qTitle").textContent = q.t;
  setQuestIcon($("qIc"), q);
  $("qStep").textContent = T("GÖREV ") + (game.quest + 1) + "/" + QUESTS.length;
  $("qDesc").innerHTML = q.d + " <b style='color:#5ad1ff'>(" + cur + "/" + q.n + ")</b>";
  $("qFill").style.width = (cur / q.n) * 100 + "%";
  $("qReward").textContent = "";
  let how = q.how || "";
  if (q.k === "repaired" && game.repair.state === "ok" && !game.stormBroke)
    how = Tf(
      `⏳ Fırtına bekleniyor: <b>Gün 2</b>, saat {0} civarı. O zamana kadar numune topla, tarım yap.`,
      [marsClock(STORM_START)],
    );
  $("qHow").innerHTML = "💡 " + how;
  _qsLast = "";
  refreshQuestSteps(true);
  if (pop) {
    el.classList.remove("done");
    void el.offsetWidth;
    el.classList.add("done");
  }
}
/* ============== ETKİLEŞİM ============== */
const nearRocket = () => Math.hypot(p.x - ROCKET.x, p.y - ROCKET.y) <= CFG.interactRange;
function nearestPickup() {
  let b = null,
    bd = CFG.pickupRange;
  for (const s of stones) {
    if (s.taken) continue;
    const d = Math.hypot(p.x - s.x, p.y - s.y);
    if (d < bd) {
      bd = d;
      b = { kind: "stone", o: s };
    }
  }
  for (const d of drops) {
    if (d.taken) continue;
    const dd = Math.hypot(p.x - d.x, p.y - d.y);
    if (dd < bd) {
      bd = dd;
      b = { kind: d.type, o: d };
    }
  }
  for (const n of rareNodes) {
    if (n.taken || n.split) continue;
    const dd = Math.hypot(p.x - n.x, p.y - n.y);
    if (dd < 125 && (!b || dd - 60 < bd)) {
      bd = dd - 60;
      b = { kind: "rare", o: n };
    }
  }
  return b;
}
function nearestPlot() {
  let b = null,
    bd = CFG.plotRange;
  farmArr().forEach((pl, i) => {
    const d = Math.hypot(p.x - pl.x, p.y - pl.y);
    if (d < bd) {
      bd = d;
      b = { i, pl };
    }
  });
  return b;
}

function openRocket(kind) {
  rocketOpen = true;
  const d = $("dest"),
    top = $("navTop");
  d.innerHTML = "";
  top.innerHTML = "";
  $("rocketSub").textContent = PLANETS[scene].name + T(" yüzeyi · sol ") + gameDayNumber();
  const cargo = Math.min(game.cargo || 0, CFG.cargoGoal);
  top.innerHTML = `<div class="con-meters">${conMeter(T("KARGO"), (cargo / CFG.cargoGoal) * 100, "linear-gradient(90deg,#c2410c,#ffb347)")}
    ${conMeter(T("GÖREV"), (Math.min(game.quest, QUESTS.length) / QUESTS.length) * 100, "linear-gradient(90deg,#1f7fb8,#7fe0ff)")}</div>`;
  if (game.repair.state !== "ok") {
    const a = document.createElement("div");
    a.className = "con-alert";
    a.innerHTML = Tf(
      `<div class="ai">⚠️</div><div><b>Ana motor hasarlı — kalkış kilitli.</b><br>Makine dairesindeki ana motoru onar · aşama {0}/4</div>`,
      [(game.repair.stage || 0) + 1],
    );
    top.appendChild(a);
  }
  const idxNow = progIdxOf(scene),
    locked0 = game.repair.state !== "ok";
  PROG_ORDER.forEach((k, idx) => {
    const P = PLANETS[k],
      isEarth = k === "earth",
      locked = idx > game.progIdx;
    const earthFinal = isEarth && game.progIdx >= PROG_ORDER.length - 1 && !game.won;
    const row = document.createElement("div");
    row.className = "con-row" + (idx === idxNow ? " cur" : "");
    let desc, right;
    if (idx === idxNow) {
      desc = T("Şu an buradasın");
      right = T('<span class="badge ok">BURADASIN</span>');
    } else if (locked) {
      desc =
        T("Görevleri tamamla (") + Math.min(game.quest, QUESTS.length - 1) + "/" + (QUESTS.length - 1) + ")";
      right = T('<span class="badge mute">🔒 KİLİTLİ</span>');
    } else if (earthFinal) {
      desc = T("Eve dönüş rotası hazır");
      right = "";
    } else {
      desc = game.visited.includes(k) ? T("Daha önce ziyaret edildi") : T("Yeni rota");
      right = "";
    }
    row.innerHTML = `<div class="ri"><span class="planet" style="background:radial-gradient(circle at 35% 30%,#ffffff88,${P.ground} 45%,${P.dot})"></span></div>
      <div><div class="rn">${P.name}</div><div class="rd">${desc}</div></div><div class="rp"></div>`;
    const act = document.createElement("div");
    if (right) act.innerHTML = right;
    else {
      const b = document.createElement("button");
      b.className = "cbtn pri";
      b.textContent = earthFinal ? T("🌍 EVE DÖN") : T("🚀 KALKIŞ");
      b.disabled = locked0;
      if (locked0) b.title = T("Ana motor hasarlı");
      b.onclick = () => {
        if (earthFinal) {
          game.won = true;
          startOutro();
          return;
        }
        startTravel(k);
      };
      act.appendChild(b);
    }
    row.appendChild(act);
    d.appendChild(row);
  });
  $("rocketScreen").classList.remove("hidden");
}
function conMeter(label, val, bg) {
  const v = Math.max(0, Math.min(100, val));
  return `<div class="con-meter"><span>${label}</span><div class="bar"><i style="width:${v}%;background:${bg}"></i></div><span>${Math.round(v)}%</span></div>`;
}
function closeRocket() {
  rocketOpen = false;
  clearInterval(openRocket._t);
  $("rocketScreen").classList.add("hidden");
  focusGame();
}
$("rocketClose").onclick = closeRocket;

/* --- Roket yolculuk animasyonu --- */
let fly = null,
  pendingWin = false,
  winOpen = false;
function startTravel(k) {
  if (fly) return;
  if (game.repair && game.repair.state !== "ok") {
    sfx("error");
    toast(T("Ana motor arızalı — makine dairesinde motoru onar"));
    return;
  }
  closeRocket();
  insideRocket = false;
  game.sleeping = false;
  fly = { t: 0, from: scene, to: k, switched: false };
  sfx("travel");
}
function updateFly(dt) {
  const f = fly;
  if (!f) return;
  f.t += dt;
  updateParticles(dt);
  shake = Math.max(0, shake - dt * 36);
  warp = Math.max(0, warp - dt * 1.3);
  $("hint").classList.add("hidden");
  $("eBtn").style.display = "none";
  $("fBtn").style.display = "none";
  $("gBtn").style.display = "none";
  $("qBtn").style.display = "none";
  if (!f.switched && f.t >= 0.45) {
    f.switched = true;
    enterPlanet(f.to, false, true);
  }
  if (f.t >= CFG.flyDur) {
    const to = f.to;
    fly = null;
    bumpQuest("traveled"); // seyahat tamamlandı (son görev: Kaşif)
    toast(PLANETS[to].name + T("'e varıldı"));
    sfx("click");
    if (pendingWin) {
      pendingWin = false;
      showWin();
    }
  }
}
function drawFlyOverlay() {
  const f = fly;
  if (!f) return;
  const t = f.t,
    d = CFG.flyDur;
  const a = t < 0.4 ? t / 0.4 : t > d - 0.45 ? Math.max(0, (d - t) / 0.45) : 1;
  ctx.save();
  ctx.fillStyle = "rgba(4,5,16," + a + ")";
  ctx.fillRect(0, 0, W, H);
  if (a > 0.08) {
    const prog = Math.max(0, Math.min(1, (t - 0.4) / (d - 0.85)));
    ctx.globalAlpha = a;
    for (let i = 0; i < 80; i++) {
      const sx = (i * 149.3) % W,
        sy = (i * 97.7) % H;
      const len = 16 + ((i * 53) % 70) * prog;
      ctx.strokeStyle = "rgba(255,255,255," + (0.1 + ((i * 17) % 70) / 160) + ")";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx - len, sy + len * 0.3);
      ctx.stroke();
    }
    const ease = prog < 0.5 ? 2 * prog * prog : 1 - Math.pow(-2 * prog + 2, 2) / 2;
    const rx = -150 + (W + 300) * ease,
      ry = H * 0.72 - H * 0.36 * ease;
    ctx.globalAlpha = a;
    storyRocket(rx, ry, Math.PI / 2 + Math.sin(ease * 7) * 0.05, Math.min(W, H) / 560, 1, true);
    ctx.globalAlpha = 1;
    ctx.textAlign = "center";
    ctx.fillStyle = "#eef0ff";
    ctx.font = "800 " + Math.round(Math.min(W, H) * 0.05) + "px 'Segoe UI',sans-serif";
    ctx.shadowColor = "#5ad1ff";
    ctx.shadowBlur = 18;
    ctx.fillText("🚀 " + PLANETS[f.from].name + "  →  " + PLANETS[f.to].name, W / 2, H * 0.2);
    ctx.shadowBlur = 0;
    ctx.font = "500 15px 'Segoe UI',sans-serif";
    ctx.fillStyle = "#9aa0cf";
    ctx.fillText(T("Roket yolculuğu sürüyor…"), W / 2, H * 0.2 + 36);
    const bw = Math.min(380, W * 0.5),
      bx = W / 2 - bw / 2,
      by = H * 0.2 + 58;
    ctx.fillStyle = "rgba(255,255,255,.14)";
    if (ctx.roundRect) ctx.roundRect(bx, by, bw, 8, 4);
    else ctx.rect(bx, by, bw, 8);
    ctx.fill();
    ctx.fillStyle = "#5ad1ff";
    if (ctx.roundRect) ctx.roundRect(bx, by, Math.max(4, bw * ease), 8, 4);
    else ctx.rect(bx, by, Math.max(4, bw * ease), 8);
    ctx.fill();
  }
  ctx.restore();
}

function openMarket() {
  marketOpen = true;
  const S = game.stock;
  $("mktTitle").textContent = T("Kargo Terminali");
  $("marketSub").textContent = T("Numuneleri kargo bölmesine yükle · erzak kapsüllerde");
  $("mktCoins").textContent = "📦 " + Math.min(game.cargo, CFG.cargoGoal) + "/" + CFG.cargoGoal;
  $("mktRate").textContent = "💧 +1 / " + Math.round((recycleInt() / 60) * 10) / 10 + T(" dk");
  const sh = $("shop");
  sh.innerHTML = "";
  const items = [
    ["water", "💧", T("Su"), T("Susuzluğu giderir · geri dönüştürülür")],
    ["potato", "🥔", T("Patates"), T("Açlığı giderir · tarladan yetişir")],
    ["seed", "🌱", T("Patates tohumu"), T("Dışarıdaki parsele ek")],
    ["medkit", "💊", T("Medikit"), T("Canı yeniler")],
  ];
  items.forEach(([key, ic, name, desc]) => {
    const inv = game.inventory[key] || 0,
      st = S[key] || 0;
    const el = document.createElement("div");
    el.className = "con-row";
    el.innerHTML = Tf(
      `<div class="ri">{0}</div><div><div class="rn">{1}</div><div class="rd">{2}</div></div>
      <div class="rp"><span>DEPO {3}</span><span class="rp-sub">ÇANTA {4}</span></div>`,
      [ic, name, desc, st, inv],
    );
    const act = document.createElement("div");
    act.className = "con-2b";
    const take = document.createElement("button");
    take.className = "cbtn pri";
    take.textContent = T("Al");
    take.disabled = st <= 0;
    take.onclick = () => {
      if (S[key] <= 0) return;
      S[key]--;
      game.inventory[key] = (game.inventory[key] || 0) + 1;
      sfx("pickup");
      updateInv();
      openMarket();
    };
    const put = document.createElement("button");
    put.className = "cbtn";
    put.textContent = T("Bırak");
    put.disabled = inv <= 0;
    put.onclick = () => {
      if ((game.inventory[key] || 0) <= 0) return;
      game.inventory[key]--;
      S[key] = (S[key] || 0) + 1;
      sfx("click");
      updateInv();
      openMarket();
    };
    act.append(take, put);
    el.appendChild(act);
    sh.appendChild(el);
  });
  // kargo bölmesi
  const cargo = Math.min(game.cargo || 0, CFG.cargoGoal);
  $("sellSum").textContent = cargo + " / " + CFG.cargoGoal;
  const list = $("sellList");
  list.innerHTML = "";
  list.insertAdjacentHTML(
    "beforeend",
    `<div class="con-meters" style="width:100%">${conMeter(T("KARGO"), (cargo / CFG.cargoGoal) * 100, "linear-gradient(90deg,#c2410c,#ffb347)")}</div>`,
  );
  const st = game.inventory.stone || 0,
    sr = game.inventory.star || 0;
  if (st)
    list.insertAdjacentHTML(
      "beforeend",
      Tf(`<span class="chip">🔩 Metal <b>×{0}</b> <i>+{1}</i></span>`, [st, st]),
    );
  if (sr)
    list.insertAdjacentHTML(
      "beforeend",
      Tf(`<span class="chip">⭐ Yıldız <b>×{0}</b> <i>+{1}</i></span>`, [sr, sr * 2]),
    );
  if (!st && !sr)
    list.insertAdjacentHTML(
      "beforeend",
      Tf(
        `<div class="con-note">Çantanda numune yok — dışarıda metal ve ⭐ topla, burada kargoya yükle.</div>`,
        [],
      ),
    );
  {
    ensureRare();
    const C = commState();
    C.flags.rock = C.flags.rock || {};
    const hdr = document.createElement("div");
    let any = false;
    for (const k of RARE_ALL) {
      const n = game.rare[k] || 0,
        st = C.flags.rock[k],
        known = !!game.rareKnown[k];
      if (known || (!n && !(st > 0))) continue;
      any = true;
      const wait = st > 0;
      const row = document.createElement("div");
      row.className = "con-row ana-row";
      row.innerHTML = Tf(
        `<div class="ri"><img src="{0}" alt="" style="width:32px;height:32px;filter:{1}"></div><div><div class="rn">Bilinmeyen taş · {2}. tür<span class="ana-tag">ANALİZ İÇİN</span></div><div class="rd">{3}</div></div><div class="rp"><span>ÇANTA {4}</span></div>`,
        [
          rareIconURL(k),
          known ? "none" : "grayscale(.6) hue-rotate(200deg)",
          RARE_ALL.indexOf(k) + 1,
          wait
            ? T("Dünya'ya gönderildi · laboratuvar inceliyor")
            : T("Ne olduğunu ve tehlikeli olup olmadığını öğrenmek için gönder"),
          n,
        ],
      );
      const b = document.createElement("button");
      b.className = "cbtn pri";
      b.textContent = wait ? T("Analizde…") : T("Analize gönder");
      b.disabled = wait || n < 1;
      b.onclick = () => sendRockSample(k);
      const a = document.createElement("div");
      a.className = "con-2b";
      a.appendChild(b);
      row.appendChild(a);
      list.appendChild(row);
    }
  }
  {
    const rt = game.inventory.rotten || 0,
      C = commState(),
      wait = C.flags.capsAt && !C.flags.ana;
    if (rt > 0 || wait) {
      const row = document.createElement("div");
      row.className = "con-row rot-row ana-row";
      row.innerHTML = Tf(
        `<div class="ri"><img src="{0}" alt="" style="width:30px;height:30px"></div><div><div class="rn">Çürük patates<span class="ana-tag">ANALİZ İÇİN</span></div><div class="rd">{1}</div></div><div class="rp"><span>ÇANTA {2}</span></div>`,
        [
          itemIconURL("rotten"),
          wait
            ? T("Dünya'ya gönderildi · analiz bekleniyor")
            : T("Kargoyla Dünya'ya gönder · neden çürüdüğünü incelesinler"),
          rt,
        ],
      );
      const b = document.createElement("button");
      b.className = "cbtn pri";
      b.textContent = T("Dünya'ya gönder");
      b.disabled = wait || rt < 1;
      b.onclick = sendRotCargo;
      const a = document.createElement("div");
      a.className = "con-2b";
      a.appendChild(b);
      row.appendChild(a);
      list.appendChild(row);
    }
  }
  $("marketTrade").textContent =
    st + sr > 0 ? T("📦 Numuneleri kargoya yükle · +") + (st + sr * 2) : T("Yüklenecek numune yok");
  $("marketTrade").disabled = st + sr <= 0;
  $("marketScreen").classList.remove("hidden");
}
function closeMarket() {
  marketOpen = false;
  $("marketScreen").classList.add("hidden");
  focusGame();
}
$("marketClose").onclick = closeMarket;
$("marketTrade").onclick = () => depositSamples();

function pressE() {
  if (mode !== "play" || paused) return;
  if (upgOpen) {
    closeUpg();
    return;
  }
  if (commOpen) {
    closeComm();
    return;
  }
  if (capOpen) {
    closeCapsule();
    return;
  }
  if (o2Fill) {
    stopO2Fill(false);
    return;
  }
  if (repairOpen) {
    closeRepair();
    return;
  }
  if (rocketOpen) {
    closeRocket();
    return;
  }
  if (marketOpen) {
    closeMarket();
    return;
  }
  if (bedOpen) {
    if (game.sleeping) wakeUp(T("Uyandın"));
    else closeBed();
    return;
  }
  if (insideRocket) {
    stationAction();
    return;
  }
  sfx("click");
  if (nearRocket()) enterRocket();
}
function pressF() {
  if (radM) return;
  if (
    mode !== "play" ||
    paused ||
    rocketOpen ||
    marketOpen ||
    repairOpen ||
    capOpen ||
    commOpen ||
    upgOpen ||
    o2Fill ||
    bookOpen ||
    bedOpen
  )
    return;
  if (insideRocket) {
    insideF();
    return;
  }
  const pk = nearestPickup();
  if (pk) {
    if (pk.kind === "rare") {
      startBreak(pk.o);
      return;
    }
    if (pk.kind === "gold") {
      pk.o.taken = true;
      ensureUpg();
      game.gold += pk.o.n || 1;
      bumpQuest("gold", pk.o.n || 1);
      burst(pk.o.x, pk.o.y, 24, "#ffd34d", { sp: 150, life: 0.7, size: 5 });
      addFloat(pk.o.x, pk.o.y - 24, "+" + (pk.o.n || 1) + T(" altın"), "#ffd34d");
      sfx("star");
      tone(1568, 0.12, "sine", 0.05, 0, 0.05);
      if (!game._goldTip) {
        game._goldTip = 1;
        toast(
          T("🪙 <b>Altın parçası</b> — roketteki geliştirme istasyonunda roketini güçlendirmek için kullan"),
        );
      }
      return;
    }
    if (pk.kind === "stone" && (game.inventory.stone || 0) >= stoneCap()) {
      sfx("full");
      toast(T("Envanter dolu! (") + game.inventory.stone + "/" + stoneCap() + ")");
      return;
    }
    pk.o.taken = true;
    game.inventory[pk.kind] = (game.inventory[pk.kind] || 0) + 1;
    burst(pk.o.x, pk.o.y, pk.kind === "star" ? 20 : 12, pk.kind === "star" ? "#ffd34d" : "#c9d2e0", {
      sp: 130,
      life: 0.6,
      size: 5,
    });
    addFloat(
      pk.o.x,
      pk.o.y - 24,
      pk.kind === "star" ? "+1 ⭐" : "+1 🔩",
      pk.kind === "star" ? "#ffd34d" : "#dfe7f5",
    );
    sfx(pk.kind === "star" ? "star" : "pickup");
    updateInv();
    commsObs("geo", pk.kind === "star" ? { star: 1 } : { metal: 1 });
    bumpQuest("mined");
    return;
  }
  if (nearRocket() && sampleCount() > 0) {
    depositSamples();
    return;
  }
  {
    const nm = nearestMark(),
      pl0 = nearestPlot();
    if (nm && (!pl0 || nm.d < Math.hypot(p.x - pl0.pl.x, p.y - pl0.pl.y))) {
      removeMark(nm);
      return;
    }
  }
  if (heldItemKey() === "radmeter" && !nearestPlot()) {
    startMeasure(p.x + p.dir * 80, p.y + 26);
    return;
  }
  const pl = nearestPlot(),
    held = heldItemKey();
  if (pl) {
    const fa = farmArr(),
      g = fa[pl.i];
    if (!g || g.g <= 0) {
      if (held === "ceramic") {
        coverPlot(g);
        return;
      }
      if (g && g.cov && g.shut) {
        sfx("error");
        toast(T("🔒 Kalkan kapalı — tohum ekmek için önce <b>Q</b> ile aç"));
        return;
      }
      if (!isSeedKey(held)) {
        const sk = nextSeedKey();
        if (sk) {
          equip(sk);
          toast(
            sk === "tuber"
              ? T("🥔 Tohumluk patatesi eline aldın — ekmek için tekrar <b>F</b>")
              : T("🌱 Tohumu eline aldın — ekmek için tekrar <b>F</b>"),
          );
        } else {
          sfx("error");
          toast(T("Tohum yok — roketteki alet sandığından al ya da sağlıklı hasat yap"));
        }
        return;
      }
      game.inventory[held]--;
      Object.assign(fa[pl.i], { g: 0.1, wet: 0, idle: 0, fill: 0 });
      updateInv();
      burst(pl.pl.x, pl.pl.y, 14, "#8a6a3c", { sp: 90, life: 0.6, size: 4 });
      addFloat(pl.pl.x, pl.pl.y - 30, T("🌱 Ekildi"), "#7fe0ff");
      sfx("plant");
      bumpQuest("planted");
      if (fa[pl.i].cov && !fa[pl.i].shut) toast(T("🌱 Ekildi — şimdi <b>Q</b> ile kalkanı kapat"));
      else storyTrigger("seedTip");
      return;
    }
    if (held === "ceramic") {
      coverPlot(g);
      return;
    }
    if (g.cov && (g.shut || domeMoving(g))) {
      sfx("error");
      toast(
        g.g >= CFG.farmGrow
          ? T("🔒 Kalkan kapalı — patatese ulaşmak için <b>Q</b> ile aç")
          : T("🔒 Kalkan kapalı — sulamak için <b>Q</b> ile aç"),
      );
      return;
    }
    if (g.g >= CFG.farmGrow) {
      const rot = plotRots(fa[pl.i]);
      fa[pl.i].g = 0;
      fa[pl.i].wet = 0;
      if (rot) {
        harvestRot(fa[pl.i]);
        return;
      }
      if (game.radLearned) bumpQuest("cleanHarvest");
      const n = 1 + (Math.random() < 0.45 ? 1 : 0);
      game.inventory.potato = (game.inventory.potato || 0) + n;
      game.inventory.tuber = (game.inventory.tuber || 0) + 1;
      burst(pl.pl.x, pl.pl.y, 22, "#4ade80", { sp: 140, life: 0.7, size: 5 });
      addFloat(pl.pl.x, pl.pl.y - 34, "+" + n + " 🥔  +1 " + T("tohumluk"), "#4ade80");
      if (!game._tuberTip) {
        game._tuberTip = 1;
        setTimeout(
          () =>
            toast(T("🥔 Hasattan <b>1 tohumluk patates</b> çıktı — filizli gözleriyle yeniden ekilebilir")),
          900,
        );
      }
      sfx("harvest");
      updateInv();
      bumpQuest("harvested");
      return;
    }
    if (held === "water") {
      game.inventory.water--;
      g.wet = Math.max(g.wet, 16);
      g.g = Math.min(CFG.farmGrow, g.g + 6);
      burst(pl.pl.x, pl.pl.y, 16, "#38bdf8", { sp: 110, life: 0.6, size: 4, up: 60 });
      game.qstats.watered = (game.qstats.watered || 0) + 1;
      addFloat(pl.pl.x, pl.pl.y - 30, T("💧 Sulandı"), "#38bdf8");
      sfx("water");
      updateInv();
      return;
    }
    if ((game.inventory.water || 0) > 0) {
      equip("water");
      toast(T("💧 Su şişesini eline aldın — sulamak için tekrar <b>F</b>"));
      return;
    }
    sfx("error");
    toast(T("Sulamak için su yok · büyüyor %") + Math.round(plotStage(g.g) * 100));
    return;
  }
  if (held === "water") {
    if (game.thirst >= 100) {
      sfx("full");
      toast(T("Susuzluğun zaten dolu"));
      return;
    }
    game.inventory.water--;
    game.thirst = Math.min(100, game.thirst + CFG.drinkThirst);
    startAct("drink", 1.8);
    burst(p.x, p.y - 30, 10, "#38bdf8", { sp: 70, life: 0.5, size: 3 });
    sfx("drink");
    toast(T("Su içildi (+") + CFG.drinkThirst + T(" su)"));
    updateInv();
    updateStats();
    bumpQuest("drunk");
    return;
  }
  if (held === "potato") {
    if (game.hunger >= 100) {
      sfx("full");
      toast(T("Tok durumdasın"));
      return;
    }
    game.inventory.potato--;
    game.hunger = Math.min(100, game.hunger + CFG.eatHunger);
    startAct("eat", 2.0);
    sfx("eat");
    toast(T("Patates yendi (+") + CFG.eatHunger + T(" tokluk)"));
    updateInv();
    updateStats();
    return;
  }
  sfx("error");
  toast(
    held === "pickaxe"
      ? T("Çapa elinde — su içmek için önce suyu eline al (numara tuşu)")
      : T("Yapılacak bir şey yok (F)"),
  );
}
function pressG() {
  if (
    mode !== "play" ||
    paused ||
    rocketOpen ||
    marketOpen ||
    repairOpen ||
    capOpen ||
    commOpen ||
    upgOpen ||
    o2Fill ||
    bookOpen ||
    bedOpen
  )
    return;
  const fromStock = insideRocket && (game.inventory.medkit || 0) <= 0 && game.stock.medkit > 0;
  if ((game.inventory.medkit || 0) <= 0 && !fromStock) {
    sfx("error");
    toast("Medikit yok — roketin revirinden al");
    return;
  }
  if (game.hp >= 100) {
    sfx("full");
    toast(T("Canın zaten dolu"));
    return;
  }
  if (fromStock) game.stock.medkit--;
  else game.inventory.medkit--;
  game.hp = Math.min(100, game.hp + CFG.healAmount);
  startAct("use", 1.2);
  burst(p.x, p.y - 20, 26, "#4ade80", { sp: 120, life: 0.8, size: 5, up: 80 });
  addFloat(p.x, p.y - 50, "+" + CFG.healAmount + " ❤️", "#4ade80");
  sfx("heal");
  updateInv();
  updateStats();
}

/* ============== OLAY SİSTEMİ (Meteor) ============== */
function damage(n, quiet) {
  if (game.hp <= 0) return;
  game.hp = Math.max(0, game.hp - n);
  if (!quiet) {
    flash = 0.7;
    shake = Math.max(shake, 14);
    sfx("hurt");
  }
  updateStats();
}
function gameDayNumber() {
  return Math.floor(Math.max(0, Number(game && game.worldTime) || 0) / DAY_SECONDS) + 1;
}
function radiationActiveNow() {
  if (!game) return false;
  const worldTime = Math.max(0, Number(game.worldTime) || 0),
    day = Math.floor(worldTime / DAY_SECONDS) + 1;
  return day >= 3 && day % 3 === 0 && worldTime % DAY_SECONDS < RADIATION_DURATION;
}
function updateRadiation(simDt) {
  const active = radiationActiveNow(),
    was = !!game.radiationActive;
  if (active && !was) {
    sfx("warn");
    if (!insideRocket) toast(T("☢️ Radyasyon dalgası başladı — canın azalıyor, rokete gir!"));
    if (scene !== "earth") {
      const open = farmArr().filter((g) => g && g.g > 0 && !domeSafe(g)).length;
      if (open > 0)
        setTimeout(
          () =>
            toast(
              Tf("🌱 {0} parsel açıkta — seramik kalkanı olmayan bitkiler radyasyondan zarar görüyor", [
                open,
              ]),
            ),
          2600,
        );
    }
  }
  if (!active && was) {
    toast(T("☢️ Radyasyon dalgası geçti"));
    if (suitSt().rad > 0.6) storyTrigger("radLesson");
    if (scene !== "earth") {
      const fa = farmArr();
      const saved = fa.filter((g) => g && g.g > 0 && g.radOK && !g.radHit).length,
        hit = fa.filter((g) => g && g.g > 0 && g.radHit).length;
      fa.forEach((g) => {
        if (g) {
          g.radOK = 0;
          g.radHit = 0;
        }
      });
      if (saved > 0) {
        bumpQuest("shieldSaved");
        storyTrigger("domeSaved");
      }
      if (hit > 0) storyTrigger("domeBurn");
    }
  }
  game.radiationActive = active;
  const wt = Math.max(0, Number(game.worldTime) || 0),
    inDay = wt % DAY_SECONDS,
    day = Math.floor(wt / DAY_SECONDS) + 1;
  if (active) {
    const left = RADIATION_DURATION - inDay;
    if (insideRocket)
      setAlert(
        "radiationBanner",
        "rad safe",
        "safe",
        T("Roket içi güvenli"),
        T("Radyasyon dalgası · gövde zırhı koruyor"),
        left / RADIATION_DURATION,
        mmss(left),
      );
    else
      setAlert(
        "radiationBanner",
        "rad",
        "rad",
        T("Radyasyon dalgası"),
        T("Dışarıda can azalıyor — rokete sığın!"),
        left / RADIATION_DURATION,
        mmss(left),
      );
    if (!insideRocket) {
      const rd = RADIATION_DAMAGE_PER_SECOND * suitSt().rad * dif().rad;
      damage(rd * simDt, true);
      game._radT = (game._radT || 0) + simDt;
      if (game._radT >= 1.2) {
        game._radT = 0;
        addFloat(
          p.x + (Math.random() - 0.5) * 30,
          p.y - 62,
          "-" + Math.max(1, Math.round(rd * 1.2)) + " ☢",
          "#a3e635",
        );
        sfx("hurt");
        shake = Math.max(shake, 3);
      }
    }
  } else if (scene !== "earth" && (day + 1) % 3 === 0 && inDay > DAY_SECONDS - RAD_WARN - desFx().radWarn) {
    if (farmArr().some((g) => g && g.g > 0 && !domeSafe(g))) {
      const SS = storyState();
      if (!SS.done.radRadio) {
        SS.rrDay = day;
        storyTrigger("radRadio");
      } else if (SS.rrDay !== day) storyTrigger("radRadio2_" + day);
    }
    const tt = DAY_SECONDS - inDay;
    setAlert(
      "radiationBanner",
      "rad warn",
      "rad",
      T("Radyasyon dalgası yaklaşıyor"),
      insideRocket ? T("Roketin içindesin — güvendesin") : T("Güneş patlaması · rokete yaklaş"),
      1 - tt / RAD_WARN,
      mmss(tt),
    );
  } else setAlert("radiationBanner");
}
function updateEvent(dt) {
  const E = ev;
  if (scene === "earth") {
    E.type = null;
    E.meteors = [];
    return;
  }
  if (E.type === null) {
    if (stormFx.phase !== "none") {
      E.next = Math.max(E.next, 20);
      return;
    } // fırtınada meteor yok
    E.next -= dt;
    if (E.next <= 0) {
      // uyarısız meteor yağmuru: 1-3 meteor
      E.type = "meteor";
      E.t = 9;
      E.spawnT = 0.8;
      E.meteors = [];
      E.goal = 1 + Math.floor(Math.random() * 3);
      E.spawned = 0;
    }
    return;
  }
  E.t -= dt;
  E.spawnT -= dt;
  if (E.spawnT <= 0 && E.spawned < E.goal && E.t > 2) {
    E.spawnT = 1.3 + Math.random() * 1.2;
    spawnMeteor();
    E.spawned++;
  }
  for (let i = E.meteors.length - 1; i >= 0; i--) {
    const m = E.meteors[i];
    m.t -= dt;
    if (m.t <= 0) {
      impact(m);
      E.meteors.splice(i, 1);
    }
  }
  if (E.t <= 0) {
    E.type = null;
    E.next = CFG.eventMin + Math.random() * (CFG.eventMax - CFG.eventMin);
    E.meteors = [];
  }
}
/* ============== İPUCU / DOKUNMATİK ============== */
function computeHint() {
  if (
    rocketOpen ||
    marketOpen ||
    repairOpen ||
    capOpen ||
    commOpen ||
    upgOpen ||
    o2Fill ||
    bookOpen ||
    bedOpen ||
    paused ||
    mode !== "play"
  )
    return "";
  if (insideRocket) return insideHint();
  const pk = nearestPickup(),
    nr = nearRocket(),
    pl = nearestPlot();
  const stone = game.inventory.stone || 0;
  if (pk) {
    if (pk.kind === "gold") return T("<b>F</b>: Altın parçası topla · roket geliştirme");
    if (pk.kind === "rare") {
      const kn = game.rareKnown[pk.o.kind];
      return (
        "<b>F</b>: " +
        (kn ? RARE_DEF[pk.o.kind].name + T(" — kazmayla kır") : T("Bilinmeyen taşı kazmayla kır")) +
        ((game.inventory.pick || 0) > 0 ? "" : T(" · <b style='color:#ff8a8a'>jeolog kazması gerekli</b>"))
      );
    }
    if (pk.kind === "stone")
      return stone >= stoneCap()
        ? T("Çanta dolu (") + stone + "/" + stoneCap() + T(") — rokete yükle")
        : T("<b>F</b>: Metal numune topla");
    return T("<b>F</b>: Yıldız kırıntısı topla (⭐ = 2 numune)");
  }
  if (brk) return T("Taş kırılıyor…");
  if (radM) return radM.done ? T("Sol tık: ölçümü kapat") : T("Ölçülüyor… hareket etme");
  {
    const nm = nearestMark();
    if (nm && !nr && (!pl || nm.d < Math.hypot(p.x - pl.pl.x, p.y - pl.pl.y)))
      return T("<b>F</b>: Ölçüm bayrağını kaldır (") + fmtN(nm.mk.u, 2) + " µSv/h)";
  }
  if (nr)
    return (
      T("<b>E</b>: Rokete gir") +
      (sampleCount() > 0 ? T("  ·  <b>F</b>: Numuneleri kargoya yükle") : "") +
      ((game.inventory.rotten || 0) > 0 ? T("  ·  çürük patatesi kargo terminalinden gönder") : "")
    );
  if (heldItemKey() === "radmeter")
    return T("<b>Sol tık</b>: toprağın radyasyonunu ölç  ·  <b>F</b>: önündeki toprağı ölç");
  if (farmArr().length === 0 && game.quest >= 2)
    return game.kitCarried
      ? heldItemKey() === "pickaxe"
        ? T("<b>Sol tık</b>: yakındaki yere kaz — ilk parseli aç")
        : T("Çapayı eline al (numara tuşu) ya da yere tıkla")
      : T("Çapa roketteki alet sandığında (makine dairesi) — rokete gir: <b>E</b>");
  if (pl) {
    const fa = farmArr(),
      g = fa[pl.i];
    const hk = heldItemKey();
    if (g && g.cov && domeMoving(g)) return g.shut ? T("🛡️ Kalkan kapanıyor…") : T("🛡️ Kalkan açılıyor…");
    if (hk === "ceramic" && !(g && g.cov))
      return T("<b>F</b>: Seramik kalkanı kur · <b>Q</b> ile açılıp kapanır");
    if (!g || g.g <= 0) {
      if (g && g.cov && g.shut) return T("🔒 Kalkan kapalı · <b>Q</b>: aç ve tohum ek");
      const sx = g && g.cov ? T("  ·  <b>Q</b>: kalkanı kapat  ·  <b>Shift+Q</b>: sök") : "";
      return (
        (isSeedKey(hk)
          ? T("<b>F</b>: Tohum ek")
          : hasSeeds()
            ? T("<b>F</b>: Tohumu eline al")
            : T("Tohum yok — roketteki alet sandığından al")) + sx
      );
    }
    if (g.cov && g.shut)
      return g.g >= CFG.farmGrow
        ? T("🔒 Patatesler hazır ama kalkan kapalı · <b>Q</b>: aç")
        : T("🛡️ Kalkan kapalı · korunuyor · büyüyor %") +
            Math.round(plotStage(g.g) * 100) +
            T(" · <b>Q</b>: aç");
    const qx = g.cov ? T("  ·  <b>Q</b>: kalkanı kapat") : "";
    if (g.g >= CFG.farmGrow)
      return (
        (plotRots(g)
          ? T("<b>F</b>: Hasat et — yapraklar solmuş, bir terslik var")
          : T("<b>F</b>: Hasat et 🥔")) + qx
      );
    if (game.radiationActive && scene !== "earth")
      return g.cov
        ? T("☢️ Radyasyon! Bitki zarar görüyor — <b>Q</b> ile kalkanı kapat")
        : T("☢️ Bitki radyasyondan zarar görüyor — seramik kalkanı eline al ve <b>F</b>");
    return (
      (heldItemKey() === "water"
        ? T("<b>F</b>: Sula (hızlandırır)")
        : (game.inventory.water || 0) > 0
          ? T("<b>F</b>: Suyu eline al (sulamak için)")
          : T("Büyüyor %") + Math.round(plotStage(g.g) * 100) + "…") + qx
    );
  }
  if ((game.inventory.medkit || 0) > 0 && game.hp < 100)
    return T("<b>G</b>: Medikit kullan (") + Math.round(game.hp) + "❤️)";
  if (game.hp < 60) return T("Dikkat: canın düşük! Roketin revirinde iyileş");
  return "";
}
function updateTouch(hint) {
  const touch = matchMedia("(pointer:coarse)").matches;
  if (!touch) return;
  if (bedOpen) {
    $("eBtn").style.display = game.sleeping ? "block" : "none";
    $("fBtn").style.display = "none";
    $("gBtn").style.display = "none";
    return;
  }
  $("qBtn").style.display = "none";
  if (insideRocket) {
    const st = nearStation();
    $("eBtn").style.display = st ? "block" : "none";
    $("fBtn").style.display = st && st.key === "trade" && sampleCount() > 0 ? "block" : "none";
    $("gBtn").style.display = "none";
    return;
  }
  const nr = nearRocket(),
    pk = nearestPickup(),
    pl = nearestPlot();
  $("eBtn").style.display = nr ? "block" : "none";
  const stone = game.inventory.stone || 0;
  const hk = heldItemKey(),
    canF =
      (pk && (pk.kind !== "stone" || stone < stoneCap())) ||
      (nr && sampleCount() > 0) ||
      pl ||
      (hk === "water" && game.thirst < 100) ||
      (hk === "potato" && game.hunger < 100);
  $("fBtn").style.display = canF ? "block" : "none";
  $("gBtn").style.display = (game.inventory.medkit || 0) > 0 && game.hp < 100 ? "block" : "none";
  $("qBtn").style.display = nearestDome() ? "block" : "none";
}

/* ============== GİRDİ ============== */
addEventListener("keydown", (e) => {
  if (game && game.wake && mode === "play") {
    if (["Space", "Enter", "Escape"].includes(e.code)) {
      e.preventDefault();
      if (!e.repeat && game.wake.t > 1.2) endWake();
    }
    return;
  } // açılışı geçmek için basılı tutulan tuş uyanışı atlamasın
  if (story && !story.end && mode === "play") {
    if (["Space", "Enter", "KeyE", "KeyF"].includes(e.code)) {
      e.preventDefault();
      storyAdvance();
    } else if (e.code === "Escape") {
      e.preventDefault();
      storyEnd();
    }
    return;
  }
  if (mode === "intro") {
    e.preventDefault();
    if (e.code === "Escape") endIntro();
    else if ((e.code === "Space" || e.code === "Enter") && intro) intro.hold = true;
    return;
  }
  if (commOpen) {
    // terminal açıkken: yazı alanında oyun tuşları çalışmaz
    const typing = /^(TEXTAREA|INPUT|SELECT)$/.test((e.target && e.target.tagName) || "");
    if (e.code === "Escape" || (!typing && e.code === "KeyE")) {
      e.preventDefault();
      closeComm();
    }
    return;
  }
  if (bookOpen) {
    // kitap açıkken sadece kitap tuşları
    e.preventDefault();
    if (e.code === "ArrowRight" || e.code === "KeyD") bookFlip(1);
    else if (e.code === "ArrowLeft" || e.code === "KeyA") bookFlip(-1);
    else if (e.code === "Escape" || e.code === "KeyR" || e.code === "KeyE") closeBook();
    return;
  }
  if (
    e.code === "KeyR" &&
    mode === "play" &&
    game &&
    !paused &&
    !rocketOpen &&
    !marketOpen &&
    !repairOpen &&
    !capOpen &&
    !commOpen &&
    !upgOpen &&
    !bedOpen &&
    !winOpen &&
    !fly
  ) {
    openBook();
    return;
  }
  if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
  if (e.code === "Space") {
    if (
      !e.repeat &&
      mode === "play" &&
      game &&
      !paused &&
      !rocketOpen &&
      !marketOpen &&
      !repairOpen &&
      !capOpen &&
      !commOpen &&
      !upgOpen &&
      !bedOpen &&
      !o2Fill &&
      !winOpen &&
      !fly
    )
      keys.Space = true;
    return;
  }
  // 1-6: hotbar slotu seç (aynı tuşa tekrar bas = kullan)
  if (/^(Digit|Numpad)[1-9]$/.test(e.code)) {
    if (
      mode === "play" &&
      game &&
      !paused &&
      !rocketOpen &&
      !marketOpen &&
      !repairOpen &&
      !capOpen &&
      !commOpen &&
      !upgOpen
    ) {
      const i = +e.code.slice(-1) - 1;
      if (i === selSlot) useSelected();
      else {
        const k = (game.slotOrder || [])[i];
        if (k) {
          selSlot = i;
          updateInv();
          sfx("click");
          toast(T("Elinde: ") + (SLOT_NAMES[SLOT_KEYS.indexOf(k)] || k));
        } else sfx("error");
      }
    }
    return;
  }
  keys[e.code] = true;
  if (e.code === "KeyQ" && !e.repeat) pressQ(e.shiftKey);
  if (e.code === "Escape") toggleEsc();
  if (e.code === "KeyE") pressE();
  if (e.code === "KeyF") pressF();
  if (e.code === "KeyG") pressG();
});
addEventListener("keyup", (e) => {
  keys[e.code] = false;
  if (mode === "intro" && intro && (e.code === "Space" || e.code === "Enter")) intro.hold = false;
});
addEventListener("pointerdown", (e) => {
  if (!(e.target && e.target.closest && e.target.closest("#commScreen"))) focusGame();
});

/* --- sol tık / dokunuş: kazmayla parsel aç --- */
function digAt(wx, wy) {
  const d = Math.hypot(wx - p.x, wy - p.y);
  if (d > CFG.digRange) {
    sfx("error");
    toast(T("Çok uzak — tıkladığın yere daha yaklaş"));
    return;
  }
  const plots = farmArr();
  if (plots.length >= CFG.maxPlots) {
    sfx("full");
    toast(T("Azami parsel sayısına ulaştın (") + CFG.maxPlots + ")");
    return;
  }
  if (plots.some((pl) => Math.hypot(wx - pl.x, wy - pl.y) < 120)) {
    sfx("error");
    toast(T("Buraya çok yakın — biraz aralık bırak"));
    return;
  }
  if (Math.hypot(wx - ROCKET.x, wy - ROCKET.y) < 170) {
    sfx("error");
    toast(T("İniş platformunu kazamazsın"));
    return;
  }
  if (Math.abs(wx) > CFG.worldHalf - 80 || Math.abs(wy) > CFG.worldHalf - 80) {
    sfx("error");
    toast(T("Dünyanın kenarını kazamazsın"));
    return;
  }
  p.dir = wx < p.x ? -1 : 1;
  if (p.action === "dig" && p.actionT > 0) return; // önceki vuruş bitmeden yeni vuruş yok
  p.action = "dig";
  p.actionT = 1.0;
  p.actionDur = 1.0;
  p.digAt = { x: wx, y: wy, t: 0 };
  tone(220, 0.25, "sine", 0.04, 320, 0.05); // kaldırırken hışırtı
}
/* ekilebilir tohumlar: paket tohum (alet sandığı) + tohumluk patates (hasattan) */
function isSeedKey(k) {
  return k === "seed" || k === "tuber";
}
function hasSeeds() {
  return (game.inventory.seed || 0) + (game.inventory.tuber || 0) > 0;
}
function nextSeedKey() {
  return (game.inventory.tuber || 0) > 0 ? "tuber" : (game.inventory.seed || 0) > 0 ? "seed" : null;
}
/* tohum/su elindeyken parsele tıkla: ek ya da sula */
function plotClickUse(wx, wy, held) {
  const fa = farmArr();
  let i = -1,
    bd = 80;
  fa.forEach((q, j) => {
    const d = Math.hypot(q.x - wx, q.y - wy);
    if (d < bd) {
      bd = d;
      i = j;
    }
  });
  if (i < 0) {
    sfx("error");
    toast(
      isSeedKey(held)
        ? T("Tohumu ekmek için açtığın bir parsele tıkla")
        : held === "ceramic"
          ? T("Kalkanı takmak için ekili bir parsele tıkla")
          : T("Sulamak için ekili bir parsele tıkla"),
    );
    return;
  }
  const g = fa[i];
  p.dir = g.x < p.x ? -1 : 1;
  if (held === "ceramic") {
    coverPlot(g);
    return;
  }
  if (g.cov && (g.shut || domeMoving(g))) {
    sfx("error");
    toast(T("🔒 Kalkan kapalı — önce <b>Q</b> ile aç"));
    return;
  }
  if (isSeedKey(held)) {
    if (g.g > 0) {
      sfx("error");
      toast(T("Parsel dolu — önce hasat et (F)"));
      return;
    }
    game.inventory[held]--;
    g.g = 0.1;
    g.wet = 0;
    updateInv();
    burst(g.x, g.y, 14, "#8a6a3c", { sp: 90, life: 0.6, size: 4 });
    addFloat(g.x, g.y - 30, "Ekildi", "#7fe0ff");
    sfx("plant");
    bumpQuest("planted");
    return;
  }
  if (g.g <= 0) {
    sfx("error");
    toast(T("Bu parsel boş — önce tohum ek"));
    return;
  }
  if (g.g >= CFG.farmGrow) {
    sfx("click");
    toast(T("Mahsul hazır — hasat için yanına git ve <b>F</b>"));
    return;
  }
  game.inventory.water--;
  g.wet = Math.max(g.wet, 16);
  g.g = Math.min(CFG.farmGrow, g.g + 6);
  burst(g.x, g.y, 16, "#38bdf8", { sp: 110, life: 0.6, size: 4, up: 60 });
  game.qstats.watered = (game.qstats.watered || 0) + 1;
  addFloat(g.x, g.y - 30, T("Sulandı"), "#38bdf8");
  sfx("water");
  updateInv();
}
const EMPTY_HOLE_T = 45;
const PLANT_RAD_DMG = 0.45; // korumasız bitkinin radyasyon dalgasında kaybettiği büyüme (sn başına)
function digImpact(wx, wy) {
  const plots = farmArr();
  const pr = { x: wx, y: wy, g: 0, wet: 0, rad: soilRad01(wx, wy) };
  plots.push(pr);
  burst(wx, wy + 6, 22, "#c98a5a", { sp: 150, life: 0.7, size: 5, up: 90 });
  burst(wx, wy + 6, 12, "#8f6a4a", { sp: 80, life: 1, size: 4 });
  burst(wx, wy + 2, 8, "#e8c4a0", { sp: 40, life: 1.3, size: 7, up: 20, drag: 2 });
  addFloat(wx, wy - 34, T("Yeni parsel: boş"), "#ffd8a8");
  shake = Math.max(shake, 5);
  sfx("dig");
  noiseBurst(0.12, 0.18, 700);
  toast(T("Yeni parsel hazır: <b>boş</b> — tohum ek (F)"));
}
cv.addEventListener("pointerdown", (e) => {
  if (
    mode !== "play" ||
    paused ||
    rocketOpen ||
    marketOpen ||
    repairOpen ||
    capOpen ||
    commOpen ||
    upgOpen ||
    o2Fill ||
    bookOpen ||
    bedOpen ||
    winOpen ||
    fly ||
    !game ||
    insideRocket
  )
    return;
  if (e.button !== 0) return;
  if (radM) {
    if (radM.done) radM.t = Math.max(radM.t, radM.T - 0.5);
    return;
  }
  if (brk) return;
  const z = ((CFG.zoom * Math.min(W, H)) / 700) * cam.z;
  const wx = (e.clientX - W / 2) / z + p.x + cam.ox,
    wy = (e.clientY - H / 2) / z + p.y + cam.oy;
  const held = heldItemKey();
  if (held === "radmeter") {
    startMeasure(wx, wy);
    return;
  }
  if (held === "pick") {
    const n = nearRareNode(150);
    if (n) {
      startBreak(n);
      return;
    }
  }
  if (Math.hypot(wx - p.x, wy - p.y) > CFG.digRange) return; // menzil dışı: sıradan tıklama
  if (isSeedKey(held) || held === "water" || held === "ceramic") {
    plotClickUse(wx, wy, held);
    return;
  }
  if (held === "pick") {
    const n = nearRareNode(150);
    if (n) startBreak(n);
    else {
      sfx("error");
      toast(T("Jeolog kazması yalnızca <b>bilinmeyen (?) taşları</b> kırar — kazmak için çapayı eline al"));
    }
    return;
  }
  if (held === "pickaxe") {
    digAt(wx, wy);
    return;
  }
  if (held) {
    sfx("click");
    toast(T("Elinde başka bir eşya var — kazmak için çapayı eline al (numara tuşu)"));
    return;
  }
  if (!game.kitCarried) {
    sfx("error");
    toast(T("Çapa rokette — makine dairesindeki alet sandığından al"));
    return;
  }
  equip("kit");
  toast(T("Çapayı eline aldın — kazmak için tekrar tıkla"));
});
addEventListener("load", focusGame);

function toggleEsc() {
  if (mode !== "play") return;
  if (!$("settingsScreen").classList.contains("hidden")) {
    $("settingsClose").click();
    return;
  }
  if (winOpen || fly) return;
  if (upgOpen) {
    closeUpg();
    return;
  }
  if (commOpen) {
    closeComm();
    return;
  }
  if (capOpen) {
    closeCapsule();
    return;
  }
  if (o2Fill) {
    stopO2Fill(false);
    return;
  }
  if (repairOpen) {
    closeRepair();
    return;
  }
  if (rocketOpen) {
    closeRocket();
    return;
  }
  if (marketOpen) {
    closeMarket();
    return;
  }
  if (bedOpen) {
    if (game.sleeping) wakeUp(T("Uyandın"));
    else closeBed();
    return;
  }
  paused = !paused;
  $("pauseScreen").classList.toggle("hidden", !paused);
  if (paused) renderPause();
  if (!paused) focusGame();
}
$("pResume").onclick = () => {
  paused = false;
  $("pauseScreen").classList.add("hidden");
  focusGame();
};
$("pSave").onclick = () => {
  openSaveName();
};
$("pSettings").onclick = () => openSettings();
$("pMenu").onclick = () => {
  paused = false;
  $("pauseScreen").classList.add("hidden");
  clearTimeout(toast._h);
  $("toast").style.opacity = 0;
  mode = "menu";
  insideRocket = false;
  storyReset();
  if (bookOpen) closeBook();
  if (commOpen) closeComm();
  $("commBadge").classList.add("hidden");
  resetStormFx();
  setAlert("stormBanner");
  setAlert("radiationBanner");
  ["hud", "inv", "stats", "hint", "quest", "stormBanner", "radiationBanner"].forEach((id) =>
    $(id).classList.add("hidden"),
  );
  $("menuScreen").classList.remove("hidden");
  refreshContinueButton();
};

function openSaveName() {
  $("saveNameInput").value = "";
  $("saveNameScreen").classList.remove("hidden");
  setTimeout(() => $("saveNameInput").focus(), 50);
}
$("saveNameOk").onclick = () => {
  doSave($("saveNameInput").value.trim());
  $("saveNameScreen").classList.add("hidden");
  focusGame();
};
$("saveNameCancel").onclick = () => {
  $("saveNameScreen").classList.add("hidden");
  focusGame();
};

$("mNew").onclick = () => {
  sfx("click");
  ensureAudio();
  ngOpen();
};
$("ngCancel").onclick = () => {
  sfx("click");
  ngClose();
};
$("ngGo").onclick = () => ngGo();
$("introSkipBtn").onclick = () => endIntro();
/* ============== GÖREV YAPILANDIRMASI ==============
   görev hedefi → fırlatma aracı ve yörünge → uzay aracı alt sistemleri
   → bilim aletleri → kaynak kontrolü (kütle, güç, bütçe, veri, iletişim, zaman)
   → simülasyon → fırlatma. Tasarım oyunun kendisini etkiler.
   Sayılar oyun için basitleştirilmiş kurgusal değerlerdir. */
const MD_OBJ = [
  {
    id: "hab",
    nm: T("Yaşanabilirlik araştırması"),
    d: T(
      "Mars'ta bir insanın hayatta kalıp kalamayacağını ölç. Fırtına, radyasyon ve yaşam desteği raporları daha değerli.",
    ),
    sci: { storm: 1.3, radiation: 1.3, life: 1.4 },
  },
  {
    id: "geo",
    nm: T("Jeoloji ve nadir mineraller"),
    d: T("Kayaçları ve bilinmeyen mineralleri incele. Numune ve nadir taş raporları daha değerli."),
    sci: { geo: 1.5, rare: 1.6, meteor: 1.2 },
  },
  {
    id: "bio",
    nm: T("Uzun süreli yaşam testi"),
    d: T("Mars toprağında besin üretimini dene. Tarım ve yaşam desteği raporları daha değerli."),
    sci: { agri: 2, life: 1.2 },
  },
];
const MD_DIFF = [
  { id: "easy", nm: T("Kolay"), budget: 760 },
  { id: "normal", nm: T("Normal"), budget: 600 },
  { id: "hard", nm: T("Zor"), budget: 500 },
  { id: "sandbox", nm: "Serbest (sandbox)", budget: Infinity },
];
const MD_LV = [
  {
    id: "lv1",
    nm: T("Orta sınıf roket"),
    cap: 16,
    cost: 150,
    rel: 0.94,
    d: T("Ucuz ama taşıma kapasitesi sınırlı."),
  },
  { id: "lv2", nm: T("Ağır roket"), cap: 24, cost: 240, rel: 0.97, d: T("Dengeli kapasite ve maliyet.") },
  {
    id: "lv3",
    nm: T("Süper ağır roket"),
    cap: 36,
    cost: 380,
    rel: 0.98,
    d: T("Her şeyi taşır ama bütçeyi zorlar."),
  },
];
const MD_TRJ = [
  {
    id: "fast",
    nm: T("Hızlı transfer"),
    days: 214,
    m: 6,
    c: 20,
    d: T("Daha çok yakıt (kütle) gerekir; mürettebat Mars'a erzakı dolu varır."),
  },
  {
    id: "eco",
    nm: T("Ekonomik transfer"),
    days: 259,
    m: 2,
    c: 0,
    d: T("Az yakıt gerekir ama yolculuk uzar: erzak ve oksijen eksik başlar."),
  },
];
const MD_LIFE = [
  { id: 15, nm: "15 sol", c: 0, d: T("Kısa görev: bütçe dostu, az erzak.") },
  { id: 25, nm: "25 sol", c: 40, d: T("Orta süre: ek erzak paketi.") },
  { id: 40, nm: "40 sol", c: 85, d: T("Uzun görev: bol erzak, yüksek maliyet.") },
];
// alt sistemler: m = kütle (t), c = maliyet (M$), p = güç tüketimi (kW), g = güç üretimi (kW)
const MD_SUB = {
  power: {
    nm: T("Güç sistemi"),
    why: T(
      "Tüm sistemler elektrik ister. Güneş panelleri fırtınada tozla kaplanır; radyoizotop jeneratör (RTG) hep aynı gücü verir ama ağır ve pahalıdır.",
    ),
    o: [
      {
        id: "sol",
        nm: T("Güneş panelleri"),
        m: 1.0,
        c: 20,
        g: 6,
        d: T("Hafif ve ucuz; fırtınada üretim düşer."),
      },
      {
        id: "sol2",
        nm: T("Geniş güneş panelleri"),
        m: 1.6,
        c: 40,
        g: 9,
        d: T("Daha çok güç; fırtınada yine düşer."),
      },
      {
        id: "rtg",
        nm: T("Radyoizotop jeneratör (RTG)"),
        m: 2.2,
        c: 95,
        g: 5.5,
        d: T("Fırtınadan etkilenmez; ağır ve pahalı."),
      },
    ],
  },
  battery: {
    nm: T("Batarya"),
    why: T("Batarya, güneş paneli üretimi düştüğünde (fırtına) sistemleri ayakta tutar."),
    o: [
      { id: "b1", nm: T("Standart batarya"), m: 0.4, c: 8, d: T("Fırtınada kısa süre idare eder.") },
      { id: "b2", nm: T("Büyük batarya"), m: 0.9, c: 22, d: T("Fırtınada güç kaybının yarısını karşılar.") },
    ],
  },
  life: {
    nm: T("Yaşam desteği"),
    why: T(
      "Oksijen tüpünün kapasitesini ve kendini yenileme hızını belirler. Daha iyi sistem daha çok güç ve kütle ister.",
    ),
    o: [
      {
        id: "ls1",
        nm: T("Standart O₂ tüpü"),
        m: 2.0,
        c: 30,
        p: 1.5,
        tank: 400,
        regen: 1,
        d: T("Temel kapasite."),
      },
      {
        id: "ls2",
        nm: T("Genişletilmiş tüp"),
        m: 2.8,
        c: 55,
        p: 1.8,
        tank: 560,
        regen: 1,
        d: T("%40 daha fazla oksijen."),
      },
      {
        id: "ls3",
        nm: T("Kapalı döngü rejeneratör"),
        m: 3.2,
        c: 90,
        p: 2.6,
        tank: 460,
        regen: 1.8,
        d: T("Tüp neredeyse 2 kat hızlı dolar."),
      },
    ],
  },
  struct: {
    nm: T("Yapı ve koruma"),
    why: T(
      "Gövde zırhı fırtınada motorun bozulma olasılığını azaltır. Zırh ağırdır; fırlatma aracının kapasitesini zorlar.",
    ),
    o: [
      { id: "st1", nm: T("Hafif gövde"), m: 4.0, c: 40, armor: 0, d: T("Fırtınada motor arıza riski %60.") },
      { id: "st2", nm: T("Takviyeli gövde"), m: 5.2, c: 75, armor: 1, d: T("Arıza riski %35 ile başlar.") },
      {
        id: "st3",
        nm: T("Ağır zırhlı gövde"),
        m: 6.6,
        c: 120,
        armor: 2,
        d: T("Arıza riski %15 ile başlar."),
      },
    ],
  },
  comms: {
    nm: T("İletişim"),
    why: T(
      "Anten, günde Dünya'ya gönderilebilecek veri miktarını (MB/sol) ve yanıt süresini belirler. Bilim aletlerinin ürettiği veri bu kapasiteyi aşarsa bilimin bir kısmı kaybolur.",
    ),
    o: [
      {
        id: "cm1",
        nm: T("Düşük kazançlı anten"),
        m: 0.3,
        c: 10,
        p: 0.4,
        cap: 40,
        reply: 1.5,
        relay: false,
        d: T("Ucuz; az veri, yavaş yanıt."),
      },
      {
        id: "cm2",
        nm: T("Yüksek kazançlı anten"),
        m: 0.7,
        c: 30,
        p: 0.9,
        cap: 120,
        reply: 1,
        relay: false,
        d: T("Dengeli seçim."),
      },
      {
        id: "cm3",
        nm: T("Anten + Mars yörüngesinde röle uydusu"),
        m: 1.6,
        c: 85,
        p: 1.0,
        cap: 320,
        reply: 0.75,
        relay: true,
        d: T("Çok veri, hızlı yanıt; fırtınada bile gönderim yapılır."),
      },
    ],
  },
  avionics: {
    nm: T("Aviyonik ve yönelim kontrolü"),
    why: T("Araç bilgisayarı ve yönelim kontrolü; gelişmiş sistem tarayıcının menzilini artırır."),
    o: [
      {
        id: "av1",
        nm: T("Standart bilgisayar"),
        m: 0.3,
        c: 10,
        p: 0.4,
        scan: 1,
        d: T("Temel tarayıcı menzili."),
      },
      {
        id: "av2",
        nm: T("Gelişmiş bilgisayar + yıldız izleyici"),
        m: 0.5,
        c: 30,
        p: 0.7,
        scan: 1.35,
        d: T("Tarayıcı menzili %35 artar."),
      },
    ],
  },
};
const MD_INS = [
  {
    id: "met",
    nm: T("Meteoroloji istasyonu"),
    m: 0.15,
    p: 0.2,
    c: 12,
    data: 15,
    sci: { storm: 1.3 },
    d: T("Fırtına uyarısı 30 sn daha erken gelir."),
  },
  {
    id: "rad",
    nm: T("Radyasyon dedektörü"),
    m: 0.1,
    p: 0.15,
    c: 10,
    data: 10,
    sci: { radiation: 1.3 },
    d: T("Radyasyon uyarısı 30 sn daha erken gelir."),
  },
  {
    id: "spec",
    nm: T("Kayaç spektrometresi"),
    m: 0.4,
    p: 0.6,
    c: 35,
    data: 60,
    sci: { geo: 1.5 },
    d: T("Numune raporlarının bilim değeri %50 artar."),
  },
  {
    id: "gpr",
    nm: T("Zemin radarı"),
    m: 0.5,
    p: 0.5,
    c: 30,
    data: 45,
    sci: { rare: 1.3 },
    d: T("Bilinmeyen taşları %80 daha uzaktan bulursun."),
  },
  {
    id: "green",
    nm: T("Sera modülü"),
    m: 1.2,
    p: 1.0,
    c: 40,
    data: 8,
    sci: { agri: 1.3 },
    d: T("Bitkiler %50 daha hızlı büyür."),
  },
  {
    id: "cam",
    nm: T("Panoramik kamera"),
    m: 0.2,
    p: 0.3,
    c: 15,
    data: 90,
    all: 1.15,
    d: T("Tüm raporların bilim değeri %15 artar; çok veri üretir."),
  },
];
const MD_BASE = { m: 3, c: 100, p: 1, data: 5 };
const MD_STEPS = [
  { id: "obj", nm: T("Görev hedefi") },
  { id: "launch", nm: T("Fırlatma ve yörünge") },
  { id: "craft", nm: T("Uzay aracı") },
  { id: "ins", nm: T("Bilim ve iletişim") },
  { id: "review", nm: T("Simülasyon ve fırlatma") },
  { id: "rank", nm: T("Rekorlar") },
];
const MD_KEY = "uzay_oyunu_designs_v1",
  LB_KEY = "uzay_oyunu_leaderboard_v1";
function mdDefault() {
  return {
    obj: "hab",
    diff: "normal",
    life: 25,
    lv: "lv2",
    trj: "fast",
    power: "sol",
    battery: "b1",
    life_s: "ls1",
    struct: "st1",
    comms: "cm2",
    avionics: "av1",
    ins: ["met", "spec"],
    sims: [],
  };
}
let MD = null,
  PENDING_DESIGN = null,
  PENDING_NAME = "";
{
  const _ngs = newGameState;
  newGameState = function () {
    const g = _ngs();
    try {
      applyDesign(g);
    } catch (e) {
      console.warn(e);
    }
    return g;
  };
}
const mdFind = (arr, id) => arr.find((x) => x.id === id) || arr[0];
function mdSubOpt(k, D) {
  return mdFind(MD_SUB[k].o, D[k === "life" ? "life_s" : k]);
}
/* kaynak hesabı */
function mdCalc(D) {
  const lv = mdFind(MD_LV, D.lv),
    trj = mdFind(MD_TRJ, D.trj),
    dif = mdFind(MD_DIFF, D.diff),
    life = mdFind(MD_LIFE, D.life);
  const subs = Object.keys(MD_SUB).map((k) => mdSubOpt(k, D)),
    ins = MD_INS.filter((i) => D.ins.includes(i.id));
  const mass =
    MD_BASE.m + trj.m + subs.reduce((a, o) => a + (o.m || 0), 0) + ins.reduce((a, o) => a + o.m, 0);
  const cost =
    MD_BASE.c +
    lv.cost +
    trj.c +
    life.c +
    subs.reduce((a, o) => a + (o.c || 0), 0) +
    ins.reduce((a, o) => a + o.c, 0);
  const pgen = subs.reduce((a, o) => a + (o.g || 0), 0),
    puse = MD_BASE.p + subs.reduce((a, o) => a + (o.p || 0), 0) + ins.reduce((a, o) => a + o.p, 0);
  const data = MD_BASE.data + ins.reduce((a, o) => a + o.data, 0),
    cm = mdSubOpt("comms", D),
    cap = cm.cap;
  const issues = [];
  if (mass > lv.cap)
    issues.push({
      k: "mass",
      t: Tf(
        `Kütle {0} t, fırlatma aracının kapasitesi {1} t. Daha güçlü bir roket seç ya da kütleyi azalt.`,
        [fmtN(mass), lv.cap],
      ),
    });
  if (puse > pgen)
    issues.push({
      k: "power",
      t: Tf(`Güç tüketimi {0} kW, üretim {1} kW. Güç sistemini büyüt ya da alet çıkar.`, [
        fmtN(puse),
        fmtN(pgen),
      ]),
    });
  if (cost > dif.budget)
    issues.push({
      k: "budget",
      t: Tf(`Maliyet {0} M$, bütçe {1} M$. Daha ucuz bileşenler seç.`, [Math.round(cost), dif.budget]),
    });
  const warns = [];
  if (data > cap)
    warns.push({
      k: "data",
      t: Tf(
        `Aletler günde {0} MB veri üretiyor, anten {1} MB gönderebiliyor. Bilimin yaklaşık %{2}'i kaybolacak.`,
        [data, cap, Math.round((1 - cap / data) * 100)],
      ),
    });
  if (!ins.length) warns.push({ k: "ins", t: T("Hiç bilim aleti yok: görev bilim değeri düşük olur.") });
  if (pgen - puse < 1 && mdSubOpt("power", D).id !== "rtg")
    warns.push({ k: "pmargin", t: T("Güç payı çok az: fırtınada güneş panelleri yetersiz kalabilir.") });
  return {
    lv,
    trj,
    dif,
    life,
    ins,
    mass,
    cost,
    pgen,
    puse,
    data,
    cap,
    issues,
    warns,
    valid: D.diff === "sandbox" ? true : !issues.length,
  };
}
/* tasarımın oyuna etkileri */
function mdFx(D) {
  const c = mdCalc(D),
    ls = mdSubOpt("life", D),
    st = mdSubOpt("struct", D),
    cm = mdSubOpt("comms", D),
    av = mdSubOpt("avionics", D),
    pw = mdSubOpt("power", D),
    bt = mdSubOpt("battery", D);
  const has = (id) => D.ins.includes(id);
  const sci = {};
  const add = (o) => {
    for (const k in o) sci[k] = (sci[k] || 1) * o[k];
  };
  add(mdFind(MD_OBJ, D.obj).sci);
  c.ins.forEach((i) => i.sci && add(i.sci));
  return {
    tankMax: ls.tank,
    regen: ls.regen,
    solar: pw.id !== "rtg",
    stormRegen: pw.id === "rtg" ? 1 : bt.id === "b2" ? 0.6 : 0.2,
    armor0: st.armor,
    replyMul: cm.reply,
    relay: cm.relay,
    commsCap: cm.cap,
    dataGen: c.data,
    dataFactor: Math.min(1, cm.cap / c.data),
    sci,
    sciAll: has("cam") ? 1.15 : 1,
    scanMul: av.scan * (has("gpr") ? 1.8 : 1),
    growMul: has("green") ? 1.5 : 1,
    stormWarn: has("met") ? 30 : 0,
    radWarn: has("rad") ? 30 : 0,
    lifetime: +D.life,
    days: mdFind(MD_TRJ, D.trj).days,
    eco: D.trj === "eco",
  };
}
const FX0 = {
  tankMax: 400,
  regen: 1,
  solar: false,
  stormRegen: 1,
  armor0: 0,
  replyMul: 1,
  relay: false,
  commsCap: 120,
  dataGen: 80,
  dataFactor: 1,
  sci: {},
  sciAll: 1,
  scanMul: 1,
  growMul: 1,
  stormWarn: 0,
  radWarn: 0,
  lifetime: 0,
  days: 214,
  eco: false,
};
function desFx() {
  return (game && game.design && game.design.fx) || FX0;
}
function applyDesign(g) {
  if (!PENDING_DESIGN) return;
  const D = PENDING_DESIGN,
    fx = mdFx(D),
    c = mdCalc(D);
  g.design = {
    D: JSON.parse(JSON.stringify(D)),
    fx,
    calc: {
      mass: c.mass,
      cap: c.lv.cap,
      cost: c.cost,
      budget: c.dif.budget,
      pgen: c.pgen,
      puse: c.puse,
      data: c.data,
    },
    sim: D.sims.length ? D.sims[D.sims.length - 1] : null,
  };
  g.o2Tank = fx.tankMax;
  if (PENDING_NAME) g.name = PENDING_NAME;
  if (g.rk) g.rk.armor = Math.max(g.rk.armor || 0, fx.armor0);
  const lifeExtra = { 15: 0, 25: 1, 40: 2 }[fx.lifetime] || 0;
  g.stock.water += lifeExtra * 4;
  g.stock.potato += lifeExtra * 3;
  g.stock.medkit += lifeExtra;
  if (fx.eco) {
    g.stock.water = Math.max(2, g.stock.water - 3);
    g.stock.potato = Math.max(2, g.stock.potato - 2);
    g.o2Tank = Math.round(fx.tankMax * 0.7);
  }
}
/* bilim çarpanı (rapor yanıtında) */
function desSciMul(types) {
  const fx = desFx();
  let m = 0,
    n = 0;
  for (const t in types) {
    const k = types[t].length;
    m += (fx.sci[t] || 1) * k;
    n += k;
  }
  return (n ? m / n : 1) * fx.sciAll * fx.dataFactor;
}
/* ---------- simülasyon: 200 görev ---------- */
function mdSimulate(D) {
  const c = mdCalc(D),
    fx = mdFx(D),
    N = 200;
  let ok = 0,
    sciSum = 0;
  const fails = { launch: 0, engine: 0, o2: 0, supply: 0 };
  const R = rng(Date.now() % 100000);
  const brk = [0.6, 0.35, 0.15, 0][fx.armor0];
  for (let i = 0; i < N; i++) {
    if (R() > c.lv.rel) {
      fails.launch++;
      continue;
    }
    let alive = true,
      engineOk = true;
    const storms = Math.floor((fx.lifetime - 2) / 5) + 1;
    for (let s = 0; s < storms; s++) {
      if (R() < brk * (s === 0 ? 1 : 0.6)) {
        if (R() < 0.05 + (fx.armor0 ? 0 : 0.04)) {
          engineOk = false;
          break;
        }
      }
    }
    if (!engineOk) {
      fails.engine++;
      alive = false;
    }
    const o2Risk = Math.max(
      0,
      0.09 -
        (fx.tankMax - 400) / 2000 -
        (fx.regen - 1) * 0.06 +
        (fx.eco ? 0.05 : 0) +
        (fx.solar ? (1 - fx.stormRegen) * 0.05 : 0),
    );
    if (alive && R() < o2Risk) {
      fails.o2++;
      alive = false;
    }
    const supRisk = Math.max(
      0,
      0.07 -
        ({ 15: 0, 25: 0.04, 40: 0.07 }[fx.lifetime] || 0) +
        (fx.eco ? 0.05 : 0) -
        (fx.growMul > 1 ? 0.04 : 0),
    );
    if (alive && R() < supRisk) {
      fails.supply++;
      alive = false;
    }
    if (alive) ok++;
    const sci = (60 + c.ins.length * 18) * fx.sciAll * fx.dataFactor * (alive ? 1 : 0.35) * (0.8 + R() * 0.4);
    sciSum += sci;
  }
  return {
    t: Date.now(),
    p: Math.round((ok / N) * 100),
    sci: Math.round(sciSum / N),
    fails,
    cost: Math.round(c.cost),
    mass: +c.mass.toFixed(1),
  };
}
function mdSimExplain(s) {
  const L = [];
  if (s.fails.launch)
    L.push(
      Tf(`{0} simülasyonda fırlatma başarısız oldu: fırlatma aracının güvenilirliği bunu belirler.`, [
        s.fails.launch,
      ]),
    );
  if (s.fails.engine)
    L.push(
      Tf(`{0} simülasyonda fırtına motoru onarılamaz şekilde bozdu: gövde zırhı bu riski düşürür.`, [
        s.fails.engine,
      ]),
    );
  if (s.fails.o2)
    L.push(Tf(`{0} simülasyonda oksijen yetmedi: yaşam desteği ve güç sistemi bunu etkiler.`, [s.fails.o2]));
  if (s.fails.supply)
    L.push(
      Tf(`{0} simülasyonda erzak bitti: görev süresi, transfer yörüngesi ve sera modülü bunu etkiler.`, [
        s.fails.supply,
      ]),
    );
  if (!L.length) L.push(T("Simülasyonların hiçbirinde ciddi bir arıza görülmedi."));
  return L;
}
/* ---------- tasarım kodu ve kayıt ---------- */
function mdCode(D) {
  const o = {
    o: D.obj,
    d: D.diff,
    l: D.life,
    v: D.lv,
    t: D.trj,
    p: D.power,
    b: D.battery,
    s: D.life_s,
    x: D.struct,
    c: D.comms,
    a: D.avionics,
    i: D.ins,
  };
  try {
    return "ARES-" + btoa(JSON.stringify(o)).replace(/=+$/, "");
  } catch (e) {
    return "";
  }
}
function mdFromCode(code) {
  try {
    const s = code.trim().replace(/^ARES-/, "");
    const o = JSON.parse(atob(s + "===".slice((s.length + 3) % 4)));
    const D = mdDefault();
    Object.assign(D, {
      obj: o.o,
      diff: o.d,
      life: +o.l,
      lv: o.v,
      trj: o.t,
      power: o.p,
      battery: o.b,
      life_s: o.s,
      struct: o.x,
      comms: o.c,
      avionics: o.a,
      ins: Array.isArray(o.i) ? o.i : [],
    });
    return D;
  } catch (e) {
    return null;
  }
}
function mdSaved() {
  try {
    return JSON.parse(localStorage.getItem(MD_KEY)) || [];
  } catch (e) {
    return [];
  }
}
function mdSave(D) {
  const L = mdSaved();
  L.unshift({ t: Date.now(), code: mdCode(D), p: D.sims.length ? D.sims[D.sims.length - 1].p : null });
  try {
    localStorage.setItem(MD_KEY, JSON.stringify(L.slice(0, 8)));
  } catch (e) {}
}
function lbLoad() {
  try {
    return JSON.parse(localStorage.getItem(LB_KEY)) || [];
  } catch (e) {
    return [];
  }
}
function lbAdd(e) {
  const L = lbLoad();
  L.push(e);
  L.sort((a, b) => b.score - a.score);
  try {
    localStorage.setItem(LB_KEY, JSON.stringify(L.slice(0, 15)));
  } catch (e2) {}
}
/* ---------- arayüz: yeni görev ekranı (standart / özel) ---------- */
const NG = { name: "", diff: "normal", intro: true };
function ngOpen() {
  NG.intro = settings.intro !== false;
  NG.diff = ["easy", "normal", "hard"].includes(settings.diff) ? settings.diff : "normal";
  $("menuScreen").classList.add("hidden");
  const S = $("ngScreen");
  S.classList.remove("hidden", "ng-out");
  ngRender();
  S.classList.remove("ng-in");
  void S.offsetWidth;
  S.classList.add("ng-in");
  clearTimeout(S._t);
  S._t = setTimeout(() => S.classList.remove("ng-in"), 1200);
  setTimeout(() => {
    const n = $("ngName");
    if (n) n.focus();
  }, 60);
}
function ngClose() {
  const S = $("ngScreen");
  if (S.classList.contains("ng-out")) return;
  S.classList.add("ng-out");
  setTimeout(() => {
    S.classList.add("hidden");
    S.classList.remove("ng-out");
    $("menuScreen").classList.remove("hidden");
  }, 260);
}
const NG_DIFF_INFO = {
  easy: {
    tag: T("Mars'a ilk adım"),
    d: T(
      "Mars'a yeni gelenler için. Kaynaklar daha yavaş tükenir, tehlikeler daha hafif vurur ve yaralar daha çabuk iyileşir. Keşfetmeye ve öğrenmeye odaklan.",
    ),
  },
  normal: {
    tag: T("Dengeli görev"),
    d: T(
      "Oyunun tasarlandığı denge. Hayatta kalmak için yemeğini, suyunu ve oksijenini planlaman gerekir ama küçük hatalara yer vardır.",
    ),
  },
  hard: {
    tag: T("Deneyimli komutan"),
    d: T(
      "Her kaynak değerlidir. Açlık, susuzluk ve oksijen daha hızlı düşer; fırtınalar, radyasyon ve meteorlar daha sert vurur, iyileşme yavaşlar.",
    ),
  },
};
function ngRows(id) {
  const D = DIFF[id] || DIFF.normal;
  const R = [
    [T("Açlık hızı"), "food", 0],
    [T("Susuzluk hızı"), "water", 0],
    [T("Oksijen tüketimi"), "o2", 0],
    [T("Radyasyon hasarı"), "rad", 1],
    [T("Fırtına etkisi"), "storm", 2],
    [T("Meteor hasarı"), "met", 1],
    [T("İyileşme hızı"), "regen", 3],
  ];
  return R.map(([nm, k, t]) => {
    const v = D[k],
      n = Math.round(Math.abs(v - 1) * 100),
      good = t === 3 ? v > 1 : v < 1,
      bad = t === 3 ? v < 1 : v > 1;
    const txt =
      n === 0
        ? T("Standart")
        : t === 0 || t === 3
          ? v > 1
            ? Tf(`%{0} daha hızlı`, [n])
            : Tf(`%{0} daha yavaş`, [n])
          : t === 1
            ? v > 1
              ? Tf(`%{0} daha fazla`, [n])
              : Tf(`%{0} daha az`, [n])
            : v > 1
              ? Tf(`%{0} daha güçlü`, [n])
              : Tf(`%{0} daha zayıf`, [n]);
    return { nm, k, w: Math.round(Math.min(1, v / 1.6) * 100), cls: good ? "good" : bad ? "bad" : "", txt };
  });
}
function ngRender() {
  const D = mdDefault(),
    c = mdCalc(D),
    best = lbLoad()[0];
  const diffs = MD_DIFF.filter((d) => d.id !== "sandbox");
  if (!DIFF[NG.diff]) NG.diff = "normal";
  const prev = Tf(
    `<h4>Görev özeti</h4><p>ARES-1 Mars'a doğru yola çıkıyor. İnişten sonra hayatta kal, keşfet ve bulgularını Dünya'ya raporla.</p>
      <dl class="ng-dl"><dt>Fırlatma aracı</dt><dd>{0}</dd><dt>Transfer</dt><dd>{1} · {2} gün</dd><dt>Güç</dt><dd>{3}</dd>
      <dt>Yaşam desteği</dt><dd>{4}</dd><dt>Gövde</dt><dd>{5}</dd><dt>İletişim</dt><dd>{6}</dd>
      <dt>Bilim aletleri</dt><dd>{7}</dd><dt>Görev süresi</dt><dd>{8} sol</dd></dl>`,
    [
      c.lv.nm,
      c.trj.nm,
      c.trj.days,
      mdSubOpt("power", D).nm,
      mdSubOpt("life", D).nm,
      mdSubOpt("struct", D).nm,
      mdSubOpt("comms", D).nm,
      c.ins.map((i) => i.nm).join(", "),
      D.life,
    ],
  );
  const lvl = { easy: 1, normal: 2, hard: 3 };
  $("ngBody").innerHTML = Tf(
    `<div class="ng-left">
      <label class="ng-lbl">Görev adı</label><input class="md-in ng-name" id="ngName" maxlength="24" placeholder="ARES-1" value="{0}">
      <label class="ng-lbl">Zorluk</label>
      <div class="ng-diffs">{1}</div>
      <div class="ng-dbox" data-lv="{2}"><p id="ngDesc">{3}</p>
        <div class="ng-rows">{4}</div>
      </div>
      <div class="ng-tg"><span><b>Açılış hikâyesi</b><small>Görev başlamadan önce ARES-1 sinemasını oynat.</small></span><div class="m2-tg {5}" id="ngIntro" role="switch"></div></div>
    </div>
    <div class="ng-right">{6}{7}</div>`,
    [
      escH(NG.name),
      diffs
        .map(
          (d) =>
            `<button class="ng-df ${NG.diff === d.id ? "on" : ""}" data-d="${d.id}" data-lv="${lvl[d.id]}"><span class="ng-pips"><i></i><i></i><i></i></span><b>${d.nm}</b><small>${NG_DIFF_INFO[d.id].tag}</small></button>`,
        )
        .join(""),
      lvl[NG.diff],
      NG_DIFF_INFO[NG.diff].d,
      ngRows(NG.diff)
        .map(
          (r) =>
            `<div class="ng-row" data-k="${r.k}"><span>${r.nm}</span><div class="ng-bar"><i class="${r.cls}" style="width:${r.w}%"></i><u></u></div><em class="${r.cls}">${r.txt}</em></div>`,
        )
        .join(""),
      NG.intro ? "on" : "",
      prev,
      best
        ? `<div class="ng-best"><span>En iyi puan</span><b>${best.score}</b><em>${best.grade}</em></div>`
        : "",
    ],
  );
  const B = $("ngBody");
  $("ngName").oninput = (e) => {
    NG.name = e.target.value;
  };
  B.querySelectorAll("[data-d]").forEach(
    (b) =>
      (b.onclick = () => {
        if (NG.diff === b.dataset.d) return;
        NG.diff = b.dataset.d;
        sfx("click");
        ngDiffUpdate();
      }),
  );
  $("ngIntro").onclick = () => {
    NG.intro = !NG.intro;
    sfx("click");
    $("ngIntro").classList.toggle("on", NG.intro);
  };
}
function ngDiffUpdate() {
  const B = $("ngBody"),
    lvl = { easy: 1, normal: 2, hard: 3 }[NG.diff];
  B.querySelectorAll("[data-d]").forEach((b) => b.classList.toggle("on", b.dataset.d === NG.diff));
  const box = B.querySelector(".ng-dbox");
  box.dataset.lv = lvl;
  const ds = $("ngDesc");
  ds.classList.remove("ng-fade");
  void ds.offsetWidth;
  ds.textContent = NG_DIFF_INFO[NG.diff].d;
  ds.classList.add("ng-fade");
  ngRows(NG.diff).forEach((r) => {
    const row = B.querySelector(`.ng-row[data-k="${r.k}"]`);
    const bar = row.querySelector("i"),
      em = row.querySelector("em");
    bar.style.width = r.w + "%";
    bar.className = r.cls;
    em.className = r.cls;
    em.textContent = r.txt;
    em.classList.remove("ng-pop");
    void em.offsetWidth;
    em.classList.add("ng-pop");
  });
}
function ngGo() {
  settings.intro = NG.intro;
  if (NG.diff !== "sandbox") settings.diff = NG.diff;
  saveSettings();
  PENDING_NAME = NG.name.trim();
  const S = $("ngScreen");
  if (S.classList.contains("ng-out")) return;
  S.classList.add("ng-out", "ng-launch");
  setTimeout(() => {
    S.classList.remove("ng-out", "ng-launch");
    MD = mdDefault();
    MD.diff = "normal";
    MD.sims.push(mdSimulate(MD));
    S.classList.add("hidden");
    mdLaunch();
  }, 420);
}
function mdLaunch() {
  const c = mdCalc(MD);
  if (!c.valid) return;
  mdSave(MD);
  PENDING_DESIGN = JSON.parse(JSON.stringify(MD));
  $("ngScreen").classList.add("hidden");
  sfx("click");
  ensureAudio();
  if (settings.intro === false) startNewGame();
  else startIntro();
}
/* ---------- görev sonu: puan, rapor ve analiz ---------- */
function missionScore() {
  const g = game,
    C = commState(),
    des = g.design,
    fx = desFx();
  const sol = gameDayNumber(),
    log = C.log || [];
  const breaks = log.filter((o) => o.type === "engine_fail").length,
    crit = log.filter((o) => o.type === "life").length;
  const success = 300 + Math.round((Math.min(g.quest, QUESTS.length) / QUESTS.length) * 120);
  const science = Math.min(300, Math.round((C.sci || 0) * 1.2));
  let eff = 0,
    time = 0;
  const why = [];
  if (des) {
    const bm = isFinite(des.calc.budget) ? Math.max(0, 1 - des.calc.cost / des.calc.budget) : 0,
      mm = Math.max(0, 1 - des.calc.mass / des.calc.cap);
    eff = Math.round(bm * 120 + mm * 80);
    time = fx.lifetime ? (sol <= fx.lifetime ? 100 : Math.max(0, 100 - (sol - fx.lifetime) * 10)) : 50;
    if (fx.dataFactor < 1)
      why.push(
        Tf(`Aletlerin ürettiği veri anten kapasitesini aştı; bilimin %{0}'i Dünya'ya ulaşamadı.`, [
          Math.round((1 - fx.dataFactor) * 100),
        ]),
      );
    if (fx.lifetime && sol > fx.lifetime)
      why.push(
        Tf(`Görev planlanan {0} solu {1} sol aştı: erzak ve bütçe zorlandı.`, [
          fx.lifetime,
          sol - fx.lifetime,
        ]),
      );
  }
  if (crit > 0)
    why.push(
      Tf(`{0} kez kritik yaşam değeri kaydedildi: oksijen, su veya yiyecek tükenmeye yaklaştı.`, [crit]),
    );
  if ((C.sci || 0) < SCI_GOAL * 0.5)
    why.push(
      T(
        "Bilim hedefinin yarısına ulaşılmadı: daha çok rapor göndermek ve hedefe uygun gözlem yapmak puanı artırır.",
      ),
    );
  const total = success + science + eff + time;
  const grade = total >= 800 ? "S" : total >= 660 ? "A" : total >= 520 ? "B" : total >= 380 ? "C" : "D";
  return {
    parts: [
      [T("Görev başarısı"), success],
      [T("Bilim değeri"), science],
      [T("Kaynak verimliliği"), eff],
      [T("Zaman yönetimi"), time],
    ],
    total,
    grade,
    why,
  };
}

function startNewGame() {
  game = newGameState();
  currentSaveId = null;
  storyReset();
  p.x = game.px;
  p.y = game.py;
  enterPlanet(START_PLANET, true);
  resetStormFx();
  startWake();
  $("wkSkip").innerHTML = T("Atla") + " <kbd>Space</kbd>";
}
$("mContinue").onclick = () => {
  const saves = loadSaves().sort((a, b) => b.updatedAt - a.updatedAt);
  if (saves.length) loadGame(saves[0].id);
};
$("mSaves").onclick = () => {
  renderSavesList();
  $("savesScreen").classList.remove("hidden");
};
$("savesClose").onclick = () => {
  $("savesScreen").classList.add("hidden");
  focusGame();
};
$("mSettings").onclick = () => openSettings();

let settingsFrom = "menu",
  setTab = "general";
const SET_DEF = {
  master: 100,
  music: 60,
  sfx: 80,
  amb: 80,
  fps: 60,
  vsync: true,
  fullscreen: false,
  lang: "tr",
  diff: "normal",
  hints: true,
  intro: true,
  autosave: 3,
  floats: true,
  ultra: true,
  parts: 1,
  atmos: true,
  grain: true,
  hud: 1,
  map: 1,
  subs: 1,
  story: true,
  shake: 100,
  noflash: false,
  contrast: false,
};
const LANGS = [
  ["tr", "🇹🇷", "Türkçe", T("Turkish")],
  ["en", "🇬🇧", "English", T("İngilizce")],
  ["de", "🇩🇪", "Deutsch", T("Almanca")],
  ["es", "🇪🇸", "Español", T("İspanyolca")],
];
const DIFF = {
  easy: { food: 0.75, water: 0.75, o2: 0.75, rad: 0.6, storm: 0.6, met: 0.7, regen: 1.4 },
  normal: { food: 1, water: 1, o2: 1, rad: 1, storm: 1, met: 1, regen: 1 },
  hard: { food: 1.3, water: 1.3, o2: 1.25, rad: 1.4, storm: 1.4, met: 1.3, regen: 0.7 },
};
function dif() {
  return DIFF[settings.diff] || DIFF.normal;
}
function SHK() {
  return (settings.shake == null ? 100 : settings.shake) / 100;
}
function mapW() {
  return Math.round(Math.min(184, W * 0.24) * (settings.map || 1));
}
const SET_TABS = [
  ["general", "⚙️", T("Genel")],
  ["audio", "🔊", T("Ses")],
  ["video", "🖥️", T("Görüntü")],
  ["ui", "🧭", T("Arayüz")],
  ["access", "♿", T("Erişilebilirlik")],
  ["controls", "⌨️", T("Kontroller")],
];
function setRows(tab) {
  const R = [];
  if (tab === "general") {
    R.push({ sec: T("Dil") }, { lang: 1 });
    R.push(
      { sec: T("Oynanış") },
      {
        k: "diff",
        t: "seg",
        l: T("Zorluk"),
        d: T(
          "Açlık, susuzluk ve oksijen tüketimini; radyasyon, fırtına ve meteor hasarını ve iyileşme hızını belirler.",
        ),
        o: [
          ["easy", T("Kolay")],
          ["normal", T("Normal")],
          ["hard", T("Zor")],
        ],
      },
      {
        k: "hints",
        t: "tg",
        l: T("Etkileşim ipuçları"),
        d: T("Ekranın altındaki “F: topla”, “E: kullan” gibi ipuçlarını göster."),
      },
      {
        k: "floats",
        t: "tg",
        l: T("Hasar ve kazanç sayıları"),
        d: T("Oyuncunun üzerinde beliren +/− sayılarını göster."),
      },
      {
        k: "intro",
        t: "tg",
        l: T("Açılış hikâyesi"),
        d: T("Her yeni görevde ARES-1 açılış sinemasını oynat."),
      },
      {
        k: "autosave",
        t: "seg",
        l: T("Otomatik kayıt"),
        d: T("Görevi belirli aralıklarla kendiliğinden kaydet."),
        o: [
          [0, T("Kapalı")],
          [1, "1 dk"],
          [3, "3 dk"],
          [5, "5 dk"],
        ],
      },
    );
  } else if (tab === "audio") {
    R.push(
      { sec: T("Ses düzeyleri") },
      { k: "master", t: "rg", l: T("Genel ses"), min: 0, max: 100, u: "%" },
      { k: "music", t: "rg", l: T("Müzik"), min: 0, max: 100, u: "%" },
      {
        k: "sfx",
        t: "rg",
        l: T("Efektler"),
        d: T("Çapa, toplama, meteor, telsiz ve arayüz sesleri."),
        min: 0,
        max: 100,
        u: "%",
      },
      {
        k: "amb",
        t: "rg",
        l: T("Ortam sesi"),
        d: T("Rüzgâr ve kum fırtınası uğultusu."),
        min: 0,
        max: 100,
        u: "%",
      },
    );
  } else if (tab === "video") {
    R.push(
      { sec: T("Grafik kalitesi") },
      {
        k: "ultra",
        t: "tg",
        l: T("Ultra grafik (WebGL)"),
        d: T(
          "Ana menü manzarası ve hikâyedeki gezegenler ekran kartıyla işlenir. Zayıf bilgisayarlarda kapatabilirsin.",
        ),
      },
      {
        k: "parts",
        t: "seg",
        l: T("Parçacık yoğunluğu"),
        d: T("Toz, duman, kıvılcım ve patlama parçacıkları."),
        o: [
          [0.4, T("Düşük")],
          [1, T("Orta")],
          [1.5, T("Yüksek")],
        ],
      },
      {
        k: "atmos",
        t: "tg",
        l: T("Atmosfer efektleri"),
        d: T("Ufuk pusu, süzülen toz perdeleri ve havadaki zerreler."),
      },
      { k: "grain", t: "tg", l: T("Film greni"), d: T("Menü ve hikâyede sinematik gren dokusu.") },
    );
    R.push(
      { sec: T("Ekran") },
      { k: "fps", t: "rg", l: T("FPS sınırı"), min: 30, max: 144, u: "" },
      { k: "vsync", t: "tg", l: "VSync", d: T("Ekran yenilemesiyle eşitle.") },
      { k: "fullscreen", t: "tg", l: T("Tam ekran") },
    );
  } else if (tab === "ui") {
    R.push(
      { sec: T("Arayüz") },
      {
        k: "hud",
        t: "seg",
        l: T("Arayüz ölçeği"),
        d: T("Gün kartı, görev kartı, durum barları ve envanter boyutu."),
        o: [
          [0.85, T("Küçük")],
          [1, T("Normal")],
          [1.15, T("Büyük")],
        ],
      },
      {
        k: "map",
        t: "seg",
        l: T("Harita boyutu"),
        o: [
          [0.8, T("Küçük")],
          [1, T("Normal")],
          [1.25, T("Büyük")],
        ],
      },
      {
        k: "subs",
        t: "seg",
        l: T("Altyazı boyutu"),
        d: T("Açılış hikâyesindeki altyazılar."),
        o: [
          [0.85, T("Küçük")],
          [1, T("Normal")],
          [1.3, T("Büyük")],
        ],
      },
      {
        k: "story",
        t: "tg",
        l: T("Hikâye anları"),
        d: T(
          "İlk fırtına, radyasyon, nadir taş gibi anlarda kısa sahne ve iç ses. Kapalıyken yalnızca acil hedef gösterilir.",
        ),
      },
    );
  } else if (tab === "access") {
    R.push(
      { sec: T("Erişilebilirlik") },
      {
        k: "shake",
        t: "rg",
        l: T("Ekran sarsıntısı"),
        d: T("Meteor, fırtına ve patlamalarda kamera sarsıntısının şiddeti."),
        min: 0,
        max: 100,
        u: "%",
      },
      {
        k: "noflash",
        t: "tg",
        l: T("Parlamaları azalt"),
        d: T("Meteor çarpması ve patlamalardaki beyaz ekran parlamalarını yumuşat."),
      },
      {
        k: "contrast",
        t: "tg",
        l: T("Yüksek kontrast"),
        d: T("Arayüz metinlerini ve panelleri daha belirgin yap."),
      },
    );
  } else if (tab === "controls") {
    R.push({ keys: 1 });
  }
  return R;
}
function fmtSet(r, v) {
  if (r.t === "rg") return v + (r.u || "");
  return v;
}
function renderSettings() {
  $("setTabs").innerHTML = SET_TABS.map(
    ([k, ic, n]) =>
      `<button class="${k === setTab ? "on" : ""}" data-k="${k}"><i>${ic}</i><span>${n}</span></button>`,
  ).join("");
  $("setTabs")
    .querySelectorAll("button")
    .forEach(
      (b) =>
        (b.onclick = () => {
          setTab = b.dataset.k;
          sfx("click");
          renderSettings();
        }),
    );
  const B = $("setBody");
  let h = "";
  for (const r of setRows(setTab)) {
    if (r.sec) {
      h += `<div class="m2-sec">${r.sec}</div>`;
      continue;
    }
    if (r.lang) {
      h += `<div class="m2-langs">${LANGS.map(([c, f, n, sub]) => `<button class="m2-lang ${settings.lang === c ? "on" : ""}" data-lang="${c}"><span class="fl">${f}</span><span><b>${n}</b><small>${c === settings.lang ? T("Etkin") : sub}</small></span></button>`).join("")}</div>`;
      continue;
    }
    if (r.keys) {
      h +=
        Tf(`<div class="m2-sec">Klavye</div><div class="m2-keys">`, []) +
        [
          [T("Hareket"), "W A S D"],
          [T("Koş"), "Shift"],
          [T("Etkileşim / rokete gir"), "E"],
          [T("Topla · ek · sula · hasat"), "F"],
          [T("Medikit kullan"), "G"],
          [T("Seramik kalkanı aç / kapat"), "Q"],
          [T("Boş parseldeki kalkanı sök"), "Shift + Q"],
          [T("Rehber kitap"), "R"],
          [T("Çapayla kaz"), T("Sol tık")],
          [T("Eşyayı eline al"), "1 – 7"],
          [T("Merdiven"), "W / S"],
          [T("Duraklat"), "Esc"],
          [T("Hikâyeyi geç"), T("Space (basılı)")],
          [T("Harita"), T("sağ üst")],
        ]
          .map(([a, k]) => `<div><span>${a}</span><kbd>${k}</kbd></div>`)
          .join("") +
        Tf(
          `</div>
      <div class="m2-sec">Dokunmatik</div><div class="m2-keys"><div><span>Hareket</span><kbd>sol joystick</kbd></div><div><span>Eylemler</span><kbd>sağ düğmeler</kbd></div></div>`,
          [],
        );
      continue;
    }
    const v = settings[r.k];
    let ctl = "";
    if (r.t === "rg")
      ctl = `<input type="range" class="m2-range" data-k="${r.k}" min="${r.min}" max="${r.max}" value="${v}" style="--v:${((v - r.min) / (r.max - r.min)) * 100}%"><output>${fmtSet(r, v)}</output>`;
    if (r.t === "tg") ctl = `<div class="m2-tg ${v ? "on" : ""}" data-k="${r.k}" role="switch"></div>`;
    if (r.t === "seg")
      ctl = `<div class="m2-seg">${r.o.map(([ov, ol]) => `<button class="${String(v) === String(ov) ? "on" : ""}" data-k="${r.k}" data-v="${ov}">${ol}</button>`).join("")}</div>`;
    h += `<div class="m2-it"><div><b>${r.l}</b>${r.d ? `<small>${r.d}</small>` : ""}</div><div class="m2-ctl">${ctl}</div></div>`;
  }
  B.innerHTML = h;
  B.querySelectorAll(".m2-range").forEach(
    (el) =>
      (el.oninput = () => {
        const k = el.dataset.k,
          v = +el.value,
          r = setRows(setTab).find((x) => x.k === k);
        settings[k] = v;
        el.style.setProperty("--v", ((v - r.min) / (r.max - r.min)) * 100 + "%");
        el.nextElementSibling.textContent = fmtSet(r, v);
        applySettings(k);
      }),
  );
  B.querySelectorAll(".m2-tg").forEach(
    (el) =>
      (el.onclick = () => {
        const k = el.dataset.k;
        settings[k] = !settings[k];
        el.classList.toggle("on", settings[k]);
        sfx("click");
        applySettings(k);
      }),
  );
  B.querySelectorAll(".m2-seg button").forEach(
    (el) =>
      (el.onclick = () => {
        const k = el.dataset.k,
          raw = el.dataset.v,
          v = isNaN(+raw) ? raw : +raw;
        settings[k] = v;
        el.parentNode.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === el));
        sfx("click");
        applySettings(k);
      }),
  );
  B.querySelectorAll(".m2-lang").forEach(
    (el) =>
      (el.onclick = () => {
        const c = el.dataset.lang;
        if (c === settings.lang) return;
        sfx("click");
        askLang(c);
      }),
  );
}
let _pendLang = null;
function askLang(c) {
  _pendLang = c;
  const L = I18N_UI[c] || I18N_UI.en;
  $("langKick").textContent =
    "ARES-1 · " + ({ tr: "D\u0130L", en: "LANGUAGE", de: "SPRACHE", es: "IDIOMA" }[c] || "LANGUAGE");
  $("langTitle").textContent = L.t;
  $("langMsg").textContent = L.m;
  $("langOk").textContent = L.ok;
  $("langCancel").textContent = L.no;
  $("langScreen").classList.remove("hidden");
}
$("langCancel").onclick = () => {
  _pendLang = null;
  $("langScreen").classList.add("hidden");
};
$("langOk").onclick = () => {
  if (!_pendLang) return;
  settings.lang = _pendLang;
  saveSettings();
  try {
    if (game && mode === "play") {
      doSave(game.name || undefined, true);
      sessionStorage.setItem("uzay_resume", currentSaveId);
    }
  } catch (e) {}
  location.reload();
};
/* dil değişiminden sonra kaldığın göreve otomatik dön */
setTimeout(() => {
  try {
    const id = sessionStorage.getItem("uzay_resume");
    if (id) {
      sessionStorage.removeItem("uzay_resume");
      if (loadSaves().some((x) => x.id === id)) loadGame(id);
    }
  } catch (e) {}
}, 60);
function applySettings(k) {
  saveSettings();
  if (k === "master" || k === "music" || k === "sfx") {
    applyVol();
    ensureAudio();
  }
  if (k === "fullscreen") {
    try {
      settings.fullscreen
        ? document.documentElement.requestFullscreen && document.documentElement.requestFullscreen()
        : document.exitFullscreen && document.exitFullscreen();
    } catch (e) {}
  }
  if (k === "ultra") {
    if (!settings.ultra) {
      GLX.ok = false;
      GLX.tried = true;
    } else {
      GLX.tried = false;
      glxInit();
    }
  }
  applyUiSettings();
}
function applyUiSettings() {
  const ui = $("ui");
  ui.classList.toggle("no-hints", !settings.hints);
  ui.classList.toggle("hi-contrast", !!settings.contrast);
  ["hud", "quest", "stats", "inv"].forEach((id) => {
    const e = $(id);
    if (e) e.style.zoom = settings.hud || 1;
  });
}
function openSettings() {
  settingsFrom = mode === "play" && paused ? "pause" : "menu";
  if (settingsFrom === "pause") $("pauseScreen").classList.add("hidden");
  $("settingsScreen").classList.remove("hidden");
  renderSettings();
}
$("settingsClose").onclick = () => {
  $("settingsScreen").classList.add("hidden");
  if (settingsFrom === "pause" && mode === "play" && paused) {
    $("pauseScreen").classList.remove("hidden");
    renderPause();
  } else focusGame();
};
$("setReset").onclick = () => {
  const l = settings.lang;
  Object.assign(settings, SET_DEF, { lang: l });
  ["master", "ultra", "fullscreen"].forEach(applySettings);
  renderSettings();
  sfx("click");
};
function applySettingsToUI() {
  renderSettings();
}
/* --- duraklatma ekranı --- */
function renderPause() {
  if (!game) return;
  ensureUpg();
  const day = gameDayNumber(),
    wt = game.worldTime,
    hh = marsClock(wt),
    q = QUESTS[Math.min(game.quest, QUESTS.length - 1)];
  $("pSub").textContent =
    "SOL " + day + " · " + hh + " · " + (insideRocket ? T("ROKET İÇİ") : PLANETS[scene].name.toUpperCase());
  const bar = (n, v, c) =>
    `<div class="m2-bar"><span>${n}<b>${Math.round(v)}</b></span><i><em style="width:${Math.max(0, Math.min(100, v))}%;background:${c}"></em></i></div>`;
  const s = curSuit(),
    A = rkArmor(),
    sk = ROCKET_SKINS.find((x) => x.id === game.rk.skin) || ROCKET_SKINS[0];
  const R = upgRes();
  $("pStatus").innerHTML =
    crewCardHTML() +
    Tf(
      `<h4>GÖREV DURUMU</h4>
    <div class="m2-bars">{0}{1}{2}{3}</div>
    <dl class="m2-kv"><dt>Görev</dt><dd>{4}</dd><dt>Kıyafet</dt><dd>{5}</dd>
      <dt>Ana motor</dt><dd style="color:{6}">{7}</dd>
      <dt>Fırtına kalkanı</dt><dd>{8}</dd><dt>Roket boyası</dt><dd>{9}</dd>
      <dt>Kargo</dt><dd>{10} / {11}</dd><dt>Oynama süresi</dt><dd>{12}</dd></dl>
    <h4>KAYNAKLAR</h4>
    <div class="m2-res"><span><img src="{13}">{14}</span><span><img src="{15}">{16}</span><span><i class="ug-au"></i>{17}</span>{18}</div>`,
      [
        bar(T("Can"), game.hp, "linear-gradient(90deg,#ef4444,#f87171)"),
        bar(T("Oksijen"), game.o2, "linear-gradient(90deg,#0ea5e9,#67e8f9)"),
        bar(T("Tokluk"), game.hunger, "linear-gradient(90deg,#f59e0b,#fcd34d)"),
        bar(T("Su"), game.thirst, "linear-gradient(90deg,#3b82f6,#93c5fd)"),
        q ? q.ic + " " + q.t : "—",
        s.name,
        game.repair.state === "ok" ? "#4ade80" : "#ff8a8a",
        game.repair.state === "ok" ? T("Çalışıyor") : T("Arızalı · ") + (game.repair.stage || 0) + "/4",
        A ? T("Seviye ") + A : T("Yok"),
        sk.name,
        Math.min(game.cargo || 0, CFG.cargoGoal),
        CFG.cargoGoal,
        fmtTime(game.playTime || 0),
        itemIconURL("stone"),
        R.stone,
        itemIconURL("star"),
        R.star,
        R.gold,
        RARE_KEYS.map(
          (k) => `<span title="${rareLabel(k)}"><img src="${rareIconURL(k)}">${R[k]}</span>`,
        ).join(""),
      ],
    );
}
$("pBook").onclick = () => {
  paused = false;
  $("pauseScreen").classList.add("hidden");
  openBook();
};
/* --- otomatik kayıt --- */
let _autoT = 0;
function autoSaveTick(dt) {
  if (!game || mode !== "play" || !settings.autosave) return;
  _autoT += dt;
  if (_autoT >= settings.autosave * 60) {
    _autoT = 0;
    try {
      doSave(undefined, true);
    } catch (e) {}
  }
}
/* Dokunmatik joystick */
const pad = $("pad"),
  knob = $("knob");
function joyMove(e) {
  const r = pad.getBoundingClientRect(),
    t = e.touches[0];
  let dx = (t.clientX - r.left - 65) / 45,
    dy = (t.clientY - r.top - 65) / 45;
  const l = Math.hypot(dx, dy);
  if (l > 1) {
    dx /= l;
    dy /= l;
  }
  joy = { x: dx, y: dy };
  knob.style.left = 45 + dx * 45 + "px";
  knob.style.top = 45 + dy * 45 + "px";
  e.preventDefault();
}
function joyEnd() {
  joy = { x: 0, y: 0 };
  knob.style.left = "45px";
  knob.style.top = "45px";
}
pad.addEventListener("touchstart", joyMove, { passive: false });
pad.addEventListener("touchmove", joyMove, { passive: false });
pad.addEventListener("touchend", joyEnd);
$("eBtn").onclick = pressE;
$("fBtn").onclick = pressF;
$("gBtn").onclick = pressG;
$("qBtn").onclick = () => pressQ(false);

/* --- yolculuk animasyonunda kullanılan roket --- */
function storyRocket(x, y, rot, s, flame, smoke, damaged) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  rocketBody({ flame: flame, broken: !!damaged, t: performance.now() / 1000 });
  ctx.restore();
}

/* ============== ZAFER EKRANI ============== */
function showWin() {
  winOpen = true;
  paused = true;
  $("winStats").innerHTML =
    T("Motoru onardın, numuneleri yükledin ve <b>Dünya'ya geri döndün!</b><br><br>") +
    T("⏱ Süre: <b>") +
    fmtTime(game.playTime || 0) +
    "</b><br>" +
    T("🌍 Ziyaret edilen gezegen: <b>") +
    game.visited.length +
    "/" +
    PROG_ORDER.length +
    "</b><br>" +
    T("📦 Getirilen numune: <b>") +
    (game.cargo || 0) +
    T("</b><br>📅 Mars'ta geçen gün: <b>") +
    gameDayNumber() +
    "</b><br>" +
    T("📋 Tamamlanan görev: <b>") +
    game.quest +
    "/" +
    QUESTS.length +
    "</b>";
  $("winStats").innerHTML = $("winStats").innerHTML.replace(
    /[\u{1F300}-\u{1FAFF}\u2300-\u23FF\u2600-\u27BF]\uFE0F?\s*/gu,
    "",
  );
  {
    const S = missionScore(),
      des = game.design;
    const team = (game.name || "").trim() || "ARES-1";
    $("winReport").innerHTML = `<div class="wr-score"><b>${S.total}</b><em>${S.grade}</em></div>
      <div class="wr-parts">${S.parts.map((p) => `<span>${p[0]}</span><b>${p[1]}</b>`).join("")}</div>
      ${S.why.length ? Tf(`<h4 style="margin:6px 0;color:#fff;text-align:left">Görev sonrası analiz</h4><ul class="wr-why">{0}</ul>`, [S.why.map((x) => `<li>${x}</li>`).join("")]) : ""}`;
    if (!game._lbDone) {
      game._lbDone = true;
      lbAdd({ team, score: S.total, grade: S.grade, obj: des ? des.D.obj : "hab", t: Date.now() });
    }
  }
  $("winScreen").classList.remove("hidden");
  sfx("harvest");
  // zafer seslendirmesi kaldırıldı
}
$("winContinue").onclick = () => {
  winOpen = false;
  $("winScreen").classList.add("hidden");
  paused = false;
  focusGame();
  sfx("click");
};
$("winMenu").onclick = () => {
  winOpen = false;
  $("winScreen").classList.add("hidden");
  $("pMenu").click();
};

/* ============== ANA MENÜ ARKA PLANI ============== */
/* --- Mars menü arka planı: kızıl yüzey, ince atmosfer, Phobos --- */
let _mars = null;
function _mkMars() {
  const per = 6,
    w = 384,
    h = 192,
    H1 = (x, y) => {
      const n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
      return n - Math.floor(n);
    };
  const vn = (x, y, p) => {
    const xi = Math.floor(x),
      yi = Math.floor(y),
      u = x - xi,
      v = y - yi,
      s = (a) => a * a * (3 - 2 * a),
      m = (a) => ((a % p) + p) % p;
    const a = H1(m(xi), yi),
      b = H1(m(xi + 1), yi),
      c = H1(m(xi), yi + 1),
      d = H1(m(xi + 1), yi + 1),
      su = s(u),
      sv = s(v);
    return (a + (b - a) * su) * (1 - sv) + (c + (d - c) * su) * sv;
  };
  const fbm = (x, y, p) => {
    let s = 0,
      a = 0.5,
      f = 1;
    for (let o = 0; o < 5; o++) {
      s += a * vn(x * f, y * f, p * f);
      a *= 0.5;
      f *= 2;
    }
    return s;
  };
  const mk = () => {
    const c = document.createElement("canvas");
    c.width = w * 2;
    c.height = h;
    return c;
  };
  const land = mk(),
    cl = mk(),
    L = land.getContext("2d"),
    C = cl.getContext("2d"),
    li = L.createImageData(w, h),
    ci = C.createImageData(w, h);
  for (let y = 0; y < h; y++)
    for (let x = 0; x < w; x++) {
      const nx = (x / w) * per,
        ny = (y / h) * 3,
        i = (y * w + x) * 4,
        lat = Math.abs(y / h - 0.5) * 2;
      const n = fbm(nx, ny, per),
        m = fbm(nx + 7, ny + 3, per),
        d = fbm(nx * 2 + 3, ny * 2, 12),
        t = Math.min(1, n * 0.7 + d * 0.45);
      let r = 150 + t * 74,
        g = 66 + t * 86,
        b = 40 + t * 58;
      const k = Math.max(0, Math.min(0.85, (m - 0.56) * 4));
      r += (74 - r) * k;
      g += (34 - g) * k;
      b += (28 - b) * k;
      if (lat > 0.9) {
        r = g = b = 236;
      }
      li.data[i] = r;
      li.data[i + 1] = g;
      li.data[i + 2] = b;
      li.data[i + 3] = 255;
      const cv = Math.max(0, Math.min(1, (fbm((nx * 4) / 3 + 20, ny * 1.4, 8) - 0.52) * 2.6));
      ci.data[i] = 255;
      ci.data[i + 1] = 228;
      ci.data[i + 2] = 205;
      ci.data[i + 3] = cv * 85;
    }
  L.putImageData(li, 0, 0);
  L.putImageData(li, w, 0);
  C.putImageData(ci, 0, 0);
  C.putImageData(ci, w, 0);
  return { land, cl, w, h };
}
function drawMenuBgOld() {
  const c = mctx,
    PI = Math.PI;
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.globalCompositeOperation = "source-over";
  c.fillStyle = "#05030a";
  c.fillRect(0, 0, W, H);
  const t = performance.now() / 1000;
  c.globalCompositeOperation = "lighter";
  for (let i = 0; i < 18; i++) {
    const f = i / 17,
      x = W * f,
      y = H * (0.78 - 0.68 * f) + Math.sin(i * 1.7) * H * 0.04,
      r = H * (0.17 + 0.06 * Math.sin(i * 2.3));
    const g = c.createRadialGradient(x, y, 0, x, y, r);
    g.addColorStop(0, i % 3 ? "rgba(235,185,160,.07)" : "rgba(255,170,120,.055)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    c.fillStyle = g;
    c.fillRect(x - r, y - r, r * 2, r * 2);
  }
  c.globalCompositeOperation = "source-over";
  for (const s of stars) {
    const x = (s.x * W + t * (1.5 + s.h * 4)) % W,
      y = s.y * H,
      tw = 0.55 + 0.45 * Math.sin(t * 1.6 + s.h * 40),
      sz = 0.6 + s.h * s.h * 2.2,
      a = (0.3 + s.h * 0.7) * tw;
    c.fillStyle =
      s.h > 0.86
        ? "rgba(190,210,255," + a + ")"
        : s.h < 0.14
          ? "rgba(255,200,150," + a + ")"
          : "rgba(255,255,255," + a + ")";
    c.fillRect(x, y, sz, sz);
    if (s.h > 0.95) {
      c.strokeStyle = "rgba(255,225,200," + a * 0.4 + ")";
      c.lineWidth = 0.8;
      c.beginPath();
      c.moveTo(x - 6, y);
      c.lineTo(x + 7, y);
      c.moveTo(x, y - 6);
      c.lineTo(x, y + 7);
      c.stroke();
    }
  }
  /* Mars */
  if (!_mars) _mars = _mkMars();
  const R = Math.max(W, H) * 0.5,
    cx = W * 0.76,
    cy = H + R * 0.3,
    E = _mars,
    N = 130,
    cw = (2 * R) / N,
    off = (t * 2.5) % E.w,
    off2 = (t * 4) % E.w;
  c.save();
  c.beginPath();
  c.arc(cx, cy, R, 0, 7);
  c.clip();
  for (let i = 0; i < N; i++) {
    const l0 = Math.asin(-1 + (2 * i) / N),
      l1 = Math.asin(Math.min(1, -1 + (2 * (i + 1)) / N)),
      dx = cx - R + i * cw;
    c.drawImage(
      E.land,
      off + (l0 / (2 * PI) + 0.5) * E.w,
      E.h * 0.18,
      Math.max(0.4, ((l1 - l0) / (2 * PI)) * E.w),
      E.h * 0.64,
      dx,
      cy - R,
      cw + 0.6,
      R * 2,
    );
    c.drawImage(
      E.cl,
      off2 + (l0 / (2 * PI) + 0.5) * E.w,
      E.h * 0.18,
      Math.max(0.4, ((l1 - l0) / (2 * PI)) * E.w),
      E.h * 0.64,
      dx,
      cy - R,
      cw + 0.6,
      R * 2,
    );
  }
  let g = c.createRadialGradient(cx - R * 0.55, cy - R * 0.75, R * 0.2, cx, cy, R * 1.25);
  g.addColorStop(0, "rgba(10,2,2,0)");
  g.addColorStop(0.55, "rgba(10,2,2,.3)");
  g.addColorStop(1, "rgba(6,1,2,.95)");
  c.fillStyle = g;
  c.fillRect(cx - R, cy - R, R * 2, R * 2);
  g = c.createRadialGradient(cx, cy, R * 0.88, cx, cy, R);
  g.addColorStop(0, "rgba(255,150,100,0)");
  g.addColorStop(1, "rgba(255,170,120,.5)");
  c.fillStyle = g;
  c.fillRect(cx - R, cy - R, R * 2, R * 2);
  c.restore();
  g = c.createRadialGradient(cx, cy, R * 0.99, cx, cy, R * 1.06);
  g.addColorStop(0, "rgba(255,175,125,.6)");
  g.addColorStop(0.45, "rgba(200,160,200,.25)");
  g.addColorStop(1, "rgba(120,160,255,0)");
  c.fillStyle = g;
  c.beginPath();
  c.arc(cx, cy, R * 1.06, 0, 7);
  c.fill();
  c.globalCompositeOperation = "lighter";
  const fx = cx - R * 0.62,
    fy = cy - R * 0.78,
    fr = R * (0.28 + 0.02 * Math.sin(t * 0.7));
  g = c.createRadialGradient(fx, fy, 0, fx, fy, fr);
  g.addColorStop(0, "rgba(255,235,200,.75)");
  g.addColorStop(0.3, "rgba(255,170,100,.28)");
  g.addColorStop(1, "rgba(255,120,60,0)");
  c.fillStyle = g;
  c.fillRect(fx - fr, fy - fr, fr * 2, fr * 2);
  c.globalCompositeOperation = "source-over";
  /* toz sisi */
  g = c.createLinearGradient(0, H * 0.65, 0, H);
  g.addColorStop(0, "rgba(150,60,30,0)");
  g.addColorStop(1, "rgba(150,60,30,.22)");
  c.fillStyle = g;
  c.fillRect(0, H * 0.65, W, H * 0.35);
  /* Phobos */
  const k = (t % 70) / 70,
    mx = W * (1.05 - 1.1 * k),
    my = H * 0.22 - Math.sin(k * PI) * H * 0.06,
    mr = Math.min(W, H) * 0.024;
  c.save();
  c.translate(mx, my);
  c.rotate(t * 0.05);
  g = c.createRadialGradient(-mr * 0.4, -mr * 0.4, mr * 0.2, 0, 0, mr * 1.3);
  g.addColorStop(0, "#b8a89a");
  g.addColorStop(1, "#3e342f");
  c.fillStyle = g;
  c.beginPath();
  c.ellipse(0, 0, mr * 1.3, mr, 0, 0, 7);
  c.fill();
  c.fillStyle = "rgba(50,40,36,.55)";
  for (const [qx, qy, qr] of [
    [0.3, -0.2, 0.3],
    [-0.5, 0.25, 0.22],
    [0.6, 0.35, 0.16],
  ]) {
    c.beginPath();
    c.arc(qx * mr, qy * mr, qr * mr, 0, 7);
    c.fill();
  }
  c.restore();
  const st = (t + 3) % 9;
  if (st < 0.6) {
    const q = st / 0.6,
      x0 = W * 0.08,
      y0 = H * 0.05,
      x1 = W * 0.55,
      y1 = H * 0.34,
      px = x0 + (x1 - x0) * q,
      py = y0 + (y1 - y0) * q,
      g2 = c.createLinearGradient(px - (x1 - x0) * 0.28, py - (y1 - y0) * 0.28, px, py);
    g2.addColorStop(0, "rgba(255,255,255,0)");
    g2.addColorStop(1, "rgba(255,255,255," + (1 - q) + ")");
    c.strokeStyle = g2;
    c.lineWidth = 2;
    c.lineCap = "round";
    c.beginPath();
    c.moveTo(px - (x1 - x0) * 0.28, py - (y1 - y0) * 0.28);
    c.lineTo(px, py);
    c.stroke();
  }
}

/* ============== GÜNCELLEME ============== */
/* ---------- görev adımları: her görev kartında canlı ✓ işaretli kısa yol tarifi ---------- */
const Qs = (k) => game.qstats[k] || 0;
const QSTEPS = {
  mined: [
    [T("Hava kilidinden dışarı çık — <b>E</b>"), () => !insideRocket || Qs("mined") > 0],
    [T("Haritadaki ◆ işaretine yürü"), () => Qs("mined") > 0 || !!nearestPickup()],
    [T("Numunenin yanında <b>F</b>'ye bas"), () => Qs("mined") > 0],
    [T("Toplam <b>5</b> numune topla"), () => Qs("mined") >= 5],
  ],
  kit: [
    [
      T("Merdivenden makine dairesine in — <b>S</b>"),
      () => (insideRocket && ip.deck === 0) || game.kitCarried,
    ],
    [T("<b>ALET SANDIĞI</b> → <b>E</b> → Çapa: <b>Al</b>"), () => !!game.kitCarried],
  ],
  planted: [
    [T("Alet sandığından <b>tohum</b> al"), () => hasSeeds() || Qs("planted") > 0],
    [T("Dışarıda yere <b>sol tıkla</b> — çapayla kaz"), () => farmArr().length > 0],
    [T("Çukurun yanında <b>F</b> ile tohum ek"), () => Qs("planted") > 0],
  ],
  covered: [
    [
      T("Rokete gir → makine dairesi → <b>ALET SANDIĞI</b>"),
      () => capOpen === "kit" || (game.inventory.ceramic || 0) > 0 || Qs("covered") > 0,
    ],
    [T("Seramik kalkan: <b>Al</b>"), () => (game.inventory.ceramic || 0) > 0 || Qs("covered") > 0],
    [T("Dışarıda kalkanı eline al — numara tuşu"), () => heldItemKey() === "ceramic" || Qs("covered") > 0],
    [T("Ekili parselin yanında <b>F</b> — kalkan kurulur ve kapanır"), () => Qs("covered") > 0],
  ],
  domeCycle: [
    [T("Kalkanlı parselin yanına git"), () => !!nearestDome() || Qs("domeCycle") > 0],
    [T("<b>Q</b> ile kalkanı aç"), () => Qs("domeOpen") > 0 || Qs("domeCycle") > 0],
    [T("<b>Q</b> ile yeniden kapat"), () => Qs("domeCycle") > 0],
  ],
  shieldSaved: [
    [
      T("Bitkin kalkanın altında olsun, kalkan kapalı"),
      () => farmArr().some((g) => g && g.g > 0 && domeClosed(g)) || Qs("shieldSaved") > 0,
    ],
    [
      T("Yeşil radyasyon uyarısını bekle (her 3 günde bir)"),
      () => game.radiationActive || Qs("shieldSaved") > 0,
    ],
    [T("Dalga boyunca kalkanı kapalı tut — sen de rokete sığın"), () => Qs("shieldSaved") > 0],
  ],
  drunk: [
    [T("Su şişesini eline al — alttaki numara tuşu"), () => heldItemKey() === "water" || Qs("drunk") > 0],
    [T("<b>F</b> ile iç (ya da roketin mutfağında <b>İç</b>)"), () => Qs("drunk") > 0],
  ],
  reported: [
    [
      T("Rokete gir, komuta güvertesine çık"),
      () => (insideRocket && ip.deck === 2) || commOpen || Qs("reported") > 0,
    ],
    [T("Soldaki <b>İLETİŞİM</b> masasında <b>E</b>"), () => commOpen || Qs("reported") > 0],
    [T("<b>Rapor hazırla</b> → gözlem seç, not yaz → <b>Dünya'ya gönder</b>"), () => Qs("reported") > 0],
  ],
  stormSafe: [
    [
      () => T("Turuncu fırtına uyarısını bekle (Gün 2, ") + marsClock(STORM_START - STORM_WARN) + ")",
      () => stormFx.phase !== "none" || Qs("stormSafe") > 0,
    ],
    [
      T("Uyarı çıkınca 45 sn içinde rokete gir"),
      () => (stormFx.phase !== "none" && insideRocket) || Qs("stormSafe") > 0,
    ],
    [T("Fırtına bitene kadar içeride kal"), () => Qs("stormSafe") > 0],
  ],
  repaired: [
    [T("Fırtınanın motoru bozması — duman çıkar"), () => !!game.stormBroke],
    ["Makine dairesi → <b>ANA MOTOR</b> → <b>E</b>", () => repairOpen || Qs("repaired") > 0],
    [T("4 onarım aşamasını tamamla"), () => Qs("repaired") > 0],
  ],
  radSafe: [
    [T("Yeşil radyasyon uyarısını bekle (Gün 3)"), () => game.radiationActive || Qs("radSafe") > 0],
    [
      "Rokete gir — en iyisi uyku kabininde uyumak",
      () => (game.radiationActive && insideRocket) || Qs("radSafe") > 0,
    ],
    [T("Dalga geçene kadar içeride kal"), () => Qs("radSafe") > 0],
  ],
  harvested: [
    [
      T("Halka sarıya dönene kadar bekle (sulamak hızlandırır)"),
      () => farmArr().some((g) => g && g.g >= CFG.farmGrow) || Qs("harvested") > 0,
    ],
    [
      T("Kalkanı <b>Q</b> ile aç"),
      () => farmArr().some((g) => g && g.g >= CFG.farmGrow && !(g.cov && g.shut)) || Qs("harvested") > 0,
    ],
    [T("<b>F</b> ile hasat et"), () => Qs("harvested") > 0],
  ],
  replyRead: [
    [T("Dünya'nın yanıtını bekle (~½ sol)"), () => commState().inbox.some((m) => m.kind === "reply")],
    [T("Komuta güvertesi → <b>İLETİŞİM</b> → <b>E</b>"), () => commOpen || Qs("replyRead") > 0],
    [T("Gelen kutusu → <b>YANIT</b> etiketli mesajı aç"), () => Qs("replyRead") > 0],
  ],
  rotSample: [
    [
      T("Çürük patates çantanda olsun (hasattan çıkar)"),
      () => (game.inventory.rotten || 0) > 0 || Qs("rotSample") > 0,
    ],
    [
      T("Rokete gir, komuta güvertesine çık"),
      () => (insideRocket && ip.deck === 2) || marketOpen || Qs("rotSample") > 0,
    ],
    ["<b>Kargo terminali</b> → <b>E</b>", () => marketOpen || Qs("rotSample") > 0],
    [T("Çürük patates → <b>Dünya'ya gönder</b>"), () => Qs("rotSample") > 0],
  ],
  rotAnalysis: [
    [T("Laboratuvar inceliyor — kısa sürede yanıt gelir"), () => !!commState().flags.ana],
    [
      T("Komuta güvertesi → <b>İLETİŞİM</b> → <b>E</b>"),
      () => (commOpen && commState().flags.ana) || Qs("rotAnalysis") > 0,
    ],
    [T("Gelen kutusu → <b>ANALİZ</b> mesajı: çürümenin nedeni"), () => Qs("rotAnalysis") > 0],
  ],
  measured: [
    [
      T("Alet sandığından <b>radyasyon ölçeri</b> al"),
      () => (game.inventory.radmeter || 0) > 0 || Qs("measured") > 0,
    ],
    [T("Ölçeri eline al — numara tuşu"), () => heldItemKey() === "radmeter" || Qs("measured") > 0],
    [T("Toprağa <b>sol tıkla</b> — 3 farklı yer"), () => Qs("measured") >= 3],
  ],
  cleanHarvest: [
    [
      T("Yeşil bayraklı yer bul (1,0 µSv/h altı)"),
      () => (game.radMarks || []).some((m) => m.u < SOIL_SAFE) || Qs("cleanHarvest") > 0,
    ],
    [
      "Oraya kaz ve tohum ek",
      () => farmArr().some((g) => g && g.g > 0 && !plotRots(g)) || Qs("cleanHarvest") > 0,
    ],
    [T("Sula, büyüt ve sağlıklı hasat al"), () => Qs("cleanHarvest") > 0],
  ],
  gold: [
    [T("Meteor düşmesini bekle — uğultu ve gölge"), () => Qs("gold") > 0],
    [T("Kraterin çevresindeki sarı parçaları <b>F</b> ile topla (3)"), () => Qs("gold") >= 3],
  ],
  rare: [
    [
      T("Alet sandığından <b>jeolog kazmasını</b> al"),
      () => (game.inventory.pick || 0) > 0 || Qs("rare") > 0,
    ],
    [T("Roketten uzaklaş, haritadaki <b>?</b> işaretine git"), () => Qs("rare") > 0 || !!nearRareNode(200)],
    [T("Taşın yanında <b>F</b> — kazmayla 3 vuruşta kır"), () => Qs("rare") > 0],
  ],
  rockSent: [
    [T("Bilinmeyen taşı çapayla çıkar"), () => Qs("rare") > 0 || Qs("rockSent") > 0],
    [T("Rokete gir → komuta güvertesi → <b>Kargo terminali</b>"), () => marketOpen || Qs("rockSent") > 0],
    [T("<b>ANALİZ İÇİN</b> satırında <b>Analize gönder</b>"), () => Qs("rockSent") > 0],
  ],
  radSuit: [
    [T("Malzeme topla: 8 metal, 1 ⭐, 2 olivin"), () => canPay(SUITS[2].cost) || Qs("radSuit") > 0],
    [T("Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b>"), () => upgOpen || Qs("radSuit") > 0],
    [T("Kıyafet setleri → <b>Öncü Mk-II</b> → Üret ve giy"), () => Qs("radSuit") > 0],
  ],
  armor: [
    [T("Malzeme topla: 10 altın, 3 titanyum"), () => canPay(ARMOR[0].c) || Qs("armor") > 0],
    [
      T("Atölye → <b>Roket geliştirme</b> sekmesi"),
      () => (upgOpen && upgTab === "rocket") || Qs("armor") > 0,
    ],
    [T("<b>Titanyum Plakalar</b> → <b>Kur</b>"), () => Qs("armor") > 0],
  ],
  suit: [
    [T("Yaşam güvertesi → <b>FABRİKASYON ATÖLYESİ</b> → <b>E</b>"), () => upgOpen || Qs("suit") > 0],
    [T("Kıyafet setleri → <b>Kaşif Mk-I</b> → Üret ve giy"), () => Qs("suit") > 0],
  ],
  loaded: [
    ["Numune topla (metal = 1, ⭐ = 2)", () => Qs("loaded") > 0 || sampleCount() > 0],
    [T("Roketin yanında <b>F</b> ile kargoya yükle (10)"), () => Qs("loaded") >= 10],
  ],
  traveled: [
    [T("Komuta güvertesi → <b>NAVİGASYON</b> → <b>E</b>"), () => rocketOpen || Qs("traveled") > 0],
    [T("<b>EVE DÖN</b>'e bas"), () => Qs("traveled") > 0],
  ],
};
function questStepsHTML(q) {
  const L = QSTEPS[q.k];
  if (!L) return "";
  let cur = 0;
  for (let j = L.length - 1; j >= 0; j--) {
    let ok = false;
    try {
      ok = !!L[j][1]();
    } catch (e) {}
    if (ok) {
      cur = j + 1;
      break;
    }
  }
  return (
    '<div class="qs-l">' +
    L.map((s, j) => {
      const t = typeof s[0] === "function" ? s[0]() : s[0];
      return (
        '<div class="qs ' +
        (j < cur ? "ok" : j === cur ? "cur" : "") +
        '"><i>' +
        (j < cur ? "✓" : j + 1) +
        "</i><span>" +
        t +
        "</span></div>"
      );
    }).join("") +
    "</div>"
  );
}
let _qsLast = "";
function refreshQuestSteps(force) {
  if (!game || game.quest >= QUESTS.length) return;
  const h = questStepsHTML(QUESTS[game.quest]);
  if (!h || (!force && h === _qsLast)) return;
  _qsLast = h;
  $("qHow").innerHTML = h;
}

/* ---------- UYKU KAPSÜLÜ (yaşam güvertesi) ----------
   Yatay kapsül: kaide + beyaz kabuk + dolgulu iç yatak + menteşeli cam kapak.
   Kapak uyurken kapanır, uyanınca açılır; cam, içindeki astronotun üstüne çizilir. */
const POD = { x0: -168, x1: -92, o: 1 };
function podOpenTarget() {
  if (game.wake) {
    const T = game.wake.t;
    return T < 2.0 ? 0 : Math.min(1, (T - 2.0) / 0.6);
  }
  return game.sleeping ? 0 : 1;
}
function drawPodBase(t) {
  const F = DECKS[1].floor,
    C = DECKS[1].ceil,
    x0 = POD.x0,
    x1 = POD.x1,
    cx = (x0 + x1) / 2,
    L = x1 - x0;
  const tgt = podOpenTarget();
  if (game.wake) POD.o = tgt;
  else POD.o += (tgt - POD.o) * 0.08;
  // nişin arka duvarı + dolap + fotoğraf + lamba (eski ranzanın yerine)
  ctx.fillStyle = "#2a2f47";
  rrp(x0 - 2, C + 22, L + 4, F - C - 24, 4);
  ctx.fill();
  ctx.fillStyle = "#4e5578";
  rrp(x0 + 2, C + 26, 22, 32, 2);
  ctx.fill();
  ctx.strokeStyle = "#20243a";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#ffd34d";
  ctx.fillRect(x0 + 19, C + 40, 2, 5);
  ctx.fillStyle = "#fff";
  rrp(x0 + 30, C + 28, 18, 14, 1);
  ctx.fill();
  ctx.fillStyle = "#5ab0f0";
  ctx.fillRect(x0 + 32, C + 30, 14, 10);
  ctx.fillStyle = "#2f7d4f";
  ctx.fillRect(x0 + 32, C + 36, 14, 4);
  ctx.fillStyle = "#9aa3bf";
  rrp(x1 - 16, C + 30, 12, 5, 2);
  ctx.fill();
  const lamp = ctx.createRadialGradient(x1 - 10, C + 36, 1, x1 - 10, C + 36, 26);
  lamp.addColorStop(0, "rgba(255,230,170,.4)");
  lamp.addColorStop(1, "rgba(255,230,170,0)");
  ctx.fillStyle = lamp;
  ctx.beginPath();
  ctx.arc(x1 - 10, C + 36, 26, 0, 7);
  ctx.fill();
  // kaide: ayaklar + LED şerit
  ctx.fillStyle = "#3b4160";
  rrp(x0 + 6, F - 14, L - 12, 12, 3);
  ctx.fill();
  ctx.fillStyle = "#262b40";
  for (const lx of [x0 + 10, x1 - 18]) (rrp(lx, F - 4, 8, 4, 1), ctx.fill());
  const led = game.sleeping ? "rgba(90,160,255," : "rgba(90,220,255,",
    pl = 0.55 + 0.45 * Math.sin(t * (game.sleeping ? 1.4 : 3));
  ctx.fillStyle = led + (0.5 + 0.5 * pl) + ")";
  ctx.shadowColor = "#5ad1ff";
  ctx.shadowBlur = 6;
  rrp(x0 + 12, F - 9, L - 24, 2, 1);
  ctx.fill();
  ctx.shadowBlur = 0;
  // alt kabuk (küvet)
  const sg = ctx.createLinearGradient(0, F - 34, 0, F - 14);
  sg.addColorStop(0, "#f4f6fb");
  sg.addColorStop(0.6, "#c9cfe0");
  sg.addColorStop(1, "#8f97b2");
  ctx.fillStyle = sg;
  ctx.beginPath();
  ctx.moveTo(x0 + 4, F - 30);
  ctx.lineTo(x1 - 4, F - 30);
  ctx.quadraticCurveTo(x1 + 2, F - 30, x1, F - 22);
  ctx.quadraticCurveTo(x1 - 2, F - 14, x1 - 12, F - 14);
  ctx.lineTo(x0 + 12, F - 14);
  ctx.quadraticCurveTo(x0 + 2, F - 14, x0, F - 22);
  ctx.quadraticCurveTo(x0 - 2, F - 30, x0 + 4, F - 30);
  ctx.closePath();
  ctx.fill();
  ctx.strokeStyle = "#5f6886";
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,.7)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x0 + 6, F - 29);
  ctx.lineTo(x1 - 6, F - 29);
  ctx.stroke();
  // turuncu şerit + yan ekran (nabız/uyku dalgası)
  ctx.fillStyle = "#ff8c42";
  ctx.fillRect(x0 + 8, F - 21, L - 16, 2);
  ctx.fillStyle = "#0b1424";
  rrp(cx - 9, F - 27, 18, 9, 2);
  ctx.fill();
  ctx.strokeStyle = "#5ad1ff";
  ctx.lineWidth = 0.9;
  ctx.beginPath();
  for (let i = 0; i <= 16; i++) {
    const xx = cx - 8 + i,
      ph = (i / 16) * 6.283 + t * (game.sleeping ? 1.5 : 4);
    const v = game.sleeping ? Math.sin(ph) * 1.6 : (i % 8 === 4 ? -2.6 : 0) * Math.max(0, Math.sin(t * 6));
    i ? ctx.lineTo(xx, F - 22.5 + v) : ctx.moveTo(xx, F - 22.5 + v);
  }
  ctx.stroke();
  // iç yatak: dolgulu minder + yastık (kapak açıkken görünür)
  ctx.fillStyle = "#2b3f73";
  rrp(x0 + 5, F - 34, L - 10, 7, 3);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,.12)";
  ctx.lineWidth = 1;
  for (let i = 1; i < 6; i++) {
    const xx = x0 + 5 + ((L - 10) * i) / 6;
    ctx.beginPath();
    ctx.moveTo(xx, F - 33);
    ctx.lineTo(xx, F - 28);
    ctx.stroke();
  }
  ctx.fillStyle = "#e9edf7";
  rrp(x0 + 5, F - 37, 16, 7, 3);
  ctx.fill();
  // iç ışık: uyurken yumuşak mavi
  if (POD.o < 0.98 || game.sleeping) {
    const a = (1 - POD.o) * 0.35 + (game.sleeping ? 0.15 : 0);
    const ig = ctx.createRadialGradient(cx, F - 36, 3, cx, F - 36, 44);
    ig.addColorStop(0, "rgba(110,170,255," + a + ")");
    ig.addColorStop(1, "rgba(110,170,255,0)");
    ctx.fillStyle = ig;
    ctx.fillRect(x0, F - 60, L, 40);
  }
  ctx.fillStyle = "#d9dcea";
  ctx.font = "700 7px monospace";
  ctx.textAlign = "center";
  ctx.fillText(T("UYKU KAPSÜLÜ"), cx, C + 16);
  if (game.sleeping && !game.wake) {
    ctx.fillStyle = "rgba(255,255,255,.8)";
    ctx.font = "700 10px sans-serif";
    ctx.fillText("z  z  Z", cx + 10 + Math.sin(t * 2) * 3, F - 62 - ((t * 8) % 12));
  }
}
/* cam kapak: arka uçtan menteşeli, açılınca yukarı kalkar (astronotun üstüne çizilir) */
function drawPodCanopy(t) {
  const F = DECKS[1].floor,
    x0 = POD.x0,
    x1 = POD.x1,
    L = x1 - x0,
    o = Math.max(0, Math.min(1, POD.o));
  const hx = x0 + 3,
    hy = F - 30;
  ctx.save();
  ctx.translate(hx, hy);
  ctx.rotate(-o * 1.05);
  const path = () => {
    ctx.beginPath();
    ctx.moveTo(1, 0);
    ctx.bezierCurveTo(2, -22, L - 12, -24, L - 6, 0);
    ctx.closePath();
  };
  const gg = ctx.createLinearGradient(0, -22, 0, 0);
  gg.addColorStop(0, "rgba(190,235,255,.30)");
  gg.addColorStop(1, "rgba(120,190,240,.12)");
  ctx.fillStyle = gg;
  path();
  ctx.fill();
  if (game.sleeping || o < 0.3) {
    ctx.fillStyle = "rgba(220,240,255," + 0.1 * (1 - o) + ")";
    for (let i = 0; i < 9; i++) {
      const fx = 8 + ((i * 23) % (L - 20)),
        fy = -4 - ((i * 7) % 14);
      ctx.beginPath();
      ctx.arc(fx, fy, 1.4 + (i % 3), 0, 7);
      ctx.fill();
    }
  } // buğu
  ctx.strokeStyle = "rgba(230,245,255,.85)";
  ctx.lineWidth = 1.6;
  path();
  ctx.stroke();
  ctx.strokeStyle = "rgba(255,255,255,.75)";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(10, -12);
  ctx.quadraticCurveTo(L * 0.35, -20, L * 0.55, -17);
  ctx.stroke(); // yansıma
  ctx.fillStyle = "#c9cfe0";
  rrp(-2, -3, L - 2, 4, 2);
  ctx.fill();
  ctx.strokeStyle = "#5f6886";
  ctx.lineWidth = 0.8;
  ctx.stroke(); // kapak çerçevesi
  ctx.restore();
  ctx.fillStyle = "#7f879f";
  ctx.beginPath();
  ctx.arc(hx, hy, 2.2, 0, 7);
  ctx.fill(); // menteşe
}

/* ============== UYANIŞ SAHNESİ ==============
   Yeni oyun roketin uyku kabininde başlar: alarm çalar, kapak açılır, astronot doğrulup
   yataktan zıplar; tam o an "MARS'A ULAŞILDI" kartı belirir. ~7 sn, Space/Esc ile atlanır. */
const WAKE_LEN = 8.2;
let WK_CARD0 = null;
function startWake(kind) {
  const faint = kind === "faint";
  enterRocket();
  clearTimeout(toast._h);
  $("toast").style.opacity = 0;
  ip.deck = 1;
  ip.x = -62;
  ip.y = DECKS[1].floor;
  ip.dir = 1;
  game.wake = { t: 0, cues: {}, faint };
  const card = $("wkCard");
  if (WK_CARD0 == null) WK_CARD0 = card.innerHTML;
  card.innerHTML = faint
    ? '<div class="wk-k">SOL ' +
      gameDayNumber() +
      ' · ARES-1</div><div class="wk-t">' +
      T("KENDİNE GELDİN") +
      '</div><div class="wk-ln"></div>' +
      '<div class="wk-s">' +
      T("UYKU KAPSÜLÜ · YAŞAM GÜVERTESİ") +
      "</div>" +
      '<div class="wk-r"><b>' +
      T("GÖREV KONTROL · TELSİZ") +
      "</b>" +
      T(
        "ARES-1, yaşam değerlerin kritik seviyeye düştü. Kapsülde kendine geldin. Önce yemek, su ve oksijeni toparla.",
      ) +
      "</div>"
    : WK_CARD0;
  document.body.classList.add("story");
  const el = $("wake");
  el.className = "";
  void el.offsetWidth;
  el.classList.add("on");
}
function wakeCue(k, at, fn) {
  const W = game.wake;
  if (!W.cues[k] && W.t >= at) {
    W.cues[k] = 1;
    fn();
  }
}
function updateWake(dt) {
  const W = game.wake;
  if (!W) return;
  W.t += dt;
  for (let i = 0; i < 3; i++)
    wakeCue("b" + i, 0.35 + i * 0.62, () => {
      tone(880, 0.11, "square", 0.045);
      tone(660, 0.11, "square", 0.04, null, 0.14);
    });
  wakeCue("hiss", 2.05, () => {
    noiseBurst(0.55, 0.07, 2200);
    tone(320, 0.4, "sine", 0.03, 520);
  });
  wakeCue("blank", 2.35, () => {
    noiseBurst(0.35, 0.06, 1200);
  });
  wakeCue("step", 3.6, () => {
    tone(140, 0.08, "sine", 0.05, 110);
  });
  wakeCue("jump", 4.05, () => {
    noiseBurst(0.25, 0.05, 900);
    $("wake").classList.add("card");
  });
  wakeCue("land", 4.52, () => {
    tone(85, 0.22, "sine", 0.13, 60);
    noiseBurst(0.18, 0.12, 500);
    shake = Math.max(shake, 5);
  });
  wakeCue("sting", 4.65, () => {
    [392, 523, 784].forEach((f, i) => tone(f, 0.9, "sine", 0.035, null, i * 0.12));
  });
  wakeCue("radio", 5.5, () => {
    noiseBurst(0.2, 0.05, 2600);
    tone(1046, 0.07, "square", 0.02, null, 0.05);
  });
  if (W.t >= WAKE_LEN) endWake();
}
function endWake() {
  if (!game || !game.wake) return;
  const faint = !!game.wake.faint;
  game.wake = null;
  ip.x = -62;
  ip.dir = 1;
  const el = $("wake");
  el.classList.remove("on", "card");
  setTimeout(() => (el.className = "hidden"), 600);
  document.body.classList.remove("story");
  if (faint) {
    toast(T("😵 Bilincini kaybettin, uyku kapsülünde kendine geldin. Kendine dikkat et!"));
    return;
  }
  storyTrigger("start");
}
/* can sıfırlanınca: açık panelleri kapat, uyku kapsülünde uyandır (roketin içinde) */
function faintToPod() {
  game.sleeping = false;
  sleepT = 0;
  stopO2Fill(false);
  try {
    if (upgOpen) closeUpg();
    if (commOpen) closeComm();
    if (capOpen) closeCapsule();
    if (repairOpen) closeRepair();
    if (rocketOpen) closeRocket();
    if (marketOpen) closeMarket();
    if (bedOpen) closeBed();
    if (bookOpen) closeBook();
  } catch (e) {}
  if (radM) {
    radM = null;
    radUIClose();
  }
  brk = null;
  p.action = null;
  p.actionT = 0;
  p.digAt = null;
  p.vx = p.vy = 0;
  p.z = 0;
  p.vz = 0;
  game.hp = 50;
  game.hunger = Math.max(game.hunger, 60);
  game.thirst = Math.max(game.thirst, 60);
  game.o2 = 100;
  p.x = ROCKET.x;
  p.y = ROCKET.y + 118;
  startWake("faint");
  $("wkSkip").innerHTML = T("Atla") + " <kbd>Space</kbd>";
  updateStats();
}
/* yataktan kalkan astronot (drawInterior içinde, roket koordinatlarında)
   evreler: uyku (battaniye altında) → battaniyeyi atıp doğrulma → bacakları kenardan sarkıtma
            → adım atıp zıplama → dizleri kırarak iniş → etrafa bakınma */
function wakePose(T, F) {
  const yM = F - 26,
    ST = F - 45,
    E = (x) => x * x * (3 - 2 * x),
    cl = (x) => Math.max(0, Math.min(1, x)),
    L = (a, b, k) => a + (b - a) * k;
  const H = Math.PI / 2;
  let hx,
    hy,
    r,
    s,
    b,
    f,
    dir = 1,
    air = 0;
  if (T < 2.3) {
    // uyku: sırt üstü, baş yastıkta
    hx = -120;
    hy = yM - 11;
    r = -H;
    s = 0.52;
    b = [0, 0];
    f = [0, 0];
  } else if (T < 3.15) {
    // doğrulma: gövde kalkar, bacaklar yatakta düz kalır
    const k = E(cl((T - 2.3) / 0.85));
    hx = -120;
    hy = L(yM - 11, yM - 5, k);
    r = -H * (1 - k) + 0.06 * Math.sin(k * Math.PI);
    s = L(0.52, 0.62, k);
    b = [H * k, H * k];
    f = [H * k, H * k];
  } else if (T < 3.85) {
    // bacakları kenardan sarkıt, kenara kay
    const k = E(cl((T - 3.15) / 0.7)),
      k2 = E(cl((T - 3.3) / 0.55));
    hx = L(-120, -101, k);
    hy = yM - 5;
    r = -0.05 * k;
    s = L(0.62, 0.78, k);
    b = [L(H, H * 0.92, k), L(H, 0.05, k2)];
    f = [L(H, H * 0.86, k), L(H, -0.08, cl(k2 * 1.15))];
  } else if (T < 4.05) {
    // öne eğil, ön ayağı uzat — adım
    const k = E(cl((T - 3.85) / 0.2));
    hx = L(-101, -96, k);
    hy = L(yM - 5, yM - 9, k);
    r = L(-0.05, 0.32, k);
    s = L(0.78, 0.84, k);
    b = [H * 0.92, L(0.05, -0.2, k)];
    f = [L(H * 0.86, 0.55, k), L(-0.08, 0.25, k)];
  } else if (T < 4.52) {
    // zıplama yayı
    const k = cl((T - 4.05) / 0.47),
      ke = E(k);
    air = Math.sin(Math.PI * k);
    hx = L(-96, -62, ke);
    hy = L(yM - 9, ST + 16, ke) - 30 * air;
    r = L(0.32, 0, ke) + 0.12 * air;
    s = L(0.84, 1, ke);
    b = [L(H * 0.92, -0.25, ke) - 0.2 * air, L(-0.2, -0.9, ke) + 0.5 * (1 - air)];
    f = [L(0.55, 0.35, ke), L(0.25, 0.15, ke)];
  } else if (T < 5.05) {
    // iniş: dizler kırılır, toparlanır
    const k = cl((T - 4.52) / 0.53),
      sq = Math.sin(Math.PI * Math.min(1, k * 1.4)) * (1 - k * 0.4);
    hx = -62;
    hy = ST + 16 + 7 * sq;
    r = 0.14 * sq;
    s = 1;
    b = [L(-0.25, 0, E(k)) + 0.45 * sq, L(-0.9, 0, E(k)) - 0.5 * sq];
    f = [0.5 * sq, -0.45 * sq];
  } else {
    // ayakta: sola sağa bakınır
    hx = -62;
    hy = ST + 16;
    r = 0;
    s = 1;
    b = [0, 0];
    f = [0, 0];
    dir = T > 5.5 && T < 6.3 ? -1 : 1;
  }
  return { hx, hy, r, s, b, f, dir, air, yM };
}
const WAKE_CAM = [
  [0, -130, 298, 4.7],
  [2.25, -128, 296, 4.4],
  [3.9, -110, 290, 3.4],
  [4.6, -84, 288, 2.75],
  [5.8, -74, 288, 2.5],
  [99, -74, 288, 2.5],
];
function wakeCam(T) {
  let i = 0;
  while (i < WAKE_CAM.length - 2 && T >= WAKE_CAM[i + 1][0]) i++;
  const a = WAKE_CAM[i],
    b = WAKE_CAM[i + 1],
    k0 = Math.max(0, Math.min(1, (T - a[0]) / (b[0] - a[0]))),
    k = k0 * k0 * (3 - 2 * k0);
  return { x: a[1] + (b[1] - a[1]) * k, y: a[2] + (b[2] - a[2]) * k, z: a[3] + (b[3] - a[3]) * k };
}
function drawWakeAstro(t) {
  const W = game.wake,
    T = W.t,
    F = DECKS[1].floor,
    P = wakePose(T, F),
    yM = P.yM;
  // okuma lambası: uyanınca titreyerek yanar, ışık konisinde toz zerreleri
  if (T > 1.95) {
    const on = Math.min(1, (T - 1.95) / 0.35) * (T < 2.15 ? (Math.random() < 0.5 ? 0.3 : 1) : 1),
      lx = -101,
      ly = DECKS[1].ceil + 38;
    const cg = ctx.createLinearGradient(lx, ly, lx, yM);
    cg.addColorStop(0, "rgba(255,226,170," + 0.34 * on + ")");
    cg.addColorStop(1, "rgba(255,226,170,0)");
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.moveTo(lx - 5, ly);
    ctx.lineTo(lx + 5, ly);
    ctx.lineTo(lx + 34, yM + 4);
    ctx.lineTo(lx - 62, yM + 4);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "rgba(255,240,210," + 0.55 * on + ")";
    for (let i = 0; i < 14; i++) {
      const ph = (t * 0.07 + i * 0.137) % 1,
        mx = lx - 50 + ((i * 37) % 80) + Math.sin(t * 0.6 + i) * 4,
        my = ly + ph * (yM - ly);
      ctx.fillRect(mx, my, 1.1, 1.1);
    }
  }
  // gece lambası: uyurken ranzaya soğuk mavi ışık
  if (T < 2.6) {
    const a = T < 2 ? 1 : 1 - (T - 2) / 0.6,
      ng = ctx.createRadialGradient(-128, yM - 12, 3, -128, yM - 12, 58);
    ng.addColorStop(0, "rgba(120,170,255," + 0.32 * a + ")");
    ng.addColorStop(1, "rgba(120,170,255,0)");
    ctx.fillStyle = ng;
    ctx.fillRect(-190, yM - 70, 130, 90);
  }
  // uyku baloncukları
  if (T < 1.9) {
    ctx.font = "700 9px Inter,sans-serif";
    ctx.textAlign = "center";
    for (let i = 0; i < 3; i++) {
      const ph = (t * 0.45 + i / 3) % 1;
      ctx.fillStyle = "rgba(220,235,255," + 0.75 * (1 - ph) * (1 - T / 1.9) + ")";
      ctx.fillText(i % 2 ? "z" : "Z", -150 + ph * 10 + Math.sin(ph * 6) * 2, yM - 24 - ph * 26);
    }
  }
  // astronot
  const pd = p.dir,
    psx = p.sx,
    psy = p.sy,
    pw = p.walk;
  p.dir = P.dir;
  p.sx = p.sy = 1;
  p.walk = 0;
  ASTRO_POSE = { b: P.b, f: P.f, ns: true };
  if (P.air > 0 || T >= 4.05) {
    const sh = Math.max(0.25, 1 - P.air * 0.7);
    ctx.fillStyle = "rgba(0,0,0," + 0.3 * sh + ")";
    ctx.beginPath();
    ctx.ellipse(P.hx, F - 2, 22 * P.s * sh, 5 * sh, 0, 0, 7);
    ctx.fill();
  }
  ctx.save();
  ctx.translate(P.hx, P.hy);
  ctx.rotate(P.r);
  ctx.scale(P.s, P.s);
  astronaut(0, -16, false, null, 0);
  // vizör HUD'ı uyanınca yanar
  if (T > 2.1 && T < 4.2) {
    const a = Math.min(1, (T - 2.1) / 0.3) * (1 - Math.max(0, (T - 3.6) / 0.6));
    ctx.fillStyle = "rgba(120,220,255," + 0.35 * a + ")";
    ctx.beginPath();
    ctx.ellipse(8 * P.dir, -58, 9, 6, 0, 0, 7);
    ctx.fill();
  }
  ctx.restore();
  ASTRO_POSE = null;
  p.dir = pd;
  p.sx = psx;
  p.sy = psy;
  p.walk = pw;
  // iniş tozu
  if (T > 4.52 && T < 5.3) {
    const k = (T - 4.52) / 0.78;
    ctx.fillStyle = "rgba(205,210,225," + 0.5 * (1 - k) + ")";
    for (const sd of [-1, 1])
      for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.ellipse(
          -62 + sd * (14 + k * (26 + i * 9)),
          F - 3 - i * 2 * k,
          (5 + k * 9) * (1 - i * 0.2),
          2.5 + k * 2.5,
          0,
          0,
          7,
        );
        ctx.fill();
      }
  }
}
/* ekran üstü: karanlık + kırmızı alarm darbesi, yavaşça aydınlanır */
function drawWakeOverlay() {
  const W = game && game.wake;
  if (!W) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const dark = W.t < 2.2 ? 0.72 - W.t * 0.1 : Math.max(0, 0.5 - (W.t - 2.2) * 0.45);
  if (dark > 0) {
    ctx.fillStyle = "rgba(2,3,8," + dark + ")";
    ctx.fillRect(0, 0, W.t >= 0 ? innerWidth : 0, innerHeight);
  }
  if (W.t < 2.6) {
    const pulse = Math.max(0, Math.sin((W.t * Math.PI) / 0.62)) * 0.32 * (1 - W.t / 2.6);
    const g = ctx.createRadialGradient(
      innerWidth / 2,
      innerHeight / 2,
      innerHeight * 0.15,
      innerWidth / 2,
      innerHeight / 2,
      innerHeight * 0.9,
    );
    g.addColorStop(0, "rgba(255,40,30," + pulse * 0.4 + ")");
    g.addColorStop(1, "rgba(255,30,20," + pulse + ")");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, innerWidth, innerHeight);
  }
}

/* ---------- görev hedefi vurgusu: roket içinde gidilecek istasyon kırmızı parlar ---------- */
function questTargetKey() {
  if (!game || game.wake) return null;
  const S = game.story;
  if (S && S.goal && STORY_DEF[S.goal]) {
    const g = S.goal,
      G = STORY_DEF[g].goal,
      st = goalStep(G);
    if (g === "rot" || g === "ares" || g === "firstRock") return st >= 2 || insideRocket ? "trade" : null;
    if (g === "rotReply" || g === "aresReply" || g === "rockReply") return "comm";
    if (g === "engine") return "engine";
    if (g === "home") return "nav";
  }
  if (game.quest >= QUESTS.length) return null;
  const k = QUESTS[game.quest].k,
    I = game.inventory;
  switch (k) {
    case "kit":
      return game.kitCarried ? null : "kit";
    case "rare":
      return (I.pick || 0) > 0 ? "exit" : "kit";
    case "mined":
    case "harvested":
    case "cleanHarvest":
    case "gold":
    case "loaded":
      return "exit";
    case "planted":
      return hasSeeds() ? "exit" : "kit";
    case "covered":
      return (I.ceramic || 0) > 0 ? "exit" : "kit";
    case "domeCycle":
      return "exit";
    case "shieldSaved":
      return game.radiationActive ? "bed" : null;
    case "drunk":
      return (I.water || 0) > 0 ? null : "kitchen";
    case "reported":
    case "replyRead":
    case "rotAnalysis":
      return "comm";
    case "repaired":
      return game.stormBroke && game.repair.state !== "ok" ? "engine" : null;
    case "radSafe":
      return game.radiationActive ? "bed" : null;
    case "rotSample":
      return (I.rotten || 0) > 0 ? "trade" : "exit";
    case "measured":
      return (I.radmeter || 0) > 0 ? "exit" : "kit";
    case "rockSent":
      return "trade";
    case "suit":
    case "radSuit":
    case "armor":
      return "upg";
    case "traveled":
      return "nav";
  }
  return null;
}
function drawQuestTarget(t) {
  const key = questTargetKey();
  if (!key || ip.climb) return;
  const s = STATIONS.find((q) => q.key === key);
  if (!s) return;
  const pulse = 0.5 + 0.5 * Math.sin(t * 4.2);
  ctx.save();
  if (s.deck === ip.deck) {
    const d = DECKS[s.deck],
      x0 = s.x - s.w - 6,
      w = (s.w + 6) * 2,
      y0 = d.ceil + 6,
      h = d.floor - d.ceil - 6;
    // iç parıltı + parlayan kırmızı çerçeve
    const g = ctx.createRadialGradient(s.x, d.floor - 30, 4, s.x, d.floor - 30, Math.max(w, h) * 0.8);
    g.addColorStop(0, "rgba(255,70,50," + (0.16 + 0.12 * pulse) + ")");
    g.addColorStop(1, "rgba(255,70,50,0)");
    ctx.fillStyle = g;
    rrp(x0, y0, w, h, 8);
    ctx.fill();
    ctx.shadowColor = "rgba(255,60,40,.95)";
    ctx.shadowBlur = 16 + 18 * pulse;
    ctx.strokeStyle = "rgba(255," + Math.round(80 + 60 * pulse) + ",60," + (0.75 + 0.25 * pulse) + ")";
    ctx.lineWidth = 3.6;
    ctx.setLineDash([10, 6]);
    ctx.lineDashOffset = -t * 18;
    rrp(x0, y0, w, h, 8);
    ctx.stroke();
    ctx.setLineDash([]);
    // köşe parantezleri
    ctx.shadowBlur = 10;
    ctx.lineWidth = 4.5;
    ctx.strokeStyle = "#ff6a4a";
    const c = 13;
    for (const [cx, cy, sx, sy] of [
      [x0, y0, 1, 1],
      [x0 + w, y0, -1, 1],
      [x0, y0 + h, 1, -1],
      [x0 + w, y0 + h, -1, -1],
    ]) {
      ctx.beginPath();
      ctx.moveTo(cx, cy + sy * c);
      ctx.lineTo(cx, cy);
      ctx.lineTo(cx + sx * c, cy);
      ctx.stroke();
    }
    // zıplayan ok + etiket
    const ay = y0 + 14 + Math.sin(t * 5) * 4;
    ctx.shadowBlur = 12;
    ctx.fillStyle = "#ff5a3c";
    ctx.beginPath();
    ctx.moveTo(s.x, ay + 14);
    ctx.lineTo(s.x - 12, ay - 3);
    ctx.lineTo(s.x + 12, ay - 3);
    ctx.closePath();
    ctx.fill();
  } else {
    // başka güvertede: oraya çıkan/inen merdiveni vurgula
    const up = s.deck > ip.deck,
      l = LADDERS.find((q) => (up ? q.from === ip.deck : q.to === ip.deck));
    if (!l) {
      ctx.restore();
      return;
    }
    const d = DECKS[ip.deck],
      x0 = l.x - 22,
      w = 44,
      y0 = d.ceil + 6,
      h = d.floor - d.ceil - 6;
    ctx.shadowColor = "rgba(255,60,40,.95)";
    ctx.shadowBlur = 16 + 18 * pulse;
    ctx.strokeStyle = "rgba(255," + Math.round(80 + 60 * pulse) + ",60," + (0.75 + 0.25 * pulse) + ")";
    ctx.lineWidth = 3.6;
    ctx.setLineDash([8, 5]);
    ctx.lineDashOffset = -t * 18;
    rrp(x0, y0, w, h, 6);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "#ff5a3c";
    ctx.shadowBlur = 12;
    for (let i = 0; i < 2; i++) {
      const yy = up ? y0 + h * 0.55 - ((t * 40 + i * 22) % 44) : y0 + h * 0.25 + ((t * 40 + i * 22) % 44),
        a = 0.4 + 0.6 * (1 - ((t * 40 + i * 22) % 44) / 44);
      ctx.globalAlpha = a;
      ctx.beginPath();
      if (up) {
        ctx.moveTo(l.x, yy - 7);
        ctx.lineTo(l.x - 8, yy + 3);
        ctx.lineTo(l.x + 8, yy + 3);
      } else {
        ctx.moveTo(l.x, yy + 7);
        ctx.lineTo(l.x - 8, yy - 3);
        ctx.lineTo(l.x + 8, yy - 3);
      }
      ctx.closePath();
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.shadowBlur = 0;
    ctx.font = "800 14px ui-monospace,monospace";
    ctx.textAlign = "center";
    ctx.fillStyle = "#fff";
    ctx.fillText(up ? "W ▲" : "S ▼", l.x, y0 + 12);
  }
  ctx.restore();
}
/* dışarıdayken: hedef roketin içindeyse roketin üstünde kırmızı işaret */
function drawQuestRocketMark(z) {
  if (!game || insideRocket || story) return;
  const key = questTargetKey();
  if (!key || key === "exit") return;
  if (game.story && game.story.goal) return; // acil hedef oku zaten gösteriliyor
  const t = performance.now() / 1000,
    sx = W / 2 + (ROCKET.x - p.x - cam.ox) * z,
    sy = H / 2 + (ROCKET.y - 150 - p.y - cam.oy) * z;
  if (sx < -40 || sx > W + 40 || sy < -40 || sy > H + 40) return;
  const y = sy - 6 + Math.sin(t * 5) * 5,
    pulse = 0.5 + 0.5 * Math.sin(t * 4.2);
  ctx.save();
  ctx.shadowColor = "#ff4a30";
  ctx.shadowBlur = 10 + 10 * pulse;
  ctx.fillStyle = "#ff5a3c";
  ctx.beginPath();
  ctx.moveTo(sx, y + 11);
  ctx.lineTo(sx - 10, y - 3);
  ctx.lineTo(sx + 10, y - 3);
  ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.font = "800 11px ui-monospace,monospace";
  ctx.textAlign = "center";
  const lb = "E · " + (STATIONS.find((q) => q.key === key) || { name: "" }).name;
  const tw = ctx.measureText(lb).width;
  ctx.fillStyle = "rgba(30,8,6,.8)";
  rrp(sx - tw / 2 - 7, y - 24, tw + 14, 17, 6);
  ctx.fill();
  ctx.strokeStyle = "rgba(255,90,60,.7)";
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.fillStyle = "#ffd9cf";
  ctx.fillText(lb, sx, y - 12);
  ctx.restore();
}

/* ---------- jeolog kazması: yalnızca bilinmeyen/nadir taşları kırar ---------- */
function rrc(c, x, y, w, h, r) {
  c.beginPath();
  c.moveTo(x + r, y);
  c.arcTo(x + w, y, x + w, y + h, r);
  c.arcTo(x + w, y + h, x, y + h, r);
  c.arcTo(x, y + h, x, y, r);
  c.arcTo(x, y, x + w, y, r);
  c.closePath();
}
function drawGeoPick(c, px, py, rot, sc) {
  c.save();
  c.translate(px, py);
  c.rotate(rot);
  c.scale(sc || 1.4, sc || 1.4);
  // sap: grafit/titanyum, belirgin kenar ışığı
  const hg = c.createLinearGradient(-2.8, 0, 2.8, 0);
  hg.addColorStop(0, "#2a2f3b");
  hg.addColorStop(0.35, "#8d97ad");
  hg.addColorStop(0.55, "#c9d0de");
  hg.addColorStop(1, "#3a4150");
  c.fillStyle = hg;
  rrc(c, -2.6, -31, 5.2, 52, 2.2);
  c.fill();
  c.strokeStyle = "#151922";
  c.lineWidth = 1;
  c.stroke();
  c.strokeStyle = "rgba(40,46,60,.35)";
  c.lineWidth = 0.6;
  for (let i = 0; i < 9; i++) {
    c.beginPath();
    c.moveTo(-2.4, -24 + i * 3.4);
    c.lineTo(2.4, -22 + i * 3.4);
    c.stroke();
  }
  // turuncu tutamak sargıları
  for (let i = 0; i < 3; i++) {
    const y = 5 + i * 5;
    const og = c.createLinearGradient(-3.2, 0, 3.2, 0);
    og.addColorStop(0, "#c2410c");
    og.addColorStop(0.45, "#ff9a4d");
    og.addColorStop(1, "#b33a0a");
    c.fillStyle = og;
    rrc(c, -3.3, y, 6.6, 3.8, 1.3);
    c.fill();
    c.strokeStyle = "rgba(70,20,0,.6)";
    c.lineWidth = 0.7;
    c.stroke();
  }
  c.fillStyle = "#9aa3b8";
  rrc(c, -3.2, 20, 6.4, 3.6, 1.5);
  c.fill();
  c.strokeStyle = "#2c3242";
  c.lineWidth = 0.8;
  c.stroke(); // uç kapağı
  // bilezik + LED
  const bg = c.createLinearGradient(-4.6, 0, 4.6, 0);
  bg.addColorStop(0, "#4b5366");
  bg.addColorStop(0.5, "#aab3c7");
  bg.addColorStop(1, "#3b4254");
  c.fillStyle = bg;
  rrc(c, -4.6, -36, 9.2, 8, 2);
  c.fill();
  c.strokeStyle = "#20242f";
  c.lineWidth = 0.9;
  c.stroke();
  const tt = performance.now() / 1000;
  c.fillStyle = "rgba(90,220,255," + (0.7 + 0.3 * Math.sin(tt * 5)) + ")";
  c.shadowColor = "#5ad1ff";
  c.shadowBlur = 6;
  c.fillRect(-3.6, -31.6, 7.2, 1.5);
  c.shadowBlur = 0;
  // baş: önde kıvrık sivri uç, arkada geniş keski ağzı
  const sg = c.createLinearGradient(0, -44, 0, -27);
  sg.addColorStop(0, "#ffffff");
  sg.addColorStop(0.4, "#c3cad9");
  sg.addColorStop(1, "#4d5671");
  c.fillStyle = sg;
  c.beginPath();
  c.moveTo(-17, -39.5); // keski üst köşe
  c.quadraticCurveTo(-6, -42.5, 4, -41); // üst kenar
  c.quadraticCurveTo(18, -39, 28.5, -27); // sivri uca iniş
  c.lineTo(27.2, -26.2); // uç
  c.quadraticCurveTo(17, -33.5, 4, -33.5); // alt kenar
  c.quadraticCurveTo(-6, -33.5, -17, -30); // keski alt köşe
  c.closePath();
  c.fill();
  c.strokeStyle = "#262c3c";
  c.lineWidth = 1.1;
  c.stroke();
  c.fillStyle = "#e9edf5";
  c.beginPath();
  c.moveTo(-17, -39.5);
  c.lineTo(-18.6, -38.6);
  c.lineTo(-18.6, -30.6);
  c.lineTo(-17, -30);
  c.closePath();
  c.fill(); // keski ağzı
  c.strokeStyle = "rgba(255,255,255,.9)";
  c.lineWidth = 1;
  c.beginPath();
  c.moveTo(4, -40.3);
  c.quadraticCurveTo(17, -38.4, 27.4, -27.4);
  c.stroke(); // parlak sırt
  c.strokeStyle = "rgba(30,36,50,.45)";
  c.lineWidth = 0.8;
  c.beginPath();
  c.moveTo(-15, -35);
  c.quadraticCurveTo(4, -37.5, 20, -31);
  c.stroke(); // bilenmiş kenar çizgisi
  c.fillStyle = "#2c3242";
  c.beginPath();
  c.arc(0, -37, 1.4, 0, 7);
  c.fill();
  c.fillStyle = "rgba(255,255,255,.6)";
  c.beginPath();
  c.arc(-0.4, -37.4, 0.5, 0, 7);
  c.fill(); // perçin
  c.restore();
}
function drawPickArt(c) {
  c.save();
  c.rotate(0.7);
  drawGeoPick(c, -3, 9, 0, 0.76);
  c.restore();
}

let brk = null; // kırma sahnesi: {n,t,hits}
function nearRareNode(r) {
  let b = null,
    bd = r || 125;
  for (const n of rareNodes) {
    if (n.taken || n.split) continue;
    const d = Math.hypot(p.x - n.x, p.y - n.y);
    if (d < bd) {
      bd = d;
      b = n;
    }
  }
  return b;
}
function startBreak(n) {
  if (brk) return;
  if (!((game.inventory.pick || 0) > 0)) {
    sfx("error");
    toast(
      T("Bu taşı kırmak için <b>jeolog kazması</b> gerekli — makine dairesindeki <b>alet sandığından</b> al"),
    );
    return;
  }
  if (radM) return;
  const dir = n.x < p.x ? -1 : 1;
  p.dir = dir;
  brk = { n, t: 0, hits: 0, dir, x0: p.x, y0: p.y, tx: n.x - dir * 88, ty: n.y - 22, next: 0.32 };
  sfx("click");
}
function strikeFx(n, i) {
  const now = performance.now() / 1000,
    P = rarePal(n);
  n.hits = i;
  n.hitT = now;
  const hx = n.x - brk.dir * 26,
    hy = n.y - 16;
  burst(hx, hy, 16, "#ffffff", { sp: 260, life: 0.35, size: 2.5, up: 60 });
  burst(hx, hy, 14, P.gl, { sp: 180, life: 0.7, size: 4, up: 90 });
  burst(hx, hy + 10, 10, "#5a3a2e", { sp: 120, life: 0.8, size: 5, up: 50 });
  shake = Math.max(shake, 3 + i * 1.5);
  tone(2600 - i * 200, 0.09, "triangle", 0.07, 1900);
  tone(1750, 0.14, "sine", 0.05, null, 0.01);
  noiseBurst(0.12, 0.2, 3400);
  tone(120, 0.14, "sine", 0.14, 70);
}
function splitFx(n) {
  const now = performance.now() / 1000,
    P = rarePal(n);
  n.split = now;
  n.hits = 3;
  for (let i = 0; i < 3; i++)
    burst(n.x, n.y - 18, 18, i ? P.gl : "#ffffff", { sp: 240 + i * 60, life: 0.9, size: i ? 5 : 3, up: 120 });
  burst(n.x, n.y, 20, "#4a2e25", { sp: 200, life: 1, size: 6, up: 70 });
  shake = Math.max(shake, 9);
  noiseBurst(0.55, 0.22, 4200);
  tone(80, 0.45, "sine", 0.16, 40);
  [1568, 2093, 2637, 3136].forEach((f, i) => tone(f, 0.5, "sine", 0.04, null, 0.08 + i * 0.07));
}
function updateBreak(dt) {
  if (!brk) return;
  const b = brk,
    n = b.n;
  b.t += dt;
  // taşın yanına konumlan
  const k = Math.min(1, b.t / 0.3);
  p.x = b.x0 + (b.tx - b.x0) * k;
  p.y = b.y0 + (b.ty - b.y0) * k;
  p.dir = b.dir;
  p.walk = 0;
  // 3 vuruş: her biri ayrı bir savurma
  if (b.hits < 3 && b.t >= b.next) {
    p.action = "mine";
    p.actionT = 0.62;
    p.actionDur = 0.62;
    b.strikeAt = b.t + 0.35;
    b.next = b.t + 0.72;
    b.hits++;
  }
  if (b.strikeAt && b.t >= b.strikeAt) {
    const i = b.hits;
    b.strikeAt = 0;
    if (i < 3) strikeFx(n, i);
    else splitFx(n);
  }
  if (n.split && !n.flyT && b.t >= b.next + 0.55) {
    n.flyT = performance.now() / 1000;
    tone(880, 0.2, "sine", 0.06, 1760);
  }
  if (n.flyT && performance.now() / 1000 - n.flyT > 0.36) {
    n.fadeEnd = performance.now() / 1000 + 1.6;
    brk = null;
    pickRare(n);
  }
}
/* ============== YERÇEKİMİ ==============
   Mars: 3,72 m/s² = 0,38 g (gerçek değer). Dışarıda adımlar seker, ataletle kayılır, havadayken
   yön değiştirmek zordur; Space ile alçak yerçekimi zıplaması. Roketin içinde yapay yerçekimi (1 g);
   motor arızalanınca jeneratör de durur ve içerisi de Mars yerçekimine düşer.
   Kıyafet dengeleyicileri (st.grav) bu etkiyi azaltır. */
const G_MARS = 3.72 / 9.81,
  G_PX = 900; // 1 g = 900 px/s² (oyun ölçeği)
function cabinGravFail() {
  return !!(game && game.repair && game.repair.state !== "ok");
}
function gravNow() {
  if (!game) return 1;
  if (insideRocket) return cabinGravFail() ? G_MARS : 1;
  return scene === "mars" ? G_MARS : 1;
}
function gravStab() {
  const g = suitSt().grav || 0;
  return Math.max(0, Math.min(0.95, g));
}
function gravLow() {
  return (1 - gravNow()) * (1 - gravStab() * 0.85);
} // 0 = Dünya hissi, ~0,62 = standart kıyafetle Mars
function gravAcc() {
  const G = gravNow();
  return G_PX * (G + (1 - G) * gravStab() * 0.85);
} // dengeleyici "ağırlaştırır"
/* hareket: hedef hıza ataletle yaklaş; havada kontrol zayıf */
function gravMove(o, tvx, tvy, dt) {
  const L = gravLow(),
    air = o.z > 0.5;
  const K = air ? 0.9 + 2.4 * (1 - L) : 3.2 + 11 * (1 - L * 1.05);
  const k = Math.min(1, dt * K);
  o.vx += (tvx - o.vx) * k;
  if (tvy != null) o.vy += (tvy - o.vy) * k;
}
/* sekme ve zıplama (o.z: yerden yükseklik, o.vz: dikey hız) */
function gravHop(o, moving, running, dt, ceil) {
  const L = gravLow(),
    g = gravAcc();
  if (o.z > 0 || o.vz > 0) {
    o.vz -= g * dt;
    o.z += o.vz * dt;
    if (ceil && o.z > ceil) {
      o.z = ceil;
      if (o.vz > 0) {
        o.vz = -o.vz * 0.25;
        tone(140, 0.08, "sine", 0.1, 90);
        shake = Math.max(shake, 2);
      }
    } // tavana kafa çarpması
    if (o.z <= 0) {
      const imp = -o.vz;
      o.z = 0;
      o.vz = 0;
      o.landed = imp;
    }
  } else if (moving && L > 0.05) {
    // yürürken her adım küçük bir sıçrayış
    const h = (running ? 34 : 24) * L;
    o.vz = Math.sqrt(2 * g * h);
    o.z = 0.01;
  }
}
function gravJump(o) {
  if (o.z > 0.5) return false;
  const L = gravLow(),
    g = gravAcc(),
    h = 18 + 72 * L;
  o.vz = Math.sqrt(2 * g * h);
  o.z = 0.01;
  o.jumped = true;
  noiseBurst(0.18, 0.08, 700);
  tone(220, 0.12, "sine", 0.05, 330);
  return true;
}
function gravLand(o, x, y) {
  const imp = o.landed;
  o.landed = 0;
  if (!imp) return;
  const big = imp > 260;
  burst(x, y + 38, big ? 10 : 3, PLANETS[scene] ? PLANETS[scene].dot : "#c98", {
    sp: big ? 90 : 40,
    life: big ? 0.8 : 0.45,
    size: big ? 4 : 3,
    g: 40,
    drag: 2.5,
  });
  p.sx = 1 + (big ? 0.14 : 0.06);
  p.sy = 1 - (big ? 0.14 : 0.06);
  if (big || o.jumped) {
    tone(90, 0.16, "sine", 0.12, 60);
    noiseBurst(0.14, 0.1, 500);
    if (big) shake = Math.max(shake, 2.5);
  }
  o.jumped = false;
}
/* zıplarken bacaklar toplanır; gölge yerde kalır ve yükseldikçe küçülür */
function drawGravShadow(x, y, z) {
  const k = Math.max(0.3, 1 - z / 140);
  ctx.fillStyle = "rgba(0,0,0," + 0.32 * k + ")";
  ctx.beginPath();
  ctx.ellipse(x, y + 44, 24 * k, 7 * k, 0, 0, 7);
  ctx.fill();
}
function drawAstroGrav(x, y, z, running, held, act) {
  if (z > 0.5) {
    drawGravShadow(x, y, z);
    const tuck = Math.min(1, z / 40);
    ASTRO_POSE =
      z > 14
        ? {
            ns: true,
            b: [0.15 + 0.5 * tuck, -0.15 - 0.45 * tuck],
            f: [0.35 + 0.55 * tuck, 0.1 + 0.25 * tuck],
          }
        : { ns: true };
    astronaut(x, y - z, running, held, act);
    ASTRO_POSE = null;
  } else astronaut(x, y, running, held, act);
}
let _gravWas = null;
function updateGravHud() {
  if (!game) return;
  const G = gravNow(),
    el = $("bioGrav");
  if (!el) return;
  const fail = insideRocket && cabinGravFail(),
    stab = gravStab();
  const lbl = insideRocket
    ? fail
      ? T("JENERATÖR ARIZALI")
      : T("YAPAY YERÇEKİMİ")
    : scene === "mars"
      ? T("MARS")
      : T("DÜNYA");
  $("bgVal").textContent = fmtN(G, 2) + " g";
  $("bgLbl").textContent = lbl;
  $("bgFill").style.width = Math.round(G * 100) + "%";
  $("bgStab").textContent =
    stab > 0 && G < 1 ? "⚙ " + (curSuit().gf || "") + " · −%" + Math.round(stab * 85) : "";
  el.classList.toggle("warn", fail);
  el.classList.toggle("low", G < 1 && !fail);
  const key = (insideRocket ? "in" : "out") + (fail ? "F" : "") + (G < 1 ? "L" : "");
  if (_gravWas !== null && key !== _gravWas) {
    if (insideRocket && fail && !_gravWas.includes("F"))
      toast(
        T(
          "⚠️ <b>Yapay yerçekimi jeneratörü durdu</b> — roketin içi de Mars yerçekiminde (0,38 g). Motoru onarınca geri gelir.",
        ),
      );
    else if (insideRocket && !fail && _gravWas === "inFL") toast(T("✅ Yapay yerçekimi yeniden aktif (1 g)"));
  }
  _gravWas = key;
  if (!insideRocket && scene === "mars" && !game._gravTip) {
    game._gravTip = 1;
    setTimeout(
      () =>
        toast(
          T("🪐 <b>Mars yerçekimi: 0,38 g</b> — adımların seker, durması zordur. <b>Space</b> ile zıpla."),
        ),
      900,
    );
  }
}

/* ============== HİKÂYE ANLARI ==============
   Oyunun kritik ilk anlarında (ilk fırtına, ilk radyasyon, en nadir taş…) kısa bir sahne:
   zaman yavaşlar, kamera yaklaşır, astronotun iç sesi 2-3 cümle konuşur, ardından
   görevlerle uyumlu bir ACİL HEDEF verilir. Her an oyunda yalnızca bir kez oynar. */
const ST_ME = "me",
  ST_RADIO = "radio";
const STORY_DEF = {
  start: {
    lines: [
      [ST_ME, T("Uff… Uzun bir uykuydu. ARES-1 yerde, ben de sağ salimim.")],
      [ST_ME, T("Burada hayatta kalmalı, Mars'ı araştırmalı ve sonunda eve dönmeliyim.")],
      [
        ST_ME,
        T(
          "Önce makine dairesindeki alet sandığından ekipmanımı alayım. Sol üstteki görev kartı yolu gösterir.",
        ),
      ],
    ],
  },
  storm: {
    lines: [
      [ST_ME, T("Bu uğultu da ne?… Rüzgâr bir anda döndü!")],
      [ST_ME, T("Kum her yeri yutuyor, önümü göremiyorum… Bu hıza dayanamam.")],
      [ST_ME, T("Bir dahakine bu rüzgâra dayanmak için atölyede kıyafetimi ve roketimi güçlendirmeliyim.")],
      [ST_ME, T("Ama şimdi hemen rokete gitmeliyim!")],
    ],
    goal: {
      t: T("Fırtınadan korun — rokete sığın"),
      to: "rocket",
      done: () => insideRocket || stormFx.phase === "none",
      next: "stormIn",
    },
  },
  stormIn: {
    lines: [
      [ST_ME, T("Kapağı son anda kapattım… Gövde zangır zangır titriyor.")],
      [
        ST_ME,
        T("Dışarıda kalsam rüzgâr beni savururdu. Bir dahakine uyarı kartını görünce erkenden döneceğim."),
      ],
    ],
  },
  stormIn2: {
    lines: [
      [ST_ME, T("Gövde zangır zangır titriyor… Dışarıda kum fırtınası kopmuş.")],
      [ST_ME, T("İyi ki içerideyim. Fırtına bitene kadar buradan çıkmıyorum.")],
    ],
  },
  engine: {
    lines: [
      [ST_RADIO, T("ARES-1, telemetride ana motor arızası görüyoruz!")],
      [ST_ME, T("Fırtına motoru vurmuş… Bu motor olmadan eve dönüş yok.")],
      [ST_ME, T("Fırtına diner dinmez makine dairesine inip onarmalıyım.")],
    ],
    goal: { t: "Ana motoru onar — makine dairesi", done: () => game.repair.state === "ok" },
  },
  rad: {
    lines: [
      [ST_ME, T("Başım dönüyor… Canım neden bu kadar hızlı azalıyor?")],
      [ST_ME, T("Dozimetre çıldırmış — güneş patlaması! Bu radyasyon kıyafetimden geçiyor.")],
      [ST_ME, T("Bir dahakine etkilenmemek için atölyede astronot kıyafetimi geliştirmeliyim.")],
      [ST_ME, T("Şimdilik tek çare roketin kalın gövdesi. Hemen içeri!")],
    ],
    goal: {
      t: "Radyasyondan korun — rokete gir",
      to: "rocket",
      done: () => insideRocket || !game.radiationActive,
      next: "radIn",
    },
  },
  radIn: {
    lines: [
      [ST_ME, T("Gövde zırhı radyasyonu kesiyor, değerler düşüyor.")],
      [ST_ME, T("Dalga geçene kadar içerideyim. En iyisi uyku kabininde dinlenmek.")],
    ],
  },
  radIn2: {
    lines: [
      [ST_ME, T("Dozimetre bir anda yükseldi… Dışarıda güneş patlaması var.")],
      [ST_ME, T("Gövde zırhı beni koruyor. Dalga geçene kadar dışarı çıkmayacağım.")],
    ],
  },
  stormLesson: {
    lines: [
      [ST_ME, T("Motor yeniden çalışıyor… Ama bir sonraki fırtınada yine bozulabilir.")],
      [
        ST_ME,
        T(
          "Atölyedeki roket geliştirmeden gövdeye titanyum zırh takmalıyım. Bunun için altın ve titanyum gerek.",
        ),
      ],
    ],
  },
  radLesson: {
    lines: [
      [ST_ME, T("Canım çok hızlı eridi… Bu standart kıyafet radyasyonu durdurmuyor.")],
      [
        ST_ME,
        T("Atölyede radyasyon katmanlı bir kıyafet üretmeliyim. Bir sonraki dalgaya hazırlıklı olacağım."),
      ],
    ],
  },
  rot: {
    lines: [
      [ST_ME, T("Bu ne?… Patatesler kararmış, yumuşamış.")],
      [ST_ME, T("Suyu da verdim, ışığı da aldı. Sorun toprakta olmalı ama bunu burada çözemem.")],
      [
        ST_ME,
        T(
          "Çürük patates çantamda. Rokete dönüp komuta güvertesindeki kargo terminalinden Dünya'ya göndereyim.",
        ),
      ],
      [ST_ME, T("Laboratuvar inceleyip neden çürüdüğünü bana yazar.")],
    ],
    goal: {
      steps: [
        [T("Rokete dön"), () => insideRocket],
        [T("Komuta güvertesine çık — merdivende W"), () => insideRocket && ip.deck === 2],
        [T("Kargo terminalinde E'ye bas"), () => marketOpen],
        [T("Çürük patates → Dünya'ya gönder"), () => (game.qstats.rotSample || 0) > 0],
      ],
      to: "rocket",
    },
  },
  rotReply: {
    lines: [
      [ST_RADIO, T("ARES-1, burası Dünya laboratuvarı. Patates numunen elimize ulaştı.")],
      [ST_RADIO, T("Çürümenin nedenini bulduk. Raporu gelen kutuna yolladık, hemen oku.")],
    ],
    goal: {
      steps: [
        [T("Rokete dön"), () => insideRocket],
        [T("Komuta güvertesi → İLETİŞİM masası → E"), () => commOpen],
        [T("Gelen kutusu → ANALİZ mesajını aç"), () => (game.qstats.rotAnalysis || 0) > 0],
      ],
      to: "rocket",
    },
  },
  rotLearn: {
    lines: [
      [ST_ME, T("Demek sebep toprağın radyasyonuymuş… Mikrop değil.")],
      [ST_ME, T("Bundan sonra ekmeden önce radyasyon ölçerle toprağı ölçüp yeşil çıkan yere ekeceğim.")],
      [
        ST_ME,
        T(
          "Seramik kalkan da burada işe yaramaz: yalnızca gökten gelen dalgayı keser, topraktaki radyasyonu değil.",
        ),
      ],
    ],
  },
  ares: {
    lines: [
      [ST_ME, T("Aman Allah'ım… Bu taş kendi kendine ışık saçıyor!")],
      [ST_ME, T("Böyle bir mineral hiçbir kayıtta yok. İçinde ne var bunun?")],
      [ST_ME, T("Hemen rokete götürüp kargo terminalinden Dünya'ya analize göndermeliyim!")],
    ],
    goal: {
      steps: [
        [T("Taşı rokete götür"), () => insideRocket],
        [T("Komuta güvertesine çık — merdivende W"), () => insideRocket && ip.deck === 2],
        [T("Kargo terminalinde E'ye bas"), () => marketOpen],
        [
          T("Parlayan taş → Analize gönder"),
          () => {
            const C = commState();
            return !!(C.flags.rock && C.flags.rock.ares);
          },
        ],
      ],
      to: "rocket",
    },
  },
  firstRock: {
    lines: [
      [ST_ME, T("Vay… İçinden ışık sızan bir taş! Böylesini hiç görmedim.")],
      [ST_ME, T("Çok güzel… ama ne olduğunu bilmeden kullanmamalıyım.")],
      [
        ST_ME,
        T("Rokete götürüp kargo terminalinden Dünya'ya analize göndermeliyim. İnceleyip bana bildirsinler."),
      ],
    ],
    goal: {
      steps: [
        [T("Taşı rokete götür"), () => insideRocket],
        [T("Komuta güvertesine çık — merdivende W"), () => insideRocket && ip.deck === 2],
        [T("Kargo terminalinde E'ye bas"), () => marketOpen],
        [
          T("Bilinmeyen taş → Analize gönder"),
          () => {
            const C = commState(),
              k = game.story.rk;
            return !!(C.flags.rock && C.flags.rock[k]);
          },
        ],
      ],
      to: "rocket",
    },
  },
  rockReply: {
    lines: [
      [
        ST_RADIO,
        () =>
          T("ARES-1, numunen laboratuvara ulaştı. Ona bir ad verdik: ") + RARE_DEF[game.story.rk].name + ".",
      ],
      [
        ST_RADIO,
        T("Bileşimi, ne kadar tehlikeli olduğu ve ne işe yarayacağı raporda. Gelen kutuna yolladık."),
      ],
    ],
    goal: {
      steps: [
        [T("Rokete dön"), () => insideRocket],
        [T("Komuta güvertesi → İLETİŞİM masası → E"), () => commOpen],
        [T("Gelen kutusu → ANALİZ mesajını aç"), () => rockMsgRead(game.story.rk)],
      ],
      to: "rocket",
    },
  },
  rockLearn: {
    lines: [
      [ST_ME, () => RARE_DEF[game.story.rk].name + T("… Demek adı buymuş. Artık bu taşı tanıyorum.")],
      [ST_ME, T("Haritada da adıyla görünüyor. Başka bilinmeyen taş bulursam onları da kırıp göndereceğim.")],
    ],
  },
  aresReply: {
    lines: [
      [ST_RADIO, T("ARES-1, gönderdiğin parlayan taşın analizi bitti.")],
      [ST_RADIO, T("Ekip şaşkın — sonuçlar gelen kutunda. Okumadan o taşa dokunma!")],
    ],
    goal: {
      steps: [
        [T("Rokete dön"), () => insideRocket],
        [T("Komuta güvertesi → İLETİŞİM masası → E"), () => commOpen],
        [
          T("Gelen kutusu → Ares taşı analizini aç"),
          () => commState().inbox.some((m) => m.kind === "rock" && m.rk === "ares" && m.read),
        ],
      ],
      to: "rocket",
    },
  },
  seedTip: {
    lines: [
      [ST_ME, T("İlk tohum toprakta… Mars'ta filiz görmek tuhaf olacak.")],
      [ST_ME, T("Ama burada güneş patlamaları var. Radyasyon dalgası gelince bu filiz kavrulur.")],
      [ST_ME, T("Alet sandığında seramik kalkanlar vardı. Parselin üstüne kurup kapatırsam bitki korunur.")],
    ],
  },
  domeFirst: {
    lines: [
      [ST_ME, T("Kalkan yerine oturdu. Servolar çalışıyor, kanatlar kendiliğinden kapandı.")],
      [ST_ME, T("Kapalıyken içeri elim yetişmez. Sulamak ya da hasat için Q ile açmam gerek.")],
      [ST_ME, T("Ama radyasyon gelirken mutlaka kapalı olmalı. Bunu unutmamalıyım.")],
    ],
  },
  radRadio: {
    lines: [
      [ST_RADIO, T("ARES-1, burası uzay hava durumu birimi. Güneşte büyük bir patlama gördük!")],
      [
        ST_RADIO,
        T("Radyasyon dalgası birazdan yüzeye ulaşacak. Seramik kalkanlarını kapat, sonra hemen rokete gir."),
      ],
      [ST_ME, T("Anlaşıldı. Önce kalkanlar, sonra ben.")],
    ],
  },
  domeSaved: {
    lines: [
      [ST_ME, T("Dalga geçti… Kalkanın altındaki bitki sapasağlam!")],
      [ST_ME, T("Seramik radyasyonu kesiyor. Dünya'daki mühendislere teşekkür borçluyum.")],
    ],
  },
  domeBurn: {
    lines: [
      [ST_ME, T("Açıkta kalan bitki kavrulmuş, büyümesi geriye gitti.")],
      [ST_ME, T("Bir dahakine dalga gelmeden kalkanı Q ile kapatmalıyım.")],
    ],
  },
  readyShut: {
    lines: [
      [ST_ME, T("Patatesler olgunlaşmış ama kalkan kapalı, içeri uzanamıyorum.")],
      [ST_ME, T("Q ile kalkanı açıp hasat edeyim. Sonra yeniden ekip kapatırım.")],
    ],
  },
  home: {
    lines: [
      [ST_RADIO, T("ARES-1, görevlerin tamam. Dünya'ya dönüş penceresi açıldı.")],
      [ST_ME, T("Eve dönme zamanı… Komuta güvertesinde navigasyonu açıp EVE DÖN'e basacağım.")],
    ],
    goal: { t: T("Navigasyondan EVE DÖN"), to: "rocket", done: () => !!game.won },
  },
};
let story = null;
const ST_AV_ME =
  '<svg viewBox="0 0 44 44"><circle cx="22" cy="22" r="17" fill="#e9edf5"/><circle cx="22" cy="22" r="17" fill="none" stroke="#9aa6bd" stroke-width="2"/><rect x="10" y="15" width="24" height="15" rx="7.5" fill="#1a2440"/><rect x="13" y="17" width="9" height="4" rx="2" fill="#ffb36b" opacity=".85"/><circle cx="22" cy="38" r="3" fill="#ff7a3c"/></svg>';
const ST_AV_RADIO =
  '<svg viewBox="0 0 44 44"><circle cx="22" cy="26" r="3.5" fill="#5ad1ff"/><g fill="none" stroke="#5ad1ff" stroke-width="2.4" stroke-linecap="round"><circle cx="22" cy="26" r="9" stroke-dasharray="14 100" transform="rotate(-135 22 26)"/><circle cx="22" cy="26" r="15" stroke-dasharray="23 100" transform="rotate(-135 22 26)" opacity=".7"/></g><rect x="20.6" y="29" width="2.8" height="10" fill="#5ad1ff"/></svg>';
function rockMsgRead(k) {
  return !!k && commState().inbox.some((m) => m.kind === "rock" && m.rk === k && m.read);
}
function storyState() {
  if (!game.story || typeof game.story !== "object") game.story = { done: {}, goal: null };
  if (!game.story.done) game.story.done = {};
  return game.story;
}
function storySeen(k) {
  return !!(game && storyState().done[k]);
}
function storyTrigger(k) {
  if (k && k.startsWith("radRadio2_")) {
    if (!game || storySeen(k)) return false;
    storyState().done[k] = 1;
    toast(T("📡 Görev Kontrol: radyasyon dalgası yaklaşıyor — seramik kalkanlarını kapat!"));
    sfx("warn");
    return true;
  }
  if (!game || !STORY_DEF[k] || storySeen(k)) return false;
  if (settings.story === false) {
    storyState().done[k] = 1;
    storySetGoal(k);
    return true;
  }
  const S = storyState();
  S.done[k] = 1;
  S.q = S.q || [];
  if (!S.q.includes(k)) S.q.push(k);
  return true;
}
function storyBusy() {
  return (
    !!(game && game.wake) ||
    rocketOpen ||
    marketOpen ||
    repairOpen ||
    capOpen ||
    commOpen ||
    upgOpen ||
    bookOpen ||
    bedOpen ||
    winOpen ||
    o2Fill ||
    radM ||
    paused ||
    fly ||
    mode !== "play"
  );
}
function storyStart(k) {
  const D = STORY_DEF[k];
  story = { k, i: 0, c: 0, t: 0, on: true, end: false };
  document.body.classList.add("story");
  const el = $("story");
  el.classList.remove("hidden");
  void el.offsetWidth;
  el.classList.add("on");
  $("stDots").innerHTML = D.lines.map(() => "<i></i>").join("");
  $("stNext").innerHTML = T("Devam") + " <kbd>Space</kbd> · " + T("Atla") + " <kbd>Esc</kbd>";
  tone(196, 0.9, "sine", 0.05, null, 0);
  tone(294, 0.9, "sine", 0.035, null, 0.08);
  tone(392, 1.1, "sine", 0.025, null, 0.18);
  storyShowLine();
}
function storyShowLine() {
  const D = STORY_DEF[story.k],
    L = D.lines[story.i];
  story.c = 0;
  story.t = 0;
  story.txt = typeof L[1] === "function" ? L[1]() : L[1];
  const box = $("stBox");
  box.classList.toggle("radio", L[0] === ST_RADIO);
  box.classList.add("talk");
  $("stAv").innerHTML = L[0] === ST_RADIO ? ST_AV_RADIO : ST_AV_ME;
  $("stWho").textContent = L[0] === ST_RADIO ? T("GÖREV KONTROL · TELSİZ") : T("KOMUTAN · İÇ SES");
  $("stLine").textContent = "";
  [...$("stDots").children].forEach((d, j) => d.classList.toggle("on", j <= story.i));
  if (L[0] === ST_RADIO) {
    noiseBurst(0.22, 0.06, 2400);
    tone(1046, 0.07, "square", 0.025, null, 0.05);
  }
}
function storyAdvance() {
  if (!story || story.end) return;
  if (story.c < story.txt.length) {
    story.c = story.txt.length;
    $("stLine").textContent = story.txt;
    $("stBox").classList.remove("talk");
    return;
  }
  story.i++;
  if (story.i >= STORY_DEF[story.k].lines.length) storyEnd();
  else {
    sfx("click");
    storyShowLine();
  }
}
function storyEnd() {
  if (!story) return;
  const k = story.k;
  story.end = true;
  $("story").classList.remove("on");
  setTimeout(() => {
    if (story && story.end) {
      story = null;
      $("story").classList.add("hidden");
      document.body.classList.remove("story");
    }
  }, 450);
  storySetGoal(k);
  updateQuest(true);
}
function goalDone(G) {
  return G.steps ? !!G.steps[G.steps.length - 1][1]() : G.done();
}
function goalStep(G) {
  if (!G.steps) return -1;
  for (let j = G.steps.length - 1; j >= 0; j--)
    if (G.steps[j][1]()) return Math.min(G.steps.length - 1, j + 1);
  return 0;
}
function goalText(G) {
  const i = goalStep(G);
  return i < 0 ? G.t : G.steps[i][0];
}
function storySetGoal(k) {
  const G = STORY_DEF[k].goal;
  if (!G) return;
  if (goalDone(G)) return storyGoalDone(k);
  storyState().goal = k;
  $("stGoal").className = "";
  $("stGoalK").textContent = T("ACİL HEDEF");
  $("stGoalT").textContent = goalText(G);
  $("stGoalD").textContent = "";
  tone(659, 0.12, "triangle", 0.05);
  tone(988, 0.16, "triangle", 0.045, null, 0.1);
}
function storyGoalDone(k) {
  const S = storyState(),
    G = STORY_DEF[k].goal;
  S.goal = null;
  const el = $("stGoal");
  el.className = "ok";
  $("stGoalK").textContent = "HEDEF TAMAM";
  $("stGoalT").textContent = G.steps ? G.steps[G.steps.length - 1][0] : G.t;
  $("stGoalD").textContent = "";
  el.querySelector(".sg-ic").textContent = "✓";
  tone(784, 0.12, "triangle", 0.05);
  tone(1175, 0.18, "triangle", 0.045, null, 0.1);
  clearTimeout(storyGoalDone._h);
  storyGoalDone._h = setTimeout(() => {
    el.className = "hidden";
    el.querySelector(".sg-ic").textContent = "!";
  }, 2600);
  if (G.next && insideRocket) storyTrigger(G.next);
  $("quest").classList.remove("hold");
  setTimeout(() => {
    checkQuest();
    updateQuest();
  }, 400);
}
/* gerçek zamanla çalışır (oyun yavaşlatılmış olsa bile) */
function updateStory(dt) {
  if (!game || mode !== "play") return;
  const S = storyState();
  // tetikleyiciler
  if (stormFx.phase === "active" && stormFx.I > 0.4 && !S.done.storm && !S.done.stormIn2) {
    if (insideRocket) {
      S.done.storm = 1;
      storyTrigger("stormIn2");
    } else storyTrigger("storm");
  }
  if (game.radiationActive && !S.done.rad && !S.done.radIn2) {
    if (insideRocket) {
      S.done.rad = 1;
      storyTrigger("radIn2");
    } else {
      S._radT = (S._radT || 0) + dt;
      if (S._radT > 1.6) storyTrigger("rad");
    }
  }
  // aktif hedef
  if (S.goal && STORY_DEF[S.goal]) {
    const G = STORY_DEF[S.goal].goal;
    if (goalDone(G)) storyGoalDone(S.goal);
    else {
      const gl = $("stGoal"),
        ab = $("alerts").getBoundingClientRect();
      gl.style.setProperty("--sgTop", Math.max(14, ab.bottom + 10) + "px");
      if (gl.classList.contains("ok")) gl.className = "";
      gl.classList.toggle("hidden", !!story);
      const gt = goalText(G),
        gi = goalStep(G),
        gk = gi < 0 ? T("ACİL HEDEF") : T("ACİL HEDEF · ") + (gi + 1) + "/" + G.steps.length;
      if ($("stGoalT").textContent !== gt || $("stGoalK").textContent !== gk) {
        $("stGoalT").textContent = gt;
        $("stGoalK").textContent = gk;
        gl.querySelector(".sg-ic").textContent = "!";
        if (gi > 0) {
          gl.classList.remove("bump");
          void gl.offsetWidth;
          gl.classList.add("bump");
          tone(880, 0.08, "triangle", 0.04);
        }
      }
      if (G.to === "rocket" && !insideRocket && goalStep(G) <= 0) {
        const d = Math.hypot(ROCKET.x - p.x, ROCKET.y - p.y);
        $("stGoalD").textContent = " · " + Math.round(d / 10) + " m";
      } else $("stGoalD").textContent = "";
    }
  }
  S._qt = (S._qt || 0) + dt;
  if (S._qt > 0.3) {
    S._qt = 0;
    refreshQuestSteps();
    if (S.done.rockReply && !S.done.rockLearn && rockMsgRead(S.rk)) storyTrigger("rockLearn");
    const qe = $("quest");
    qe.classList.toggle("hold", !!S.goal);
    if (S.goal) qe.dataset.hold = T("⏸ GÖREV BEKLEMEDE · ÖNCE ACİL HEDEF");
  }
  // sıradaki sahne
  if (!story && S.q && S.q.length && !storyBusy()) storyStart(S.q.shift());
  if (story && !story.end) {
    story.t += dt;
    if (story.c < story.txt.length) {
      const n = Math.min(story.txt.length, Math.floor(story.t * 42));
      if (n > story.c) {
        if (n % 3 === 0) tone(1500 + Math.random() * 300, 0.012, "square", 0.006);
        story.c = n;
        $("stLine").textContent = story.txt.slice(0, n);
      }
      if (story.c >= story.txt.length) $("stBox").classList.remove("talk");
    } else if (story.t > story.txt.length / 42 + 3.2) storyAdvance(); // okuma süresi dolunca kendiliğinden ilerler
  }
  // kamera: sahne sırasında oyuncuya yaklaşır
  if (!radM) {
    const on = story && !story.end && !insideRocket,
      want = on ? { z: 1.5, ox: 0, oy: -8 } : { z: 1, ox: 0, oy: 0 },
      k = 1 - Math.exp(-dt * (on ? 2.2 : 3.5));
    cam.z += (want.z - cam.z) * k;
    cam.ox += (want.ox - cam.ox) * k;
    cam.oy += (want.oy - cam.oy) * k;
  }
}
function storyReset() {
  story = null;
  markFx = [];
  $("wake").className = "hidden";
  if (game && game.wake) game.wake = null;
  $("story").className = "hidden";
  $("stGoal").className = "hidden";
  document.body.classList.remove("story");
}
$("story").addEventListener("click", (e) => {
  e.stopPropagation();
  storyAdvance();
});
function storySlow() {
  return story && !story.end ? 0.1 : 1;
}
/* hedef oku: roket ekran dışındaysa kenarda yön oku, içindeyse üstünde zıplayan işaret */
function drawStoryArrow(z) {
  if (!game || insideRocket || story) return;
  const S = game.story;
  if (!S || !S.goal) return;
  const G = STORY_DEF[S.goal] && STORY_DEF[S.goal].goal;
  if (!G || G.to !== "rocket" || goalStep(G) > 0) return;
  const t = performance.now() / 1000,
    sx = W / 2 + (ROCKET.x - p.x - cam.ox) * z,
    sy = H / 2 + (ROCKET.y - 140 - p.y - cam.oy) * z,
    m = 60;
  ctx.save();
  if (sx > m && sx < W - m && sy > m && sy < H - m) {
    const y = sy - 8 + Math.sin(t * 5) * 6;
    ctx.fillStyle = "#ff6a3d";
    ctx.shadowColor = "#ff6a3d";
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.moveTo(sx, y + 12);
    ctx.lineTo(sx - 11, y - 4);
    ctx.lineTo(sx + 11, y - 4);
    ctx.closePath();
    ctx.fill();
  } else {
    const a = Math.atan2(sy - H / 2, sx - W / 2),
      R = Math.min(W, H) / 2 - 70,
      ax = W / 2 + Math.cos(a) * R,
      ay = H / 2 + Math.sin(a) * R,
      pl = 1 + 0.12 * Math.sin(t * 6);
    ctx.translate(ax, ay);
    ctx.rotate(a);
    ctx.scale(pl, pl);
    ctx.fillStyle = "rgba(255,106,61,.95)";
    ctx.shadowColor = "#ff6a3d";
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.moveTo(18, 0);
    ctx.lineTo(-10, -13);
    ctx.lineTo(-4, 0);
    ctx.lineTo(-10, 13);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

/* ---------- ölçüm bayrağını kaldır ---------- */
let markFx = [];
function nearestMark() {
  const M = game.radMarks;
  if (!Array.isArray(M) || !M.length) return null;
  let b = null,
    bd = 62;
  M.forEach((mk, i) => {
    const d = Math.hypot(mk.x - p.x, mk.y - (p.y + 26));
    if (d < bd) {
      bd = d;
      b = { i, mk, d };
    }
  });
  return b;
}
function removeMark(nm) {
  game.radMarks.splice(nm.i, 1);
  markFx.push({ x: nm.mk.x, y: nm.mk.y, u: nm.mk.u, t: 0 });
  p.dir = nm.mk.x < p.x ? -1 : 1;
  startAct("use", 0.6);
  burst(nm.mk.x, nm.mk.y, 12, "#8a6a3c", { sp: 80, life: 0.6, size: 4, up: 40 });
  sfx("pickup");
  tone(880, 0.06, "triangle", 0.04, 660);
  if (!game._markTip) {
    game._markTip = 1;
    toast(T("Bayrak kaldırıldı. Ölçtüğün yerleri istediğin zaman temizleyebilirsin."));
  }
}
function drawMarkFx(dt) {
  for (const f of markFx) {
    f.t += dt;
    const k = Math.min(1, f.t / 0.7),
      x = f.x,
      y = f.y - k * 30,
      L = RAD_LV[radLevel(f.u)];
    ctx.save();
    ctx.globalAlpha = 1 - k;
    ctx.translate(x, y);
    ctx.rotate(-k * 0.6);
    ctx.strokeStyle = "#d7dce8";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -42);
    ctx.stroke();
    ctx.fillStyle = L[1];
    ctx.beginPath();
    ctx.moveTo(1, -42);
    ctx.lineTo(19, -36);
    ctx.lineTo(1, -30);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  markFx = markFx.filter((f) => f.t < 0.7);
}

function update(dt) {
  if (game.wake) {
    updateWake(dt);
    updateStats();
    return;
  }
  const simDt = dt * (game.sleeping && insideRocket ? SLEEP_MULTIPLIER : 1);
  updateBio(dt);
  let ix = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0) + joy.x;
  let iy = (keys.KeyS || keys.ArrowDown ? 1 : 0) - (keys.KeyW || keys.ArrowUp ? 1 : 0) + joy.y;
  let l = Math.hypot(ix, iy);
  if (l > 1) {
    ix /= l;
    iy /= l;
  }
  if (radM || story || brk) {
    ix = 0;
    iy = 0;
    l = 0;
  }
  updateMeasure(dt);
  updateBreak(dt);
  const running = !!keys.ShiftLeft || !!keys.ShiftRight;
  BIO.ex = l > 0.1 ? (running ? 1 : 0.4) : 0;
  if (insideRocket) {
    if (
      bedOpen ||
      rocketOpen ||
      marketOpen ||
      repairOpen ||
      capOpen ||
      commOpen ||
      upgOpen ||
      o2Fill ||
      bookOpen
    ) {
      ix = 0;
      iy = 0;
    }
    updateInside(dt, ix, iy, running);
    updateSleep(simDt);
  } else {
    const totalItems = Object.values(game.inventory).reduce((a, b) => a + (b || 0), 0);
    const weightPenalty = Math.min(CFG.maxWeightPenalty, totalItems * CFG.weightPerItem);
    const spMul =
      PLANETS[scene].speedMul * (running ? CFG.runMultiplier : 1) * (1 - weightPenalty) * suitSt().spd;
    const B = CFG.worldHalf;
    // fırtına: rüzgâra karşı yürümek zor, rüzgâr oyuncuyu savurur
    const SI = Math.min(1, stormFx.I),
      wx = Math.cos(stormFx.ang),
      wy = Math.sin(stormFx.ang);
    const against = Math.max(0, -(ix * wx + iy * wy));
    const SS = suitSt().storm * dif().storm;
    const stormMul = 1 - SI * (0.18 + 0.35 * against) * SS;
    const push = SI * (38 + stormFx.gust * 70) * SS;
    if (SI > 0.35) {
      damage(0.45 * SI * SS * dt, true);
      game._stT = (game._stT || 0) + dt;
      if (game._stT > 2.2) {
        game._stT = 0;
        addFloat(
          p.x + (Math.random() - 0.5) * 30,
          p.y - 62,
          "-" + Math.max(1, Math.round(0.45 * SI * SS * 2.2)) + " 🌪",
          "#ffcf8a",
        );
      }
    }
    if (p.vx == null) {
      p.vx = 0;
      p.vy = 0;
      p.z = 0;
      p.vz = 0;
    }
    if (brk) {
      p.vx = p.vy = 0;
    }
    gravMove(p, ix * CFG.walkSpeed * spMul * stormMul, iy * CFG.walkSpeed * spMul * stormMul, dt);
    gravHop(p, l > 0.05 && !brk, running, dt);
    gravLand(p, p.x, p.y);
    if (keys.Space && !radM && !brk && !story) {
      keys.Space = false;
      gravJump(p);
    }
    const nx = Math.max(-B, Math.min(B, p.x + p.vx * dt + wx * push * dt));
    const ny = Math.max(-B, Math.min(B, p.y + p.vy * dt + wy * push * dt));
    if (nx === B || nx === -B) p.vx = 0;
    if (ny === B || ny === -B) p.vy = 0;
    p.x = nx;
    p.y = ny;
    if (ix > 0.1) p.dir = 1;
    if (ix < -0.1) p.dir = -1;
    if (l > 0.05) p.hd = Math.atan2(iy, ix);
    if (l > 0.05 || Math.hypot(p.vx, p.vy) > 40) {
      p.t += dt * CFG.springSpeed * (running ? 1.4 : 1) * (p.z > 0.5 ? 0.35 : 1);
      p.walk = Math.min(1, p.walk + dt * 8);
      const s = Math.sin(p.t * 2) * CFG.springAmount;
      p.sx = 1 + s;
      p.sy = 1 - s;
      stepDust -= dt;
      if (stepDust <= 0) {
        stepDust = running ? 0.16 : 0.26;
        burst(p.x, p.y + 38, 2, PLANETS[scene].dot, { sp: 34, life: 0.45, size: 3, g: 60, drag: 3 });
      }
    } else {
      p.walk = Math.max(0, p.walk - dt * 8);
      const k = Math.min(1, dt * 10);
      p.sx += (1 - p.sx) * k;
      p.sy += (1 - p.sy) * k;
    }
    p._running = running;
    p.actionT = Math.max(0, (p.actionT || 0) - dt);
    if (p.digAt) {
      p.digAt.t += dt;
      if (p.digAt.t >= 0.53) {
        const d = p.digAt;
        p.digAt = null;
        digImpact(d.x, d.y);
      }
    }
    if (p.actionT <= 0) p.action = null; // animasyon bitince el durumu serbest kalır
  }

  updateO2(simDt, dt, running);
  {
    const df = dif();
    game.hunger = Math.max(0, game.hunger - CFG.hungerDrain * (df.food || 1) * simDt);
    game.thirst = Math.max(0, game.thirst - CFG.thirstDrain * (df.water || 1) * simDt);
    if (game.hunger <= 0 || game.thirst <= 0) {
      game.hp = Math.max(0, game.hp - CFG.hpDrainEmpty * simDt);
    } else if (game.hp < 100) {
      game.hp = Math.min(100, game.hp + CFG.hpRegen * (df.regen || 1) * simDt * 0.25);
    }
  }
  const previousDay = gameDayNumber();
  game.worldTime = (Number(game.worldTime) || 0) + simDt;
  const currentDay = gameDayNumber();
  if (currentDay > previousDay) toast(T("🌅 Gün ") + currentDay + T(" başladı"));
  updateRadiation(simDt);
  updateStorm(simDt, dt);
  updateAmbient(dt);
  rareScan(dt);
  autoSaveTick(dt);
  updateDistress(dt);
  updateGravHud();
  commsTick(simDt, dt);
  if (game.hp <= 0) {
    faintToPod();
    return;
  }
  game.playTime = (game.playTime || 0) + simDt;
  game.recyT = (game.recyT || 0) + simDt;
  if (game.recyT >= recycleInt()) {
    game.recyT = 0;
    if (game.stock.water < 12) game.stock.water++;
  }

  // tarım büyümesi
  const fa = farmArr();
  for (let i = fa.length - 1; i >= 0; i--) {
    // boş bırakılan çukur bir süre sonra kendiliğinden kapanır
    const g = fa[i];
    if (!g || g.g > 0 || g.cov) {
      if (g) g.idle = 0;
      continue;
    } // kalkanlı parsel kapanmaz
    g.idle = (g.idle || 0) + simDt;
    if (g.idle > EMPTY_HOLE_T) {
      g.fill = Math.min(1, (g.fill || 0) + simDt / 3.5);
      if (Math.random() < simDt * 6)
        burst(g.x + (Math.random() - 0.5) * 50, g.y + (Math.random() - 0.5) * 20, 2, "#b98058", {
          sp: 30,
          life: 0.6,
          size: 3,
          up: 10,
        });
      if (g.fill >= 1) {
        burst(g.x, g.y, 14, "#b98058", { sp: 70, life: 0.8, size: 4, up: 20 });
        fa.splice(i, 1);
      }
    }
  }
  const radNow = game.radiationActive && scene !== "earth";
  updateDomes(dt);
  for (const g of fa) {
    if (!g || g.g <= 0) continue;
    if (radNow) {
      if (domeSafe(g)) g.radOK = 1;
      else g.radHit = 1;
    }
    if (radNow && !domeSafe(g)) {
      // korumasız bitki: radyasyon dalgası büyümeyi geri alır
      g.g = Math.max(0.1, g.g - simDt * PLANT_RAD_DMG);
      g._rz = (g._rz || 0) + simDt;
      if (g._rz > 1.6) {
        g._rz = 0;
        addFloat(g.x + (Math.random() - 0.5) * 30, g.y - 50, "☢ -", "#a3e635");
      }
      if (g.g < CFG.farmGrow) g._ready = false;
      continue;
    }
    if (g.wet > 0) g.wet = Math.max(0, g.wet - simDt);
    g.g = Math.min(
      CFG.farmGrow,
      g.g + simDt * PLANETS[scene].grow * desFx().growMul * (1 + (g.wet > 0 ? 1.4 : 0)),
    );
    if (g.g >= CFG.farmGrow && !g._ready) {
      g._ready = true;
      sfx("harvest2");
      if (g.cov && g.shut) {
        toast(T("🌲 Mahsul hazır! Kalkan kapalı — <b>Q</b> ile aç, <b>F</b> ile hasat"));
        storyTrigger("readyShut");
      } else toast(T("🌲 Mahsul hazır! (F ile hasat)"));
    }
    if (g.g < CFG.farmGrow) g._ready = false;
  }

  updateEvent(simDt);
  updateMeteorFx(dt);
  updateParticles(dt);
  shake = Math.max(0, shake - dt * 36);
  flash = Math.max(0, flash - dt * 1.7);
  warp = Math.max(0, warp - dt * 1.3);

  updateStats();
  updateHud();
  if (!rocketOpen && !marketOpen && !repairOpen && !capOpen && !commOpen && !upgOpen && !paused) {
    const h = computeHint();
    $("hint").innerHTML = h;
    $("hint").classList.toggle("hidden", !h);
    $("hint").classList.toggle("inside", insideRocket);
    updateTouch(h);
  }
  $("ui").classList.toggle(
    "con-open",
    [
      "rocketScreen",
      "marketScreen",
      "bedScreen",
      "repairScreen",
      "capScreen",
      "commScreen",
      "upgScreen",
    ].some((id) => !$(id).classList.contains("hidden")),
  );
  $("ui").classList.toggle("comm-open", commOpen);
  $("ui").classList.toggle("wide-open", commOpen || upgOpen);
}

/* ============== HAVA DURUMU (ekran uzayı) ============== */
function drawWeather() {
  const w = PLANETS[scene].weather,
    t = performance.now() / 1000;
  ctx.save();
  if (stormFx.I > 0.003) {
    drawSandstorm();
    ctx.restore();
    return;
  }
  if (false) {
    const fl = 0.22 + 0.1 * Math.sin(t * 1.7);
    ctx.fillStyle = "rgba(214,138,74," + fl.toFixed(3) + ")";
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = "rgba(255,204,150,.5)";
    ctx.lineWidth = 2.6;
    ctx.lineCap = "round";
    ctx.beginPath();
    for (let i = 0; i < 120; i++) {
      const sp = 380 + (i % 6) * 70;
      const x = ((i * 167 + t * sp) % (W + 360)) - 180,
        y = ((i * 89 + Math.sin(t * 3 + i) * 30) % (H + 40)) - 20;
      ctx.moveTo(x, y);
      ctx.lineTo(x - 120 - Math.sin(t * 2 + i) * 26, y + 8);
    }
    ctx.stroke();
    ctx.fillStyle = "rgba(255,225,180,.30)";
    for (let i = 0; i < 70; i++) {
      const x = ((i * 131 + t * (520 + (i % 5) * 80)) % (W + 60)) - 30,
        y = ((i * 97 + Math.sin(t * 4 + i) * 40) % (H + 30)) - 15;
      ctx.beginPath();
      ctx.arc(x, y, 1.4 + (i % 3), 0, 7);
      ctx.fill();
    }
  } else if (w === "rain") {
    ctx.strokeStyle = "rgba(170,225,255,.34)";
    ctx.lineWidth = 1.8;
    ctx.lineCap = "round";
    ctx.beginPath();
    for (let i = 0; i < 80; i++) {
      const x = ((i * 149 + t * 90) % (W + 180)) - 90,
        y = ((i * 97 + t * 1500) % (H + 100)) - 50;
      ctx.moveTo(x, y);
      ctx.lineTo(x - 7, y + 20);
    }
    ctx.stroke();
  } else if (w === "dust") {
    ctx.strokeStyle = "rgba(255,205,150,.20)";
    ctx.lineWidth = 2.4;
    ctx.lineCap = "round";
    ctx.beginPath();
    for (let i = 0; i < 46; i++) {
      const x = ((i * 233 + t * (140 + (i % 5) * 40)) % (W + 300)) - 150,
        y = (i * 71) % (H + 40);
      ctx.moveTo(x, y);
      ctx.lineTo(x - 70 - Math.sin(t + i) * 20, y + 6);
    }
    ctx.stroke();
  } else if (w === "ash") {
    ctx.fillStyle = "rgba(120,90,60,.35)";
    for (let i = 0; i < 54; i++) {
      const x = ((i * 167 + Math.sin(t * 0.7 + i) * 40) % (W + 40)) - 20,
        y = (((i * 83 - t * 46) % (H + 40)) + H + 40) % (H + 40);
      ctx.beginPath();
      ctx.arc(x, y, 1.6 + (i % 3), 0, 7);
      ctx.fill();
    }
  } else if (w === "snow") {
    ctx.fillStyle = "rgba(255,255,255,.7)";
    for (let i = 0; i < 70; i++) {
      const x = ((i * 137 + Math.sin(t * 0.9 + i) * 36) % (W + 40)) - 20,
        y = (i * 89 + t * 70) % (H + 40);
      ctx.beginPath();
      ctx.arc(x, y, 1.4 + (i % 3) * 0.8, 0, 7);
      ctx.fill();
    }
  } else if (w === "spark") {
    ctx.fillStyle = "rgba(255,240,190,.55)";
    for (let i = 0; i < 34; i++) {
      const x = ((i * 211 + Math.sin(t * 1.3 + i) * 60) % (W + 40)) - 20,
        y = (((i * 97 - t * 30) % (H + 40)) + H + 40) % (H + 40);
      ctx.beginPath();
      ctx.arc(x, y, 1.5 + (i % 2), 0, 7);
      ctx.fill();
    }
    const fl = (Math.sin(t * 0.8) + Math.sin(t * 2.9) + Math.sin(t * 5.3)) / 3;
    if (fl > 0.72) {
      const a = Math.min(0.34, (fl - 0.72) * 2.4);
      ctx.fillStyle = "rgba(255,255,255," + a + ")";
      ctx.fillRect(0, 0, W, H);
    }
  }
  ctx.restore();
}

/* ============== HARİTA (radar yerine) ============== */
let mapTex = null;
function buildMapTex() {
  const N = 1024,
    B = CFG.worldHalf,
    c = document.createElement("canvas");
  c.width = c.height = N;
  const g = c.getContext("2d");
  const S = PLANETS[scene],
    sc = N / (2 * B),
    r = rng(91);
  g.fillStyle = S.ground;
  g.fillRect(0, 0, N, N);
  // arazi tonları
  for (let i = 0; i < 2000; i++) {
    const x = r() * N,
      y = r() * N,
      rad = 6 + r() * 34;
    const gr = g.createRadialGradient(x, y, 0, x, y, rad);
    const light = r() < 0.5;
    gr.addColorStop(0, light ? "rgba(255,206,160,.09)" : "rgba(50,8,0,.12)");
    gr.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gr;
    g.fillRect(x - rad, y - rad, rad * 2, rad * 2);
  }
  // eş yükselti çizgileri
  g.strokeStyle = "rgba(255,220,190,.07)";
  g.lineWidth = 1;
  for (let k = 0; k < 26; k++) {
    const cx = r() * N,
      cy = r() * N,
      base = 20 + r() * 60;
    for (let ring = 0; ring < 3; ring++) {
      g.beginPath();
      for (let a = 0; a <= 6.3; a += 0.25) {
        const rr = base + ring * 12 + Math.sin(a * 3 + k) * 8;
        const x = cx + Math.cos(a) * rr,
          y = cy + Math.sin(a) * rr * 0.8;
        a ? g.lineTo(x, y) : g.moveTo(x, y);
      }
      g.closePath();
      g.stroke();
    }
  }
  // dekor: krater, kaya, çatlak
  for (const d of decor[scene]) {
    const x = (d.x + B) * sc,
      y = (d.y + B) * sc,
      rad = Math.max(1.2, d.r * sc * 1.1);
    if (d.type === "crater") {
      g.fillStyle = "rgba(40,8,4,.35)";
      g.beginPath();
      g.arc(x, y, rad * 1.4, 0, 7);
      g.fill();
      g.strokeStyle = "rgba(255,200,160,.22)";
      g.lineWidth = 1;
      g.beginPath();
      g.arc(x - rad * 0.2, y - rad * 0.2, rad * 1.4, 3.6, 5.6);
      g.stroke();
    } else if (d.type === "rock") {
      g.fillStyle = "rgba(30,6,2,.45)";
      g.beginPath();
      g.arc(x, y, Math.max(1, rad * 0.6), 0, 7);
      g.fill();
    } else if (d.type === "crack") {
      g.strokeStyle = "rgba(30,6,2,.35)";
      g.lineWidth = 1;
      g.beginPath();
      g.moveTo(x - rad, y);
      g.lineTo(x, y + rad * 0.4);
      g.lineTo(x + rad, y - rad * 0.2);
      g.stroke();
    }
  }
  // yer şekilleri
  if (scene === "mars") {
    if (!landmarks) landmarks = genLandmarks();
    for (const l of landmarks) {
      const x = (l.x + B) * sc,
        y = (l.y + B) * sc,
        rr = l.r * sc;
      g.fillStyle = {
        dunes: "rgba(255,200,150,.10)",
        basalt: "rgba(30,8,4,.30)",
        frost: "rgba(220,235,255,.32)",
        river: "rgba(40,10,4,.25)",
        layers: "rgba(255,190,140,.10)",
      }[l.type];
      g.beginPath();
      g.ellipse(x, y, rr, rr * (l.type === "river" ? 0.25 : 0.7), l.ang, 0, 7);
      g.fill();
    }
  }
  // iniş platformu çevresi
  const rx = (ROCKET.x + B) * sc,
    ry = (ROCKET.y + B) * sc;
  g.fillStyle = "rgba(170,179,214,.18)";
  g.beginPath();
  g.arc(rx, ry + 58 * sc, 11, 0, 7);
  g.fill();
  mapTex = { c, scene, N };
}
function mapRocketIcon(x, y, s, broken, t) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  const gl = ctx.createRadialGradient(0, 0, 1, 0, 0, 14);
  gl.addColorStop(0, "rgba(255,180,120,.55)");
  gl.addColorStop(1, "rgba(255,140,66,0)");
  ctx.fillStyle = gl;
  ctx.beginPath();
  ctx.arc(0, 0, 14, 0, 7);
  ctx.fill();
  ctx.fillStyle = "#d43d2d";
  ctx.beginPath();
  ctx.moveTo(-3.5, 3);
  ctx.lineTo(-7, 9);
  ctx.lineTo(-3, 8);
  ctx.closePath();
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(3.5, 3);
  ctx.lineTo(7, 9);
  ctx.lineTo(3, 8);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = "#f4f6fc";
  ctx.beginPath();
  ctx.moveTo(0, -11);
  ctx.quadraticCurveTo(5, -5, 4, 8);
  ctx.lineTo(-4, 8);
  ctx.quadraticCurveTo(-5, -5, 0, -11);
  ctx.fill();
  ctx.strokeStyle = "#1b2140";
  ctx.lineWidth = 1.1;
  ctx.stroke();
  ctx.fillStyle = "#ff8c42";
  ctx.beginPath();
  ctx.moveTo(0, -11);
  ctx.quadraticCurveTo(3, -8, 3.4, -6);
  ctx.lineTo(-3.4, -6);
  ctx.quadraticCurveTo(-3, -8, 0, -11);
  ctx.fill();
  ctx.fillStyle = "#3f8fd8";
  ctx.beginPath();
  ctx.arc(0, -1.5, 1.9, 0, 7);
  ctx.fill();
  if (!broken) {
    ctx.fillStyle = "rgba(255,190,90," + (0.7 + 0.3 * Math.sin(t * 14)) + ")";
    ctx.beginPath();
    ctx.moveTo(-2, 8.5);
    ctx.lineTo(2, 8.5);
    ctx.lineTo(0, 12 + Math.sin(t * 20));
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
  if (broken)
    for (let i = 0; i < 4; i++) {
      const ph = (t * 0.6 + i * 0.25) % 1;
      ctx.fillStyle = "rgba(190,196,214," + 0.6 * (1 - ph) + ")";
      ctx.beginPath();
      ctx.arc(x + 3 * s + ph * 6, y - 6 * s - ph * 16, 2 + ph * 4.5, 0, 7);
      ctx.fill();
    }
}
function drawMap() {
  if (!mapTex || mapTex.scene !== scene) buildMapTex();
  const t = performance.now() / 1000,
    B = CFG.worldHalf,
    N = mapTex.N;
  const MW = mapW(),
    MH = MW,
    mx = W - 16 - MW,
    my = 14,
    RANGE = 1700,
    sc = MW / RANGE;
  const toMap = (o) => ({ x: mx + MW / 2 + (o.x - p.x) * sc, y: my + MH / 2 + (o.y - p.y) * sc });
  ctx.save();
  // panel
  ctx.shadowColor = "rgba(0,0,0,.45)";
  ctx.shadowBlur = 18;
  ctx.shadowOffsetY = 6;
  ctx.fillStyle = "#0b1024";
  rrp(mx - 5, my - 5, MW + 10, MH + 30, 14);
  ctx.fill();
  ctx.shadowColor = "transparent";
  ctx.strokeStyle = "rgba(90,209,255,.28)";
  ctx.lineWidth = 1;
  rrp(mx - 5, my - 5, MW + 10, MH + 30, 14);
  ctx.stroke();
  ctx.save();
  rrp(mx, my, MW, MH, 10);
  ctx.clip();
  ctx.fillStyle = "#120806";
  ctx.fillRect(mx, my, MW, MH);
  const px = ((p.x + B) / (2 * B)) * N,
    py = ((p.y + B) / (2 * B)) * N,
    sw = (RANGE / (2 * B)) * N;
  ctx.imageSmoothingEnabled = true;
  ctx.drawImage(mapTex.c, px - sw / 2, py - sw / 2, sw, sw, mx, my, MW, MH);
  // ızgara (250 birim)
  ctx.strokeStyle = "rgba(255,255,255,.07)";
  ctx.lineWidth = 1;
  const G = 250,
    gx0 = Math.ceil((p.x - RANGE / 2) / G) * G,
    gy0 = Math.ceil((p.y - RANGE / 2) / G) * G;
  ctx.beginPath();
  for (let gx = gx0; gx < p.x + RANGE / 2; gx += G) {
    const X = toMap({ x: gx, y: 0 }).x;
    ctx.moveTo(X, my);
    ctx.lineTo(X, my + MH);
  }
  for (let gy = gy0; gy < p.y + RANGE / 2; gy += G) {
    const Y = toMap({ x: 0, y: gy }).y;
    ctx.moveTo(mx, Y);
    ctx.lineTo(mx + MW, Y);
  }
  ctx.stroke();
  // dünya sınırı
  const b0 = toMap({ x: -B, y: -B }),
    b1 = toMap({ x: B, y: B });
  ctx.strokeStyle = "rgba(255,90,90,.6)";
  ctx.setLineDash([4, 3]);
  ctx.strokeRect(b0.x, b0.y, b1.x - b0.x, b1.y - b0.y);
  ctx.setLineDash([]);
  // tarlalar
  for (const pl of farmArr()) {
    const q = toMap(pl);
    const ready = pl.g >= CFG.farmGrow,
      grow = pl.g > 0;
    ctx.fillStyle = ready ? "#ffd34d" : grow ? "#4ade80" : "#7a4a2a";
    ctx.strokeStyle = "rgba(0,0,0,.55)";
    ctx.lineWidth = 1;
    if (ready) {
      ctx.shadowColor = "#ffd34d";
      ctx.shadowBlur = 8;
    }
    rrp(q.x - 3.5, q.y - 3.5, 7, 7, 2);
    ctx.fill();
    ctx.stroke();
    ctx.shadowBlur = 0;
    if (grow && !ready) {
      ctx.fillStyle = "#bbf7d0";
      ctx.fillRect(q.x - 0.6, q.y - 2.6, 1.2, 4);
    }
  }
  // numuneler (metal elmas) + yıldız düşüşleri
  for (const st of stones) {
    if (st.taken) continue;
    const q = toMap(st);
    if (q.x < mx - 4 || q.x > mx + MW + 4 || q.y < my - 4 || q.y > my + MH + 4) continue;
    ctx.fillStyle = "#d7deee";
    ctx.strokeStyle = "rgba(20,24,40,.8)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(q.x, q.y - 3.2);
    ctx.lineTo(q.x + 2.6, q.y);
    ctx.lineTo(q.x, q.y + 3.2);
    ctx.lineTo(q.x - 2.6, q.y);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  for (const n of rareNodes) {
    if (n.taken) continue;
    const dd = Math.hypot(n.x - p.x, n.y - p.y);
    if (dd > 1100 && !game.rareKnown[n.kind]) continue;
    if (dd > 1700) continue;
    const q = toMap(n),
      kn = game.rareKnown[n.kind],
      D = RARE_DEF[n.kind];
    const pu = 0.5 + 0.5 * Math.sin(t * 4 + n.seed);
    ctx.save();
    ctx.translate(q.x, q.y);
    if (kn) {
      ctx.fillStyle = D.glow;
      ctx.shadowColor = D.glow;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.moveTo(0, -4);
      ctx.lineTo(3.4, 0);
      ctx.lineTo(0, 4);
      ctx.lineTo(-3.4, 0);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
    } else {
      ctx.strokeStyle = "rgba(185,168,255," + (0.4 + 0.6 * pu) + ")";
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.arc(0, 0, 4 + pu * 3, 0, 7);
      ctx.stroke();
      ctx.fillStyle = "#d8ccff";
      ctx.font = "800 8px monospace";
      ctx.textAlign = "center";
      ctx.fillText("?", 0, 3);
    }
    ctx.restore();
  }
  for (const d of drops) {
    if (d.taken) continue;
    const q = toMap(d);
    if (d.type === "star") {
      ctx.fillStyle = "#ffd34d";
      ctx.shadowColor = "#ffd34d";
      ctx.shadowBlur = 6 + 3 * Math.sin(t * 5);
      ctx.beginPath();
      for (let k = 0; k < 8; k++) {
        const a = (k * Math.PI) / 4 - Math.PI / 2,
          rr = k % 2 ? 1.6 : 4.6;
        ctx.lineTo(q.x + Math.cos(a) * rr, q.y + Math.sin(a) * rr);
      }
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
    } else if (d.type === "gold") {
      ctx.fillStyle = "#ffc93c";
      ctx.shadowColor = "#ffc93c";
      ctx.shadowBlur = 5;
      ctx.beginPath();
      ctx.arc(q.x, q.y, 2.6, 0, 7);
      ctx.fill();
      ctx.shadowBlur = 0;
    } else {
      ctx.fillStyle = "#d7deee";
      ctx.beginPath();
      ctx.arc(q.x, q.y, 2.4, 0, 7);
      ctx.fill();
    }
  }
  // meteorlar
  for (const m of ev.meteors) {
    const q = toMap(m),
      k = 0.5 + 0.5 * Math.sin(t * 12);
    ctx.strokeStyle = "rgba(255,120,60," + (0.6 + 0.4 * k) + ")";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(q.x, q.y, 4 + k * 3, 0, 7);
    ctx.stroke();
    ctx.fillStyle = "#ffcc66";
    ctx.beginPath();
    ctx.arc(q.x, q.y, 2, 0, 7);
    ctx.fill();
  }
  // roket (harita içinde ya da kenarda ok)
  const broken = game.repair.state !== "ok",
    rq = toMap(ROCKET);
  const inside = rq.x > mx + 8 && rq.x < mx + MW - 8 && rq.y > my + 8 && rq.y < my + MH - 8;
  if (inside) mapRocketIcon(rq.x, rq.y, 1, broken, t);
  // oyuncu: görüş konisi + ok
  const hd = p.hd != null ? p.hd : p.dir > 0 ? 0 : Math.PI,
    cx0 = mx + MW / 2,
    cy0 = my + MH / 2;
  const cg = ctx.createRadialGradient(cx0, cy0, 2, cx0, cy0, 34);
  cg.addColorStop(0, "rgba(90,209,255,.35)");
  cg.addColorStop(1, "rgba(90,209,255,0)");
  ctx.fillStyle = cg;
  ctx.beginPath();
  ctx.moveTo(cx0, cy0);
  ctx.arc(cx0, cy0, 34, hd - 0.55, hd + 0.55);
  ctx.closePath();
  ctx.fill();
  ctx.save();
  ctx.translate(cx0, cy0);
  ctx.rotate(hd + Math.PI / 2);
  ctx.shadowColor = "#5ad1ff";
  ctx.shadowBlur = 10;
  ctx.fillStyle = "#5ad1ff";
  ctx.beginPath();
  ctx.moveTo(0, -7.5);
  ctx.lineTo(5.5, 6);
  ctx.lineTo(0, 3);
  ctx.lineTo(-5.5, 6);
  ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = "#fff";
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.restore();
  // fırtına: sinyal paraziti
  const SI = Math.min(1, stormFx.I);
  if (SI > 0.02) {
    ctx.fillStyle = "rgba(170,96,50," + 0.55 * SI + ")";
    ctx.fillRect(mx, my, MW, MH);
    for (let i = 0; i < Math.round(160 * SI); i++) {
      ctx.fillStyle = "rgba(255,226,190," + Math.random() * 0.5 * SI + ")";
      ctx.fillRect(mx + Math.random() * MW, my + Math.random() * MH, 2, 1);
    }
    for (let i = 0; i < 3; i++) {
      const yy = my + ((t * 90 + i * 61) % MH);
      ctx.fillStyle = "rgba(255,226,190," + 0.12 * SI + ")";
      ctx.fillRect(mx, yy, MW, 2);
    }
    if (SI > 0.5 && Math.sin(t * 6) > -0.3) {
      ctx.fillStyle = "rgba(255,236,210,.9)";
      ctx.font = "800 10px ui-monospace,Consolas,monospace";
      ctx.textAlign = "center";
      ctx.fillText(T("SİNYAL ZAYIF"), mx + MW / 2, my + MH / 2 + 30);
    }
  }
  // kenar vinyeti
  const vg = ctx.createRadialGradient(
    mx + MW / 2,
    my + MH / 2,
    MW * 0.35,
    mx + MW / 2,
    my + MH / 2,
    MW * 0.75,
  );
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(0,0,0,.45)");
  ctx.fillStyle = vg;
  ctx.fillRect(mx, my, MW, MH);
  ctx.restore(); // klip
  // roket ekran dışındaysa kenar oku
  if (!inside) {
    const ang = Math.atan2(rq.y - (my + MH / 2), rq.x - (mx + MW / 2)),
      R = MW / 2 - 11;
    const ex = mx + MW / 2 + Math.cos(ang) * R,
      ey = my + MH / 2 + Math.sin(ang) * R,
      dist = Math.round(Math.hypot(ROCKET.x - p.x, ROCKET.y - p.y) / 10);
    ctx.fillStyle = "rgba(11,16,36,.85)";
    ctx.beginPath();
    ctx.arc(ex, ey, 10, 0, 7);
    ctx.fill();
    ctx.strokeStyle = "#ff8c42";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    mapRocketIcon(ex, ey, 0.55, broken, t);
    ctx.save();
    ctx.translate(ex, ey);
    ctx.rotate(ang);
    ctx.fillStyle = "#ff8c42";
    ctx.beginPath();
    ctx.moveTo(15, 0);
    ctx.lineTo(10, -4);
    ctx.lineTo(10, 4);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    ctx.fillStyle = "#ffd2a8";
    ctx.font = "700 9px ui-monospace,Consolas,monospace";
    ctx.textAlign = "center";
    ctx.fillText(dist + "m", ex, ey + (Math.sin(ang) > 0 ? -14 : 20));
  }
  // çerçeve + başlık + pusula + ölçek
  ctx.strokeStyle = "rgba(90,209,255,.45)";
  ctx.lineWidth = 1.4;
  rrp(mx, my, MW, MH, 10);
  ctx.stroke();
  ctx.fillStyle = "rgba(11,16,36,.85)";
  rrp(mx + MW / 2 - 11, my - 2, 22, 15, 6);
  ctx.fill();
  ctx.fillStyle = "#ff8c42";
  ctx.font = "800 10px 'Segoe UI',sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("K", mx + MW / 2, my + 9);
  ctx.textAlign = "left";
  ctx.fillStyle = "#8d9cc0";
  ctx.font = "800 9.5px ui-monospace,Consolas,monospace";
  ctx.fillText(T("HARİTA · ") + PLANETS[scene].name.toLocaleUpperCase("tr-TR"), mx + 2, my + MH + 16);
  const sb = Math.round(250 * sc);
  ctx.strokeStyle = "#cdd6f0";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(mx + MW - sb - 2, my + MH + 12);
  ctx.lineTo(mx + MW - 2, my + MH + 12);
  ctx.moveTo(mx + MW - sb - 2, my + MH + 9);
  ctx.lineTo(mx + MW - sb - 2, my + MH + 15);
  ctx.moveTo(mx + MW - 2, my + MH + 9);
  ctx.lineTo(mx + MW - 2, my + MH + 15);
  ctx.stroke();
  ctx.textAlign = "right";
  ctx.fillStyle = "#cdd6f0";
  ctx.fillText("25 m", mx + MW - sb - 6, my + MH + 16);
  ctx.restore();
}

/* ============== TOPRAK RADYASYONU · ÇÜRÜYEN HASAT · RADYASYON ÖLÇER ==============
   Mars toprağında radyoaktif mineral damarları var. Radyasyonu yüksek toprağa
   ekilen patatesler hasatta çürük çıkar. Oyuncu çürüyen hasadı Dünya'ya bildirir,
   numuneyi kapsülle yörüngedeki laboratuvara gönderir, analiz sonucunda
   radyasyon ölçeri (DZ-7) alır ve güvenli toprağı ölçerek bulur. */
const SOIL_SAFE = 1.0; // µSv/h altı güvenli
function _sh(ix, iy) {
  let h = (Math.imul(ix, 374761393) + Math.imul(iy, 668265263)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
function _vn(x, y, c) {
  const gx = x / c,
    gy = y / c,
    ix = Math.floor(gx),
    iy = Math.floor(gy),
    fx = gx - ix,
    fy = gy - iy,
    sx = fx * fx * (3 - 2 * fx),
    sy = fy * fy * (3 - 2 * fy);
  const a = _sh(ix, iy),
    b = _sh(ix + 1, iy),
    d = _sh(ix, iy + 1),
    e = _sh(ix + 1, iy + 1),
    t = a + (b - a) * sx;
  return t + (d + (e - d) * sx - t) * sy;
}
function soilRad01(x, y) {
  // her yere serpiştirilmiş: yeşil, sarı ve kırmızı noktalar iç içe (~%40 normal)
  let v = 0.62 * _vn(x, y, 90) + 0.38 * _vn(x + 5000, y - 3000, 38);
  v = (v - 0.5) * 2.2 + 0.43;
  return Math.max(0.02, Math.min(1, v));
}
const radUSv = (r) => 0.15 + r * 2.85;
function plotRadUSv(pl) {
  if (pl.rad == null) pl.rad = soilRad01(pl.x, pl.y);
  return radUSv(pl.rad);
}
function soilUSvAt(x, y) {
  const pl = farmArr().find((q) => Math.hypot(q.x - x, q.y - y) < 60);
  return pl ? plotRadUSv(pl) : radUSv(soilRad01(x, y));
}
const radLevel = (u) => (u < SOIL_SAFE ? 0 : u < 2 ? 1 : 2);
const RAD_LV = [
  ["NORMAL", "#4ade80", T("Ekim için uygun")],
  [T("DİKKAT"), "#fbbf24", T("Patates çürür")],
  [T("YÜKSEK"), "#ff5d5d", T("Patates çürür")],
];
const plotRots = (pl) => plotRadUSv(pl) >= SOIL_SAFE;

/* ---------- çürük hasat ---------- */
function harvestRot(pl) {
  game.inventory.rotten = (game.inventory.rotten || 0) + 1; // çürük yumrudan tohum çıkmaz
  burst(pl.x, pl.y, 26, "#4a3a22", { sp: 120, life: 0.9, size: 5, up: 50 });
  burst(pl.x, pl.y - 10, 14, "#7d8a3a", { sp: 50, life: 1.6, size: 3, up: 26 });
  addFloat(pl.x, pl.y - 38, T("Patatesler çürümüş!"), "#d6c08a");
  sfx("error");
  noiseBurst(0.3, 0.1, 520);
  tone(196, 0.35, "sawtooth", 0.05, 140, 0.05);
  shake = Math.max(shake, 2);
  const first = !(game.qstats.rotSeen > 0);
  storyTrigger("rot");
  bumpQuest("rotSeen");
  bumpQuest("harvested");
  commsObs("rot", { n: 1 });
  updateInv();
  if (first)
    setTimeout(
      () =>
        toast(
          T(
            "Patatesler çürük çıktı, bir tanesi çantanda. Roketteki <b>kargo terminalinden</b> Dünya'ya gönder, incelesinler.",
          ),
        ),
      900,
    );
  else
    toast(
      game.radLearned
        ? T("Bu toprak radyasyonlu, patatesler yine çürüdü. Ekmeden önce radyasyon ölçerle ölç")
        : T("Patatesler yine çürüdü"),
    );
  setTimeout(() => toast(T("🥀 Çürük yumrudan tohum çıkmaz — tohumu kaybettin")), first ? 4200 : 2600);
}

/* ---------- ölçüm ---------- */
let radM = null;
const cam = { z: 1, ox: 0, oy: 0 };
function startMeasure(wx, wy) {
  if (radM || !game) return;
  if (Math.hypot(wx - p.x, wy - p.y) > CFG.digRange) {
    sfx("error");
    toast(T("Çok uzak — ölçmek istediğin yere biraz yaklaş"));
    return;
  }
  if (Math.hypot(wx - ROCKET.x, wy - ROCKET.y) < 170) {
    sfx("error");
    toast(T("İniş platformu metal — ölçümü toprak üzerinde yap"));
    return;
  }
  const u = soilUSvAt(wx, wy);
  radM = { x: wx, y: wy, t: 0, T: 5.2, u, lv: radLevel(u), clk: 0.3, disp: 0, hist: [], done: false, cpm: 0 };
  p.dir = wx < p.x ? -1 : 1;
  tone(1200, 0.05, "square", 0.05);
  tone(1600, 0.07, "square", 0.04, 0, 0.08);
  tone(2100, 0.05, "sine", 0.04, 0, 0.16);
  radUIOpen();
}
function geigerClick() {
  noiseBurst(0.012, 0.26, 3600);
}
function updateMeasure(dt) {
  const m = radM;
  const want = m ? { z: 1.8, ox: (m.x - p.x) * 0.55, oy: (m.y - p.y) * 0.55 - 14 } : { z: 1, ox: 0, oy: 0 };
  const k = 1 - Math.exp(-dt * (m ? 3.6 : 4.5));
  if (!m) return;
  cam.z += (want.z - cam.z) * k;
  cam.ox += (want.ox - cam.ox) * k;
  cam.oy += (want.oy - cam.oy) * k;
  m.t += dt;
  const scan = Math.max(0, Math.min(1, (m.t - 0.8) / 2.7));
  m.scan = scan;
  if (m.t > 0.7 && m.t < m.T - 0.5) {
    const rate = 1.2 + m.u * 8.5 * (scan < 1 ? 0.35 + 0.65 * scan : 1);
    m.clk -= dt;
    while (m.clk <= 0) {
      m.clk += -Math.log(Math.random() + 1e-6) / rate;
      geigerClick();
      m.hist.push(m.t);
      const a = Math.random() * 6.283,
        r = Math.random() * 38;
      burst(
        m.x + Math.cos(a) * r,
        m.y + Math.sin(a) * r * 0.5,
        1,
        m.lv === 0 ? "#b8ffcf" : m.lv === 1 ? "#ffe08a" : "#ff9a8a",
        { sp: 14, life: 0.55, size: 2.6, up: 90 },
      );
    }
  }
  m.hist = m.hist.filter((h) => m.t - h < 3.2);
  const tgt = m.u * (scan < 1 ? 0.25 + 0.75 * scan : 1);
  m.disp += (tgt * (1 + (Math.random() - 0.5) * 0.5 * (1 - scan)) - m.disp) * Math.min(1, dt * 7);
  if (scan >= 1) m.disp += (m.u - m.disp) * Math.min(1, dt * 10);
  m.cpm = Math.round(m.disp * 148 + (scan < 1 ? (Math.random() - 0.5) * 12 : 0));
  if (scan >= 1 && !m.done) {
    m.done = true;
    m.disp = m.u;
    finishMeasure(m);
  }
  radUIUpdate(m);
  if (m.t >= m.T) {
    radM = null;
    radUIClose();
  }
}
function finishMeasure(m) {
  const L = RAD_LV[m.lv];
  if (!Array.isArray(game.radMarks)) game.radMarks = [];
  const near = game.radMarks.find((q) => Math.hypot(q.x - m.x, q.y - m.y) < 90);
  if (near) Object.assign(near, { x: m.x, y: m.y, u: m.u, t: game.worldTime });
  else {
    game.radMarks.push({ x: m.x, y: m.y, u: m.u, t: game.worldTime });
    if (game.radMarks.length > 24) game.radMarks.shift();
    bumpQuest("measured");
  }
  m.born = performance.now() / 1000;
  burst(m.x, m.y, 22, L[1], { sp: 130, life: 0.8, size: 4, up: 60 });
  if (m.lv === 0) {
    tone(880, 0.12, "sine", 0.08);
    tone(1320, 0.2, "sine", 0.07, 0, 0.12);
    tone(1760, 0.25, "triangle", 0.05, 0, 0.26);
  } else if (m.lv === 1) {
    tone(520, 0.14, "triangle", 0.07);
    tone(520, 0.14, "triangle", 0.07, 0, 0.22);
  } else [0, 0.16, 0.32].forEach((d) => tone(330, 0.12, "square", 0.06, 0, d));
  setTimeout(() => {
    if (!game) return;
    toast(
      m.lv === 0
        ? T("<b>Güvenli toprak</b> (") +
            fmtN(m.u, 2) +
            T(" µSv/h) — buraya kazıp patates ekebilirsin. Yeşil bayrak yeri işaretliyor.")
        : T("Bu toprakta patates çürür (") +
            fmtN(m.u, 2) +
            T(" µSv/h). <b>1,0 µSv/h altını</b> ara — biraz uzaklaşıp yeniden ölç."),
    );
  }, 700);
}
function unlockMeter() {
  if (!game || game.radLearned) return;
  game.radLearned = true;
  game.meterOwned = true;
  updateInv();
  bumpQuest("rotAnalysis");
  storyTrigger("rotLearn");
  sfx("star");
  setTimeout(
    () =>
      toast(T("Toprağı ölçmek için <b>radyasyon ölçeri</b> makine dairesindeki <b>alet sandığından</b> al.")),
    600,
  );
}

/* ---------- dünya çizimi: tarama efekti + ölçüm bayrakları ---------- */
function drawRadMarks(vis) {
  {
    const n = performance.now() / 1000;
    drawMarkFx(Math.min(0.05, n - (drawRadMarks._t || n)));
    drawRadMarks._t = n;
  }
  const M = game.radMarks;
  if (!Array.isArray(M) || !M.length) return;
  const t = performance.now() / 1000;
  for (const mk of M) {
    if (!vis(mk)) continue;
    const L = RAD_LV[radLevel(mk.u)],
      x = mk.x,
      y = mk.y;
    ctx.fillStyle = L[1] + "33";
    ctx.beginPath();
    ctx.ellipse(x, y, 26, 12, 0, 0, 7);
    ctx.fill();
    ctx.strokeStyle = L[1] + "99";
    ctx.lineWidth = 1.4;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.ellipse(x, y, 26, 12, 0, 0, 7);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = "rgba(0,0,0,.3)";
    ctx.beginPath();
    ctx.ellipse(x + 2, y + 1, 4, 2, 0, 0, 7);
    ctx.fill();
    ctx.strokeStyle = "#d7dce8";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x, y - 42);
    ctx.stroke();
    const w = Math.sin(t * 3 + x * 0.01) * 2.5;
    ctx.fillStyle = L[1];
    ctx.beginPath();
    ctx.moveTo(x + 1, y - 42);
    ctx.quadraticCurveTo(x + 10, y - 40 + w, x + 19, y - 36 + w * 0.6);
    ctx.quadraticCurveTo(x + 10, y - 32 + w, x + 1, y - 30);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#fff";
    ctx.beginPath();
    ctx.arc(x, y - 43, 2, 0, 7);
    ctx.fill();
    if (Math.hypot(p.x - x, p.y - y) < 300) {
      const s = fmtN(mk.u, 2) + " µSv/h";
      ctx.font = "700 11px ui-monospace,monospace";
      const tw = ctx.measureText(s).width;
      ctx.fillStyle = "rgba(8,10,18,.75)";
      rr(x - tw / 2 - 6, y - 64, tw + 12, 16, 5, "rgba(8,10,18,.75)");
      ctx.fillStyle = L[1];
      ctx.textAlign = "center";
      ctx.fillText(s, x, y - 52);
      ctx.textAlign = "left";
    }
  }
}
function drawRadScan() {
  const m = radM;
  if (!m) return;
  const t = performance.now() / 1000,
    x = m.x,
    y = m.y,
    sc = m.scan || 0;
  const col = m.done ? RAD_LV[m.lv][1] : "#7fe7ff";
  const intro = Math.min(1, m.t / 0.6),
    out = m.t > m.T - 0.6 ? Math.max(0, (m.T - m.t) / 0.6) : 1,
    A = intro * out;
  ctx.save();
  ctx.globalAlpha = A;
  // zemin ızgarası
  ctx.strokeStyle = col + "55";
  ctx.lineWidth = 1;
  for (let i = -3; i <= 3; i++) {
    ctx.beginPath();
    ctx.moveTo(x - 60, y + i * 8);
    ctx.lineTo(x + 60, y + i * 8);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x + i * 18, y - 26);
    ctx.lineTo(x + i * 18, y + 26);
    ctx.stroke();
  }
  // genişleyen halkalar
  for (let i = 0; i < 3; i++) {
    const ph = (t * 0.9 + i / 3) % 1;
    ctx.strokeStyle = col;
    ctx.globalAlpha = A * (1 - ph) * 0.8;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(x, y, 14 + ph * 70, (14 + ph * 70) * 0.48, 0, 0, 7);
    ctx.stroke();
  }
  ctx.globalAlpha = A;
  // radar süpürmesi
  if (!m.done) {
    const a0 = t * 4.2;
    ctx.fillStyle = col + "40";
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.ellipse(x, y, 64, 31, 0, a0, a0 + 0.7);
    ctx.closePath();
    ctx.fill();
  }
  // nişangah
  ctx.strokeStyle = col;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.ellipse(x, y, 64, 31, 0, 0, 7);
  ctx.stroke();
  for (const [dx, dy] of [
    [-1, 0],
    [1, 0],
    [0, -1],
    [0, 1],
  ]) {
    ctx.beginPath();
    ctx.moveTo(x + dx * 56, y + dy * 27);
    ctx.lineTo(x + dx * 72, y + dy * 35);
    ctx.stroke();
  }
  // ilerleme yayı
  ctx.lineWidth = 4;
  ctx.strokeStyle = col;
  ctx.beginPath();
  ctx.ellipse(x, y, 76, 37, 0, -Math.PI / 2, -Math.PI / 2 + sc * 6.283);
  ctx.stroke();
  // sonuç ışıması
  if (m.done) {
    const pu = 0.5 + 0.5 * Math.sin(t * 6);
    const g = ctx.createRadialGradient(x, y, 4, x, y, 70);
    g.addColorStop(0, col + "aa");
    g.addColorStop(1, col + "00");
    ctx.fillStyle = g;
    ctx.globalAlpha = A * (0.6 + 0.4 * pu);
    ctx.beginPath();
    ctx.ellipse(x, y, 70, 34, 0, 0, 7);
    ctx.fill();
    ctx.globalAlpha = A;
  }
  // cihazdan toprağa ışın
  const hx = p.x + p.dir * 24,
    hy = p.y - 16;
  const g2 = ctx.createLinearGradient(hx, hy, x, y);
  g2.addColorStop(0, col + "ee");
  g2.addColorStop(1, col + "22");
  ctx.strokeStyle = g2;
  ctx.lineWidth = 2.4;
  ctx.setLineDash([7, 6]);
  ctx.lineDashOffset = -t * 60;
  ctx.beginPath();
  ctx.moveTo(hx, hy);
  ctx.quadraticCurveTo((hx + x) / 2, Math.min(hy, y) - 30, x, y);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.arc(hx, hy, 3 + Math.sin(t * 12), 0, 7);
  ctx.fill();
  ctx.restore();
}

/* ---------- cihaz arayüzü (HTML) ---------- */
function radUIOpen() {
  const el = $("radUI");
  el.querySelector(".rd-scr").style.color = "";
  el.classList.remove("hidden", "rd-close", "lv0", "lv1", "lv2");
  void el.offsetWidth;
  el.classList.add("rd-open");
  $("rdSt").innerHTML = T("Prob toprağa hizalanıyor…");
  $("rdVal").textContent = fmtN(0, 2);
  $("rdCpm").textContent = "0 CPM";
  $("rdLoc").textContent = "X " + Math.round(radM.x / 8) + " · Y " + Math.round(-radM.y / 8);
  $("rdHist").innerHTML = Array.from({ length: 28 }, () => "<i></i>").join("");
}
function radUIUpdate(m) {
  const el = $("radUI");
  if (!el) return;
  const fr = Math.min(1, Math.max(0, m.disp) / 3);
  $("rdNeedle").setAttribute("transform", "rotate(" + (-135 + fr * 270).toFixed(1) + " 60 60)");
  $("rdArc").setAttribute("stroke-dasharray", (fr * 179.1).toFixed(1) + " 238.8");
  if (!m.done)
    $("radUI").querySelector(".rd-scr").style.color = ["#4ade80", "#fbbf24", "#ff5d5d"][radLevel(m.disp)];
  $("rdVal").textContent = fmtN(Math.max(0, m.disp), 2);
  $("rdMark").style.left = Math.min(1, Math.max(0, m.disp) / 3) * 100 + "%";
  {
    const lv = radLevel(m.disp);
    ["rdZ0", "rdZ1", "rdZ2"].forEach((id, i) => $(id).classList.toggle("on", i === lv));
  }
  $("rdCpm").textContent = Math.max(0, m.cpm) + " CPM";
  const bars = $("rdHist").children,
    N = bars.length;
  for (let i = 0; i < N; i++) {
    const t0 = m.t - (N - i) * 0.11,
      c = m.hist.filter((h) => h >= t0 && h < t0 + 0.11).length;
    bars[i].style.height = Math.min(100, 8 + c * 30) + "%";
  }
  $("rdLed").classList.toggle("on", m.hist.length && m.t - m.hist[m.hist.length - 1] < 0.06);
  if (!m.done) {
    const s = m.scan || 0;
    $("rdSt").innerHTML =
      s <= 0 ? T("Prob toprağa hizalanıyor…") : Tf(`Ölçülüyor… <b>%{0}</b>`, [Math.round(s * 100)]);
    $("rdBar").style.width = s * 100 + "%";
  } else if (!el.classList.contains("lv" + m.lv)) {
    const L = RAD_LV[m.lv];
    el.classList.add("lv" + m.lv);
    el.querySelector(".rd-scr").style.color = "";
    $("rdBar").style.width = "100%";
    $("rdSt").innerHTML = Tf(
      `<span class="rd-vd"><b>RADYASYON {0}</b><small>{1} µSv/h · {2}</small></span>`,
      [L[0], fmtN(m.u, 2), L[2]],
    );
  }
}
function radUIClose() {
  const el = $("radUI");
  el.classList.remove("rd-open");
  el.classList.add("rd-close");
  setTimeout(() => {
    if (!radM) el.classList.add("hidden");
  }, 420);
}

/* ---------- Dünya ile yazışma: numune talebi + laboratuvar raporu ---------- */
function rotAnalysisMsg(wt) {
  const C = commState(),
    no = "GK-" + pad3(C.seq.msg++);
  const body = Tf(
    `<p>Komutan,</p>
  <p>Gönderdiğin çürük patatesi inceledik. Mikrop ya da aşırı sulama izi yok. Neden <b>toprağın radyasyonu</b>: patatesin ekildiği yer yüksek radyasyonlu.</p>
  <div class="ltr-dir"><b>NE YAPMALI?</b><ol>
    <li>Roketteki alet sandığından <b>radyasyon ölçeri</b> al.</li>
    <li>Ekmeden önce toprağı ölç: ölçeri eline al ve toprağa <b>sol tıkla</b>.</li>
    <li>Ekranda <b>RADYASYON NORMAL</b> yazan yere ek. Yüksek çıkan yerde patates çürür.</li></ol></div>
  <div class="ltr-scale"><span style="flex:1;background:#4ade80">0 – 1,0 NORMAL</span><span style="flex:1;background:#fbbf24">1,0 – 2,0 DİKKAT</span><span style="flex:1;background:#ff5d5d">2,0+ YÜKSEK</span></div>`,
    [],
  );
  return {
    id: no,
    t: wt,
    kind: "lab",
    subject: T("Çürük patates analizi"),
    from: SIG.bio[0],
    read: false,
    html: letter({ no, wt, subject: T("Çürük patates analizi"), body, signers: ["bio"], cc: ["fd"] }),
  };
}
function sendRotCargo() {
  const C = commState();
  if (C.flags.capsAt && !C.flags.ana) {
    sfx("error");
    toast(T("Önceki kargo hâlâ inceleniyor — Dünya'nın cevabını bekle"));
    return;
  }
  if ((game.inventory.rotten || 0) < 1) {
    sfx("error");
    toast(T("Çantanda çürük patates yok"));
    return;
  }
  game.inventory.rotten--;
  updateInv();
  C.flags.capsAt = game.worldTime;
  C.flags.ana = false;
  C.flags.anaAt = game.worldTime + DAY_SECONDS * 0.05;
  bumpQuest("rotSample");
  tone(523, 0.1, "triangle", 0.07);
  tone(784, 0.14, "triangle", 0.07, 0, 0.1);
  noiseBurst(0.4, 0.08, 1400, 0.15);
  toast(T("Çürük patates kargoyla Dünya'ya gönderildi. Cevap birazdan gelen kutunda."));
  if (marketOpen) openMarket();
}
/* ============== ÇİZİM ============== */
function draw() {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  if (mode !== "play") {
    ctx.clearRect(0, 0, W, H);
    return;
  }
  if (insideRocket) {
    ctx.save();
    if (shake > 0)
      ctx.translate((Math.random() - 0.5) * shake * SHK(), (Math.random() - 0.5) * shake * SHK());
    drawInterior();
    ctx.restore();
    drawSleepOverlay();
    drawWakeOverlay();
    if (fly) drawFlyOverlay();
    return;
  }
  const S = PLANETS[scene],
    z = ((CFG.zoom * Math.min(W, H)) / 700) * cam.z;
  const vr = Math.hypot(W, H) / 2 / z + 140;
  const vis = (o) => Math.abs(o.x - p.x - cam.ox) < vr && Math.abs(o.y - p.y - cam.oy) < vr;

  ctx.save();
  if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * SHK(), (Math.random() - 0.5) * shake * SHK());

  // zemin + ışıklandırma her zaman ekranı doldurur (kamera oyuncuyu izler)
  ctx.fillStyle = S.ground;
  ctx.fillRect(0, 0, W, H);
  const lg = ctx.createRadialGradient(
    W / 2,
    H / 2,
    Math.min(W, H) * 0.08,
    W / 2,
    H / 2,
    Math.max(W, H) * 0.72,
  );
  lg.addColorStop(0, "rgba(255,255,255,.12)");
  lg.addColorStop(1, "rgba(0,0,0,.36)");
  ctx.fillStyle = lg;
  ctx.fillRect(0, 0, W, H);

  ctx.save();
  ctx.translate(W / 2, H / 2);
  ctx.scale(z, z);
  ctx.translate(-p.x - cam.ox, -p.y - cam.oy);

  // hafif yıldız (havasız gövdeler)
  if (S.air) {
    ctx.fillStyle = "rgba(255,255,255,.28)";
    for (let i = 0; i < 60; i++) {
      const sx = p.x + ((i * 97) % 2000) - 1000,
        sy = p.y + ((i * 173) % 1600) - 800;
      ctx.fillRect(sx, sy, 1.6, 1.6);
    }
  }
  ctx.strokeStyle = S.dot;
  ctx.fillStyle = S.dot;
  ctx.lineWidth = 3;
  drawLandmarks(vis);
  for (const c of decor[scene]) {
    if (vis(c)) drawDecor(c);
  }
  drawGroundDrift();
  drawCraters(vis);

  ctx.strokeStyle = "rgba(255,255,255,.5)";
  ctx.lineWidth = 10;
  const B = CFG.worldHalf + 50;
  ctx.strokeRect(-B, -B, B * 2, B * 2);

  const fa = farmArr();
  fa.forEach((pl, i) => {
    if (vis(pl)) drawPlot(pl, fa[i]);
  });
  drawRadMarks(vis);
  drawRadScan();
  for (const st of stones) if (!st.taken && vis(st)) drawStone(st);
  for (const d of drops) if (!d.taken && vis(d)) drawDrop(d);
  {
    const tt = performance.now() / 1000;
    for (const n of rareNodes) if ((!n.taken || (n.fadeEnd && n.fadeEnd > tt)) && vis(n)) drawRare(n, tt);
    for (const n of rareNodes) if (n.split && vis(n)) drawRareCore(n, tt);
    drawDevils(tt);
  }
  for (const m of ev.meteors) if (vis(m)) drawMeteor(m);

  drawRocket(ROCKET.x, ROCKET.y);
  drawParticles();
  drawAstroGrav(p.x, p.y, p.z || 0, p._running, heldItemKey(), p.actionT);
  drawMeteorSky();
  ctx.restore();

  // atmosfer tonlaması
  ctx.fillStyle = S.atmo;
  ctx.fillRect(0, 0, W, H);
  drawAtmosphere();
  drawWeather();
  if (mflash > 0) {
    ctx.fillStyle = "rgba(255,240,215," + Math.min(0.8, mflash) * (settings.noflash ? 0.25 : 1) + ")";
    ctx.fillRect(0, 0, W, H);
  }
  if (game.o2 < 25 && scene !== "earth") {
    // düşük oksijen: kararan, nefes gibi atan kenarlar
    const q = 1 - game.o2 / 25,
      pu = 0.5 + 0.5 * Math.sin(performance.now() / (game.o2 <= 0 ? 160 : 380));
    const og = ctx.createRadialGradient(
      W / 2,
      H / 2,
      Math.min(W, H) * (0.38 - 0.18 * q),
      W / 2,
      H / 2,
      Math.max(W, H) * 0.75,
    );
    og.addColorStop(0, "rgba(0,20,40,0)");
    og.addColorStop(1, "rgba(0,18,40," + Math.min(0.85, (0.35 + 0.35 * pu) * q) + ")");
    ctx.fillStyle = og;
    ctx.fillRect(0, 0, W, H);
  }
  if (game.radiationActive && !insideRocket) {
    // radyasyon: yeşil ekran + kenarlarda yoğun ışıma + parazit
    const tt = performance.now() / 1000,
      pulse = 0.5 + 0.5 * Math.sin(tt * 4);
    ctx.fillStyle = "rgba(70,210,70," + (0.13 + 0.05 * pulse) + ")";
    ctx.fillRect(0, 0, W, H);
    const rg = ctx.createRadialGradient(
      W / 2,
      H / 2,
      Math.min(W, H) * 0.3,
      W / 2,
      H / 2,
      Math.max(W, H) * 0.75,
    );
    rg.addColorStop(0, "rgba(120,255,90,0)");
    rg.addColorStop(1, "rgba(60,200,40," + (0.38 + 0.14 * pulse) + ")");
    ctx.fillStyle = rg;
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = "rgba(190,255,160,.35)";
    for (let i = 0; i < 70; i++) {
      ctx.fillRect(Math.random() * W, Math.random() * H, 1.6, 1.6);
    }
    ctx.fillStyle = "rgba(170,255,140,.06)";
    const sy = (tt * 120) % H;
    ctx.fillRect(0, sy, W, 3);
  }

  // vinyet
  const vg = ctx.createRadialGradient(
    W / 2,
    H / 2,
    Math.min(W, H) * 0.34,
    W / 2,
    H / 2,
    Math.max(W, H) * 0.78,
  );
  vg.addColorStop(0, "rgba(0,0,0,0)");
  vg.addColorStop(1, "rgba(0,0,0,.46)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, W, H);
  drawStoryArrow(z);
  drawQuestRocketMark(z);
  if (cam.z > 1.02) {
    const q = Math.min(1, (cam.z - 1) / 0.8);
    const sg = ctx.createRadialGradient(
      W / 2,
      H / 2,
      Math.min(W, H) * 0.22,
      W / 2,
      H / 2,
      Math.max(W, H) * 0.7,
    );
    sg.addColorStop(0, "rgba(0,0,0,0)");
    sg.addColorStop(1, "rgba(0,8,14," + 0.55 * q + ")");
    ctx.fillStyle = sg;
    ctx.fillRect(0, 0, W, H);
  }

  // düşük can uyarısı
  if (game.hp < 35) {
    const a = (0.16 + 0.12 * Math.sin(performance.now() / 300)) * (1 - game.hp / 35);
    const rg = ctx.createRadialGradient(
      W / 2,
      H / 2,
      Math.min(W, H) * 0.25,
      W / 2,
      H / 2,
      Math.max(W, H) * 0.7,
    );
    rg.addColorStop(0, "rgba(255,0,0,0)");
    rg.addColorStop(1, "rgba(255,40,40," + Math.min(0.6, a) + ")");
    ctx.fillStyle = rg;
    ctx.fillRect(0, 0, W, H);
  }
  // hasar flaşı
  if (flash > 0) {
    ctx.fillStyle = "rgba(255,60,60," + flash * 0.4 * (settings.noflash ? 0.35 : 1) + ")";
    ctx.fillRect(0, 0, W, H);
  }

  ctx.restore(); // shake

  drawMap();

  // gezegen geçiş efekti
  if (warp > 0) {
    const a = Math.min(1, warp * 1.5);
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255," + a * 0.9 + ")";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    for (let i = 0; i < 54; i++) {
      const ang = (i / 54) * 6.283 + (1 - warp) * 2;
      const r1 = Math.hypot(W, H) * 0.55 * (1.05 - warp * 0.85),
        r0 = r1 * 0.45;
      ctx.beginPath();
      ctx.moveTo(W / 2 + Math.cos(ang) * r0, H / 2 + Math.sin(ang) * r0);
      ctx.lineTo(W / 2 + Math.cos(ang) * r1, H / 2 + Math.sin(ang) * r1);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(215,240,255," + a * 0.55 + ")";
    ctx.fillRect(0, 0, W, H);
    ctx.restore();
  }

  // roket yolculuk animasyonu (her şeyin üstünde)
  if (fly) drawFlyOverlay();
}

/* ============== DÖNGÜ ============== */
let last = performance.now(),
  lastDraw = 0,
  acc = 0;
function loop(now) {
  requestAnimationFrame(loop);
  const interval = 1000 / Math.max(20, settings.fps || 60);
  let dt = (now - last) / 1000;
  last = now;
  if (dt > 0.25) dt = 0.25;
  acc += dt;
  if (now - lastDraw < interval - 1) return;
  lastDraw = now;
  const step = Math.min(acc, 0.05);
  acc = 0;
  if (mode === "menu") {
    drawMenuBg();
    return;
  }
  if (mode === "intro") {
    updateIntro(step);
    drawIntro();
    return;
  }
  syncLooks();
  if (mode === "play") {
    if (fly) updateFly(step);
    else if (!paused && !bookOpen) {
      updateStory(step);
      update(step * storySlow());
    } // kitap açıkken zaman durur
    draw();
  }
}
resize();
refreshContinueButton();
applySettingsToUI();
requestAnimationFrame(loop);
