# SOL ZERO

Mars'ta hayatta kalma oyunu (2D, HTML5 Canvas). Kurulum gerektirmez.

## Klasör yapısı

```
sol-zero/
├── index.html          → sayfa iskeleti ve arayüz (menüler, paneller)
├── css/style.css       → tüm stiller
├── js/ceviriler.js     → İngilizce / Almanca / İspanyolca çeviri verisi
└── js/oyun.js          → oyunun tüm kodu
```

`ceviriler.js` dosyası `oyun.js`'ten **önce** yüklenmelidir (index.html'de bu sırayla duruyor).

## Visual Studio Code'da çalıştırma

1. VS Code'da **Dosya → Klasör Aç** ile `sol-zero` klasörünü açın.
2. Önerilen **Live Server** eklentisini kurun (VS Code sağ altta önerir).
3. `index.html` dosyasına sağ tıklayın → **Open with Live Server**.

Eklenti olmadan da çalışır: `index.html` dosyasına çift tıklayıp tarayıcıda açmanız yeterli.

## Not

`index.html` otomatik biçimlendirmeye kapatıldı (`.vscode/settings.json`, `.prettierignore`).
Sayfadaki yazılar çeviri sisteminde birebir eşleştirildiği için satırların bölünmesi
diğer dillerdeki çeviriyi bozar. CSS ve JS dosyaları Prettier ile güvenle biçimlendirilebilir.

Kayıtlar ve ayarlar tarayıcının yerel deposunda (localStorage) tutulur.
